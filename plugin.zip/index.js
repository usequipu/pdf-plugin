var Q0 = Object.defineProperty;
var Dg = (d) => {
  throw TypeError(d);
};
var ty = (d, t, e) => t in d ? Q0(d, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : d[t] = e;
var L = (d, t, e) => ty(d, typeof t != "symbol" ? t + "" : t, e), Tf = (d, t, e) => t.has(d) || Dg("Cannot " + e);
var n = (d, t, e) => (Tf(d, t, "read from private field"), e ? e.call(d) : t.get(d)), g = (d, t, e) => t.has(d) ? Dg("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(d) : t.set(d, e), p = (d, t, e, s) => (Tf(d, t, "write to private field"), s ? s.call(d, e) : t.set(d, e), e), b = (d, t, e) => (Tf(d, t, "access private method"), e);
var oe = (d, t, e, s) => ({
  set _(i) {
    p(d, t, i, e);
  },
  get _() {
    return n(d, t, s);
  }
});
import { jsx as K, jsxs as le } from "react/jsx-runtime";
import * as I from "react";
import { createContext as cg, useReducer as ey, forwardRef as sy, useRef as ii, useImperativeHandle as iy, useEffect as wt, useCallback as Se, useMemo as We, useContext as wm, useLayoutEffect as ny, useState as Te } from "react";
const ss = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser"), Bf = [1e-3, 0, 0, 1e-3, 0, 0], xf = 1.35, Os = {
  ANY: 1,
  DISPLAY: 2,
  PRINT: 4,
  ANNOTATIONS_FORMS: 16,
  ANNOTATIONS_STORAGE: 32,
  ANNOTATIONS_DISABLE: 64,
  IS_EDITING: 128,
  OPLIST: 256
}, Zi = {
  DISABLE: 0,
  ENABLE: 1,
  ENABLE_FORMS: 2,
  ENABLE_STORAGE: 3
}, Gh = "pdfjs_internal_editor_", Z = {
  DISABLE: -1,
  NONE: 0,
  FREETEXT: 3,
  HIGHLIGHT: 9,
  STAMP: 13,
  INK: 15,
  POPUP: 16,
  SIGNATURE: 101,
  COMMENT: 102
}, ht = {
  RESIZE: 1,
  CREATE: 2,
  FREETEXT_SIZE: 11,
  FREETEXT_COLOR: 12,
  FREETEXT_OPACITY: 13,
  INK_COLOR: 21,
  INK_THICKNESS: 22,
  INK_OPACITY: 23,
  HIGHLIGHT_COLOR: 31,
  HIGHLIGHT_THICKNESS: 32,
  HIGHLIGHT_FREE: 33,
  HIGHLIGHT_SHOW_ALL: 34,
  DRAW_STEP: 41
}, vm = {
  PRINT: 4,
  MODIFY_CONTENTS: 8,
  COPY: 16,
  MODIFY_ANNOTATIONS: 32,
  FILL_INTERACTIVE_FORMS: 256,
  COPY_FOR_ACCESSIBILITY: 512,
  ASSEMBLE: 1024,
  PRINT_HIGH_QUALITY: 2048
}, xe = {
  FILL: 0,
  STROKE: 1,
  FILL_STROKE: 2,
  INVISIBLE: 3,
  FILL_STROKE_MASK: 3,
  ADD_TO_PATH_FLAG: 4
}, zh = {
  GRAYSCALE_1BPP: 1,
  RGB_24BPP: 2,
  RGBA_32BPP: 3
}, te = {
  TEXT: 1,
  LINK: 2,
  FREETEXT: 3,
  LINE: 4,
  SQUARE: 5,
  CIRCLE: 6,
  POLYGON: 7,
  POLYLINE: 8,
  HIGHLIGHT: 9,
  UNDERLINE: 10,
  SQUIGGLY: 11,
  STRIKEOUT: 12,
  STAMP: 13,
  CARET: 14,
  INK: 15,
  POPUP: 16,
  FILEATTACHMENT: 17,
  SOUND: 18,
  MOVIE: 19,
  WIDGET: 20,
  SCREEN: 21,
  PRINTERMARK: 22,
  TRAPNET: 23,
  WATERMARK: 24,
  THREED: 25,
  REDACT: 26
}, So = {
  SOLID: 1,
  DASHED: 2,
  BEVELED: 3,
  INSET: 4,
  UNDERLINE: 5
}, Dd = {
  ERRORS: 0,
  WARNINGS: 1,
  INFOS: 5
}, dh = {
  dependency: 1,
  setLineWidth: 2,
  setLineCap: 3,
  setLineJoin: 4,
  setMiterLimit: 5,
  setDash: 6,
  setRenderingIntent: 7,
  setFlatness: 8,
  setGState: 9,
  save: 10,
  restore: 11,
  transform: 12,
  moveTo: 13,
  lineTo: 14,
  curveTo: 15,
  curveTo2: 16,
  curveTo3: 17,
  closePath: 18,
  rectangle: 19,
  stroke: 20,
  closeStroke: 21,
  fill: 22,
  eoFill: 23,
  fillStroke: 24,
  eoFillStroke: 25,
  closeFillStroke: 26,
  closeEOFillStroke: 27,
  endPath: 28,
  clip: 29,
  eoClip: 30,
  beginText: 31,
  endText: 32,
  setCharSpacing: 33,
  setWordSpacing: 34,
  setHScale: 35,
  setLeading: 36,
  setFont: 37,
  setTextRenderingMode: 38,
  setTextRise: 39,
  moveText: 40,
  setLeadingMoveText: 41,
  setTextMatrix: 42,
  nextLine: 43,
  showText: 44,
  showSpacedText: 45,
  nextLineShowText: 46,
  nextLineSetSpacingShowText: 47,
  setCharWidth: 48,
  setCharWidthAndBounds: 49,
  setStrokeColorSpace: 50,
  setFillColorSpace: 51,
  setStrokeColor: 52,
  setStrokeColorN: 53,
  setFillColor: 54,
  setFillColorN: 55,
  setStrokeGray: 56,
  setFillGray: 57,
  setStrokeRGBColor: 58,
  setFillRGBColor: 59,
  setStrokeCMYKColor: 60,
  setFillCMYKColor: 61,
  shadingFill: 62,
  beginInlineImage: 63,
  beginImageData: 64,
  endInlineImage: 65,
  paintXObject: 66,
  markPoint: 67,
  markPointProps: 68,
  beginMarkedContent: 69,
  beginMarkedContentProps: 70,
  endMarkedContent: 71,
  beginCompat: 72,
  endCompat: 73,
  paintFormXObjectBegin: 74,
  paintFormXObjectEnd: 75,
  beginGroup: 76,
  endGroup: 77,
  beginAnnotation: 80,
  endAnnotation: 81,
  paintImageMaskXObject: 83,
  paintImageMaskXObjectGroup: 84,
  paintImageXObject: 85,
  paintInlineImageXObject: 86,
  paintInlineImageXObjectGroup: 87,
  paintImageXObjectRepeat: 88,
  paintImageMaskXObjectRepeat: 89,
  paintSolidColorImageMask: 90,
  constructPath: 91,
  setStrokeTransparent: 92,
  setFillTransparent: 93,
  rawFillPath: 94
}, Wd = {
  moveTo: 0,
  lineTo: 1,
  curveTo: 2,
  closePath: 3
}, Em = {
  NEED_PASSWORD: 1,
  INCORRECT_PASSWORD: 2
};
let uf = Dd.WARNINGS;
function ry(d) {
  Number.isInteger(d) && (uf = d);
}
function ay() {
  return uf;
}
function ff(d) {
  uf >= Dd.INFOS && console.info(`Info: ${d}`);
}
function J(d) {
  uf >= Dd.WARNINGS && console.warn(`Warning: ${d}`);
}
function Dt(d) {
  throw new Error(d);
}
function dt(d, t) {
  d || Dt(t);
}
function oy(d) {
  switch (d == null ? void 0 : d.protocol) {
    case "http:":
    case "https:":
    case "ftp:":
    case "mailto:":
    case "tel:":
      return !0;
    default:
      return !1;
  }
}
function dg(d, t = null, e = null) {
  if (!d)
    return null;
  if (e && typeof d == "string") {
    if (e.addDefaultProtocol && d.startsWith("www.")) {
      const i = d.match(/\./g);
      (i == null ? void 0 : i.length) >= 2 && (d = `http://${d}`);
    }
    if (e.tryConvertEncoding)
      try {
        d = uy(d);
      } catch {
      }
  }
  const s = t ? URL.parse(d, t) : URL.parse(d);
  return oy(s) ? s : null;
}
function ug(d, t, e = !1) {
  const s = URL.parse(d);
  return s ? (s.hash = t, s.href) : e && dg(d, "http://example.com") ? d.split("#", 1)[0] + `${t ? `#${t}` : ""}` : "";
}
function it(d, t, e, s = !1) {
  return Object.defineProperty(d, t, {
    value: e,
    enumerable: !s,
    configurable: !0,
    writable: !1
  }), e;
}
const wo = (function() {
  function t(e, s) {
    this.message = e, this.name = s;
  }
  return t.prototype = new Error(), t.constructor = t, t;
})();
class Ig extends wo {
  constructor(t, e) {
    super(t, "PasswordException"), this.code = e;
  }
}
class Pf extends wo {
  constructor(t, e) {
    super(t, "UnknownErrorException"), this.details = e;
  }
}
class Iu extends wo {
  constructor(t) {
    super(t, "InvalidPDFException");
  }
}
class jh extends wo {
  constructor(t, e, s) {
    super(t, "ResponseException"), this.status = e, this.missing = s;
  }
}
class ly extends wo {
  constructor(t) {
    super(t, "FormatError");
  }
}
class Gn extends wo {
  constructor(t) {
    super(t, "AbortException");
  }
}
function Sm(d) {
  (typeof d != "object" || (d == null ? void 0 : d.length) === void 0) && Dt("Invalid argument for bytesToString");
  const t = d.length, e = 8192;
  if (t < e)
    return String.fromCharCode.apply(null, d);
  const s = [];
  for (let i = 0; i < t; i += e) {
    const r = Math.min(i + e, t), a = d.subarray(i, r);
    s.push(String.fromCharCode.apply(null, a));
  }
  return s.join("");
}
function Id(d) {
  typeof d != "string" && Dt("Invalid argument for stringToBytes");
  const t = d.length, e = new Uint8Array(t);
  for (let s = 0; s < t; ++s)
    e[s] = d.charCodeAt(s) & 255;
  return e;
}
function hy(d) {
  return String.fromCharCode(d >> 24 & 255, d >> 16 & 255, d >> 8 & 255, d & 255);
}
function cy() {
  const d = new Uint8Array(4);
  return d[0] = 1, new Uint32Array(d.buffer, 0, 1)[0] === 1;
}
function dy() {
  try {
    return new Function(""), !0;
  } catch {
    return !1;
  }
}
class _e {
  static get isLittleEndian() {
    return it(this, "isLittleEndian", cy());
  }
  static get isEvalSupported() {
    return it(this, "isEvalSupported", dy());
  }
  static get isOffscreenCanvasSupported() {
    return it(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
  }
  static get isImageDecoderSupported() {
    return it(this, "isImageDecoderSupported", typeof ImageDecoder < "u");
  }
  static get platform() {
    const {
      platform: t,
      userAgent: e
    } = navigator;
    return it(this, "platform", {
      isAndroid: e.includes("Android"),
      isLinux: t.includes("Linux"),
      isMac: t.includes("Mac"),
      isWindows: t.includes("Win"),
      isFirefox: e.includes("Firefox")
    });
  }
  static get isCSSRoundSupported() {
    var t, e;
    return it(this, "isCSSRoundSupported", (e = (t = globalThis.CSS) == null ? void 0 : t.supports) == null ? void 0 : e.call(t, "width: round(1.5px, 1px)"));
  }
}
const Rf = Array.from(Array(256).keys(), (d) => d.toString(16).padStart(2, "0"));
var Vn, su, Hf;
class V {
  static makeHexColor(t, e, s) {
    return `#${Rf[t]}${Rf[e]}${Rf[s]}`;
  }
  static domMatrixToTransform(t) {
    return [t.a, t.b, t.c, t.d, t.e, t.f];
  }
  static scaleMinMax(t, e) {
    let s;
    t[0] ? (t[0] < 0 && (s = e[0], e[0] = e[2], e[2] = s), e[0] *= t[0], e[2] *= t[0], t[3] < 0 && (s = e[1], e[1] = e[3], e[3] = s), e[1] *= t[3], e[3] *= t[3]) : (s = e[0], e[0] = e[1], e[1] = s, s = e[2], e[2] = e[3], e[3] = s, t[1] < 0 && (s = e[1], e[1] = e[3], e[3] = s), e[1] *= t[1], e[3] *= t[1], t[2] < 0 && (s = e[0], e[0] = e[2], e[2] = s), e[0] *= t[2], e[2] *= t[2]), e[0] += t[4], e[1] += t[5], e[2] += t[4], e[3] += t[5];
  }
  static transform(t, e) {
    return [t[0] * e[0] + t[2] * e[1], t[1] * e[0] + t[3] * e[1], t[0] * e[2] + t[2] * e[3], t[1] * e[2] + t[3] * e[3], t[0] * e[4] + t[2] * e[5] + t[4], t[1] * e[4] + t[3] * e[5] + t[5]];
  }
  static multiplyByDOMMatrix(t, e) {
    return [t[0] * e.a + t[2] * e.b, t[1] * e.a + t[3] * e.b, t[0] * e.c + t[2] * e.d, t[1] * e.c + t[3] * e.d, t[0] * e.e + t[2] * e.f + t[4], t[1] * e.e + t[3] * e.f + t[5]];
  }
  static applyTransform(t, e, s = 0) {
    const i = t[s], r = t[s + 1];
    t[s] = i * e[0] + r * e[2] + e[4], t[s + 1] = i * e[1] + r * e[3] + e[5];
  }
  static applyTransformToBezier(t, e, s = 0) {
    const i = e[0], r = e[1], a = e[2], o = e[3], l = e[4], h = e[5];
    for (let c = 0; c < 6; c += 2) {
      const u = t[s + c], f = t[s + c + 1];
      t[s + c] = u * i + f * a + l, t[s + c + 1] = u * r + f * o + h;
    }
  }
  static applyInverseTransform(t, e) {
    const s = t[0], i = t[1], r = e[0] * e[3] - e[1] * e[2];
    t[0] = (s * e[3] - i * e[2] + e[2] * e[5] - e[4] * e[3]) / r, t[1] = (-s * e[1] + i * e[0] + e[4] * e[1] - e[5] * e[0]) / r;
  }
  static axialAlignedBoundingBox(t, e, s) {
    const i = e[0], r = e[1], a = e[2], o = e[3], l = e[4], h = e[5], c = t[0], u = t[1], f = t[2], m = t[3];
    let A = i * c + l, y = A, v = i * f + l, w = v, S = o * u + h, E = S, _ = o * m + h, C = _;
    if (r !== 0 || a !== 0) {
      const T = r * c, x = r * f, R = a * u, M = a * m;
      A += R, w += R, v += M, y += M, S += T, C += T, _ += x, E += x;
    }
    s[0] = Math.min(s[0], A, v, y, w), s[1] = Math.min(s[1], S, _, E, C), s[2] = Math.max(s[2], A, v, y, w), s[3] = Math.max(s[3], S, _, E, C);
  }
  static inverseTransform(t) {
    const e = t[0] * t[3] - t[1] * t[2];
    return [t[3] / e, -t[1] / e, -t[2] / e, t[0] / e, (t[2] * t[5] - t[4] * t[3]) / e, (t[4] * t[1] - t[5] * t[0]) / e];
  }
  static singularValueDecompose2dScale(t, e) {
    const s = t[0], i = t[1], r = t[2], a = t[3], o = s ** 2 + i ** 2, l = s * r + i * a, h = r ** 2 + a ** 2, c = (o + h) / 2, u = Math.sqrt(c ** 2 - (o * h - l ** 2));
    e[0] = Math.sqrt(c + u || 1), e[1] = Math.sqrt(c - u || 1);
  }
  static normalizeRect(t) {
    const e = t.slice(0);
    return t[0] > t[2] && (e[0] = t[2], e[2] = t[0]), t[1] > t[3] && (e[1] = t[3], e[3] = t[1]), e;
  }
  static intersect(t, e) {
    const s = Math.max(Math.min(t[0], t[2]), Math.min(e[0], e[2])), i = Math.min(Math.max(t[0], t[2]), Math.max(e[0], e[2]));
    if (s > i)
      return null;
    const r = Math.max(Math.min(t[1], t[3]), Math.min(e[1], e[3])), a = Math.min(Math.max(t[1], t[3]), Math.max(e[1], e[3]));
    return r > a ? null : [s, r, i, a];
  }
  static pointBoundingBox(t, e, s) {
    s[0] = Math.min(s[0], t), s[1] = Math.min(s[1], e), s[2] = Math.max(s[2], t), s[3] = Math.max(s[3], e);
  }
  static rectBoundingBox(t, e, s, i, r) {
    r[0] = Math.min(r[0], t, s), r[1] = Math.min(r[1], e, i), r[2] = Math.max(r[2], t, s), r[3] = Math.max(r[3], e, i);
  }
  static bezierBoundingBox(t, e, s, i, r, a, o, l, h) {
    h[0] = Math.min(h[0], t, o), h[1] = Math.min(h[1], e, l), h[2] = Math.max(h[2], t, o), h[3] = Math.max(h[3], e, l), b(this, Vn, Hf).call(this, t, s, r, o, e, i, a, l, 3 * (-t + 3 * (s - r) + o), 6 * (t - 2 * s + r), 3 * (s - t), h), b(this, Vn, Hf).call(this, t, s, r, o, e, i, a, l, 3 * (-e + 3 * (i - a) + l), 6 * (e - 2 * i + a), 3 * (i - e), h);
  }
}
Vn = new WeakSet(), su = function(t, e, s, i, r, a, o, l, h, c) {
  if (h <= 0 || h >= 1)
    return;
  const u = 1 - h, f = h * h, m = f * h, A = u * (u * (u * t + 3 * h * e) + 3 * f * s) + m * i, y = u * (u * (u * r + 3 * h * a) + 3 * f * o) + m * l;
  c[0] = Math.min(c[0], A), c[1] = Math.min(c[1], y), c[2] = Math.max(c[2], A), c[3] = Math.max(c[3], y);
}, Hf = function(t, e, s, i, r, a, o, l, h, c, u, f) {
  if (Math.abs(h) < 1e-12) {
    Math.abs(c) >= 1e-12 && b(this, Vn, su).call(this, t, e, s, i, r, a, o, l, -u / c, f);
    return;
  }
  const m = c ** 2 - 4 * u * h;
  if (m < 0)
    return;
  const A = Math.sqrt(m), y = 2 * h;
  b(this, Vn, su).call(this, t, e, s, i, r, a, o, l, (-c + A) / y, f), b(this, Vn, su).call(this, t, e, s, i, r, a, o, l, (-c - A) / y, f);
}, g(V, Vn);
function uy(d) {
  return decodeURIComponent(escape(d));
}
let Mf = null, Fg = null;
function _m(d) {
  return Mf || (Mf = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc-\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa-\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, Fg = /* @__PURE__ */ new Map([["ﬅ", "ſt"]])), d.replaceAll(Mf, (t, e, s) => e ? e.normalize("NFKC") : Fg.get(s));
}
function fg() {
  if (typeof crypto.randomUUID == "function")
    return crypto.randomUUID();
  const d = new Uint8Array(32);
  return crypto.getRandomValues(d), Sm(d);
}
const pg = "pdfjs_internal_id_";
function fy(d, t, e) {
  if (!Array.isArray(e) || e.length < 2)
    return !1;
  const [s, i, ...r] = e;
  if (!d(s) && !Number.isInteger(s) || !t(i))
    return !1;
  const a = r.length;
  let o = !0;
  switch (i.name) {
    case "XYZ":
      if (a < 2 || a > 3)
        return !1;
      break;
    case "Fit":
    case "FitB":
      return a === 0;
    case "FitH":
    case "FitBH":
    case "FitV":
    case "FitBV":
      if (a > 1)
        return !1;
      break;
    case "FitR":
      if (a !== 4)
        return !1;
      o = !1;
      break;
    default:
      return !1;
  }
  for (const l of r)
    if (!(typeof l == "number" || o && l === null))
      return !1;
  return !0;
}
function je(d, t, e) {
  return Math.min(Math.max(d, t), e);
}
function Cm(d) {
  return Uint8Array.prototype.toBase64 ? d.toBase64() : btoa(Sm(d));
}
function py(d) {
  return Uint8Array.fromBase64 ? Uint8Array.fromBase64(d) : Id(atob(d));
}
typeof Promise.try != "function" && (Promise.try = function(d, ...t) {
  return new Promise((e) => {
    e(d(...t));
  });
});
typeof Math.sumPrecise != "function" && (Math.sumPrecise = function(d) {
  return d.reduce((t, e) => t + e, 0);
});
class Wh {
  static textContent(t) {
    const e = [], s = {
      items: e,
      styles: /* @__PURE__ */ Object.create(null)
    };
    function i(r) {
      var l;
      if (!r)
        return;
      let a = null;
      const o = r.name;
      if (o === "#text")
        a = r.value;
      else if (Wh.shouldBuildText(o))
        (l = r == null ? void 0 : r.attributes) != null && l.textContent ? a = r.attributes.textContent : r.value && (a = r.value);
      else return;
      if (a !== null && e.push({
        str: a
      }), !!r.children)
        for (const h of r.children)
          i(h);
    }
    return i(t), s;
  }
  static shouldBuildText(t) {
    return !(t === "textarea" || t === "input" || t === "option" || t === "select");
  }
}
class gg {
  static setupStorage(t, e, s, i, r) {
    const a = i.getValue(e, {
      value: null
    });
    switch (s.name) {
      case "textarea":
        if (a.value !== null && (t.textContent = a.value), r === "print")
          break;
        t.addEventListener("input", (o) => {
          i.setValue(e, {
            value: o.target.value
          });
        });
        break;
      case "input":
        if (s.attributes.type === "radio" || s.attributes.type === "checkbox") {
          if (a.value === s.attributes.xfaOn ? t.setAttribute("checked", !0) : a.value === s.attributes.xfaOff && t.removeAttribute("checked"), r === "print")
            break;
          t.addEventListener("change", (o) => {
            i.setValue(e, {
              value: o.target.checked ? o.target.getAttribute("xfaOn") : o.target.getAttribute("xfaOff")
            });
          });
        } else {
          if (a.value !== null && t.setAttribute("value", a.value), r === "print")
            break;
          t.addEventListener("input", (o) => {
            i.setValue(e, {
              value: o.target.value
            });
          });
        }
        break;
      case "select":
        if (a.value !== null) {
          t.setAttribute("value", a.value);
          for (const o of s.children)
            o.attributes.value === a.value ? o.attributes.selected = !0 : o.attributes.hasOwnProperty("selected") && delete o.attributes.selected;
        }
        t.addEventListener("input", (o) => {
          const l = o.target.options, h = l.selectedIndex === -1 ? "" : l[l.selectedIndex].value;
          i.setValue(e, {
            value: h
          });
        });
        break;
    }
  }
  static setAttributes({
    html: t,
    element: e,
    storage: s = null,
    intent: i,
    linkService: r
  }) {
    const {
      attributes: a
    } = e, o = t instanceof HTMLAnchorElement;
    a.type === "radio" && (a.name = `${a.name}-${i}`);
    for (const [l, h] of Object.entries(a))
      if (h != null)
        switch (l) {
          case "class":
            h.length && t.setAttribute(l, h.join(" "));
            break;
          case "dataId":
            break;
          case "id":
            t.setAttribute("data-element-id", h);
            break;
          case "style":
            Object.assign(t.style, h);
            break;
          case "textContent":
            t.textContent = h;
            break;
          default:
            (!o || l !== "href" && l !== "newWindow") && t.setAttribute(l, h);
        }
    o && r.addLinkAttributes(t, a.href, a.newWindow), s && a.dataId && this.setupStorage(t, a.dataId, e, s);
  }
  static render(t) {
    var u, f;
    const e = t.annotationStorage, s = t.linkService, i = t.xfaHtml, r = t.intent || "display", a = document.createElement(i.name);
    i.attributes && this.setAttributes({
      html: a,
      element: i,
      intent: r,
      linkService: s
    });
    const o = r !== "richText", l = t.div;
    if (l.append(a), t.viewport) {
      const m = `matrix(${t.viewport.transform.join(",")})`;
      l.style.transform = m;
    }
    o && l.setAttribute("class", "xfaLayer xfaFont");
    const h = [];
    if (i.children.length === 0) {
      if (i.value) {
        const m = document.createTextNode(i.value);
        a.append(m), o && Wh.shouldBuildText(i.name) && h.push(m);
      }
      return {
        textDivs: h
      };
    }
    const c = [[i, -1, a]];
    for (; c.length > 0; ) {
      const [m, A, y] = c.at(-1);
      if (A + 1 === m.children.length) {
        c.pop();
        continue;
      }
      const v = m.children[++c.at(-1)[1]];
      if (v === null)
        continue;
      const {
        name: w
      } = v;
      if (w === "#text") {
        const E = document.createTextNode(v.value);
        h.push(E), y.append(E);
        continue;
      }
      const S = (u = v == null ? void 0 : v.attributes) != null && u.xmlns ? document.createElementNS(v.attributes.xmlns, w) : document.createElement(w);
      if (y.append(S), v.attributes && this.setAttributes({
        html: S,
        element: v,
        storage: e,
        intent: r,
        linkService: s
      }), ((f = v.children) == null ? void 0 : f.length) > 0)
        c.push([v, -1, S]);
      else if (v.value) {
        const E = document.createTextNode(v.value);
        o && Wh.shouldBuildText(w) && h.push(E), S.append(E);
      }
    }
    for (const m of l.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
      m.setAttribute("readOnly", !0);
    return {
      textDivs: h
    };
  }
  static update(t) {
    const e = `matrix(${t.viewport.transform.join(",")})`;
    t.div.style.transform = e, t.div.hidden = !1;
  }
}
const sn = "http://www.w3.org/2000/svg", sa = class sa {
};
L(sa, "CSS", 96), L(sa, "PDF", 72), L(sa, "PDF_TO_CSS_UNITS", sa.CSS / sa.PDF);
let jn = sa;
async function ph(d, t = "text") {
  if (Eh(d, document.baseURI)) {
    const e = await fetch(d);
    if (!e.ok)
      throw new Error(e.statusText);
    switch (t) {
      case "arraybuffer":
        return e.arrayBuffer();
      case "blob":
        return e.blob();
      case "json":
        return e.json();
    }
    return e.text();
  }
  return new Promise((e, s) => {
    const i = new XMLHttpRequest();
    i.open("GET", d, !0), i.responseType = t, i.onreadystatechange = () => {
      if (i.readyState === XMLHttpRequest.DONE) {
        if (i.status === 200 || i.status === 0) {
          switch (t) {
            case "arraybuffer":
            case "blob":
            case "json":
              e(i.response);
              return;
          }
          e(i.responseText);
          return;
        }
        s(new Error(i.statusText));
      }
    }, i.send(null);
  });
}
class Fd {
  constructor({
    viewBox: t,
    userUnit: e,
    scale: s,
    rotation: i,
    offsetX: r = 0,
    offsetY: a = 0,
    dontFlip: o = !1
  }) {
    this.viewBox = t, this.userUnit = e, this.scale = s, this.rotation = i, this.offsetX = r, this.offsetY = a, s *= e;
    const l = (t[2] + t[0]) / 2, h = (t[3] + t[1]) / 2;
    let c, u, f, m;
    switch (i %= 360, i < 0 && (i += 360), i) {
      case 180:
        c = -1, u = 0, f = 0, m = 1;
        break;
      case 90:
        c = 0, u = 1, f = 1, m = 0;
        break;
      case 270:
        c = 0, u = -1, f = -1, m = 0;
        break;
      case 0:
        c = 1, u = 0, f = 0, m = -1;
        break;
      default:
        throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
    }
    o && (f = -f, m = -m);
    let A, y, v, w;
    c === 0 ? (A = Math.abs(h - t[1]) * s + r, y = Math.abs(l - t[0]) * s + a, v = (t[3] - t[1]) * s, w = (t[2] - t[0]) * s) : (A = Math.abs(l - t[0]) * s + r, y = Math.abs(h - t[1]) * s + a, v = (t[2] - t[0]) * s, w = (t[3] - t[1]) * s), this.transform = [c * s, u * s, f * s, m * s, A - c * s * l - f * s * h, y - u * s * l - m * s * h], this.width = v, this.height = w;
  }
  get rawDims() {
    const t = this.viewBox;
    return it(this, "rawDims", {
      pageWidth: t[2] - t[0],
      pageHeight: t[3] - t[1],
      pageX: t[0],
      pageY: t[1]
    });
  }
  clone({
    scale: t = this.scale,
    rotation: e = this.rotation,
    offsetX: s = this.offsetX,
    offsetY: i = this.offsetY,
    dontFlip: r = !1
  } = {}) {
    return new Fd({
      viewBox: this.viewBox.slice(),
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: i,
      dontFlip: r
    });
  }
  convertToViewportPoint(t, e) {
    const s = [t, e];
    return V.applyTransform(s, this.transform), s;
  }
  convertToViewportRectangle(t) {
    const e = [t[0], t[1]];
    V.applyTransform(e, this.transform);
    const s = [t[2], t[3]];
    return V.applyTransform(s, this.transform), [e[0], e[1], s[0], s[1]];
  }
  convertToPdfPoint(t, e) {
    const s = [t, e];
    return V.applyInverseTransform(s, this.transform), s;
  }
}
class pf extends wo {
  constructor(t, e = 0) {
    super(t, "RenderingCancelledException"), this.extraDelay = e;
  }
}
function Nd(d) {
  const t = d.length;
  let e = 0;
  for (; e < t && d[e].trim() === ""; )
    e++;
  return d.substring(e, e + 5).toLowerCase() === "data:";
}
function gf(d) {
  return typeof d == "string" && /\.pdf$/i.test(d);
}
function Tm(d) {
  return [d] = d.split(/[#?]/, 1), d.substring(d.lastIndexOf("/") + 1);
}
function xm(d, t = "document.pdf") {
  if (typeof d != "string")
    return t;
  if (Nd(d))
    return J('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), t;
  const s = ((o) => {
    try {
      return new URL(o);
    } catch {
      try {
        return new URL(decodeURIComponent(o));
      } catch {
        try {
          return new URL(o, "https://foo.bar");
        } catch {
          try {
            return new URL(decodeURIComponent(o), "https://foo.bar");
          } catch {
            return null;
          }
        }
      }
    }
  })(d);
  if (!s)
    return t;
  const i = (o) => {
    try {
      let l = decodeURIComponent(o);
      return l.includes("/") ? (l = l.split("/").at(-1), l.test(/^\.pdf$/i) ? l : o) : l;
    } catch {
      return o;
    }
  }, r = /\.pdf$/i, a = s.pathname.split("/").at(-1);
  if (r.test(a))
    return i(a);
  if (s.searchParams.size > 0) {
    const o = Array.from(s.searchParams.values()).reverse();
    for (const h of o)
      if (r.test(h))
        return i(h);
    const l = Array.from(s.searchParams.keys()).reverse();
    for (const h of l)
      if (r.test(h))
        return i(h);
  }
  if (s.hash) {
    const l = /[^/?#=]+\.pdf\b(?!.*\.pdf\b)/i.exec(s.hash);
    if (l)
      return i(l[0]);
  }
  return t;
}
class Ng {
  constructor() {
    L(this, "started", /* @__PURE__ */ Object.create(null));
    L(this, "times", []);
  }
  time(t) {
    t in this.started && J(`Timer is already running for ${t}`), this.started[t] = Date.now();
  }
  timeEnd(t) {
    t in this.started || J(`Timer has not been started for ${t}`), this.times.push({
      name: t,
      start: this.started[t],
      end: Date.now()
    }), delete this.started[t];
  }
  toString() {
    const t = [];
    let e = 0;
    for (const {
      name: s
    } of this.times)
      e = Math.max(s.length, e);
    for (const {
      name: s,
      start: i,
      end: r
    } of this.times)
      t.push(`${s.padEnd(e)} ${r - i}ms
`);
    return t.join("");
  }
}
function Eh(d, t) {
  const e = t ? URL.parse(d, t) : URL.parse(d);
  return (e == null ? void 0 : e.protocol) === "http:" || (e == null ? void 0 : e.protocol) === "https:";
}
function $s(d) {
  d.preventDefault();
}
function zt(d) {
  d.preventDefault(), d.stopPropagation();
}
function gy(d) {
  console.log("Deprecated API usage: " + d);
}
var Qh;
class Xh {
  static toDateObject(t) {
    if (t instanceof Date)
      return t;
    if (!t || typeof t != "string")
      return null;
    n(this, Qh) || p(this, Qh, new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+|-])?(\\d{2})?'?(\\d{2})?'?"));
    const e = n(this, Qh).exec(t);
    if (!e)
      return null;
    const s = parseInt(e[1], 10);
    let i = parseInt(e[2], 10);
    i = i >= 1 && i <= 12 ? i - 1 : 0;
    let r = parseInt(e[3], 10);
    r = r >= 1 && r <= 31 ? r : 1;
    let a = parseInt(e[4], 10);
    a = a >= 0 && a <= 23 ? a : 0;
    let o = parseInt(e[5], 10);
    o = o >= 0 && o <= 59 ? o : 0;
    let l = parseInt(e[6], 10);
    l = l >= 0 && l <= 59 ? l : 0;
    const h = e[7] || "Z";
    let c = parseInt(e[8], 10);
    c = c >= 0 && c <= 23 ? c : 0;
    let u = parseInt(e[9], 10) || 0;
    return u = u >= 0 && u <= 59 ? u : 0, h === "-" ? (a += c, o += u) : h === "+" && (a -= c, o -= u), new Date(Date.UTC(s, i, r, a, o, l));
  }
}
Qh = new WeakMap(), g(Xh, Qh);
function Pm(d, {
  scale: t = 1,
  rotation: e = 0
}) {
  const {
    width: s,
    height: i
  } = d.attributes.style, r = [0, 0, parseInt(s), parseInt(i)];
  return new Fd({
    viewBox: r,
    userUnit: 1,
    scale: t,
    rotation: e
  });
}
function gh(d) {
  if (d.startsWith("#")) {
    const t = parseInt(d.slice(1), 16);
    return [(t & 16711680) >> 16, (t & 65280) >> 8, t & 255];
  }
  return d.startsWith("rgb(") ? d.slice(4, -1).split(",").map((t) => parseInt(t)) : d.startsWith("rgba(") ? d.slice(5, -1).split(",").map((t) => parseInt(t)).slice(0, 3) : (J(`Not a valid color format: "${d}"`), [0, 0, 0]);
}
function my(d) {
  const t = document.createElement("span");
  t.style.visibility = "hidden", t.style.colorScheme = "only light", document.body.append(t);
  for (const e of d.keys()) {
    t.style.color = e;
    const s = window.getComputedStyle(t).color;
    d.set(e, gh(s));
  }
  t.remove();
}
function Vt(d) {
  const {
    a: t,
    b: e,
    c: s,
    d: i,
    e: r,
    f: a
  } = d.getTransform();
  return [t, e, s, i, r, a];
}
function Ci(d) {
  const {
    a: t,
    b: e,
    c: s,
    d: i,
    e: r,
    f: a
  } = d.getTransform().invertSelf();
  return [t, e, s, i, r, a];
}
function jr(d, t, e = !1, s = !0) {
  if (t instanceof Fd) {
    const {
      pageWidth: i,
      pageHeight: r
    } = t.rawDims, {
      style: a
    } = d, o = _e.isCSSRoundSupported, l = `var(--total-scale-factor) * ${i}px`, h = `var(--total-scale-factor) * ${r}px`, c = o ? `round(down, ${l}, var(--scale-round-x))` : `calc(${l})`, u = o ? `round(down, ${h}, var(--scale-round-y))` : `calc(${h})`;
    !e || t.rotation % 180 === 0 ? (a.width = c, a.height = u) : (a.width = u, a.height = c);
  }
  s && d.setAttribute("data-main-rotation", t.rotation);
}
class Si {
  constructor() {
    const {
      pixelRatio: t
    } = Si;
    this.sx = t, this.sy = t;
  }
  get scaled() {
    return this.sx !== 1 || this.sy !== 1;
  }
  get symmetric() {
    return this.sx === this.sy;
  }
  limitCanvas(t, e, s, i, r = -1) {
    let a = 1 / 0, o = 1 / 0, l = 1 / 0;
    s = Si.capPixels(s, r), s > 0 && (a = Math.sqrt(s / (t * e))), i !== -1 && (o = i / t, l = i / e);
    const h = Math.min(a, o, l);
    return this.sx > h || this.sy > h ? (this.sx = h, this.sy = h, !0) : !1;
  }
  static get pixelRatio() {
    return globalThis.devicePixelRatio || 1;
  }
  static capPixels(t, e) {
    if (e >= 0) {
      const s = Math.ceil(window.screen.availWidth * window.screen.availHeight * this.pixelRatio ** 2 * (1 + e / 100));
      return t > 0 ? Math.min(t, s) : s;
    }
    return t;
  }
}
const Fu = ["image/apng", "image/avif", "image/bmp", "image/gif", "image/jpeg", "image/png", "image/svg+xml", "image/webp", "image/x-icon"];
class by {
  static get isDarkMode() {
    var t;
    return it(this, "isDarkMode", !!((t = window == null ? void 0 : window.matchMedia) != null && t.call(window, "(prefers-color-scheme: dark)").matches));
  }
}
class Rm {
  static get commentForegroundColor() {
    const t = document.createElement("span");
    t.classList.add("comment", "sidebar");
    const {
      style: e
    } = t;
    e.width = e.height = "0", e.display = "none", e.color = "var(--comment-fg-color)", document.body.append(t);
    const {
      color: s
    } = window.getComputedStyle(t);
    return t.remove(), it(this, "commentForegroundColor", gh(s));
  }
}
function Mm(d, t, e, s) {
  s = Math.min(Math.max(s ?? 1, 0), 1);
  const i = 255 * (1 - s);
  return d = Math.round(d * s + i), t = Math.round(t * s + i), e = Math.round(e * s + i), [d, t, e];
}
function Og(d, t) {
  const e = d[0] / 255, s = d[1] / 255, i = d[2] / 255, r = Math.max(e, s, i), a = Math.min(e, s, i), o = (r + a) / 2;
  if (r === a)
    t[0] = t[1] = 0;
  else {
    const l = r - a;
    switch (t[1] = o < 0.5 ? l / (r + a) : l / (2 - r - a), r) {
      case e:
        t[0] = ((s - i) / l + (s < i ? 6 : 0)) * 60;
        break;
      case s:
        t[0] = ((i - e) / l + 2) * 60;
        break;
      case i:
        t[0] = ((e - s) / l + 4) * 60;
        break;
    }
  }
  t[2] = o;
}
function Uf(d, t) {
  const e = d[0], s = d[1], i = d[2], r = (1 - Math.abs(2 * i - 1)) * s, a = r * (1 - Math.abs(e / 60 % 2 - 1)), o = i - r / 2;
  switch (Math.floor(e / 60)) {
    case 0:
      t[0] = r + o, t[1] = a + o, t[2] = o;
      break;
    case 1:
      t[0] = a + o, t[1] = r + o, t[2] = o;
      break;
    case 2:
      t[0] = o, t[1] = r + o, t[2] = a + o;
      break;
    case 3:
      t[0] = o, t[1] = a + o, t[2] = r + o;
      break;
    case 4:
      t[0] = a + o, t[1] = o, t[2] = r + o;
      break;
    case 5:
    case 6:
      t[0] = r + o, t[1] = o, t[2] = a + o;
      break;
  }
}
function Bg(d) {
  return d <= 0.03928 ? d / 12.92 : ((d + 0.055) / 1.055) ** 2.4;
}
function Hg(d, t, e) {
  Uf(d, e), e.map(Bg);
  const s = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  Uf(t, e), e.map(Bg);
  const i = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  return s > i ? (s + 0.05) / (i + 0.05) : (i + 0.05) / (s + 0.05);
}
const Ug = /* @__PURE__ */ new Map();
function km(d, t) {
  const e = d[0] + d[1] * 256 + d[2] * 65536 + t[0] * 16777216 + t[1] * 4294967296 + t[2] * 1099511627776;
  let s = Ug.get(e);
  if (s)
    return s;
  const i = new Float32Array(9), r = i.subarray(0, 3), a = i.subarray(3, 6);
  Og(d, a);
  const o = i.subarray(6, 9);
  Og(t, o);
  const l = o[2] < 0.5, h = l ? 12 : 4.5;
  if (a[2] = l ? Math.sqrt(a[2]) : 1 - Math.sqrt(1 - a[2]), Hg(a, o, r) < h) {
    let c, u;
    l ? (c = a[2], u = 1) : (c = 0, u = a[2]);
    const f = 5e-3;
    for (; u - c > f; ) {
      const m = a[2] = (c + u) / 2;
      l === Hg(a, o, r) < h ? c = m : u = m;
    }
    a[2] = l ? u : c;
  }
  return Uf(a, r), s = V.makeHexColor(Math.round(r[0] * 255), Math.round(r[1] * 255), Math.round(r[2] * 255)), Ug.set(e, s), s;
}
function mg({
  html: d,
  dir: t,
  className: e
}, s) {
  const i = document.createDocumentFragment();
  if (typeof d == "string") {
    const r = document.createElement("p");
    r.dir = t || "auto";
    const a = d.split(/(?:\r\n?|\n)/);
    for (let o = 0, l = a.length; o < l; ++o) {
      const h = a[o];
      r.append(document.createTextNode(h)), o < l - 1 && r.append(document.createElement("br"));
    }
    i.append(r);
  } else
    gg.render({
      xfaHtml: d,
      div: i,
      intent: "richText"
    });
  i.firstChild.classList.add("richText", e), s.append(i);
}
var Zn, Jn, Ws, Xs, tc, Qn, Ho, Uo, ec, Wu, Lm, Fe, Dm, Im, _o, Sh;
const an = class an {
  constructor(t) {
    g(this, Fe);
    g(this, Zn, null);
    g(this, Jn, null);
    g(this, Ws);
    g(this, Xs, null);
    g(this, tc, null);
    g(this, Qn, null);
    g(this, Ho, null);
    g(this, Uo, null);
    p(this, Ws, t), n(an, ec) || p(an, ec, Object.freeze({
      freetext: "pdfjs-editor-remove-freetext-button",
      highlight: "pdfjs-editor-remove-highlight-button",
      ink: "pdfjs-editor-remove-ink-button",
      stamp: "pdfjs-editor-remove-stamp-button",
      signature: "pdfjs-editor-remove-signature-button"
    }));
  }
  render() {
    const t = p(this, Zn, document.createElement("div"));
    t.classList.add("editToolbar", "hidden"), t.setAttribute("role", "toolbar");
    const e = n(this, Ws)._uiManager._signal;
    e instanceof AbortSignal && !e.aborted && (t.addEventListener("contextmenu", $s, {
      signal: e
    }), t.addEventListener("pointerdown", b(an, Wu, Lm), {
      signal: e
    }));
    const s = p(this, Xs, document.createElement("div"));
    s.className = "buttons", t.append(s);
    const i = n(this, Ws).toolbarPosition;
    if (i) {
      const {
        style: r
      } = t, a = n(this, Ws)._uiManager.direction === "ltr" ? 1 - i[0] : i[0];
      r.insetInlineEnd = `${100 * a}%`, r.top = `calc(${100 * i[1]}% + var(--editor-toolbar-vert-offset))`;
    }
    return t;
  }
  get div() {
    return n(this, Zn);
  }
  hide() {
    var t;
    n(this, Zn).classList.add("hidden"), (t = n(this, Jn)) == null || t.hideDropdown();
  }
  show() {
    var t, e;
    n(this, Zn).classList.remove("hidden"), (t = n(this, tc)) == null || t.shown(), (e = n(this, Qn)) == null || e.shown();
  }
  addDeleteButton() {
    const {
      editorType: t,
      _uiManager: e
    } = n(this, Ws), s = document.createElement("button");
    s.classList.add("basic", "deleteButton"), s.tabIndex = 0, s.setAttribute("data-l10n-id", n(an, ec)[t]), b(this, Fe, _o).call(this, s) && s.addEventListener("click", (i) => {
      e.delete();
    }, {
      signal: e._signal
    }), n(this, Xs).append(s);
  }
  async addAltText(t) {
    const e = await t.render();
    b(this, Fe, _o).call(this, e), n(this, Xs).append(e, n(this, Fe, Sh)), p(this, tc, t);
  }
  addComment(t, e = null) {
    if (n(this, Qn))
      return;
    const s = t.renderForToolbar();
    if (!s)
      return;
    b(this, Fe, _o).call(this, s);
    const i = p(this, Ho, n(this, Fe, Sh));
    e ? (n(this, Xs).insertBefore(s, e), n(this, Xs).insertBefore(i, e)) : n(this, Xs).append(s, i), p(this, Qn, t), t.toolbar = this;
  }
  addColorPicker(t) {
    if (n(this, Jn))
      return;
    p(this, Jn, t);
    const e = t.renderButton();
    b(this, Fe, _o).call(this, e), n(this, Xs).append(e, n(this, Fe, Sh));
  }
  async addEditSignatureButton(t) {
    const e = p(this, Uo, await t.renderEditButton(n(this, Ws)));
    b(this, Fe, _o).call(this, e), n(this, Xs).append(e, n(this, Fe, Sh));
  }
  removeButton(t) {
    var e, s;
    switch (t) {
      case "comment":
        (e = n(this, Qn)) == null || e.removeToolbarCommentButton(), p(this, Qn, null), (s = n(this, Ho)) == null || s.remove(), p(this, Ho, null);
        break;
    }
  }
  async addButton(t, e) {
    switch (t) {
      case "colorPicker":
        this.addColorPicker(e);
        break;
      case "altText":
        await this.addAltText(e);
        break;
      case "editSignature":
        await this.addEditSignatureButton(e);
        break;
      case "delete":
        this.addDeleteButton();
        break;
      case "comment":
        this.addComment(e);
        break;
    }
  }
  async addButtonBefore(t, e, s) {
    const i = n(this, Xs).querySelector(s);
    i && t === "comment" && this.addComment(e, i);
  }
  updateEditSignatureButton(t) {
    n(this, Uo) && (n(this, Uo).title = t);
  }
  remove() {
    var t;
    n(this, Zn).remove(), (t = n(this, Jn)) == null || t.destroy(), p(this, Jn, null);
  }
};
Zn = new WeakMap(), Jn = new WeakMap(), Ws = new WeakMap(), Xs = new WeakMap(), tc = new WeakMap(), Qn = new WeakMap(), Ho = new WeakMap(), Uo = new WeakMap(), ec = new WeakMap(), Wu = new WeakSet(), Lm = function(t) {
  t.stopPropagation();
}, Fe = new WeakSet(), Dm = function(t) {
  n(this, Ws)._focusEventsAllowed = !1, zt(t);
}, Im = function(t) {
  n(this, Ws)._focusEventsAllowed = !0, zt(t);
}, _o = function(t) {
  const e = n(this, Ws)._uiManager._signal;
  return !(e instanceof AbortSignal) || e.aborted ? !1 : (t.addEventListener("focusin", b(this, Fe, Dm).bind(this), {
    capture: !0,
    signal: e
  }), t.addEventListener("focusout", b(this, Fe, Im).bind(this), {
    capture: !0,
    signal: e
  }), t.addEventListener("contextmenu", $s, {
    signal: e
  }), !0);
}, Sh = function() {
  const t = document.createElement("div");
  return t.className = "divider", t;
}, g(an, Wu), g(an, ec, null);
let $f = an;
var sc, ra, ln, Wn, Fm, Nm, Vf;
class yy {
  constructor(t) {
    g(this, Wn);
    g(this, sc, null);
    g(this, ra, null);
    g(this, ln);
    p(this, ln, t);
  }
  show(t, e, s) {
    const [i, r] = b(this, Wn, Nm).call(this, e, s), {
      style: a
    } = n(this, ra) || p(this, ra, b(this, Wn, Fm).call(this));
    t.append(n(this, ra)), a.insetInlineEnd = `${100 * i}%`, a.top = `calc(${100 * r}% + var(--editor-toolbar-vert-offset))`;
  }
  hide() {
    n(this, ra).remove();
  }
}
sc = new WeakMap(), ra = new WeakMap(), ln = new WeakMap(), Wn = new WeakSet(), Fm = function() {
  const t = p(this, ra, document.createElement("div"));
  t.className = "editToolbar", t.setAttribute("role", "toolbar");
  const e = n(this, ln)._signal;
  e instanceof AbortSignal && !e.aborted && t.addEventListener("contextmenu", $s, {
    signal: e
  });
  const s = p(this, sc, document.createElement("div"));
  return s.className = "buttons", t.append(s), n(this, ln).hasCommentManager() && b(this, Wn, Vf).call(this, "commentButton", "pdfjs-comment-floating-button", "pdfjs-comment-floating-button-label", () => {
    n(this, ln).commentSelection("floating_button");
  }), b(this, Wn, Vf).call(this, "highlightButton", "pdfjs-highlight-floating-button1", "pdfjs-highlight-floating-button-label", () => {
    n(this, ln).highlightSelection("floating_button");
  }), t;
}, Nm = function(t, e) {
  let s = 0, i = 0;
  for (const r of t) {
    const a = r.y + r.height;
    if (a < s)
      continue;
    const o = r.x + (e ? r.width : 0);
    if (a > s) {
      i = o, s = a;
      continue;
    }
    e ? o > i && (i = o) : o < i && (i = o);
  }
  return [e ? 1 - i : i, s];
}, Vf = function(t, e, s, i) {
  const r = document.createElement("button");
  r.classList.add("basic", t), r.tabIndex = 0, r.setAttribute("data-l10n-id", e);
  const a = document.createElement("span");
  r.append(a), a.className = "visuallyHidden", a.setAttribute("data-l10n-id", s);
  const o = n(this, ln)._signal;
  o instanceof AbortSignal && !o.aborted && (r.addEventListener("contextmenu", $s, {
    signal: o
  }), r.addEventListener("click", i, {
    signal: o
  })), n(this, sc).append(r);
};
function Om(d, t, e) {
  for (const s of e)
    t.addEventListener(s, d[s].bind(d));
}
var Xu;
class Ay {
  constructor() {
    g(this, Xu, 0);
  }
  get id() {
    return `${Gh}${oe(this, Xu)._++}`;
  }
}
Xu = new WeakMap();
var $o, ic, He, Vo, iu;
const xg = class xg {
  constructor() {
    g(this, Vo);
    g(this, $o, fg());
    g(this, ic, 0);
    g(this, He, null);
  }
  static get _isSVGFittingCanvas() {
    const t = 'data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" style="fill:red;"/></svg>', s = new OffscreenCanvas(1, 3).getContext("2d", {
      willReadFrequently: !0
    }), i = new Image();
    i.src = t;
    const r = i.decode().then(() => (s.drawImage(i, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(s.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
    return it(this, "_isSVGFittingCanvas", r);
  }
  async getFromFile(t) {
    const {
      lastModified: e,
      name: s,
      size: i,
      type: r
    } = t;
    return b(this, Vo, iu).call(this, `${e}_${s}_${i}_${r}`, t);
  }
  async getFromUrl(t) {
    return b(this, Vo, iu).call(this, t, t);
  }
  async getFromBlob(t, e) {
    const s = await e;
    return b(this, Vo, iu).call(this, t, s);
  }
  async getFromId(t) {
    n(this, He) || p(this, He, /* @__PURE__ */ new Map());
    const e = n(this, He).get(t);
    if (!e)
      return null;
    if (e.bitmap)
      return e.refCounter += 1, e;
    if (e.file)
      return this.getFromFile(e.file);
    if (e.blobPromise) {
      const {
        blobPromise: s
      } = e;
      return delete e.blobPromise, this.getFromBlob(e.id, s);
    }
    return this.getFromUrl(e.url);
  }
  getFromCanvas(t, e) {
    n(this, He) || p(this, He, /* @__PURE__ */ new Map());
    let s = n(this, He).get(t);
    if (s != null && s.bitmap)
      return s.refCounter += 1, s;
    const i = new OffscreenCanvas(e.width, e.height);
    return i.getContext("2d").drawImage(e, 0, 0), s = {
      bitmap: i.transferToImageBitmap(),
      id: `image_${n(this, $o)}_${oe(this, ic)._++}`,
      refCounter: 1,
      isSvg: !1
    }, n(this, He).set(t, s), n(this, He).set(s.id, s), s;
  }
  getSvgUrl(t) {
    const e = n(this, He).get(t);
    return e != null && e.isSvg ? e.svgUrl : null;
  }
  deleteId(t) {
    var i;
    n(this, He) || p(this, He, /* @__PURE__ */ new Map());
    const e = n(this, He).get(t);
    if (!e || (e.refCounter -= 1, e.refCounter !== 0))
      return;
    const {
      bitmap: s
    } = e;
    if (!e.url && !e.file) {
      const r = new OffscreenCanvas(s.width, s.height);
      r.getContext("bitmaprenderer").transferFromImageBitmap(s), e.blobPromise = r.convertToBlob();
    }
    (i = s.close) == null || i.call(s), e.bitmap = null;
  }
  isValidId(t) {
    return t.startsWith(`image_${n(this, $o)}_`);
  }
};
$o = new WeakMap(), ic = new WeakMap(), He = new WeakMap(), Vo = new WeakSet(), iu = async function(t, e) {
  n(this, He) || p(this, He, /* @__PURE__ */ new Map());
  let s = n(this, He).get(t);
  if (s === null)
    return null;
  if (s != null && s.bitmap)
    return s.refCounter += 1, s;
  try {
    s || (s = {
      bitmap: null,
      id: `image_${n(this, $o)}_${oe(this, ic)._++}`,
      refCounter: 0,
      isSvg: !1
    });
    let i;
    if (typeof e == "string" ? (s.url = e, i = await ph(e, "blob")) : e instanceof File ? i = s.file = e : e instanceof Blob && (i = e), i.type === "image/svg+xml") {
      const r = xg._isSVGFittingCanvas, a = new FileReader(), o = new Image(), l = new Promise((h, c) => {
        o.onload = () => {
          s.bitmap = o, s.isSvg = !0, h();
        }, a.onload = async () => {
          const u = s.svgUrl = a.result;
          o.src = await r ? `${u}#svgView(preserveAspectRatio(none))` : u;
        }, o.onerror = a.onerror = c;
      });
      a.readAsDataURL(i), await l;
    } else
      s.bitmap = await createImageBitmap(i);
    s.refCounter = 1;
  } catch (i) {
    J(i), s = null;
  }
  return n(this, He).set(t, s), s && n(this, He).set(s.id, s), s;
};
let zf = xg;
var ee, tr, nc, $t;
class wy {
  constructor(t = 128) {
    g(this, ee, []);
    g(this, tr, !1);
    g(this, nc);
    g(this, $t, -1);
    p(this, nc, t);
  }
  add({
    cmd: t,
    undo: e,
    post: s,
    mustExec: i,
    type: r = NaN,
    overwriteIfSameType: a = !1,
    keepUndo: o = !1
  }) {
    if (i && t(), n(this, tr))
      return;
    const l = {
      cmd: t,
      undo: e,
      post: s,
      type: r
    };
    if (n(this, $t) === -1) {
      n(this, ee).length > 0 && (n(this, ee).length = 0), p(this, $t, 0), n(this, ee).push(l);
      return;
    }
    if (a && n(this, ee)[n(this, $t)].type === r) {
      o && (l.undo = n(this, ee)[n(this, $t)].undo), n(this, ee)[n(this, $t)] = l;
      return;
    }
    const h = n(this, $t) + 1;
    h === n(this, nc) ? n(this, ee).splice(0, 1) : (p(this, $t, h), h < n(this, ee).length && n(this, ee).splice(h)), n(this, ee).push(l);
  }
  undo() {
    if (n(this, $t) === -1)
      return;
    p(this, tr, !0);
    const {
      undo: t,
      post: e
    } = n(this, ee)[n(this, $t)];
    t(), e == null || e(), p(this, tr, !1), p(this, $t, n(this, $t) - 1);
  }
  redo() {
    if (n(this, $t) < n(this, ee).length - 1) {
      p(this, $t, n(this, $t) + 1), p(this, tr, !0);
      const {
        cmd: t,
        post: e
      } = n(this, ee)[n(this, $t)];
      t(), e == null || e(), p(this, tr, !1);
    }
  }
  hasSomethingToUndo() {
    return n(this, $t) !== -1;
  }
  hasSomethingToRedo() {
    return n(this, $t) < n(this, ee).length - 1;
  }
  cleanType(t) {
    if (n(this, $t) !== -1) {
      for (let e = n(this, $t); e >= 0; e--)
        if (n(this, ee)[e].type !== t) {
          n(this, ee).splice(e + 1, n(this, $t) - e), p(this, $t, e);
          return;
        }
      n(this, ee).length = 0, p(this, $t, -1);
    }
  }
  destroy() {
    p(this, ee, null);
  }
}
ee = new WeakMap(), tr = new WeakMap(), nc = new WeakMap(), $t = new WeakMap();
var qu, Bm;
class Od {
  constructor(t) {
    g(this, qu);
    this.buffer = [], this.callbacks = /* @__PURE__ */ new Map(), this.allKeys = /* @__PURE__ */ new Set();
    const {
      isMac: e
    } = _e.platform;
    for (const [s, i, r = {}] of t)
      for (const a of s) {
        const o = a.startsWith("mac+");
        e && o ? (this.callbacks.set(a.slice(4), {
          callback: i,
          options: r
        }), this.allKeys.add(a.split("+").at(-1))) : !e && !o && (this.callbacks.set(a, {
          callback: i,
          options: r
        }), this.allKeys.add(a.split("+").at(-1)));
      }
  }
  exec(t, e) {
    if (!this.allKeys.has(e.key))
      return;
    const s = this.callbacks.get(b(this, qu, Bm).call(this, e));
    if (!s)
      return;
    const {
      callback: i,
      options: {
        bubbles: r = !1,
        args: a = [],
        checker: o = null
      }
    } = s;
    o && !o(t, e) || (i.bind(t, ...a, e)(), r || zt(e));
  }
}
qu = new WeakSet(), Bm = function(t) {
  t.altKey && this.buffer.push("alt"), t.ctrlKey && this.buffer.push("ctrl"), t.metaKey && this.buffer.push("meta"), t.shiftKey && this.buffer.push("shift"), this.buffer.push(t.key);
  const e = this.buffer.join("+");
  return this.buffer.length = 0, e;
};
const Yu = class Yu {
  get _colors() {
    const t = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
    return my(t), it(this, "_colors", t);
  }
  convert(t) {
    const e = gh(t);
    if (!window.matchMedia("(forced-colors: active)").matches)
      return e;
    for (const [s, i] of this._colors)
      if (i.every((r, a) => r === e[a]))
        return Yu._colorsMapping.get(s);
    return e;
  }
  getHexCode(t) {
    const e = this._colors.get(t);
    return e ? V.makeHexColor(...e) : t;
  }
};
L(Yu, "_colorsMapping", /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]));
let Gf = Yu;
var zo, ws, Go, Xt, ce, jo, qs, Wo, Ys, Ue, er, sr, Xo, ir, Pi, Ks, aa, rc, ac, qo, oc, Ri, nr, Yo, rr, Mi, Ku, ar, Ko, lc, or, oa, Zo, lr, hc, re, yt, hn, hr, cr, cc, Jo, dc, dr, ki, cn, uc, fc, Zs, F, nu, jf, Hm, Um, _h, $m, Vm, zm, Wf, Gm, Xf, qf, jm, Ze, nn, Wm, Xm, Yf, qm, Ch, Kf;
const Lo = class Lo {
  constructor(t, e, s, i, r, a, o, l, h, c, u, f, m, A, y, v) {
    g(this, F);
    g(this, zo, new AbortController());
    g(this, ws, null);
    g(this, Go, null);
    g(this, Xt, /* @__PURE__ */ new Map());
    g(this, ce, /* @__PURE__ */ new Map());
    g(this, jo, null);
    g(this, qs, null);
    g(this, Wo, null);
    g(this, Ys, new wy());
    g(this, Ue, null);
    g(this, er, null);
    g(this, sr, null);
    g(this, Xo, 0);
    g(this, ir, /* @__PURE__ */ new Set());
    g(this, Pi, null);
    g(this, Ks, null);
    g(this, aa, /* @__PURE__ */ new Set());
    L(this, "_editorUndoBar", null);
    g(this, rc, !1);
    g(this, ac, !1);
    g(this, qo, !1);
    g(this, oc, null);
    g(this, Ri, null);
    g(this, nr, null);
    g(this, Yo, null);
    g(this, rr, !1);
    g(this, Mi, null);
    g(this, Ku, new Ay());
    g(this, ar, !1);
    g(this, Ko, !1);
    g(this, lc, !1);
    g(this, or, null);
    g(this, oa, null);
    g(this, Zo, null);
    g(this, lr, null);
    g(this, hc, null);
    g(this, re, Z.NONE);
    g(this, yt, /* @__PURE__ */ new Set());
    g(this, hn, null);
    g(this, hr, null);
    g(this, cr, null);
    g(this, cc, null);
    g(this, Jo, null);
    g(this, dc, {
      isEditing: !1,
      isEmpty: !0,
      hasSomethingToUndo: !1,
      hasSomethingToRedo: !1,
      hasSelectedEditor: !1,
      hasSelectedText: !1
    });
    g(this, dr, [0, 0]);
    g(this, ki, null);
    g(this, cn, null);
    g(this, uc, null);
    g(this, fc, null);
    g(this, Zs, null);
    const w = this._signal = n(this, zo).signal;
    p(this, cn, t), p(this, uc, e), p(this, fc, s), p(this, jo, i), p(this, Ue, r), p(this, hr, a), p(this, Jo, l), this._eventBus = o, o._on("editingaction", this.onEditingAction.bind(this), {
      signal: w
    }), o._on("pagechanging", this.onPageChanging.bind(this), {
      signal: w
    }), o._on("scalechanging", this.onScaleChanging.bind(this), {
      signal: w
    }), o._on("rotationchanging", this.onRotationChanging.bind(this), {
      signal: w
    }), o._on("setpreference", this.onSetPreference.bind(this), {
      signal: w
    }), o._on("switchannotationeditorparams", (S) => this.updateParams(S.type, S.value), {
      signal: w
    }), window.addEventListener("pointerdown", () => {
      p(this, Ko, !0);
    }, {
      capture: !0,
      signal: w
    }), window.addEventListener("pointerup", () => {
      p(this, Ko, !1);
    }, {
      capture: !0,
      signal: w
    }), b(this, F, $m).call(this), b(this, F, jm).call(this), b(this, F, Wf).call(this), p(this, qs, l.annotationStorage), p(this, oc, l.filterFactory), p(this, cr, h), p(this, Yo, c || null), p(this, rc, u), p(this, ac, f), p(this, qo, m), p(this, hc, A || null), this.viewParameters = {
      realScale: jn.PDF_TO_CSS_UNITS,
      rotation: 0
    }, this.isShiftKeyDown = !1, this._editorUndoBar = y || null, this._supportsPinchToZoom = v !== !1, r == null || r.setSidebarUiManager(this);
  }
  static get _keyboardManager() {
    const t = Lo.prototype, e = (a) => n(a, cn).contains(document.activeElement) && document.activeElement.tagName !== "BUTTON" && a.hasSomethingToControl(), s = (a, {
      target: o
    }) => {
      if (o instanceof HTMLInputElement) {
        const {
          type: l
        } = o;
        return l !== "text" && l !== "number";
      }
      return !0;
    }, i = this.TRANSLATE_SMALL, r = this.TRANSLATE_BIG;
    return it(this, "_keyboardManager", new Od([[["ctrl+a", "mac+meta+a"], t.selectAll, {
      checker: s
    }], [["ctrl+z", "mac+meta+z"], t.undo, {
      checker: s
    }], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], t.redo, {
      checker: s
    }], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], t.delete, {
      checker: s
    }], [["Enter", "mac+Enter"], t.addNewEditorFromKeyboard, {
      checker: (a, {
        target: o
      }) => !(o instanceof HTMLButtonElement) && n(a, cn).contains(o) && !a.isEnterHandled
    }], [[" ", "mac+ "], t.addNewEditorFromKeyboard, {
      checker: (a, {
        target: o
      }) => !(o instanceof HTMLButtonElement) && n(a, cn).contains(document.activeElement)
    }], [["Escape", "mac+Escape"], t.unselectAll], [["ArrowLeft", "mac+ArrowLeft"], t.translateSelectedEditors, {
      args: [-i, 0],
      checker: e
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t.translateSelectedEditors, {
      args: [-r, 0],
      checker: e
    }], [["ArrowRight", "mac+ArrowRight"], t.translateSelectedEditors, {
      args: [i, 0],
      checker: e
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t.translateSelectedEditors, {
      args: [r, 0],
      checker: e
    }], [["ArrowUp", "mac+ArrowUp"], t.translateSelectedEditors, {
      args: [0, -i],
      checker: e
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t.translateSelectedEditors, {
      args: [0, -r],
      checker: e
    }], [["ArrowDown", "mac+ArrowDown"], t.translateSelectedEditors, {
      args: [0, i],
      checker: e
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t.translateSelectedEditors, {
      args: [0, r],
      checker: e
    }]]));
  }
  destroy() {
    var t, e, s, i, r, a, o, l, h;
    (t = n(this, Zs)) == null || t.resolve(), p(this, Zs, null), (e = n(this, zo)) == null || e.abort(), p(this, zo, null), this._signal = null;
    for (const c of n(this, ce).values())
      c.destroy();
    n(this, ce).clear(), n(this, Xt).clear(), n(this, aa).clear(), (s = n(this, lr)) == null || s.clear(), p(this, ws, null), n(this, yt).clear(), n(this, Ys).destroy(), (i = n(this, jo)) == null || i.destroy(), (r = n(this, Ue)) == null || r.destroy(), (a = n(this, hr)) == null || a.destroy(), (o = n(this, Mi)) == null || o.hide(), p(this, Mi, null), (l = n(this, Zo)) == null || l.destroy(), p(this, Zo, null), p(this, Go, null), n(this, Ri) && (clearTimeout(n(this, Ri)), p(this, Ri, null)), n(this, ki) && (clearTimeout(n(this, ki)), p(this, ki, null)), (h = this._editorUndoBar) == null || h.destroy(), p(this, Jo, null);
  }
  combinedSignal(t) {
    return AbortSignal.any([this._signal, t.signal]);
  }
  get mlManager() {
    return n(this, hc);
  }
  get useNewAltTextFlow() {
    return n(this, ac);
  }
  get useNewAltTextWhenAddingImage() {
    return n(this, qo);
  }
  get hcmFilter() {
    return it(this, "hcmFilter", n(this, cr) ? n(this, oc).addHCMFilter(n(this, cr).foreground, n(this, cr).background) : "none");
  }
  get direction() {
    return it(this, "direction", getComputedStyle(n(this, cn)).direction);
  }
  get _highlightColors() {
    return it(this, "_highlightColors", n(this, Yo) ? new Map(n(this, Yo).split(",").map((t) => (t = t.split("=").map((e) => e.trim()), t[1] = t[1].toUpperCase(), t))) : null);
  }
  get highlightColors() {
    const {
      _highlightColors: t
    } = this;
    if (!t)
      return it(this, "highlightColors", null);
    const e = /* @__PURE__ */ new Map(), s = !!n(this, cr);
    for (const [i, r] of t) {
      const a = i.endsWith("_HCM");
      if (s && a) {
        e.set(i.replace("_HCM", ""), r);
        continue;
      }
      !s && !a && e.set(i, r);
    }
    return it(this, "highlightColors", e);
  }
  get highlightColorNames() {
    return it(this, "highlightColorNames", this.highlightColors ? new Map(Array.from(this.highlightColors, (t) => t.reverse())) : null);
  }
  getNonHCMColor(t) {
    if (!this._highlightColors)
      return t;
    const e = this.highlightColorNames.get(t);
    return this._highlightColors.get(e) || t;
  }
  getNonHCMColorName(t) {
    return this.highlightColorNames.get(t) || t;
  }
  setCurrentDrawingSession(t) {
    t ? (this.unselectAll(), this.disableUserSelect(!0)) : this.disableUserSelect(!1), p(this, sr, t);
  }
  setMainHighlightColorPicker(t) {
    p(this, Zo, t);
  }
  editAltText(t, e = !1) {
    var s;
    (s = n(this, jo)) == null || s.editAltText(this, t, e);
  }
  hasCommentManager() {
    return !!n(this, Ue);
  }
  editComment(t, e, s, i) {
    var r;
    (r = n(this, Ue)) == null || r.showDialog(this, t, e, s, i);
  }
  selectComment(t, e) {
    const s = n(this, ce).get(t), i = s == null ? void 0 : s.getEditorByUID(e);
    i == null || i.toggleComment(!0, !0);
  }
  updateComment(t) {
    var e;
    (e = n(this, Ue)) == null || e.updateComment(t.getData());
  }
  updatePopupColor(t) {
    var e;
    (e = n(this, Ue)) == null || e.updatePopupColor(t);
  }
  removeComment(t) {
    var e;
    (e = n(this, Ue)) == null || e.removeComments([t.uid]);
  }
  toggleComment(t, e, s = void 0) {
    var i;
    (i = n(this, Ue)) == null || i.toggleCommentPopup(t, e, s);
  }
  makeCommentColor(t, e) {
    var s;
    return t && ((s = n(this, Ue)) == null ? void 0 : s.makeCommentColor(t, e)) || null;
  }
  getCommentDialogElement() {
    var t;
    return ((t = n(this, Ue)) == null ? void 0 : t.dialogElement) || null;
  }
  async waitForEditorsRendered(t) {
    if (n(this, ce).has(t - 1))
      return;
    const {
      resolve: e,
      promise: s
    } = Promise.withResolvers(), i = (r) => {
      r.pageNumber === t && (this._eventBus._off("editorsrendered", i), e());
    };
    this._eventBus.on("editorsrendered", i), await s;
  }
  getSignature(t) {
    var e;
    (e = n(this, hr)) == null || e.getSignature({
      uiManager: this,
      editor: t
    });
  }
  get signatureManager() {
    return n(this, hr);
  }
  switchToMode(t, e) {
    this._eventBus.on("annotationeditormodechanged", e, {
      once: !0,
      signal: this._signal
    }), this._eventBus.dispatch("showannotationeditorui", {
      source: this,
      mode: t
    });
  }
  setPreference(t, e) {
    this._eventBus.dispatch("setpreference", {
      source: this,
      name: t,
      value: e
    });
  }
  onSetPreference({
    name: t,
    value: e
  }) {
    switch (t) {
      case "enableNewAltTextWhenAddingImage":
        p(this, qo, e);
        break;
    }
  }
  onPageChanging({
    pageNumber: t
  }) {
    p(this, Xo, t - 1);
  }
  focusMainContainer() {
    n(this, cn).focus();
  }
  findParent(t, e) {
    for (const s of n(this, ce).values()) {
      const {
        x: i,
        y: r,
        width: a,
        height: o
      } = s.div.getBoundingClientRect();
      if (t >= i && t <= i + a && e >= r && e <= r + o)
        return s;
    }
    return null;
  }
  disableUserSelect(t = !1) {
    n(this, uc).classList.toggle("noUserSelect", t);
  }
  addShouldRescale(t) {
    n(this, aa).add(t);
  }
  removeShouldRescale(t) {
    n(this, aa).delete(t);
  }
  onScaleChanging({
    scale: t
  }) {
    var e;
    this.commitOrRemove(), this.viewParameters.realScale = t * jn.PDF_TO_CSS_UNITS;
    for (const s of n(this, aa))
      s.onScaleChanging();
    (e = n(this, sr)) == null || e.onScaleChanging();
  }
  onRotationChanging({
    pagesRotation: t
  }) {
    this.commitOrRemove(), this.viewParameters.rotation = t;
  }
  highlightSelection(t = "", e = !1) {
    const s = document.getSelection();
    if (!s || s.isCollapsed)
      return;
    const {
      anchorNode: i,
      anchorOffset: r,
      focusNode: a,
      focusOffset: o
    } = s, l = s.toString(), c = b(this, F, nu).call(this, s).closest(".textLayer"), u = this.getSelectionBoxes(c);
    if (!u)
      return;
    s.empty();
    const f = b(this, F, jf).call(this, c), m = n(this, re) === Z.NONE, A = () => {
      const y = f == null ? void 0 : f.createAndAddNewEditor({
        x: 0,
        y: 0
      }, !1, {
        methodOfCreation: t,
        boxes: u,
        anchorNode: i,
        anchorOffset: r,
        focusNode: a,
        focusOffset: o,
        text: l
      });
      m && this.showAllEditors("highlight", !0, !0), e && (y == null || y.editComment());
    };
    if (m) {
      this.switchToMode(Z.HIGHLIGHT, A);
      return;
    }
    A();
  }
  commentSelection(t = "") {
    this.highlightSelection(t, !0);
  }
  getAndRemoveDataFromAnnotationStorage(t) {
    if (!n(this, qs))
      return null;
    const e = `${Gh}${t}`, s = n(this, qs).getRawValue(e);
    return s && n(this, qs).remove(e), s;
  }
  addToAnnotationStorage(t) {
    !t.isEmpty() && n(this, qs) && !n(this, qs).has(t.id) && n(this, qs).setValue(t.id, t);
  }
  a11yAlert(t, e = null) {
    const s = n(this, fc);
    s && (s.setAttribute("data-l10n-id", t), e ? s.setAttribute("data-l10n-args", JSON.stringify(e)) : s.removeAttribute("data-l10n-args"));
  }
  blur() {
    if (this.isShiftKeyDown = !1, n(this, rr) && (p(this, rr, !1), b(this, F, _h).call(this, "main_toolbar")), !this.hasSelection)
      return;
    const {
      activeElement: t
    } = document;
    for (const e of n(this, yt))
      if (e.div.contains(t)) {
        p(this, oa, [e, t]), e._focusEventsAllowed = !1;
        break;
      }
  }
  focus() {
    if (!n(this, oa))
      return;
    const [t, e] = n(this, oa);
    p(this, oa, null), e.addEventListener("focusin", () => {
      t._focusEventsAllowed = !0;
    }, {
      once: !0,
      signal: this._signal
    }), e.focus();
  }
  addEditListeners() {
    b(this, F, Wf).call(this), b(this, F, Xf).call(this);
  }
  removeEditListeners() {
    b(this, F, Gm).call(this), b(this, F, qf).call(this);
  }
  dragOver(t) {
    for (const {
      type: e
    } of t.dataTransfer.items)
      for (const s of n(this, Ks))
        if (s.isHandlingMimeForPasting(e)) {
          t.dataTransfer.dropEffect = "copy", t.preventDefault();
          return;
        }
  }
  drop(t) {
    for (const e of t.dataTransfer.items)
      for (const s of n(this, Ks))
        if (s.isHandlingMimeForPasting(e.type)) {
          s.paste(e, this.currentLayer), t.preventDefault();
          return;
        }
  }
  copy(t) {
    var s;
    if (t.preventDefault(), (s = n(this, ws)) == null || s.commitOrRemove(), !this.hasSelection)
      return;
    const e = [];
    for (const i of n(this, yt)) {
      const r = i.serialize(!0);
      r && e.push(r);
    }
    e.length !== 0 && t.clipboardData.setData("application/pdfjs", JSON.stringify(e));
  }
  cut(t) {
    this.copy(t), this.delete();
  }
  async paste(t) {
    t.preventDefault();
    const {
      clipboardData: e
    } = t;
    for (const r of e.items)
      for (const a of n(this, Ks))
        if (a.isHandlingMimeForPasting(r.type)) {
          a.paste(r, this.currentLayer);
          return;
        }
    let s = e.getData("application/pdfjs");
    if (!s)
      return;
    try {
      s = JSON.parse(s);
    } catch (r) {
      J(`paste: "${r.message}".`);
      return;
    }
    if (!Array.isArray(s))
      return;
    this.unselectAll();
    const i = this.currentLayer;
    try {
      const r = [];
      for (const l of s) {
        const h = await i.deserialize(l);
        if (!h)
          return;
        r.push(h);
      }
      const a = () => {
        for (const l of r)
          b(this, F, Yf).call(this, l);
        b(this, F, Kf).call(this, r);
      }, o = () => {
        for (const l of r)
          l.remove();
      };
      this.addCommands({
        cmd: a,
        undo: o,
        mustExec: !0
      });
    } catch (r) {
      J(`paste: "${r.message}".`);
    }
  }
  keydown(t) {
    !this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !0), n(this, re) !== Z.NONE && !this.isEditorHandlingKeyboard && Lo._keyboardManager.exec(this, t);
  }
  keyup(t) {
    this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !1, n(this, rr) && (p(this, rr, !1), b(this, F, _h).call(this, "main_toolbar")));
  }
  onEditingAction({
    name: t
  }) {
    switch (t) {
      case "undo":
      case "redo":
      case "delete":
      case "selectAll":
        this[t]();
        break;
      case "highlightSelection":
        this.highlightSelection("context_menu");
        break;
      case "commentSelection":
        this.commentSelection("context_menu");
        break;
    }
  }
  setEditingState(t) {
    t ? (b(this, F, Vm).call(this), b(this, F, Xf).call(this), b(this, F, Ze).call(this, {
      isEditing: n(this, re) !== Z.NONE,
      isEmpty: b(this, F, Ch).call(this),
      hasSomethingToUndo: n(this, Ys).hasSomethingToUndo(),
      hasSomethingToRedo: n(this, Ys).hasSomethingToRedo(),
      hasSelectedEditor: !1
    })) : (b(this, F, zm).call(this), b(this, F, qf).call(this), b(this, F, Ze).call(this, {
      isEditing: !1
    }), this.disableUserSelect(!1));
  }
  registerEditorTypes(t) {
    if (!n(this, Ks)) {
      p(this, Ks, t);
      for (const e of n(this, Ks))
        b(this, F, nn).call(this, e.defaultPropertiesToUpdate);
    }
  }
  getId() {
    return n(this, Ku).id;
  }
  get currentLayer() {
    return n(this, ce).get(n(this, Xo));
  }
  getLayer(t) {
    return n(this, ce).get(t);
  }
  get currentPageIndex() {
    return n(this, Xo);
  }
  addLayer(t) {
    n(this, ce).set(t.pageIndex, t), n(this, ar) ? t.enable() : t.disable();
  }
  removeLayer(t) {
    n(this, ce).delete(t.pageIndex);
  }
  async updateMode(t, e = null, s = !1, i = !1, r = !1) {
    var a, o, l, h, c, u;
    if (n(this, re) !== t && !(n(this, Zs) && (await n(this, Zs).promise, !n(this, Zs)))) {
      if (p(this, Zs, Promise.withResolvers()), (a = n(this, sr)) == null || a.commitOrRemove(), n(this, re) === Z.POPUP && ((o = n(this, Ue)) == null || o.hideSidebar()), (l = n(this, Ue)) == null || l.destroyPopup(), p(this, re, t), t === Z.NONE) {
        this.setEditingState(!1), b(this, F, Xm).call(this);
        for (const f of n(this, Xt).values())
          f.hideStandaloneCommentButton();
        (h = this._editorUndoBar) == null || h.hide(), this.toggleComment(null), n(this, Zs).resolve();
        return;
      }
      for (const f of n(this, Xt).values())
        f.addStandaloneCommentButton();
      t === Z.SIGNATURE && await ((c = n(this, hr)) == null ? void 0 : c.loadSignatures()), this.setEditingState(!0), await b(this, F, Wm).call(this), this.unselectAll();
      for (const f of n(this, ce).values())
        f.updateMode(t);
      if (t === Z.POPUP) {
        n(this, Go) || p(this, Go, await n(this, Jo).getAnnotationsByType(new Set(n(this, Ks).map((A) => A._editorType))));
        const f = /* @__PURE__ */ new Set(), m = [];
        for (const A of n(this, Xt).values()) {
          const {
            annotationElementId: y,
            hasComment: v,
            deleted: w
          } = A;
          y && f.add(y), v && !w && m.push(A.getData());
        }
        for (const A of n(this, Go)) {
          const {
            id: y,
            popupRef: v,
            contentsObj: w
          } = A;
          v && (w != null && w.str) && !f.has(y) && !n(this, ir).has(y) && m.push(A);
        }
        (u = n(this, Ue)) == null || u.showSidebar(m);
      }
      if (!e) {
        s && this.addNewEditorFromKeyboard(), n(this, Zs).resolve();
        return;
      }
      for (const f of n(this, Xt).values())
        f.uid === e ? (this.setSelected(f), r ? f.editComment() : i ? f.enterInEditMode() : f.focus()) : f.unselect();
      n(this, Zs).resolve();
    }
  }
  addNewEditorFromKeyboard() {
    this.currentLayer.canCreateNewEmptyEditor() && this.currentLayer.addNewEditor();
  }
  updateToolbar(t) {
    t.mode !== n(this, re) && this._eventBus.dispatch("switchannotationeditormode", {
      source: this,
      ...t
    });
  }
  updateParams(t, e) {
    if (n(this, Ks)) {
      switch (t) {
        case ht.CREATE:
          this.currentLayer.addNewEditor(e);
          return;
        case ht.HIGHLIGHT_SHOW_ALL:
          this._eventBus.dispatch("reporttelemetry", {
            source: this,
            details: {
              type: "editing",
              data: {
                type: "highlight",
                action: "toggle_visibility"
              }
            }
          }), (n(this, cc) || p(this, cc, /* @__PURE__ */ new Map())).set(t, e), this.showAllEditors("highlight", e);
          break;
      }
      if (this.hasSelection)
        for (const s of n(this, yt))
          s.updateParams(t, e);
      else
        for (const s of n(this, Ks))
          s.updateDefaultParams(t, e);
    }
  }
  showAllEditors(t, e, s = !1) {
    var r;
    for (const a of n(this, Xt).values())
      a.editorType === t && a.show(e);
    (((r = n(this, cc)) == null ? void 0 : r.get(ht.HIGHLIGHT_SHOW_ALL)) ?? !0) !== e && b(this, F, nn).call(this, [[ht.HIGHLIGHT_SHOW_ALL, e]]);
  }
  enableWaiting(t = !1) {
    if (n(this, lc) !== t) {
      p(this, lc, t);
      for (const e of n(this, ce).values())
        t ? e.disableClick() : e.enableClick(), e.div.classList.toggle("waiting", t);
    }
  }
  *getEditors(t) {
    for (const e of n(this, Xt).values())
      e.pageIndex === t && (yield e);
  }
  getEditor(t) {
    return n(this, Xt).get(t);
  }
  addEditor(t) {
    n(this, Xt).set(t.id, t);
  }
  removeEditor(t) {
    var e, s;
    t.div.contains(document.activeElement) && (n(this, Ri) && clearTimeout(n(this, Ri)), p(this, Ri, setTimeout(() => {
      this.focusMainContainer(), p(this, Ri, null);
    }, 0))), n(this, Xt).delete(t.id), t.annotationElementId && ((e = n(this, lr)) == null || e.delete(t.annotationElementId)), this.unselect(t), (!t.annotationElementId || !n(this, ir).has(t.annotationElementId)) && ((s = n(this, qs)) == null || s.remove(t.id));
  }
  addDeletedAnnotationElement(t) {
    n(this, ir).add(t.annotationElementId), this.addChangedExistingAnnotation(t), t.deleted = !0;
  }
  isDeletedAnnotationElement(t) {
    return n(this, ir).has(t);
  }
  removeDeletedAnnotationElement(t) {
    n(this, ir).delete(t.annotationElementId), this.removeChangedExistingAnnotation(t), t.deleted = !1;
  }
  setActiveEditor(t) {
    n(this, ws) !== t && (p(this, ws, t), t && b(this, F, nn).call(this, t.propertiesToUpdate));
  }
  updateUI(t) {
    n(this, F, qm) === t && b(this, F, nn).call(this, t.propertiesToUpdate);
  }
  updateUIForDefaultProperties(t) {
    b(this, F, nn).call(this, t.defaultPropertiesToUpdate);
  }
  toggleSelected(t) {
    if (n(this, yt).has(t)) {
      n(this, yt).delete(t), t.unselect(), b(this, F, Ze).call(this, {
        hasSelectedEditor: this.hasSelection
      });
      return;
    }
    n(this, yt).add(t), t.select(), b(this, F, nn).call(this, t.propertiesToUpdate), b(this, F, Ze).call(this, {
      hasSelectedEditor: !0
    });
  }
  setSelected(t) {
    var e;
    this.updateToolbar({
      mode: t.mode,
      editId: t.id
    }), (e = n(this, sr)) == null || e.commitOrRemove();
    for (const s of n(this, yt))
      s !== t && s.unselect();
    n(this, yt).clear(), n(this, yt).add(t), t.select(), b(this, F, nn).call(this, t.propertiesToUpdate), b(this, F, Ze).call(this, {
      hasSelectedEditor: !0
    });
  }
  isSelected(t) {
    return n(this, yt).has(t);
  }
  get firstSelectedEditor() {
    return n(this, yt).values().next().value;
  }
  unselect(t) {
    t.unselect(), n(this, yt).delete(t), b(this, F, Ze).call(this, {
      hasSelectedEditor: this.hasSelection
    });
  }
  get hasSelection() {
    return n(this, yt).size !== 0;
  }
  get isEnterHandled() {
    return n(this, yt).size === 1 && this.firstSelectedEditor.isEnterHandled;
  }
  undo() {
    var t;
    n(this, Ys).undo(), b(this, F, Ze).call(this, {
      hasSomethingToUndo: n(this, Ys).hasSomethingToUndo(),
      hasSomethingToRedo: !0,
      isEmpty: b(this, F, Ch).call(this)
    }), (t = this._editorUndoBar) == null || t.hide();
  }
  redo() {
    n(this, Ys).redo(), b(this, F, Ze).call(this, {
      hasSomethingToUndo: !0,
      hasSomethingToRedo: n(this, Ys).hasSomethingToRedo(),
      isEmpty: b(this, F, Ch).call(this)
    });
  }
  addCommands(t) {
    n(this, Ys).add(t), b(this, F, Ze).call(this, {
      hasSomethingToUndo: !0,
      hasSomethingToRedo: !1,
      isEmpty: b(this, F, Ch).call(this)
    });
  }
  cleanUndoStack(t) {
    n(this, Ys).cleanType(t);
  }
  delete() {
    var r;
    this.commitOrRemove();
    const t = (r = this.currentLayer) == null ? void 0 : r.endDrawingSession(!0);
    if (!this.hasSelection && !t)
      return;
    const e = t ? [t] : [...n(this, yt)], s = () => {
      var a;
      (a = this._editorUndoBar) == null || a.show(i, e.length === 1 ? e[0].editorType : e.length);
      for (const o of e)
        o.remove();
    }, i = () => {
      for (const a of e)
        b(this, F, Yf).call(this, a);
    };
    this.addCommands({
      cmd: s,
      undo: i,
      mustExec: !0
    });
  }
  commitOrRemove() {
    var t;
    (t = n(this, ws)) == null || t.commitOrRemove();
  }
  hasSomethingToControl() {
    return n(this, ws) || this.hasSelection;
  }
  selectAll() {
    for (const t of n(this, yt))
      t.commit();
    b(this, F, Kf).call(this, n(this, Xt).values());
  }
  unselectAll() {
    var t;
    if (!(n(this, ws) && (n(this, ws).commitOrRemove(), n(this, re) !== Z.NONE)) && !((t = n(this, sr)) != null && t.commitOrRemove()) && this.hasSelection) {
      for (const e of n(this, yt))
        e.unselect();
      n(this, yt).clear(), b(this, F, Ze).call(this, {
        hasSelectedEditor: !1
      });
    }
  }
  translateSelectedEditors(t, e, s = !1) {
    if (s || this.commitOrRemove(), !this.hasSelection)
      return;
    n(this, dr)[0] += t, n(this, dr)[1] += e;
    const [i, r] = n(this, dr), a = [...n(this, yt)], o = 1e3;
    n(this, ki) && clearTimeout(n(this, ki)), p(this, ki, setTimeout(() => {
      p(this, ki, null), n(this, dr)[0] = n(this, dr)[1] = 0, this.addCommands({
        cmd: () => {
          for (const l of a)
            n(this, Xt).has(l.id) && (l.translateInPage(i, r), l.translationDone());
        },
        undo: () => {
          for (const l of a)
            n(this, Xt).has(l.id) && (l.translateInPage(-i, -r), l.translationDone());
        },
        mustExec: !1
      });
    }, o));
    for (const l of a)
      l.translateInPage(t, e), l.translationDone();
  }
  setUpDragSession() {
    if (this.hasSelection) {
      this.disableUserSelect(!0), p(this, Pi, /* @__PURE__ */ new Map());
      for (const t of n(this, yt))
        n(this, Pi).set(t, {
          savedX: t.x,
          savedY: t.y,
          savedPageIndex: t.pageIndex,
          newX: 0,
          newY: 0,
          newPageIndex: -1
        });
    }
  }
  endDragSession() {
    if (!n(this, Pi))
      return !1;
    this.disableUserSelect(!1);
    const t = n(this, Pi);
    p(this, Pi, null);
    let e = !1;
    for (const [{
      x: i,
      y: r,
      pageIndex: a
    }, o] of t)
      o.newX = i, o.newY = r, o.newPageIndex = a, e || (e = i !== o.savedX || r !== o.savedY || a !== o.savedPageIndex);
    if (!e)
      return !1;
    const s = (i, r, a, o) => {
      if (n(this, Xt).has(i.id)) {
        const l = n(this, ce).get(o);
        l ? i._setParentAndPosition(l, r, a) : (i.pageIndex = o, i.x = r, i.y = a);
      }
    };
    return this.addCommands({
      cmd: () => {
        for (const [i, {
          newX: r,
          newY: a,
          newPageIndex: o
        }] of t)
          s(i, r, a, o);
      },
      undo: () => {
        for (const [i, {
          savedX: r,
          savedY: a,
          savedPageIndex: o
        }] of t)
          s(i, r, a, o);
      },
      mustExec: !0
    }), !0;
  }
  dragSelectedEditors(t, e) {
    if (n(this, Pi))
      for (const s of n(this, Pi).keys())
        s.drag(t, e);
  }
  rebuild(t) {
    if (t.parent === null) {
      const e = this.getLayer(t.pageIndex);
      e ? (e.changeParent(t), e.addOrRebuild(t)) : (this.addEditor(t), this.addToAnnotationStorage(t), t.rebuild());
    } else
      t.parent.addOrRebuild(t);
  }
  get isEditorHandlingKeyboard() {
    var t;
    return ((t = this.getActive()) == null ? void 0 : t.shouldGetKeyboardEvents()) || n(this, yt).size === 1 && this.firstSelectedEditor.shouldGetKeyboardEvents();
  }
  isActive(t) {
    return n(this, ws) === t;
  }
  getActive() {
    return n(this, ws);
  }
  getMode() {
    return n(this, re);
  }
  isEditingMode() {
    return n(this, re) !== Z.NONE;
  }
  get imageManager() {
    return it(this, "imageManager", new zf());
  }
  getSelectionBoxes(t) {
    if (!t)
      return null;
    const e = document.getSelection();
    for (let h = 0, c = e.rangeCount; h < c; h++)
      if (!t.contains(e.getRangeAt(h).commonAncestorContainer))
        return null;
    const {
      x: s,
      y: i,
      width: r,
      height: a
    } = t.getBoundingClientRect();
    let o;
    switch (t.getAttribute("data-main-rotation")) {
      case "90":
        o = (h, c, u, f) => ({
          x: (c - i) / a,
          y: 1 - (h + u - s) / r,
          width: f / a,
          height: u / r
        });
        break;
      case "180":
        o = (h, c, u, f) => ({
          x: 1 - (h + u - s) / r,
          y: 1 - (c + f - i) / a,
          width: u / r,
          height: f / a
        });
        break;
      case "270":
        o = (h, c, u, f) => ({
          x: 1 - (c + f - i) / a,
          y: (h - s) / r,
          width: f / a,
          height: u / r
        });
        break;
      default:
        o = (h, c, u, f) => ({
          x: (h - s) / r,
          y: (c - i) / a,
          width: u / r,
          height: f / a
        });
        break;
    }
    const l = [];
    for (let h = 0, c = e.rangeCount; h < c; h++) {
      const u = e.getRangeAt(h);
      if (!u.collapsed)
        for (const {
          x: f,
          y: m,
          width: A,
          height: y
        } of u.getClientRects())
          A === 0 || y === 0 || l.push(o(f, m, A, y));
    }
    return l.length === 0 ? null : l;
  }
  addChangedExistingAnnotation({
    annotationElementId: t,
    id: e
  }) {
    (n(this, Wo) || p(this, Wo, /* @__PURE__ */ new Map())).set(t, e);
  }
  removeChangedExistingAnnotation({
    annotationElementId: t
  }) {
    var e;
    (e = n(this, Wo)) == null || e.delete(t);
  }
  renderAnnotationElement(t) {
    var i;
    const e = (i = n(this, Wo)) == null ? void 0 : i.get(t.data.id);
    if (!e)
      return;
    const s = n(this, qs).getRawValue(e);
    s && (n(this, re) === Z.NONE && !s.hasBeenModified || s.renderAnnotationElement(t));
  }
  setMissingCanvas(t, e, s) {
    var r;
    const i = (r = n(this, lr)) == null ? void 0 : r.get(t);
    i && (i.setCanvas(e, s), n(this, lr).delete(t));
  }
  addMissingCanvas(t, e) {
    (n(this, lr) || p(this, lr, /* @__PURE__ */ new Map())).set(t, e);
  }
};
zo = new WeakMap(), ws = new WeakMap(), Go = new WeakMap(), Xt = new WeakMap(), ce = new WeakMap(), jo = new WeakMap(), qs = new WeakMap(), Wo = new WeakMap(), Ys = new WeakMap(), Ue = new WeakMap(), er = new WeakMap(), sr = new WeakMap(), Xo = new WeakMap(), ir = new WeakMap(), Pi = new WeakMap(), Ks = new WeakMap(), aa = new WeakMap(), rc = new WeakMap(), ac = new WeakMap(), qo = new WeakMap(), oc = new WeakMap(), Ri = new WeakMap(), nr = new WeakMap(), Yo = new WeakMap(), rr = new WeakMap(), Mi = new WeakMap(), Ku = new WeakMap(), ar = new WeakMap(), Ko = new WeakMap(), lc = new WeakMap(), or = new WeakMap(), oa = new WeakMap(), Zo = new WeakMap(), lr = new WeakMap(), hc = new WeakMap(), re = new WeakMap(), yt = new WeakMap(), hn = new WeakMap(), hr = new WeakMap(), cr = new WeakMap(), cc = new WeakMap(), Jo = new WeakMap(), dc = new WeakMap(), dr = new WeakMap(), ki = new WeakMap(), cn = new WeakMap(), uc = new WeakMap(), fc = new WeakMap(), Zs = new WeakMap(), F = new WeakSet(), nu = function({
  anchorNode: t
}) {
  return t.nodeType === Node.TEXT_NODE ? t.parentElement : t;
}, jf = function(t) {
  const {
    currentLayer: e
  } = this;
  if (e.hasTextLayer(t))
    return e;
  for (const s of n(this, ce).values())
    if (s.hasTextLayer(t))
      return s;
  return null;
}, Hm = function() {
  const t = document.getSelection();
  if (!t || t.isCollapsed)
    return;
  const s = b(this, F, nu).call(this, t).closest(".textLayer"), i = this.getSelectionBoxes(s);
  i && (n(this, Mi) || p(this, Mi, new yy(this)), n(this, Mi).show(s, i, this.direction === "ltr"));
}, Um = function() {
  var r, a, o;
  const t = document.getSelection();
  if (!t || t.isCollapsed) {
    n(this, hn) && ((r = n(this, Mi)) == null || r.hide(), p(this, hn, null), b(this, F, Ze).call(this, {
      hasSelectedText: !1
    }));
    return;
  }
  const {
    anchorNode: e
  } = t;
  if (e === n(this, hn))
    return;
  const i = b(this, F, nu).call(this, t).closest(".textLayer");
  if (!i) {
    n(this, hn) && ((a = n(this, Mi)) == null || a.hide(), p(this, hn, null), b(this, F, Ze).call(this, {
      hasSelectedText: !1
    }));
    return;
  }
  if ((o = n(this, Mi)) == null || o.hide(), p(this, hn, e), b(this, F, Ze).call(this, {
    hasSelectedText: !0
  }), !(n(this, re) !== Z.HIGHLIGHT && n(this, re) !== Z.NONE) && (n(this, re) === Z.HIGHLIGHT && this.showAllEditors("highlight", !0, !0), p(this, rr, this.isShiftKeyDown), !this.isShiftKeyDown)) {
    const l = n(this, re) === Z.HIGHLIGHT ? b(this, F, jf).call(this, i) : null;
    if (l == null || l.toggleDrawing(), n(this, Ko)) {
      const h = new AbortController(), c = this.combinedSignal(h), u = (f) => {
        f.type === "pointerup" && f.button !== 0 || (h.abort(), l == null || l.toggleDrawing(!0), f.type === "pointerup" && b(this, F, _h).call(this, "main_toolbar"));
      };
      window.addEventListener("pointerup", u, {
        signal: c
      }), window.addEventListener("blur", u, {
        signal: c
      });
    } else
      l == null || l.toggleDrawing(!0), b(this, F, _h).call(this, "main_toolbar");
  }
}, _h = function(t = "") {
  n(this, re) === Z.HIGHLIGHT ? this.highlightSelection(t) : n(this, rc) && b(this, F, Hm).call(this);
}, $m = function() {
  document.addEventListener("selectionchange", b(this, F, Um).bind(this), {
    signal: this._signal
  });
}, Vm = function() {
  if (n(this, nr))
    return;
  p(this, nr, new AbortController());
  const t = this.combinedSignal(n(this, nr));
  window.addEventListener("focus", this.focus.bind(this), {
    signal: t
  }), window.addEventListener("blur", this.blur.bind(this), {
    signal: t
  });
}, zm = function() {
  var t;
  (t = n(this, nr)) == null || t.abort(), p(this, nr, null);
}, Wf = function() {
  if (n(this, or))
    return;
  p(this, or, new AbortController());
  const t = this.combinedSignal(n(this, or));
  window.addEventListener("keydown", this.keydown.bind(this), {
    signal: t
  }), window.addEventListener("keyup", this.keyup.bind(this), {
    signal: t
  });
}, Gm = function() {
  var t;
  (t = n(this, or)) == null || t.abort(), p(this, or, null);
}, Xf = function() {
  if (n(this, er))
    return;
  p(this, er, new AbortController());
  const t = this.combinedSignal(n(this, er));
  document.addEventListener("copy", this.copy.bind(this), {
    signal: t
  }), document.addEventListener("cut", this.cut.bind(this), {
    signal: t
  }), document.addEventListener("paste", this.paste.bind(this), {
    signal: t
  });
}, qf = function() {
  var t;
  (t = n(this, er)) == null || t.abort(), p(this, er, null);
}, jm = function() {
  const t = this._signal;
  document.addEventListener("dragover", this.dragOver.bind(this), {
    signal: t
  }), document.addEventListener("drop", this.drop.bind(this), {
    signal: t
  });
}, Ze = function(t) {
  Object.entries(t).some(([s, i]) => n(this, dc)[s] !== i) && (this._eventBus.dispatch("annotationeditorstateschanged", {
    source: this,
    details: Object.assign(n(this, dc), t)
  }), n(this, re) === Z.HIGHLIGHT && t.hasSelectedEditor === !1 && b(this, F, nn).call(this, [[ht.HIGHLIGHT_FREE, !0]]));
}, nn = function(t) {
  this._eventBus.dispatch("annotationeditorparamschanged", {
    source: this,
    details: t
  });
}, Wm = async function() {
  if (!n(this, ar)) {
    p(this, ar, !0);
    const t = [];
    for (const e of n(this, ce).values())
      t.push(e.enable());
    await Promise.all(t);
    for (const e of n(this, Xt).values())
      e.enable();
  }
}, Xm = function() {
  if (this.unselectAll(), n(this, ar)) {
    p(this, ar, !1);
    for (const t of n(this, ce).values())
      t.disable();
    for (const t of n(this, Xt).values())
      t.disable();
  }
}, Yf = function(t) {
  const e = n(this, ce).get(t.pageIndex);
  e ? e.addOrRebuild(t) : (this.addEditor(t), this.addToAnnotationStorage(t));
}, qm = function() {
  let t = null;
  for (t of n(this, yt))
    ;
  return t;
}, Ch = function() {
  if (n(this, Xt).size === 0)
    return !0;
  if (n(this, Xt).size === 1)
    for (const t of n(this, Xt).values())
      return t.isEmpty();
  return !1;
}, Kf = function(t) {
  for (const e of n(this, yt))
    e.unselect();
  n(this, yt).clear();
  for (const e of t)
    e.isEmpty() || (n(this, yt).add(e), e.select());
  b(this, F, Ze).call(this, {
    hasSelectedEditor: this.hasSelection
  });
}, L(Lo, "TRANSLATE_SMALL", 1), L(Lo, "TRANSLATE_BIG", 10);
let Wr = Lo;
var me, Li, ci, Qo, Di, vs, tl, Ii, hs, dn, la, Fi, ur, Ei, Th, ru;
const Je = class Je {
  constructor(t) {
    g(this, Ei);
    g(this, me, null);
    g(this, Li, !1);
    g(this, ci, null);
    g(this, Qo, null);
    g(this, Di, null);
    g(this, vs, null);
    g(this, tl, !1);
    g(this, Ii, null);
    g(this, hs, null);
    g(this, dn, null);
    g(this, la, null);
    g(this, Fi, !1);
    p(this, hs, t), p(this, Fi, t._uiManager.useNewAltTextFlow), n(Je, ur) || p(Je, ur, Object.freeze({
      added: "pdfjs-editor-new-alt-text-added-button",
      "added-label": "pdfjs-editor-new-alt-text-added-button-label",
      missing: "pdfjs-editor-new-alt-text-missing-button",
      "missing-label": "pdfjs-editor-new-alt-text-missing-button-label",
      review: "pdfjs-editor-new-alt-text-to-review-button",
      "review-label": "pdfjs-editor-new-alt-text-to-review-button-label"
    }));
  }
  static initialize(t) {
    Je._l10n ?? (Je._l10n = t);
  }
  async render() {
    const t = p(this, ci, document.createElement("button"));
    t.className = "altText", t.tabIndex = "0";
    const e = p(this, Qo, document.createElement("span"));
    t.append(e), n(this, Fi) ? (t.classList.add("new"), t.setAttribute("data-l10n-id", n(Je, ur).missing), e.setAttribute("data-l10n-id", n(Je, ur)["missing-label"])) : (t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button"), e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button-label"));
    const s = n(this, hs)._uiManager._signal;
    t.addEventListener("contextmenu", $s, {
      signal: s
    }), t.addEventListener("pointerdown", (r) => r.stopPropagation(), {
      signal: s
    });
    const i = (r) => {
      r.preventDefault(), n(this, hs)._uiManager.editAltText(n(this, hs)), n(this, Fi) && n(this, hs)._reportTelemetry({
        action: "pdfjs.image.alt_text.image_status_label_clicked",
        data: {
          label: n(this, Ei, Th)
        }
      });
    };
    return t.addEventListener("click", i, {
      capture: !0,
      signal: s
    }), t.addEventListener("keydown", (r) => {
      r.target === t && r.key === "Enter" && (p(this, tl, !0), i(r));
    }, {
      signal: s
    }), await b(this, Ei, ru).call(this), t;
  }
  finish() {
    n(this, ci) && (n(this, ci).focus({
      focusVisible: n(this, tl)
    }), p(this, tl, !1));
  }
  isEmpty() {
    return n(this, Fi) ? n(this, me) === null : !n(this, me) && !n(this, Li);
  }
  hasData() {
    return n(this, Fi) ? n(this, me) !== null || !!n(this, dn) : this.isEmpty();
  }
  get guessedText() {
    return n(this, dn);
  }
  async setGuessedText(t) {
    n(this, me) === null && (p(this, dn, t), p(this, la, await Je._l10n.get("pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer", {
      generatedAltText: t
    })), b(this, Ei, ru).call(this));
  }
  toggleAltTextBadge(t = !1) {
    var e;
    if (!n(this, Fi) || n(this, me)) {
      (e = n(this, Ii)) == null || e.remove(), p(this, Ii, null);
      return;
    }
    if (!n(this, Ii)) {
      const s = p(this, Ii, document.createElement("div"));
      s.className = "noAltTextBadge", n(this, hs).div.append(s);
    }
    n(this, Ii).classList.toggle("hidden", !t);
  }
  serialize(t) {
    let e = n(this, me);
    return !t && n(this, dn) === e && (e = n(this, la)), {
      altText: e,
      decorative: n(this, Li),
      guessedText: n(this, dn),
      textWithDisclaimer: n(this, la)
    };
  }
  get data() {
    return {
      altText: n(this, me),
      decorative: n(this, Li)
    };
  }
  set data({
    altText: t,
    decorative: e,
    guessedText: s,
    textWithDisclaimer: i,
    cancel: r = !1
  }) {
    s && (p(this, dn, s), p(this, la, i)), !(n(this, me) === t && n(this, Li) === e) && (r || (p(this, me, t), p(this, Li, e)), b(this, Ei, ru).call(this));
  }
  toggle(t = !1) {
    n(this, ci) && (!t && n(this, vs) && (clearTimeout(n(this, vs)), p(this, vs, null)), n(this, ci).disabled = !t);
  }
  shown() {
    n(this, hs)._reportTelemetry({
      action: "pdfjs.image.alt_text.image_status_label_displayed",
      data: {
        label: n(this, Ei, Th)
      }
    });
  }
  destroy() {
    var t, e;
    (t = n(this, ci)) == null || t.remove(), p(this, ci, null), p(this, Qo, null), p(this, Di, null), (e = n(this, Ii)) == null || e.remove(), p(this, Ii, null);
  }
};
me = new WeakMap(), Li = new WeakMap(), ci = new WeakMap(), Qo = new WeakMap(), Di = new WeakMap(), vs = new WeakMap(), tl = new WeakMap(), Ii = new WeakMap(), hs = new WeakMap(), dn = new WeakMap(), la = new WeakMap(), Fi = new WeakMap(), ur = new WeakMap(), Ei = new WeakSet(), Th = function() {
  return n(this, me) && "added" || n(this, me) === null && this.guessedText && "review" || "missing";
}, ru = async function() {
  var i, r, a;
  const t = n(this, ci);
  if (!t)
    return;
  if (n(this, Fi)) {
    if (t.classList.toggle("done", !!n(this, me)), t.setAttribute("data-l10n-id", n(Je, ur)[n(this, Ei, Th)]), (i = n(this, Qo)) == null || i.setAttribute("data-l10n-id", n(Je, ur)[`${n(this, Ei, Th)}-label`]), !n(this, me)) {
      (r = n(this, Di)) == null || r.remove();
      return;
    }
  } else {
    if (!n(this, me) && !n(this, Li)) {
      t.classList.remove("done"), (a = n(this, Di)) == null || a.remove();
      return;
    }
    t.classList.add("done"), t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-edit-button");
  }
  let e = n(this, Di);
  if (!e) {
    p(this, Di, e = document.createElement("span")), e.className = "tooltip", e.setAttribute("role", "tooltip"), e.id = `alt-text-tooltip-${n(this, hs).id}`;
    const o = 100, l = n(this, hs)._uiManager._signal;
    l.addEventListener("abort", () => {
      clearTimeout(n(this, vs)), p(this, vs, null);
    }, {
      once: !0
    }), t.addEventListener("mouseenter", () => {
      p(this, vs, setTimeout(() => {
        p(this, vs, null), n(this, Di).classList.add("show"), n(this, hs)._reportTelemetry({
          action: "alt_text_tooltip"
        });
      }, o));
    }, {
      signal: l
    }), t.addEventListener("mouseleave", () => {
      var h;
      n(this, vs) && (clearTimeout(n(this, vs)), p(this, vs, null)), (h = n(this, Di)) == null || h.classList.remove("show");
    }, {
      signal: l
    });
  }
  n(this, Li) ? e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-decorative-tooltip") : (e.removeAttribute("data-l10n-id"), e.textContent = n(this, me)), e.parentNode || t.append(e);
  const s = n(this, hs).getElementForAltText();
  s == null || s.setAttribute("aria-describedby", e.id);
}, g(Je, ur, null), L(Je, "_l10n", null);
let Nu = Je;
var Pe, Js, ha, It, pc, ca, di, da, ua, fa, gc, Zf;
class Xd {
  constructor(t) {
    g(this, gc);
    g(this, Pe, null);
    g(this, Js, null);
    g(this, ha, !1);
    g(this, It, null);
    g(this, pc, null);
    g(this, ca, null);
    g(this, di, null);
    g(this, da, null);
    g(this, ua, !1);
    g(this, fa, null);
    p(this, It, t);
  }
  renderForToolbar() {
    const t = p(this, Js, document.createElement("button"));
    return t.className = "comment", b(this, gc, Zf).call(this, t, !1);
  }
  renderForStandalone() {
    const t = p(this, Pe, document.createElement("button"));
    t.className = "annotationCommentButton";
    const e = n(this, It).commentButtonPosition;
    if (e) {
      const {
        style: s
      } = t;
      s.insetInlineEnd = `calc(${100 * (n(this, It)._uiManager.direction === "ltr" ? 1 - e[0] : e[0])}% - var(--comment-button-dim))`, s.top = `calc(${100 * e[1]}% - var(--comment-button-dim))`;
      const i = n(this, It).commentButtonColor;
      i && (s.backgroundColor = i);
    }
    return b(this, gc, Zf).call(this, t, !0);
  }
  focusButton() {
    setTimeout(() => {
      var t;
      (t = n(this, Pe) ?? n(this, Js)) == null || t.focus();
    }, 0);
  }
  onUpdatedColor() {
    if (!n(this, Pe))
      return;
    const t = n(this, It).commentButtonColor;
    t && (n(this, Pe).style.backgroundColor = t), n(this, It)._uiManager.updatePopupColor(n(this, It));
  }
  get commentButtonWidth() {
    var t;
    return (((t = n(this, Pe)) == null ? void 0 : t.getBoundingClientRect().width) ?? 0) / n(this, It).parent.boundingClientRect.width;
  }
  get commentPopupPositionInLayer() {
    if (n(this, fa))
      return n(this, fa);
    if (!n(this, Pe))
      return null;
    const {
      x: t,
      y: e,
      height: s
    } = n(this, Pe).getBoundingClientRect(), {
      x: i,
      y: r,
      width: a,
      height: o
    } = n(this, It).parent.boundingClientRect;
    return [(t - i) / a, (e + s - r) / o];
  }
  set commentPopupPositionInLayer(t) {
    p(this, fa, t);
  }
  hasDefaultPopupPosition() {
    return n(this, fa) === null;
  }
  removeStandaloneCommentButton() {
    var t;
    (t = n(this, Pe)) == null || t.remove(), p(this, Pe, null);
  }
  removeToolbarCommentButton() {
    var t;
    (t = n(this, Js)) == null || t.remove(), p(this, Js, null);
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    n(this, Pe) && (n(this, Pe).classList.toggle("selected", t), n(this, Pe).ariaExpanded = e);
  }
  edit(t) {
    const e = this.commentPopupPositionInLayer;
    let s, i;
    if (e)
      [s, i] = e;
    else {
      [s, i] = n(this, It).commentButtonPosition;
      const {
        width: c,
        height: u,
        x: f,
        y: m
      } = n(this, It);
      s = f + s * c, i = m + i * u;
    }
    const r = n(this, It).parent.boundingClientRect, {
      x: a,
      y: o,
      width: l,
      height: h
    } = r;
    n(this, It)._uiManager.editComment(n(this, It), a + s * l, o + i * h, {
      ...t,
      parentDimensions: r
    });
  }
  finish() {
    n(this, Js) && (n(this, Js).focus({
      focusVisible: n(this, ha)
    }), p(this, ha, !1));
  }
  isDeleted() {
    return n(this, ua) || n(this, di) === "";
  }
  isEmpty() {
    return n(this, di) === null;
  }
  hasBeenEdited() {
    return this.isDeleted() || n(this, di) !== n(this, pc);
  }
  serialize() {
    return this.data;
  }
  get data() {
    return {
      text: n(this, di),
      richText: n(this, ca),
      date: n(this, da),
      deleted: this.isDeleted()
    };
  }
  set data(t) {
    if (t !== n(this, di) && p(this, ca, null), t === null) {
      p(this, di, ""), p(this, ua, !0);
      return;
    }
    p(this, di, t), p(this, da, /* @__PURE__ */ new Date()), p(this, ua, !1);
  }
  setInitialText(t, e = null) {
    p(this, pc, t), this.data = t, p(this, da, null), p(this, ca, e);
  }
  shown() {
  }
  destroy() {
    var t, e;
    (t = n(this, Js)) == null || t.remove(), p(this, Js, null), (e = n(this, Pe)) == null || e.remove(), p(this, Pe, null), p(this, di, ""), p(this, ca, null), p(this, da, null), p(this, It, null), p(this, ha, !1), p(this, ua, !1);
  }
}
Pe = new WeakMap(), Js = new WeakMap(), ha = new WeakMap(), It = new WeakMap(), pc = new WeakMap(), ca = new WeakMap(), di = new WeakMap(), da = new WeakMap(), ua = new WeakMap(), fa = new WeakMap(), gc = new WeakSet(), Zf = function(t, e) {
  if (!n(this, It)._uiManager.hasCommentManager())
    return null;
  t.tabIndex = "0", t.ariaHasPopup = "dialog", e ? (t.ariaControls = "commentPopup", t.setAttribute("data-l10n-id", "pdfjs-show-comment-button")) : (t.ariaControlsElements = [n(this, It)._uiManager.getCommentDialogElement()], t.setAttribute("data-l10n-id", "pdfjs-editor-edit-comment-button"));
  const s = n(this, It)._uiManager._signal;
  if (!(s instanceof AbortSignal) || s.aborted)
    return t;
  t.addEventListener("contextmenu", $s, {
    signal: s
  }), e && (t.addEventListener("focusin", (r) => {
    n(this, It)._focusEventsAllowed = !1, zt(r);
  }, {
    capture: !0,
    signal: s
  }), t.addEventListener("focusout", (r) => {
    n(this, It)._focusEventsAllowed = !0, zt(r);
  }, {
    capture: !0,
    signal: s
  })), t.addEventListener("pointerdown", (r) => r.stopPropagation(), {
    signal: s
  });
  const i = (r) => {
    r.preventDefault(), t === n(this, Js) ? this.edit() : n(this, It).toggleComment(!0);
  };
  return t.addEventListener("click", i, {
    capture: !0,
    signal: s
  }), t.addEventListener("keydown", (r) => {
    r.target === t && r.key === "Enter" && (p(this, ha, !0), i(r));
  }, {
    signal: s
  }), t.addEventListener("pointerenter", () => {
    n(this, It).toggleComment(!1, !0);
  }, {
    signal: s
  }), t.addEventListener("pointerleave", () => {
    n(this, It).toggleComment(!1, !1);
  }, {
    signal: s
  }), t;
};
var el, pa, mc, bc, yc, Ac, wc, un, ga, fn, ma, pn, Xr, Ym, Km, Zm;
const Pg = class Pg {
  constructor({
    container: t,
    isPinchingDisabled: e = null,
    isPinchingStopped: s = null,
    onPinchStart: i = null,
    onPinching: r = null,
    onPinchEnd: a = null,
    signal: o
  }) {
    g(this, Xr);
    g(this, el);
    g(this, pa, !1);
    g(this, mc, null);
    g(this, bc);
    g(this, yc);
    g(this, Ac);
    g(this, wc);
    g(this, un, null);
    g(this, ga);
    g(this, fn, null);
    g(this, ma);
    g(this, pn, null);
    p(this, el, t), p(this, mc, s), p(this, bc, e), p(this, yc, i), p(this, Ac, r), p(this, wc, a), p(this, ma, new AbortController()), p(this, ga, AbortSignal.any([o, n(this, ma).signal])), t.addEventListener("touchstart", b(this, Xr, Ym).bind(this), {
      passive: !1,
      signal: n(this, ga)
    });
  }
  get MIN_TOUCH_DISTANCE_TO_PINCH() {
    return 35 / Si.pixelRatio;
  }
  destroy() {
    var t, e;
    (t = n(this, ma)) == null || t.abort(), p(this, ma, null), (e = n(this, un)) == null || e.abort(), p(this, un, null);
  }
};
el = new WeakMap(), pa = new WeakMap(), mc = new WeakMap(), bc = new WeakMap(), yc = new WeakMap(), Ac = new WeakMap(), wc = new WeakMap(), un = new WeakMap(), ga = new WeakMap(), fn = new WeakMap(), ma = new WeakMap(), pn = new WeakMap(), Xr = new WeakSet(), Ym = function(t) {
  var i, r, a;
  if ((i = n(this, bc)) != null && i.call(this))
    return;
  if (t.touches.length === 1) {
    if (n(this, un))
      return;
    const o = p(this, un, new AbortController()), l = AbortSignal.any([n(this, ga), o.signal]), h = n(this, el), c = {
      capture: !0,
      signal: l,
      passive: !1
    }, u = (f) => {
      var m;
      f.pointerType === "touch" && ((m = n(this, un)) == null || m.abort(), p(this, un, null));
    };
    h.addEventListener("pointerdown", (f) => {
      f.pointerType === "touch" && (zt(f), u(f));
    }, c), h.addEventListener("pointerup", u, c), h.addEventListener("pointercancel", u, c);
    return;
  }
  if (!n(this, pn)) {
    p(this, pn, new AbortController());
    const o = AbortSignal.any([n(this, ga), n(this, pn).signal]), l = n(this, el), h = {
      signal: o,
      capture: !1,
      passive: !1
    };
    l.addEventListener("touchmove", b(this, Xr, Km).bind(this), h);
    const c = b(this, Xr, Zm).bind(this);
    l.addEventListener("touchend", c, h), l.addEventListener("touchcancel", c, h), h.capture = !0, l.addEventListener("pointerdown", zt, h), l.addEventListener("pointermove", zt, h), l.addEventListener("pointercancel", zt, h), l.addEventListener("pointerup", zt, h), (r = n(this, yc)) == null || r.call(this);
  }
  if (zt(t), t.touches.length !== 2 || (a = n(this, mc)) != null && a.call(this)) {
    p(this, fn, null);
    return;
  }
  let [e, s] = t.touches;
  e.identifier > s.identifier && ([e, s] = [s, e]), p(this, fn, {
    touch0X: e.screenX,
    touch0Y: e.screenY,
    touch1X: s.screenX,
    touch1Y: s.screenY
  });
}, Km = function(t) {
  var _;
  if (!n(this, fn) || t.touches.length !== 2)
    return;
  zt(t);
  let [e, s] = t.touches;
  e.identifier > s.identifier && ([e, s] = [s, e]);
  const {
    screenX: i,
    screenY: r
  } = e, {
    screenX: a,
    screenY: o
  } = s, l = n(this, fn), {
    touch0X: h,
    touch0Y: c,
    touch1X: u,
    touch1Y: f
  } = l, m = u - h, A = f - c, y = a - i, v = o - r, w = Math.hypot(y, v) || 1, S = Math.hypot(m, A) || 1;
  if (!n(this, pa) && Math.abs(S - w) <= Pg.MIN_TOUCH_DISTANCE_TO_PINCH)
    return;
  if (l.touch0X = i, l.touch0Y = r, l.touch1X = a, l.touch1Y = o, !n(this, pa)) {
    p(this, pa, !0);
    return;
  }
  const E = [(i + a) / 2, (r + o) / 2];
  (_ = n(this, Ac)) == null || _.call(this, E, S, w);
}, Zm = function(t) {
  var e;
  t.touches.length >= 2 || (n(this, pn) && (n(this, pn).abort(), p(this, pn, null), (e = n(this, wc)) == null || e.call(this)), n(this, fn) && (zt(t), p(this, fn, null), p(this, pa, !1)));
};
let qh = Pg;
var ba, ui, Ht, Rt, gn, sl, fr, vc, Re, ya, mn, Ni, pr, Ec, Aa, Es, Sc, wa, bn, Oi, il, nl, Qs, va, _c, Zu, q, Jf, Cc, Qf, au, Jm, Qm, tp, ou, ep, tb, eb, sb, sp, ib, ip, nb, rb, ab, np, xh;
const Q = class Q {
  constructor(t) {
    g(this, q);
    g(this, ba, null);
    g(this, ui, null);
    g(this, Ht, null);
    g(this, Rt, null);
    g(this, gn, null);
    g(this, sl, !1);
    g(this, fr, null);
    g(this, vc, "");
    g(this, Re, null);
    g(this, ya, null);
    g(this, mn, null);
    g(this, Ni, null);
    g(this, pr, null);
    g(this, Ec, "");
    g(this, Aa, !1);
    g(this, Es, null);
    g(this, Sc, !1);
    g(this, wa, !1);
    g(this, bn, !1);
    g(this, Oi, null);
    g(this, il, 0);
    g(this, nl, 0);
    g(this, Qs, null);
    g(this, va, null);
    L(this, "isSelected", !1);
    L(this, "_isCopy", !1);
    L(this, "_editToolbar", null);
    L(this, "_initialOptions", /* @__PURE__ */ Object.create(null));
    L(this, "_initialData", null);
    L(this, "_isVisible", !0);
    L(this, "_uiManager", null);
    L(this, "_focusEventsAllowed", !0);
    g(this, _c, !1);
    g(this, Zu, Q._zIndex++);
    this.parent = t.parent, this.id = t.id, this.width = this.height = null, this.pageIndex = t.parent.pageIndex, this.name = t.name, this.div = null, this._uiManager = t.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = t.isCentered, this._structTreeParentId = null, this.annotationElementId = t.annotationElementId || null, this.creationDate = t.creationDate || /* @__PURE__ */ new Date(), this.modificationDate = t.modificationDate || null;
    const {
      rotation: e,
      rawDims: {
        pageWidth: s,
        pageHeight: i,
        pageX: r,
        pageY: a
      }
    } = this.parent.viewport;
    this.rotation = e, this.pageRotation = (360 + e - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [s, i], this.pageTranslation = [r, a];
    const [o, l] = this.parentDimensions;
    this.x = t.x / o, this.y = t.y / l, this.isAttachedToDOM = !1, this.deleted = !1;
  }
  static get _resizerKeyboardManager() {
    const t = Q.prototype._resizeWithKeyboard, e = Wr.TRANSLATE_SMALL, s = Wr.TRANSLATE_BIG;
    return it(this, "_resizerKeyboardManager", new Od([[["ArrowLeft", "mac+ArrowLeft"], t, {
      args: [-e, 0]
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t, {
      args: [-s, 0]
    }], [["ArrowRight", "mac+ArrowRight"], t, {
      args: [e, 0]
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t, {
      args: [s, 0]
    }], [["ArrowUp", "mac+ArrowUp"], t, {
      args: [0, -e]
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t, {
      args: [0, -s]
    }], [["ArrowDown", "mac+ArrowDown"], t, {
      args: [0, e]
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t, {
      args: [0, s]
    }], [["Escape", "mac+Escape"], Q.prototype._stopResizingWithKeyboard]]));
  }
  get editorType() {
    return Object.getPrototypeOf(this).constructor._type;
  }
  get mode() {
    return Object.getPrototypeOf(this).constructor._editorType;
  }
  static get isDrawer() {
    return !1;
  }
  static get _defaultLineColor() {
    return it(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
  }
  static deleteAnnotationElement(t) {
    const e = new vy({
      id: t.parent.getNextId(),
      parent: t.parent,
      uiManager: t._uiManager
    });
    e.annotationElementId = t.annotationElementId, e.deleted = !0, e._uiManager.addToAnnotationStorage(e);
  }
  static initialize(t, e) {
    if (Q._l10n ?? (Q._l10n = t), Q._l10nResizer || (Q._l10nResizer = Object.freeze({
      topLeft: "pdfjs-editor-resizer-top-left",
      topMiddle: "pdfjs-editor-resizer-top-middle",
      topRight: "pdfjs-editor-resizer-top-right",
      middleRight: "pdfjs-editor-resizer-middle-right",
      bottomRight: "pdfjs-editor-resizer-bottom-right",
      bottomMiddle: "pdfjs-editor-resizer-bottom-middle",
      bottomLeft: "pdfjs-editor-resizer-bottom-left",
      middleLeft: "pdfjs-editor-resizer-middle-left"
    })), Q._borderLineWidth !== -1)
      return;
    const s = getComputedStyle(document.documentElement);
    Q._borderLineWidth = parseFloat(s.getPropertyValue("--outline-width")) || 0;
  }
  static updateDefaultParams(t, e) {
  }
  static get defaultPropertiesToUpdate() {
    return [];
  }
  static isHandlingMimeForPasting(t) {
    return !1;
  }
  static paste(t, e) {
    Dt("Not implemented");
  }
  get propertiesToUpdate() {
    return [];
  }
  get _isDraggable() {
    return n(this, _c);
  }
  set _isDraggable(t) {
    var e;
    p(this, _c, t), (e = this.div) == null || e.classList.toggle("draggable", t);
  }
  get uid() {
    return this.annotationElementId || this.id;
  }
  get isEnterHandled() {
    return !0;
  }
  center() {
    const [t, e] = this.pageDimensions;
    switch (this.parentRotation) {
      case 90:
        this.x -= this.height * e / (t * 2), this.y += this.width * t / (e * 2);
        break;
      case 180:
        this.x += this.width / 2, this.y += this.height / 2;
        break;
      case 270:
        this.x += this.height * e / (t * 2), this.y -= this.width * t / (e * 2);
        break;
      default:
        this.x -= this.width / 2, this.y -= this.height / 2;
        break;
    }
    this.fixAndSetPosition();
  }
  addCommands(t) {
    this._uiManager.addCommands(t);
  }
  get currentLayer() {
    return this._uiManager.currentLayer;
  }
  setInBackground() {
    this.div.style.zIndex = 0;
  }
  setInForeground() {
    this.div.style.zIndex = n(this, Zu);
  }
  setParent(t) {
    var e;
    t !== null ? (this.pageIndex = t.pageIndex, this.pageDimensions = t.pageDimensions) : (b(this, q, xh).call(this), (e = n(this, Ni)) == null || e.remove(), p(this, Ni, null)), this.parent = t;
  }
  focusin(t) {
    this._focusEventsAllowed && (n(this, Aa) ? p(this, Aa, !1) : this.parent.setSelected(this));
  }
  focusout(t) {
    var s;
    if (!this._focusEventsAllowed || !this.isAttachedToDOM)
      return;
    const e = t.relatedTarget;
    e != null && e.closest(`#${this.id}`) || (t.preventDefault(), (s = this.parent) != null && s.isMultipleSelection || this.commitOrRemove());
  }
  commitOrRemove() {
    this.isEmpty() ? this.remove() : this.commit();
  }
  commit() {
    this.isInEditMode() && this.addToAnnotationStorage();
  }
  addToAnnotationStorage() {
    this._uiManager.addToAnnotationStorage(this);
  }
  setAt(t, e, s, i) {
    const [r, a] = this.parentDimensions;
    [s, i] = this.screenToPageTranslation(s, i), this.x = (t + s) / r, this.y = (e + i) / a, this.fixAndSetPosition();
  }
  _moveAfterPaste(t, e) {
    const [s, i] = this.parentDimensions;
    this.setAt(t * s, e * i, this.width * s, this.height * i), this._onTranslated();
  }
  translate(t, e) {
    b(this, q, Jf).call(this, this.parentDimensions, t, e);
  }
  translateInPage(t, e) {
    n(this, Es) || p(this, Es, [this.x, this.y, this.width, this.height]), b(this, q, Jf).call(this, this.pageDimensions, t, e), this.div.scrollIntoView({
      block: "nearest"
    });
  }
  translationDone() {
    this._onTranslated(this.x, this.y);
  }
  drag(t, e) {
    n(this, Es) || p(this, Es, [this.x, this.y, this.width, this.height]);
    const {
      div: s,
      parentDimensions: [i, r]
    } = this;
    if (this.x += t / i, this.y += e / r, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
      const {
        x: u,
        y: f
      } = this.div.getBoundingClientRect();
      this.parent.findNewParent(this, u, f) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
    }
    let {
      x: a,
      y: o
    } = this;
    const [l, h] = this.getBaseTranslation();
    a += l, o += h;
    const {
      style: c
    } = s;
    c.left = `${(100 * a).toFixed(2)}%`, c.top = `${(100 * o).toFixed(2)}%`, this._onTranslating(a, o), s.scrollIntoView({
      block: "nearest"
    });
  }
  _onTranslating(t, e) {
  }
  _onTranslated(t, e) {
  }
  get _hasBeenMoved() {
    return !!n(this, Es) && (n(this, Es)[0] !== this.x || n(this, Es)[1] !== this.y);
  }
  get _hasBeenResized() {
    return !!n(this, Es) && (n(this, Es)[2] !== this.width || n(this, Es)[3] !== this.height);
  }
  getBaseTranslation() {
    const [t, e] = this.parentDimensions, {
      _borderLineWidth: s
    } = Q, i = s / t, r = s / e;
    switch (this.rotation) {
      case 90:
        return [-i, r];
      case 180:
        return [i, r];
      case 270:
        return [i, -r];
      default:
        return [-i, -r];
    }
  }
  get _mustFixPosition() {
    return !0;
  }
  fixAndSetPosition(t = this.rotation) {
    const {
      div: {
        style: e
      },
      pageDimensions: [s, i]
    } = this;
    let {
      x: r,
      y: a,
      width: o,
      height: l
    } = this;
    if (o *= s, l *= i, r *= s, a *= i, this._mustFixPosition)
      switch (t) {
        case 0:
          r = je(r, 0, s - o), a = je(a, 0, i - l);
          break;
        case 90:
          r = je(r, 0, s - l), a = je(a, o, i);
          break;
        case 180:
          r = je(r, o, s), a = je(a, l, i);
          break;
        case 270:
          r = je(r, l, s), a = je(a, 0, i - o);
          break;
      }
    this.x = r /= s, this.y = a /= i;
    const [h, c] = this.getBaseTranslation();
    r += h, a += c, e.left = `${(100 * r).toFixed(2)}%`, e.top = `${(100 * a).toFixed(2)}%`, this.moveInDOM();
  }
  screenToPageTranslation(t, e) {
    var s;
    return b(s = Q, Cc, Qf).call(s, t, e, this.parentRotation);
  }
  pageTranslationToScreen(t, e) {
    var s;
    return b(s = Q, Cc, Qf).call(s, t, e, 360 - this.parentRotation);
  }
  get parentScale() {
    return this._uiManager.viewParameters.realScale;
  }
  get parentRotation() {
    return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
  }
  get parentDimensions() {
    const {
      parentScale: t,
      pageDimensions: [e, s]
    } = this;
    return [e * t, s * t];
  }
  setDims() {
    const {
      div: {
        style: t
      },
      width: e,
      height: s
    } = this;
    t.width = `${(100 * e).toFixed(2)}%`, t.height = `${(100 * s).toFixed(2)}%`;
  }
  getInitialTranslation() {
    return [0, 0];
  }
  _onResized() {
  }
  static _round(t) {
    return Math.round(t * 1e4) / 1e4;
  }
  _onResizing() {
  }
  altTextFinish() {
    var t;
    (t = n(this, Ht)) == null || t.finish();
  }
  get toolbarButtons() {
    return null;
  }
  async addEditToolbar() {
    if (this._editToolbar || n(this, wa))
      return this._editToolbar;
    this._editToolbar = new $f(this), this.div.append(this._editToolbar.render());
    const {
      toolbarButtons: t
    } = this;
    if (t)
      for (const [e, s] of t)
        await this._editToolbar.addButton(e, s);
    return this.hasComment || this._editToolbar.addButton("comment", this.addCommentButton()), this._editToolbar.addButton("delete"), this._editToolbar;
  }
  addCommentButtonInToolbar() {
    var t;
    (t = this._editToolbar) == null || t.addButtonBefore("comment", this.addCommentButton(), ".deleteButton");
  }
  removeCommentButtonFromToolbar() {
    var t;
    (t = this._editToolbar) == null || t.removeButton("comment");
  }
  removeEditToolbar() {
    var t, e;
    (t = this._editToolbar) == null || t.remove(), this._editToolbar = null, (e = n(this, Ht)) == null || e.destroy();
  }
  addContainer(t) {
    var s;
    const e = (s = this._editToolbar) == null ? void 0 : s.div;
    e ? e.before(t) : this.div.append(t);
  }
  getClientDimensions() {
    return this.div.getBoundingClientRect();
  }
  createAltText() {
    return n(this, Ht) || (Nu.initialize(Q._l10n), p(this, Ht, new Nu(this)), n(this, ba) && (n(this, Ht).data = n(this, ba), p(this, ba, null))), n(this, Ht);
  }
  get altTextData() {
    var t;
    return (t = n(this, Ht)) == null ? void 0 : t.data;
  }
  set altTextData(t) {
    n(this, Ht) && (n(this, Ht).data = t);
  }
  get guessedAltText() {
    var t;
    return (t = n(this, Ht)) == null ? void 0 : t.guessedText;
  }
  async setGuessedAltText(t) {
    var e;
    await ((e = n(this, Ht)) == null ? void 0 : e.setGuessedText(t));
  }
  serializeAltText(t) {
    var e;
    return (e = n(this, Ht)) == null ? void 0 : e.serialize(t);
  }
  hasAltText() {
    return !!n(this, Ht) && !n(this, Ht).isEmpty();
  }
  hasAltTextData() {
    var t;
    return ((t = n(this, Ht)) == null ? void 0 : t.hasData()) ?? !1;
  }
  focusCommentButton() {
    var t;
    (t = n(this, Rt)) == null || t.focusButton();
  }
  addCommentButton() {
    return n(this, Rt) || p(this, Rt, new Xd(this));
  }
  addStandaloneCommentButton() {
    if (n(this, gn)) {
      this._uiManager.isEditingMode() && n(this, gn).classList.remove("hidden");
      return;
    }
    this.hasComment && (p(this, gn, n(this, Rt).renderForStandalone()), this.div.append(n(this, gn)));
  }
  removeStandaloneCommentButton() {
    n(this, Rt).removeStandaloneCommentButton(), p(this, gn, null);
  }
  hideStandaloneCommentButton() {
    var t;
    (t = n(this, gn)) == null || t.classList.add("hidden");
  }
  get comment() {
    const {
      data: {
        richText: t,
        text: e,
        date: s,
        deleted: i
      }
    } = n(this, Rt);
    return {
      text: e,
      richText: t,
      date: s,
      deleted: i,
      color: this.getNonHCMColor(),
      opacity: this.opacity ?? 1
    };
  }
  set comment(t) {
    n(this, Rt) || p(this, Rt, new Xd(this)), n(this, Rt).data = t, this.hasComment ? (this.removeCommentButtonFromToolbar(), this.addStandaloneCommentButton(), this._uiManager.updateComment(this)) : (this.addCommentButtonInToolbar(), this.removeStandaloneCommentButton(), this._uiManager.removeComment(this));
  }
  setCommentData({
    comment: t,
    popupRef: e,
    richText: s
  }) {
    if (!e || (n(this, Rt) || p(this, Rt, new Xd(this)), n(this, Rt).setInitialText(t, s), !this.annotationElementId))
      return;
    const i = this._uiManager.getAndRemoveDataFromAnnotationStorage(this.annotationElementId);
    i && this.updateFromAnnotationLayer(i);
  }
  get hasEditedComment() {
    var t;
    return (t = n(this, Rt)) == null ? void 0 : t.hasBeenEdited();
  }
  get hasDeletedComment() {
    var t;
    return (t = n(this, Rt)) == null ? void 0 : t.isDeleted();
  }
  get hasComment() {
    return !!n(this, Rt) && !n(this, Rt).isEmpty() && !n(this, Rt).isDeleted();
  }
  async editComment(t) {
    n(this, Rt) || p(this, Rt, new Xd(this)), n(this, Rt).edit(t);
  }
  toggleComment(t, e = void 0) {
    this.hasComment && this._uiManager.toggleComment(this, t, e);
  }
  setSelectedCommentButton(t) {
    n(this, Rt).setSelectedButton(t);
  }
  addComment(t) {
    if (this.hasEditedComment) {
      const [, , , i] = t.rect, [r] = this.pageDimensions, [a] = this.pageTranslation, o = a + r + 1, l = i - 100, h = o + 180;
      t.popup = {
        contents: this.comment.text,
        deleted: this.comment.deleted,
        rect: [o, l, h, i]
      };
    }
  }
  updateFromAnnotationLayer({
    popup: {
      contents: t,
      deleted: e
    }
  }) {
    n(this, Rt).data = e ? null : t;
  }
  get parentBoundingClientRect() {
    return this.parent.boundingClientRect;
  }
  render() {
    var a;
    const t = this.div = document.createElement("div");
    t.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), t.className = this.name, t.setAttribute("id", this.id), t.tabIndex = n(this, sl) ? -1 : 0, t.setAttribute("role", "application"), this.defaultL10nId && t.setAttribute("data-l10n-id", this.defaultL10nId), this._isVisible || t.classList.add("hidden"), this.setInForeground(), b(this, q, ip).call(this);
    const [e, s] = this.parentDimensions;
    this.parentRotation % 180 !== 0 && (t.style.maxWidth = `${(100 * s / e).toFixed(2)}%`, t.style.maxHeight = `${(100 * e / s).toFixed(2)}%`);
    const [i, r] = this.getInitialTranslation();
    return this.translate(i, r), Om(this, t, ["keydown", "pointerdown", "dblclick"]), this.isResizable && this._uiManager._supportsPinchToZoom && (n(this, va) || p(this, va, new qh({
      container: t,
      isPinchingDisabled: () => !this.isSelected,
      onPinchStart: b(this, q, tb).bind(this),
      onPinching: b(this, q, eb).bind(this),
      onPinchEnd: b(this, q, sb).bind(this),
      signal: this._uiManager._signal
    }))), this.addStandaloneCommentButton(), (a = this._uiManager._editorUndoBar) == null || a.hide(), t;
  }
  pointerdown(t) {
    const {
      isMac: e
    } = _e.platform;
    if (t.button !== 0 || t.ctrlKey && e) {
      t.preventDefault();
      return;
    }
    if (p(this, Aa, !0), this._isDraggable) {
      b(this, q, ib).call(this, t);
      return;
    }
    b(this, q, sp).call(this, t);
  }
  _onStartDragging() {
  }
  _onStopDragging() {
  }
  moveInDOM() {
    n(this, Oi) && clearTimeout(n(this, Oi)), p(this, Oi, setTimeout(() => {
      var t;
      p(this, Oi, null), (t = this.parent) == null || t.moveEditorInDOM(this);
    }, 0));
  }
  _setParentAndPosition(t, e, s) {
    t.changeParent(this), this.x = e, this.y = s, this.fixAndSetPosition(), this._onTranslated();
  }
  getRect(t, e, s = this.rotation) {
    const i = this.parentScale, [r, a] = this.pageDimensions, [o, l] = this.pageTranslation, h = t / i, c = e / i, u = this.x * r, f = this.y * a, m = this.width * r, A = this.height * a;
    switch (s) {
      case 0:
        return [u + h + o, a - f - c - A + l, u + h + m + o, a - f - c + l];
      case 90:
        return [u + c + o, a - f + h + l, u + c + A + o, a - f + h + m + l];
      case 180:
        return [u - h - m + o, a - f + c + l, u - h + o, a - f + c + A + l];
      case 270:
        return [u - c - A + o, a - f - h - m + l, u - c + o, a - f - h + l];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getRectInCurrentCoords(t, e) {
    const [s, i, r, a] = t, o = r - s, l = a - i;
    switch (this.rotation) {
      case 0:
        return [s, e - a, o, l];
      case 90:
        return [s, e - i, l, o];
      case 180:
        return [r, e - i, o, l];
      case 270:
        return [r, e - a, l, o];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getPDFRect() {
    return this.getRect(0, 0);
  }
  getNonHCMColor() {
    return this.color && Q._colorManager.convert(this._uiManager.getNonHCMColor(this.color));
  }
  onUpdatedColor() {
    var t;
    (t = n(this, Rt)) == null || t.onUpdatedColor();
  }
  getData() {
    const {
      comment: {
        text: t,
        color: e,
        date: s,
        opacity: i,
        deleted: r,
        richText: a
      },
      uid: o,
      pageIndex: l,
      creationDate: h,
      modificationDate: c
    } = this;
    return {
      id: o,
      pageIndex: l,
      rect: this.getPDFRect(),
      richText: a,
      contentsObj: {
        str: t
      },
      creationDate: h,
      modificationDate: s || c,
      popupRef: !r,
      color: e,
      opacity: i
    };
  }
  onceAdded(t) {
  }
  isEmpty() {
    return !1;
  }
  enableEditMode() {
    return this.isInEditMode() ? !1 : (this.parent.setEditingState(!1), p(this, wa, !0), !0);
  }
  disableEditMode() {
    return this.isInEditMode() ? (this.parent.setEditingState(!0), p(this, wa, !1), !0) : !1;
  }
  isInEditMode() {
    return n(this, wa);
  }
  shouldGetKeyboardEvents() {
    return n(this, bn);
  }
  needsToBeRebuilt() {
    return this.div && !this.isAttachedToDOM;
  }
  get isOnScreen() {
    const {
      top: t,
      left: e,
      bottom: s,
      right: i
    } = this.getClientDimensions(), {
      innerHeight: r,
      innerWidth: a
    } = window;
    return e < a && i > 0 && t < r && s > 0;
  }
  rebuild() {
    b(this, q, ip).call(this);
  }
  rotate(t) {
  }
  resize() {
  }
  serializeDeleted() {
    var t;
    return {
      id: this.annotationElementId,
      deleted: !0,
      pageIndex: this.pageIndex,
      popupRef: ((t = this._initialData) == null ? void 0 : t.popupRef) || ""
    };
  }
  serialize(t = !1, e = null) {
    var s;
    return {
      annotationType: this.mode,
      pageIndex: this.pageIndex,
      rect: this.getPDFRect(),
      rotation: this.rotation,
      structTreeParentId: this._structTreeParentId,
      popupRef: ((s = this._initialData) == null ? void 0 : s.popupRef) || ""
    };
  }
  static async deserialize(t, e, s) {
    const i = new this.prototype.constructor({
      parent: e,
      id: e.getNextId(),
      uiManager: s,
      annotationElementId: t.annotationElementId,
      creationDate: t.creationDate,
      modificationDate: t.modificationDate
    });
    i.rotation = t.rotation, p(i, ba, t.accessibilityData), i._isCopy = t.isCopy || !1;
    const [r, a] = i.pageDimensions, [o, l, h, c] = i.getRectInCurrentCoords(t.rect, a);
    return i.x = o / r, i.y = l / a, i.width = h / r, i.height = c / a, i;
  }
  get hasBeenModified() {
    return !!this.annotationElementId && (this.deleted || this.serialize() !== null);
  }
  remove() {
    var t, e;
    if ((t = n(this, pr)) == null || t.abort(), p(this, pr, null), this.isEmpty() || this.commit(), this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), n(this, Oi) && (clearTimeout(n(this, Oi)), p(this, Oi, null)), b(this, q, xh).call(this), this.removeEditToolbar(), n(this, Qs)) {
      for (const s of n(this, Qs).values())
        clearTimeout(s);
      p(this, Qs, null);
    }
    this.parent = null, (e = n(this, va)) == null || e.destroy(), p(this, va, null);
  }
  get isResizable() {
    return !1;
  }
  makeResizable() {
    this.isResizable && (b(this, q, Jm).call(this), n(this, Re).classList.remove("hidden"));
  }
  get toolbarPosition() {
    return null;
  }
  get commentButtonPosition() {
    return this._uiManager.direction === "ltr" ? [1, 0] : [0, 0];
  }
  get commentButtonPositionInPage() {
    const {
      commentButtonPosition: [t, e]
    } = this, [s, i, r, a] = this.getPDFRect();
    return [Q._round(s + (r - s) * t), Q._round(i + (a - i) * (1 - e))];
  }
  get commentButtonColor() {
    return this._uiManager.makeCommentColor(this.getNonHCMColor(), this.opacity);
  }
  get commentPopupPosition() {
    return n(this, Rt).commentPopupPositionInLayer;
  }
  set commentPopupPosition(t) {
    n(this, Rt).commentPopupPositionInLayer = t;
  }
  hasDefaultPopupPosition() {
    return n(this, Rt).hasDefaultPopupPosition();
  }
  get commentButtonWidth() {
    return n(this, Rt).commentButtonWidth;
  }
  get elementBeforePopup() {
    return this.div;
  }
  setCommentButtonStates(t) {
    n(this, Rt).setCommentButtonStates(t);
  }
  keydown(t) {
    if (!this.isResizable || t.target !== this.div || t.key !== "Enter")
      return;
    this._uiManager.setSelected(this), p(this, mn, {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    });
    const e = n(this, Re).children;
    if (!n(this, ui)) {
      p(this, ui, Array.from(e));
      const a = b(this, q, nb).bind(this), o = b(this, q, rb).bind(this), l = this._uiManager._signal;
      for (const h of n(this, ui)) {
        const c = h.getAttribute("data-resizer-name");
        h.setAttribute("role", "spinbutton"), h.addEventListener("keydown", a, {
          signal: l
        }), h.addEventListener("blur", o, {
          signal: l
        }), h.addEventListener("focus", b(this, q, ab).bind(this, c), {
          signal: l
        }), h.setAttribute("data-l10n-id", Q._l10nResizer[c]);
      }
    }
    const s = n(this, ui)[0];
    let i = 0;
    for (const a of e) {
      if (a === s)
        break;
      i++;
    }
    const r = (360 - this.rotation + this.parentRotation) % 360 / 90 * (n(this, ui).length / 4);
    if (r !== i) {
      if (r < i)
        for (let o = 0; o < i - r; o++)
          n(this, Re).append(n(this, Re).firstChild);
      else if (r > i)
        for (let o = 0; o < r - i; o++)
          n(this, Re).firstChild.before(n(this, Re).lastChild);
      let a = 0;
      for (const o of e) {
        const h = n(this, ui)[a++].getAttribute("data-resizer-name");
        o.setAttribute("data-l10n-id", Q._l10nResizer[h]);
      }
    }
    b(this, q, np).call(this, 0), p(this, bn, !0), n(this, Re).firstChild.focus({
      focusVisible: !0
    }), t.preventDefault(), t.stopImmediatePropagation();
  }
  _resizeWithKeyboard(t, e) {
    n(this, bn) && b(this, q, ep).call(this, n(this, Ec), {
      deltaX: t,
      deltaY: e,
      fromKeyboard: !0
    });
  }
  _stopResizingWithKeyboard() {
    b(this, q, xh).call(this), this.div.focus();
  }
  select() {
    var t, e, s;
    if (this.isSelected && this._editToolbar) {
      this._editToolbar.show();
      return;
    }
    if (this.isSelected = !0, this.makeResizable(), (t = this.div) == null || t.classList.add("selectedEditor"), !this._editToolbar) {
      this.addEditToolbar().then(() => {
        var i, r;
        (i = this.div) != null && i.classList.contains("selectedEditor") && ((r = this._editToolbar) == null || r.show());
      });
      return;
    }
    (e = this._editToolbar) == null || e.show(), (s = n(this, Ht)) == null || s.toggleAltTextBadge(!1);
  }
  focus() {
    this.div && !this.div.contains(document.activeElement) && setTimeout(() => {
      var t;
      return (t = this.div) == null ? void 0 : t.focus({
        preventScroll: !0
      });
    }, 0);
  }
  unselect() {
    var t, e, s, i, r;
    this.isSelected && (this.isSelected = !1, (t = n(this, Re)) == null || t.classList.add("hidden"), (e = this.div) == null || e.classList.remove("selectedEditor"), (s = this.div) != null && s.contains(document.activeElement) && this._uiManager.currentLayer.div.focus({
      preventScroll: !0
    }), (i = this._editToolbar) == null || i.hide(), (r = n(this, Ht)) == null || r.toggleAltTextBadge(!0), this.hasComment && this._uiManager.toggleComment(this, !1, !1));
  }
  updateParams(t, e) {
  }
  disableEditing() {
  }
  enableEditing() {
  }
  get canChangeContent() {
    return !1;
  }
  enterInEditMode() {
    this.canChangeContent && (this.enableEditMode(), this.div.focus());
  }
  dblclick(t) {
    t.target.nodeName !== "BUTTON" && (this.enterInEditMode(), this.parent.updateToolbar({
      mode: this.constructor._editorType,
      editId: this.id
    }));
  }
  getElementForAltText() {
    return this.div;
  }
  get contentDiv() {
    return this.div;
  }
  get isEditing() {
    return n(this, Sc);
  }
  set isEditing(t) {
    p(this, Sc, t), this.parent && (t ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
  }
  static get MIN_SIZE() {
    return 16;
  }
  static canCreateNewEmptyEditor() {
    return !0;
  }
  get telemetryInitialData() {
    return {
      action: "added"
    };
  }
  get telemetryFinalData() {
    return null;
  }
  _reportTelemetry(t, e = !1) {
    if (e) {
      n(this, Qs) || p(this, Qs, /* @__PURE__ */ new Map());
      const {
        action: s
      } = t;
      let i = n(this, Qs).get(s);
      i && clearTimeout(i), i = setTimeout(() => {
        this._reportTelemetry(t), n(this, Qs).delete(s), n(this, Qs).size === 0 && p(this, Qs, null);
      }, Q._telemetryTimeout), n(this, Qs).set(s, i);
      return;
    }
    t.type || (t.type = this.editorType), this._uiManager._eventBus.dispatch("reporttelemetry", {
      source: this,
      details: {
        type: "editing",
        data: t
      }
    });
  }
  show(t = this._isVisible) {
    this.div.classList.toggle("hidden", !t), this._isVisible = t;
  }
  enable() {
    this.div && (this.div.tabIndex = 0), p(this, sl, !1);
  }
  disable() {
    this.div && (this.div.tabIndex = -1), p(this, sl, !0);
  }
  updateFakeAnnotationElement(t) {
    if (!n(this, Ni) && !this.deleted) {
      p(this, Ni, t.addFakeAnnotation(this));
      return;
    }
    if (this.deleted) {
      n(this, Ni).remove(), p(this, Ni, null);
      return;
    }
    (this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized) && n(this, Ni).updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    });
  }
  renderAnnotationElement(t) {
    if (this.deleted)
      return t.hide(), null;
    let e = t.container.querySelector(".annotationContent");
    if (!e)
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), t.container.prepend(e);
    else if (e.nodeName === "CANVAS") {
      const s = e;
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), s.before(e);
    }
    return e;
  }
  resetAnnotationElement(t) {
    const {
      firstChild: e
    } = t.container;
    (e == null ? void 0 : e.nodeName) === "DIV" && e.classList.contains("annotationContent") && e.remove();
  }
};
ba = new WeakMap(), ui = new WeakMap(), Ht = new WeakMap(), Rt = new WeakMap(), gn = new WeakMap(), sl = new WeakMap(), fr = new WeakMap(), vc = new WeakMap(), Re = new WeakMap(), ya = new WeakMap(), mn = new WeakMap(), Ni = new WeakMap(), pr = new WeakMap(), Ec = new WeakMap(), Aa = new WeakMap(), Es = new WeakMap(), Sc = new WeakMap(), wa = new WeakMap(), bn = new WeakMap(), Oi = new WeakMap(), il = new WeakMap(), nl = new WeakMap(), Qs = new WeakMap(), va = new WeakMap(), _c = new WeakMap(), Zu = new WeakMap(), q = new WeakSet(), Jf = function([t, e], s, i) {
  [s, i] = this.screenToPageTranslation(s, i), this.x += s / t, this.y += i / e, this._onTranslating(this.x, this.y), this.fixAndSetPosition();
}, Cc = new WeakSet(), Qf = function(t, e, s) {
  switch (s) {
    case 90:
      return [e, -t];
    case 180:
      return [-t, -e];
    case 270:
      return [-e, t];
    default:
      return [t, e];
  }
}, au = function(t) {
  switch (t) {
    case 90: {
      const [e, s] = this.pageDimensions;
      return [0, -e / s, s / e, 0];
    }
    case 180:
      return [-1, 0, 0, -1];
    case 270: {
      const [e, s] = this.pageDimensions;
      return [0, e / s, -s / e, 0];
    }
    default:
      return [1, 0, 0, 1];
  }
}, Jm = function() {
  if (n(this, Re))
    return;
  p(this, Re, document.createElement("div")), n(this, Re).classList.add("resizers");
  const t = this._willKeepAspectRatio ? ["topLeft", "topRight", "bottomRight", "bottomLeft"] : ["topLeft", "topMiddle", "topRight", "middleRight", "bottomRight", "bottomMiddle", "bottomLeft", "middleLeft"], e = this._uiManager._signal;
  for (const s of t) {
    const i = document.createElement("div");
    n(this, Re).append(i), i.classList.add("resizer", s), i.setAttribute("data-resizer-name", s), i.addEventListener("pointerdown", b(this, q, Qm).bind(this, s), {
      signal: e
    }), i.addEventListener("contextmenu", $s, {
      signal: e
    }), i.tabIndex = -1;
  }
  this.div.prepend(n(this, Re));
}, Qm = function(t, e) {
  var c;
  e.preventDefault();
  const {
    isMac: s
  } = _e.platform;
  if (e.button !== 0 || e.ctrlKey && s)
    return;
  (c = n(this, Ht)) == null || c.toggle(!1);
  const i = this._isDraggable;
  this._isDraggable = !1, p(this, ya, [e.screenX, e.screenY]);
  const r = new AbortController(), a = this._uiManager.combinedSignal(r);
  this.parent.togglePointerEvents(!1), window.addEventListener("pointermove", b(this, q, ep).bind(this, t), {
    passive: !0,
    capture: !0,
    signal: a
  }), window.addEventListener("touchmove", zt, {
    passive: !1,
    signal: a
  }), window.addEventListener("contextmenu", $s, {
    signal: a
  }), p(this, mn, {
    savedX: this.x,
    savedY: this.y,
    savedWidth: this.width,
    savedHeight: this.height
  });
  const o = this.parent.div.style.cursor, l = this.div.style.cursor;
  this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(e.target).cursor;
  const h = () => {
    var u;
    r.abort(), this.parent.togglePointerEvents(!0), (u = n(this, Ht)) == null || u.toggle(!0), this._isDraggable = i, this.parent.div.style.cursor = o, this.div.style.cursor = l, b(this, q, ou).call(this);
  };
  window.addEventListener("pointerup", h, {
    signal: a
  }), window.addEventListener("blur", h, {
    signal: a
  });
}, tp = function(t, e, s, i) {
  this.width = s, this.height = i, this.x = t, this.y = e, this.setDims(), this.fixAndSetPosition(), this._onResized();
}, ou = function() {
  if (!n(this, mn))
    return;
  const {
    savedX: t,
    savedY: e,
    savedWidth: s,
    savedHeight: i
  } = n(this, mn);
  p(this, mn, null);
  const r = this.x, a = this.y, o = this.width, l = this.height;
  r === t && a === e && o === s && l === i || this.addCommands({
    cmd: b(this, q, tp).bind(this, r, a, o, l),
    undo: b(this, q, tp).bind(this, t, e, s, i),
    mustExec: !0
  });
}, ep = function(t, e) {
  const [s, i] = this.parentDimensions, r = this.x, a = this.y, o = this.width, l = this.height, h = Q.MIN_SIZE / s, c = Q.MIN_SIZE / i, u = b(this, q, au).call(this, this.rotation), f = (O, H) => [u[0] * O + u[2] * H, u[1] * O + u[3] * H], m = b(this, q, au).call(this, 360 - this.rotation), A = (O, H) => [m[0] * O + m[2] * H, m[1] * O + m[3] * H];
  let y, v, w = !1, S = !1;
  switch (t) {
    case "topLeft":
      w = !0, y = (O, H) => [0, 0], v = (O, H) => [O, H];
      break;
    case "topMiddle":
      y = (O, H) => [O / 2, 0], v = (O, H) => [O / 2, H];
      break;
    case "topRight":
      w = !0, y = (O, H) => [O, 0], v = (O, H) => [0, H];
      break;
    case "middleRight":
      S = !0, y = (O, H) => [O, H / 2], v = (O, H) => [0, H / 2];
      break;
    case "bottomRight":
      w = !0, y = (O, H) => [O, H], v = (O, H) => [0, 0];
      break;
    case "bottomMiddle":
      y = (O, H) => [O / 2, H], v = (O, H) => [O / 2, 0];
      break;
    case "bottomLeft":
      w = !0, y = (O, H) => [0, H], v = (O, H) => [O, 0];
      break;
    case "middleLeft":
      S = !0, y = (O, H) => [0, H / 2], v = (O, H) => [O, H / 2];
      break;
  }
  const E = y(o, l), _ = v(o, l);
  let C = f(..._);
  const T = Q._round(r + C[0]), x = Q._round(a + C[1]);
  let R = 1, M = 1, D, k;
  if (e.fromKeyboard)
    ({
      deltaX: D,
      deltaY: k
    } = e);
  else {
    const {
      screenX: O,
      screenY: H
    } = e, [st, at] = n(this, ya);
    [D, k] = this.screenToPageTranslation(O - st, H - at), n(this, ya)[0] = O, n(this, ya)[1] = H;
  }
  if ([D, k] = A(D / s, k / i), w) {
    const O = Math.hypot(o, l);
    R = M = Math.max(Math.min(Math.hypot(_[0] - E[0] - D, _[1] - E[1] - k) / O, 1 / o, 1 / l), h / o, c / l);
  } else S ? R = je(Math.abs(_[0] - E[0] - D), h, 1) / o : M = je(Math.abs(_[1] - E[1] - k), c, 1) / l;
  const N = Q._round(o * R), X = Q._round(l * M);
  C = f(...v(N, X));
  const B = T - C[0], Y = x - C[1];
  n(this, Es) || p(this, Es, [this.x, this.y, this.width, this.height]), this.width = N, this.height = X, this.x = B, this.y = Y, this.setDims(), this.fixAndSetPosition(), this._onResizing();
}, tb = function() {
  var t;
  p(this, mn, {
    savedX: this.x,
    savedY: this.y,
    savedWidth: this.width,
    savedHeight: this.height
  }), (t = n(this, Ht)) == null || t.toggle(!1), this.parent.togglePointerEvents(!1);
}, eb = function(t, e, s) {
  let r = 0.7 * (s / e) + 1 - 0.7;
  if (r === 1)
    return;
  const a = b(this, q, au).call(this, this.rotation), o = (T, x) => [a[0] * T + a[2] * x, a[1] * T + a[3] * x], [l, h] = this.parentDimensions, c = this.x, u = this.y, f = this.width, m = this.height, A = Q.MIN_SIZE / l, y = Q.MIN_SIZE / h;
  r = Math.max(Math.min(r, 1 / f, 1 / m), A / f, y / m);
  const v = Q._round(f * r), w = Q._round(m * r);
  if (v === f && w === m)
    return;
  n(this, Es) || p(this, Es, [c, u, f, m]);
  const S = o(f / 2, m / 2), E = Q._round(c + S[0]), _ = Q._round(u + S[1]), C = o(v / 2, w / 2);
  this.x = E - C[0], this.y = _ - C[1], this.width = v, this.height = w, this.setDims(), this.fixAndSetPosition(), this._onResizing();
}, sb = function() {
  var t;
  (t = n(this, Ht)) == null || t.toggle(!0), this.parent.togglePointerEvents(!0), b(this, q, ou).call(this);
}, sp = function(t) {
  const {
    isMac: e
  } = _e.platform;
  t.ctrlKey && !e || t.shiftKey || t.metaKey && e ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
}, ib = function(t) {
  const {
    isSelected: e
  } = this;
  this._uiManager.setUpDragSession();
  let s = !1;
  const i = new AbortController(), r = this._uiManager.combinedSignal(i), a = {
    capture: !0,
    passive: !1,
    signal: r
  }, o = (h) => {
    i.abort(), p(this, fr, null), p(this, Aa, !1), this._uiManager.endDragSession() || b(this, q, sp).call(this, h), s && this._onStopDragging();
  };
  e && (p(this, il, t.clientX), p(this, nl, t.clientY), p(this, fr, t.pointerId), p(this, vc, t.pointerType), window.addEventListener("pointermove", (h) => {
    s || (s = !0, this._uiManager.toggleComment(this, !0, !1), this._onStartDragging());
    const {
      clientX: c,
      clientY: u,
      pointerId: f
    } = h;
    if (f !== n(this, fr)) {
      zt(h);
      return;
    }
    const [m, A] = this.screenToPageTranslation(c - n(this, il), u - n(this, nl));
    p(this, il, c), p(this, nl, u), this._uiManager.dragSelectedEditors(m, A);
  }, a), window.addEventListener("touchmove", zt, a), window.addEventListener("pointerdown", (h) => {
    h.pointerType === n(this, vc) && (n(this, va) || h.isPrimary) && o(h), zt(h);
  }, a));
  const l = (h) => {
    if (!n(this, fr) || n(this, fr) === h.pointerId) {
      o(h);
      return;
    }
    zt(h);
  };
  window.addEventListener("pointerup", l, {
    signal: r
  }), window.addEventListener("blur", l, {
    signal: r
  });
}, ip = function() {
  if (n(this, pr) || !this.div)
    return;
  p(this, pr, new AbortController());
  const t = this._uiManager.combinedSignal(n(this, pr));
  this.div.addEventListener("focusin", this.focusin.bind(this), {
    signal: t
  }), this.div.addEventListener("focusout", this.focusout.bind(this), {
    signal: t
  });
}, nb = function(t) {
  Q._resizerKeyboardManager.exec(this, t);
}, rb = function(t) {
  var e;
  n(this, bn) && ((e = t.relatedTarget) == null ? void 0 : e.parentNode) !== n(this, Re) && b(this, q, xh).call(this);
}, ab = function(t) {
  p(this, Ec, n(this, bn) ? t : "");
}, np = function(t) {
  if (n(this, ui))
    for (const e of n(this, ui))
      e.tabIndex = t;
}, xh = function() {
  p(this, bn, !1), b(this, q, np).call(this, -1), b(this, q, ou).call(this);
}, g(Q, Cc), L(Q, "_l10n", null), L(Q, "_l10nResizer", null), L(Q, "_borderLineWidth", -1), L(Q, "_colorManager", new Gf()), L(Q, "_zIndex", 1), L(Q, "_telemetryTimeout", 1e3);
let Ft = Q;
class vy extends Ft {
  constructor(t) {
    super(t), this.annotationElementId = t.annotationElementId, this.deleted = !0;
  }
  serialize() {
    return this.serializeDeleted();
  }
}
const $g = 3285377520, Gs = 4294901760, Ti = 65535;
class ob {
  constructor(t) {
    this.h1 = t ? t & 4294967295 : $g, this.h2 = t ? t & 4294967295 : $g;
  }
  update(t) {
    let e, s;
    if (typeof t == "string") {
      e = new Uint8Array(t.length * 2), s = 0;
      for (let y = 0, v = t.length; y < v; y++) {
        const w = t.charCodeAt(y);
        w <= 255 ? e[s++] = w : (e[s++] = w >>> 8, e[s++] = w & 255);
      }
    } else if (ArrayBuffer.isView(t))
      e = t.slice(), s = e.byteLength;
    else
      throw new Error("Invalid data format, must be a string or TypedArray.");
    const i = s >> 2, r = s - i * 4, a = new Uint32Array(e.buffer, 0, i);
    let o = 0, l = 0, h = this.h1, c = this.h2;
    const u = 3432918353, f = 461845907, m = u & Ti, A = f & Ti;
    for (let y = 0; y < i; y++)
      y & 1 ? (o = a[y], o = o * u & Gs | o * m & Ti, o = o << 15 | o >>> 17, o = o * f & Gs | o * A & Ti, h ^= o, h = h << 13 | h >>> 19, h = h * 5 + 3864292196) : (l = a[y], l = l * u & Gs | l * m & Ti, l = l << 15 | l >>> 17, l = l * f & Gs | l * A & Ti, c ^= l, c = c << 13 | c >>> 19, c = c * 5 + 3864292196);
    switch (o = 0, r) {
      case 3:
        o ^= e[i * 4 + 2] << 16;
      case 2:
        o ^= e[i * 4 + 1] << 8;
      case 1:
        o ^= e[i * 4], o = o * u & Gs | o * m & Ti, o = o << 15 | o >>> 17, o = o * f & Gs | o * A & Ti, i & 1 ? h ^= o : c ^= o;
    }
    this.h1 = h, this.h2 = c;
  }
  hexdigest() {
    let t = this.h1, e = this.h2;
    return t ^= e >>> 1, t = t * 3981806797 & Gs | t * 36045 & Ti, e = e * 4283543511 & Gs | ((e << 16 | t >>> 16) * 2950163797 & Gs) >>> 16, t ^= e >>> 1, t = t * 444984403 & Gs | t * 60499 & Ti, e = e * 3301882366 & Gs | ((e << 16 | t >>> 16) * 3120437893 & Gs) >>> 16, t ^= e >>> 1, (t >>> 0).toString(16).padStart(8, "0") + (e >>> 0).toString(16).padStart(8, "0");
  }
}
const rp = Object.freeze({
  map: null,
  hash: "",
  transfer: void 0
});
var Ea, Sa, yn, Me, Ju, lb;
class bg {
  constructor() {
    g(this, Ju);
    g(this, Ea, !1);
    g(this, Sa, null);
    g(this, yn, null);
    g(this, Me, /* @__PURE__ */ new Map());
    this.onSetModified = null, this.onResetModified = null, this.onAnnotationEditor = null;
  }
  getValue(t, e) {
    const s = n(this, Me).get(t);
    return s === void 0 ? e : Object.assign(e, s);
  }
  getRawValue(t) {
    return n(this, Me).get(t);
  }
  remove(t) {
    const e = n(this, Me).get(t);
    if (e !== void 0 && (e instanceof Ft && n(this, yn).delete(e.annotationElementId), n(this, Me).delete(t), n(this, Me).size === 0 && this.resetModified(), typeof this.onAnnotationEditor == "function")) {
      for (const s of n(this, Me).values())
        if (s instanceof Ft)
          return;
      this.onAnnotationEditor(null);
    }
  }
  setValue(t, e) {
    const s = n(this, Me).get(t);
    let i = !1;
    if (s !== void 0)
      for (const [r, a] of Object.entries(e))
        s[r] !== a && (i = !0, s[r] = a);
    else
      i = !0, n(this, Me).set(t, e);
    i && b(this, Ju, lb).call(this), e instanceof Ft && ((n(this, yn) || p(this, yn, /* @__PURE__ */ new Map())).set(e.annotationElementId, e), typeof this.onAnnotationEditor == "function" && this.onAnnotationEditor(e.constructor._type));
  }
  has(t) {
    return n(this, Me).has(t);
  }
  get size() {
    return n(this, Me).size;
  }
  resetModified() {
    n(this, Ea) && (p(this, Ea, !1), typeof this.onResetModified == "function" && this.onResetModified());
  }
  get print() {
    return new hb(this);
  }
  get serializable() {
    if (n(this, Me).size === 0)
      return rp;
    const t = /* @__PURE__ */ new Map(), e = new ob(), s = [], i = /* @__PURE__ */ Object.create(null);
    let r = !1;
    for (const [a, o] of n(this, Me)) {
      const l = o instanceof Ft ? o.serialize(!1, i) : o;
      l && (t.set(a, l), e.update(`${a}:${JSON.stringify(l)}`), r || (r = !!l.bitmap));
    }
    if (r)
      for (const a of t.values())
        a.bitmap && s.push(a.bitmap);
    return t.size > 0 ? {
      map: t,
      hash: e.hexdigest(),
      transfer: s
    } : rp;
  }
  get editorStats() {
    let t = null;
    const e = /* @__PURE__ */ new Map();
    let s = 0, i = 0;
    for (const r of n(this, Me).values()) {
      if (!(r instanceof Ft)) {
        r.popup && (r.popup.deleted ? i += 1 : s += 1);
        continue;
      }
      r.isCommentDeleted ? i += 1 : r.hasEditedComment && (s += 1);
      const a = r.telemetryFinalData;
      if (!a)
        continue;
      const {
        type: o
      } = a;
      e.has(o) || e.set(o, Object.getPrototypeOf(r).constructor), t || (t = /* @__PURE__ */ Object.create(null));
      const l = t[o] || (t[o] = /* @__PURE__ */ new Map());
      for (const [h, c] of Object.entries(a)) {
        if (h === "type")
          continue;
        let u = l.get(h);
        u || (u = /* @__PURE__ */ new Map(), l.set(h, u));
        const f = u.get(c) ?? 0;
        u.set(c, f + 1);
      }
    }
    if ((i > 0 || s > 0) && (t || (t = /* @__PURE__ */ Object.create(null)), t.comments = {
      deleted: i,
      edited: s
    }), !t)
      return null;
    for (const [r, a] of e)
      t[r] = a.computeTelemetryFinalData(t[r]);
    return t;
  }
  resetModifiedIds() {
    p(this, Sa, null);
  }
  updateEditor(t, e) {
    var i;
    const s = (i = n(this, yn)) == null ? void 0 : i.get(t);
    return s ? (s.updateFromAnnotationLayer(e), !0) : !1;
  }
  getEditor(t) {
    var e;
    return ((e = n(this, yn)) == null ? void 0 : e.get(t)) || null;
  }
  get modifiedIds() {
    if (n(this, Sa))
      return n(this, Sa);
    const t = [];
    if (n(this, yn))
      for (const e of n(this, yn).values())
        e.serialize() && t.push(e.annotationElementId);
    return p(this, Sa, {
      ids: new Set(t),
      hash: t.join(",")
    });
  }
  [Symbol.iterator]() {
    return n(this, Me).entries();
  }
}
Ea = new WeakMap(), Sa = new WeakMap(), yn = new WeakMap(), Me = new WeakMap(), Ju = new WeakSet(), lb = function() {
  n(this, Ea) || (p(this, Ea, !0), typeof this.onSetModified == "function" && this.onSetModified());
};
var Tc;
class hb extends bg {
  constructor(e) {
    super();
    g(this, Tc);
    const {
      map: s,
      hash: i,
      transfer: r
    } = e.serializable, a = structuredClone(s, r ? {
      transfer: r
    } : null);
    p(this, Tc, {
      map: a,
      hash: i,
      transfer: r
    });
  }
  get print() {
    Dt("Should not call PrintAnnotationStorage.print");
  }
  get serializable() {
    return n(this, Tc);
  }
  get modifiedIds() {
    return it(this, "modifiedIds", {
      ids: /* @__PURE__ */ new Set(),
      hash: ""
    });
  }
}
Tc = new WeakMap();
var rl;
class Ey {
  constructor({
    ownerDocument: t = globalThis.document,
    styleElement: e = null
  }) {
    g(this, rl, /* @__PURE__ */ new Set());
    this._document = t, this.nativeFontFaces = /* @__PURE__ */ new Set(), this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
  }
  addNativeFontFace(t) {
    this.nativeFontFaces.add(t), this._document.fonts.add(t);
  }
  removeNativeFontFace(t) {
    this.nativeFontFaces.delete(t), this._document.fonts.delete(t);
  }
  insertRule(t) {
    this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement));
    const e = this.styleElement.sheet;
    e.insertRule(t, e.cssRules.length);
  }
  clear() {
    for (const t of this.nativeFontFaces)
      this._document.fonts.delete(t);
    this.nativeFontFaces.clear(), n(this, rl).clear(), this.styleElement && (this.styleElement.remove(), this.styleElement = null);
  }
  async loadSystemFont({
    systemFontInfo: t,
    disableFontFace: e,
    _inspectFont: s
  }) {
    if (!(!t || n(this, rl).has(t.loadedName))) {
      if (dt(!e, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
        const {
          loadedName: i,
          src: r,
          style: a
        } = t, o = new FontFace(i, r, a);
        this.addNativeFontFace(o);
        try {
          await o.load(), n(this, rl).add(i), s == null || s(t);
        } catch {
          J(`Cannot load system font: ${t.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(o);
        }
        return;
      }
      Dt("Not implemented: loadSystemFont without the Font Loading API.");
    }
  }
  async bind(t) {
    if (t.attached || t.missingFile && !t.systemFontInfo)
      return;
    if (t.attached = !0, t.systemFontInfo) {
      await this.loadSystemFont(t);
      return;
    }
    if (this.isFontLoadingAPISupported) {
      const s = t.createNativeFontFace();
      if (s) {
        this.addNativeFontFace(s);
        try {
          await s.loaded;
        } catch (i) {
          throw J(`Failed to load font '${s.family}': '${i}'.`), t.disableFontFace = !0, i;
        }
      }
      return;
    }
    const e = t.createFontFaceRule();
    if (e) {
      if (this.insertRule(e), this.isSyncFontLoadingSupported)
        return;
      await new Promise((s) => {
        const i = this._queueLoadingCallback(s);
        this._prepareFontLoadEvent(t, i);
      });
    }
  }
  get isFontLoadingAPISupported() {
    var e;
    const t = !!((e = this._document) != null && e.fonts);
    return it(this, "isFontLoadingAPISupported", t);
  }
  get isSyncFontLoadingSupported() {
    return it(this, "isSyncFontLoadingSupported", ss || _e.platform.isFirefox);
  }
  _queueLoadingCallback(t) {
    function e() {
      for (dt(!i.done, "completeRequest() cannot be called twice."), i.done = !0; s.length > 0 && s[0].done; ) {
        const r = s.shift();
        setTimeout(r.callback, 0);
      }
    }
    const {
      loadingRequests: s
    } = this, i = {
      done: !1,
      complete: e,
      callback: t
    };
    return s.push(i), i;
  }
  get _loadTestFont() {
    const t = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
    return it(this, "_loadTestFont", t);
  }
  _prepareFontLoadEvent(t, e) {
    function s(_, C) {
      return _.charCodeAt(C) << 24 | _.charCodeAt(C + 1) << 16 | _.charCodeAt(C + 2) << 8 | _.charCodeAt(C + 3) & 255;
    }
    function i(_, C, T, x) {
      const R = _.substring(0, C), M = _.substring(C + T);
      return R + x + M;
    }
    let r, a;
    const o = this._document.createElement("canvas");
    o.width = 1, o.height = 1;
    const l = o.getContext("2d");
    let h = 0;
    function c(_, C) {
      if (++h > 30) {
        J("Load test font never loaded."), C();
        return;
      }
      if (l.font = "30px " + _, l.fillText(".", 0, 20), l.getImageData(0, 0, 1, 1).data[3] > 0) {
        C();
        return;
      }
      setTimeout(c.bind(null, _, C));
    }
    const u = `lt${Date.now()}${this.loadTestFontId++}`;
    let f = this._loadTestFont;
    f = i(f, 976, u.length, u);
    const A = 16, y = 1482184792;
    let v = s(f, A);
    for (r = 0, a = u.length - 3; r < a; r += 4)
      v = v - y + s(u, r) | 0;
    r < u.length && (v = v - y + s(u + "XXX", r) | 0), f = i(f, A, 4, hy(v));
    const w = `url(data:font/opentype;base64,${btoa(f)});`, S = `@font-face {font-family:"${u}";src:${w}}`;
    this.insertRule(S);
    const E = this._document.createElement("div");
    E.style.visibility = "hidden", E.style.width = E.style.height = "10px", E.style.position = "absolute", E.style.top = E.style.left = "0px";
    for (const _ of [t.loadedName, u]) {
      const C = this._document.createElement("span");
      C.textContent = "Hi", C.style.fontFamily = _, E.append(C);
    }
    this._document.body.append(E), c(u, () => {
      E.remove(), e.complete();
    });
  }
}
rl = new WeakMap();
var Et;
class Sy {
  constructor(t, e = null, s, i) {
    g(this, Et);
    this.compiledGlyphs = /* @__PURE__ */ Object.create(null), p(this, Et, t), this._inspectFont = e, s && Object.assign(this, s), i && (this.charProcOperatorList = i);
  }
  createNativeFontFace() {
    var e;
    if (!this.data || this.disableFontFace)
      return null;
    let t;
    if (!this.cssFontInfo)
      t = new FontFace(this.loadedName, this.data, {});
    else {
      const s = {
        weight: this.cssFontInfo.fontWeight
      };
      this.cssFontInfo.italicAngle && (s.style = `oblique ${this.cssFontInfo.italicAngle}deg`), t = new FontFace(this.cssFontInfo.fontFamily, this.data, s);
    }
    return (e = this._inspectFont) == null || e.call(this, this), t;
  }
  createFontFaceRule() {
    var s;
    if (!this.data || this.disableFontFace)
      return null;
    const t = `url(data:${this.mimetype};base64,${Cm(this.data)});`;
    let e;
    if (!this.cssFontInfo)
      e = `@font-face {font-family:"${this.loadedName}";src:${t}}`;
    else {
      let i = `font-weight: ${this.cssFontInfo.fontWeight};`;
      this.cssFontInfo.italicAngle && (i += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), e = `@font-face {font-family:"${this.cssFontInfo.fontFamily}";${i}src:${t}}`;
    }
    return (s = this._inspectFont) == null || s.call(this, this, t), e;
  }
  getPathGenerator(t, e) {
    if (this.compiledGlyphs[e] !== void 0)
      return this.compiledGlyphs[e];
    const s = this.loadedName + "_path_" + e;
    let i;
    try {
      i = t.get(s);
    } catch (a) {
      J(`getPathGenerator - ignoring character: "${a}".`);
    }
    const r = new Path2D(i || "");
    return this.fontExtraProperties || t.delete(s), this.compiledGlyphs[e] = r;
  }
  get black() {
    return n(this, Et).black;
  }
  get bold() {
    return n(this, Et).bold;
  }
  get disableFontFace() {
    return n(this, Et).disableFontFace ?? !1;
  }
  get fontExtraProperties() {
    return n(this, Et).fontExtraProperties ?? !1;
  }
  get isInvalidPDFjsFont() {
    return n(this, Et).isInvalidPDFjsFont;
  }
  get isType3Font() {
    return n(this, Et).isType3Font;
  }
  get italic() {
    return n(this, Et).italic;
  }
  get missingFile() {
    return n(this, Et).missingFile;
  }
  get remeasure() {
    return n(this, Et).remeasure;
  }
  get vertical() {
    return n(this, Et).vertical;
  }
  get ascent() {
    return n(this, Et).ascent;
  }
  get defaultWidth() {
    return n(this, Et).defaultWidth;
  }
  get descent() {
    return n(this, Et).descent;
  }
  get bbox() {
    return n(this, Et).bbox;
  }
  get fontMatrix() {
    return n(this, Et).fontMatrix;
  }
  get fallbackName() {
    return n(this, Et).fallbackName;
  }
  get loadedName() {
    return n(this, Et).loadedName;
  }
  get mimetype() {
    return n(this, Et).mimetype;
  }
  get name() {
    return n(this, Et).name;
  }
  get data() {
    return n(this, Et).data;
  }
  clearData() {
    n(this, Et).clearData();
  }
  get cssFontInfo() {
    return n(this, Et).cssFontInfo;
  }
  get systemFontInfo() {
    return n(this, Et).systemFontInfo;
  }
  get defaultVMetrics() {
    return n(this, Et).defaultVMetrics;
  }
}
Et = new WeakMap();
function _y(d) {
  if (d instanceof URL)
    return d.href;
  if (typeof d == "string") {
    if (ss)
      return d;
    const t = URL.parse(d, window.location);
    if (t)
      return t.href;
  }
  throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
}
function Cy(d) {
  if (ss && typeof Buffer < "u" && d instanceof Buffer)
    throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
  if (d instanceof Uint8Array && d.byteLength === d.buffer.byteLength)
    return d;
  if (typeof d == "string")
    return Id(d);
  if (d instanceof ArrayBuffer || ArrayBuffer.isView(d) || typeof d == "object" && !isNaN(d == null ? void 0 : d.length))
    return new Uint8Array(d);
  throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
}
function qd(d) {
  if (typeof d != "string")
    return null;
  if (d.endsWith("/"))
    return d;
  throw new Error(`Invalid factory url: "${d}" must include trailing slash.`);
}
const ap = (d) => typeof d == "object" && Number.isInteger(d == null ? void 0 : d.num) && d.num >= 0 && Number.isInteger(d == null ? void 0 : d.gen) && d.gen >= 0, Ty = (d) => typeof d == "object" && typeof (d == null ? void 0 : d.name) == "string", cb = fy.bind(null, ap, Ty);
var An, Qu;
class xy {
  constructor() {
    g(this, An, /* @__PURE__ */ new Map());
    g(this, Qu, Promise.resolve());
  }
  postMessage(t, e) {
    const s = {
      data: structuredClone(t, e ? {
        transfer: e
      } : null)
    };
    n(this, Qu).then(() => {
      for (const [i] of n(this, An))
        i.call(this, s);
    });
  }
  addEventListener(t, e, s = null) {
    let i = null;
    if ((s == null ? void 0 : s.signal) instanceof AbortSignal) {
      const {
        signal: r
      } = s;
      if (r.aborted) {
        J("LoopbackPort - cannot use an `aborted` signal.");
        return;
      }
      const a = () => this.removeEventListener(t, e);
      i = () => r.removeEventListener("abort", a), r.addEventListener("abort", a);
    }
    n(this, An).set(e, i);
  }
  removeEventListener(t, e) {
    const s = n(this, An).get(e);
    s == null || s(), n(this, An).delete(e);
  }
  terminate() {
    for (const [, t] of n(this, An))
      t == null || t();
    n(this, An).clear();
  }
}
An = new WeakMap(), Qu = new WeakMap();
const Yd = {
  DATA: 1,
  ERROR: 2
}, ne = {
  CANCEL: 1,
  CANCEL_COMPLETE: 2,
  CLOSE: 3,
  ENQUEUE: 4,
  ERROR: 5,
  PULL: 6,
  PULL_COMPLETE: 7,
  START_COMPLETE: 8
};
function Vg() {
}
function os(d) {
  if (d instanceof Gn || d instanceof Iu || d instanceof Ig || d instanceof jh || d instanceof Pf)
    return d;
  switch (d instanceof Error || typeof d == "object" && d !== null || Dt('wrapReason: Expected "reason" to be a (possibly cloned) Error.'), d.name) {
    case "AbortException":
      return new Gn(d.message);
    case "InvalidPDFException":
      return new Iu(d.message);
    case "PasswordException":
      return new Ig(d.message, d.code);
    case "ResponseException":
      return new jh(d.message, d.status, d.missing);
    case "UnknownErrorException":
      return new Pf(d.message, d.details);
  }
  return new Pf(d.message, d.toString());
}
var al, ai, db, ub, fb, lu;
class Ph {
  constructor(t, e, s) {
    g(this, ai);
    g(this, al, new AbortController());
    this.sourceName = t, this.targetName = e, this.comObj = s, this.callbackId = 1, this.streamId = 1, this.streamSinks = /* @__PURE__ */ Object.create(null), this.streamControllers = /* @__PURE__ */ Object.create(null), this.callbackCapabilities = /* @__PURE__ */ Object.create(null), this.actionHandler = /* @__PURE__ */ Object.create(null), s.addEventListener("message", b(this, ai, db).bind(this), {
      signal: n(this, al).signal
    });
  }
  on(t, e) {
    const s = this.actionHandler;
    if (s[t])
      throw new Error(`There is already an actionName called "${t}"`);
    s[t] = e;
  }
  send(t, e, s) {
    this.comObj.postMessage({
      sourceName: this.sourceName,
      targetName: this.targetName,
      action: t,
      data: e
    }, s);
  }
  sendWithPromise(t, e, s) {
    const i = this.callbackId++, r = Promise.withResolvers();
    this.callbackCapabilities[i] = r;
    try {
      this.comObj.postMessage({
        sourceName: this.sourceName,
        targetName: this.targetName,
        action: t,
        callbackId: i,
        data: e
      }, s);
    } catch (a) {
      r.reject(a);
    }
    return r.promise;
  }
  sendWithStream(t, e, s, i) {
    const r = this.streamId++, a = this.sourceName, o = this.targetName, l = this.comObj;
    return new ReadableStream({
      start: (h) => {
        const c = Promise.withResolvers();
        return this.streamControllers[r] = {
          controller: h,
          startCall: c,
          pullCall: null,
          cancelCall: null,
          isClosed: !1
        }, l.postMessage({
          sourceName: a,
          targetName: o,
          action: t,
          streamId: r,
          data: e,
          desiredSize: h.desiredSize
        }, i), c.promise;
      },
      pull: (h) => {
        const c = Promise.withResolvers();
        return this.streamControllers[r].pullCall = c, l.postMessage({
          sourceName: a,
          targetName: o,
          stream: ne.PULL,
          streamId: r,
          desiredSize: h.desiredSize
        }), c.promise;
      },
      cancel: (h) => {
        dt(h instanceof Error, "cancel must have a valid reason");
        const c = Promise.withResolvers();
        return this.streamControllers[r].cancelCall = c, this.streamControllers[r].isClosed = !0, l.postMessage({
          sourceName: a,
          targetName: o,
          stream: ne.CANCEL,
          streamId: r,
          reason: os(h)
        }), c.promise;
      }
    }, s);
  }
  destroy() {
    var t;
    (t = n(this, al)) == null || t.abort(), p(this, al, null);
  }
}
al = new WeakMap(), ai = new WeakSet(), db = function({
  data: t
}) {
  if (t.targetName !== this.sourceName)
    return;
  if (t.stream) {
    b(this, ai, fb).call(this, t);
    return;
  }
  if (t.callback) {
    const s = t.callbackId, i = this.callbackCapabilities[s];
    if (!i)
      throw new Error(`Cannot resolve callback ${s}`);
    if (delete this.callbackCapabilities[s], t.callback === Yd.DATA)
      i.resolve(t.data);
    else if (t.callback === Yd.ERROR)
      i.reject(os(t.reason));
    else
      throw new Error("Unexpected callback case");
    return;
  }
  const e = this.actionHandler[t.action];
  if (!e)
    throw new Error(`Unknown action from worker: ${t.action}`);
  if (t.callbackId) {
    const s = this.sourceName, i = t.sourceName, r = this.comObj;
    Promise.try(e, t.data).then(function(a) {
      r.postMessage({
        sourceName: s,
        targetName: i,
        callback: Yd.DATA,
        callbackId: t.callbackId,
        data: a
      });
    }, function(a) {
      r.postMessage({
        sourceName: s,
        targetName: i,
        callback: Yd.ERROR,
        callbackId: t.callbackId,
        reason: os(a)
      });
    });
    return;
  }
  if (t.streamId) {
    b(this, ai, ub).call(this, t);
    return;
  }
  e(t.data);
}, ub = function(t) {
  const e = t.streamId, s = this.sourceName, i = t.sourceName, r = this.comObj, a = this, o = this.actionHandler[t.action], l = {
    enqueue(h, c = 1, u) {
      if (this.isCancelled)
        return;
      const f = this.desiredSize;
      this.desiredSize -= c, f > 0 && this.desiredSize <= 0 && (this.sinkCapability = Promise.withResolvers(), this.ready = this.sinkCapability.promise), r.postMessage({
        sourceName: s,
        targetName: i,
        stream: ne.ENQUEUE,
        streamId: e,
        chunk: h
      }, u);
    },
    close() {
      this.isCancelled || (this.isCancelled = !0, r.postMessage({
        sourceName: s,
        targetName: i,
        stream: ne.CLOSE,
        streamId: e
      }), delete a.streamSinks[e]);
    },
    error(h) {
      dt(h instanceof Error, "error must have a valid reason"), !this.isCancelled && (this.isCancelled = !0, r.postMessage({
        sourceName: s,
        targetName: i,
        stream: ne.ERROR,
        streamId: e,
        reason: os(h)
      }));
    },
    sinkCapability: Promise.withResolvers(),
    onPull: null,
    onCancel: null,
    isCancelled: !1,
    desiredSize: t.desiredSize,
    ready: null
  };
  l.sinkCapability.resolve(), l.ready = l.sinkCapability.promise, this.streamSinks[e] = l, Promise.try(o, t.data, l).then(function() {
    r.postMessage({
      sourceName: s,
      targetName: i,
      stream: ne.START_COMPLETE,
      streamId: e,
      success: !0
    });
  }, function(h) {
    r.postMessage({
      sourceName: s,
      targetName: i,
      stream: ne.START_COMPLETE,
      streamId: e,
      reason: os(h)
    });
  });
}, fb = function(t) {
  const e = t.streamId, s = this.sourceName, i = t.sourceName, r = this.comObj, a = this.streamControllers[e], o = this.streamSinks[e];
  switch (t.stream) {
    case ne.START_COMPLETE:
      t.success ? a.startCall.resolve() : a.startCall.reject(os(t.reason));
      break;
    case ne.PULL_COMPLETE:
      t.success ? a.pullCall.resolve() : a.pullCall.reject(os(t.reason));
      break;
    case ne.PULL:
      if (!o) {
        r.postMessage({
          sourceName: s,
          targetName: i,
          stream: ne.PULL_COMPLETE,
          streamId: e,
          success: !0
        });
        break;
      }
      o.desiredSize <= 0 && t.desiredSize > 0 && o.sinkCapability.resolve(), o.desiredSize = t.desiredSize, Promise.try(o.onPull || Vg).then(function() {
        r.postMessage({
          sourceName: s,
          targetName: i,
          stream: ne.PULL_COMPLETE,
          streamId: e,
          success: !0
        });
      }, function(h) {
        r.postMessage({
          sourceName: s,
          targetName: i,
          stream: ne.PULL_COMPLETE,
          streamId: e,
          reason: os(h)
        });
      });
      break;
    case ne.ENQUEUE:
      if (dt(a, "enqueue should have stream controller"), a.isClosed)
        break;
      a.controller.enqueue(t.chunk);
      break;
    case ne.CLOSE:
      if (dt(a, "close should have stream controller"), a.isClosed)
        break;
      a.isClosed = !0, a.controller.close(), b(this, ai, lu).call(this, a, e);
      break;
    case ne.ERROR:
      dt(a, "error should have stream controller"), a.controller.error(os(t.reason)), b(this, ai, lu).call(this, a, e);
      break;
    case ne.CANCEL_COMPLETE:
      t.success ? a.cancelCall.resolve() : a.cancelCall.reject(os(t.reason)), b(this, ai, lu).call(this, a, e);
      break;
    case ne.CANCEL:
      if (!o)
        break;
      const l = os(t.reason);
      Promise.try(o.onCancel || Vg, l).then(function() {
        r.postMessage({
          sourceName: s,
          targetName: i,
          stream: ne.CANCEL_COMPLETE,
          streamId: e,
          success: !0
        });
      }, function(h) {
        r.postMessage({
          sourceName: s,
          targetName: i,
          stream: ne.CANCEL_COMPLETE,
          streamId: e,
          reason: os(h)
        });
      }), o.sinkCapability.reject(l), o.isCancelled = !0, delete this.streamSinks[e];
      break;
    default:
      throw new Error("Unexpected stream case");
  }
}, lu = async function(t, e) {
  var s, i, r;
  await Promise.allSettled([(s = t.startCall) == null ? void 0 : s.promise, (i = t.pullCall) == null ? void 0 : i.promise, (r = t.cancelCall) == null ? void 0 : r.promise]), delete this.streamControllers[e];
};
var xc;
class pb {
  constructor({
    enableHWA: t = !1
  }) {
    g(this, xc, !1);
    p(this, xc, t);
  }
  create(t, e) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid canvas size");
    const s = this._createCanvas(t, e);
    return {
      canvas: s,
      context: s.getContext("2d", {
        willReadFrequently: !n(this, xc)
      })
    };
  }
  reset(t, e, s) {
    if (!t.canvas)
      throw new Error("Canvas is not specified");
    if (e <= 0 || s <= 0)
      throw new Error("Invalid canvas size");
    t.canvas.width = e, t.canvas.height = s;
  }
  destroy(t) {
    if (!t.canvas)
      throw new Error("Canvas is not specified");
    t.canvas.width = 0, t.canvas.height = 0, t.canvas = null, t.context = null;
  }
  _createCanvas(t, e) {
    Dt("Abstract method `_createCanvas` called.");
  }
}
xc = new WeakMap();
class Py extends pb {
  constructor({
    ownerDocument: t = globalThis.document,
    enableHWA: e = !1
  }) {
    super({
      enableHWA: e
    }), this._document = t;
  }
  _createCanvas(t, e) {
    const s = this._document.createElement("canvas");
    return s.width = t, s.height = e, s;
  }
}
class gb {
  constructor({
    baseUrl: t = null,
    isCompressed: e = !0
  }) {
    this.baseUrl = t, this.isCompressed = e;
  }
  async fetch({
    name: t
  }) {
    if (!this.baseUrl)
      throw new Error("Ensure that the `cMapUrl` and `cMapPacked` API parameters are provided.");
    if (!t)
      throw new Error("CMap name must be specified.");
    const e = this.baseUrl + t + (this.isCompressed ? ".bcmap" : "");
    return this._fetch(e).then((s) => ({
      cMapData: s,
      isCompressed: this.isCompressed
    })).catch((s) => {
      throw new Error(`Unable to load ${this.isCompressed ? "binary " : ""}CMap at: ${e}`);
    });
  }
  async _fetch(t) {
    Dt("Abstract method `_fetch` called.");
  }
}
class zg extends gb {
  async _fetch(t) {
    const e = await ph(t, this.isCompressed ? "arraybuffer" : "text");
    return e instanceof ArrayBuffer ? new Uint8Array(e) : Id(e);
  }
}
class mb {
  addFilter(t) {
    return "none";
  }
  addHCMFilter(t, e) {
    return "none";
  }
  addAlphaFilter(t) {
    return "none";
  }
  addLuminosityFilter(t) {
    return "none";
  }
  addHighlightHCMFilter(t, e, s, i, r) {
    return "none";
  }
  destroy(t = !1) {
  }
}
var _a, ol, wn, vn, $e, Ca, Ta, U, Be, Rh, Co, hu, To, bb, op, xo, Mh, kh, lp, Lh;
class Ry extends mb {
  constructor({
    docId: e,
    ownerDocument: s = globalThis.document
  }) {
    super();
    g(this, U);
    g(this, _a);
    g(this, ol);
    g(this, wn);
    g(this, vn);
    g(this, $e);
    g(this, Ca);
    g(this, Ta, 0);
    p(this, vn, e), p(this, $e, s);
  }
  addFilter(e) {
    if (!e)
      return "none";
    let s = n(this, U, Be).get(e);
    if (s)
      return s;
    const [i, r, a] = b(this, U, hu).call(this, e), o = e.length === 1 ? i : `${i}${r}${a}`;
    if (s = n(this, U, Be).get(o), s)
      return n(this, U, Be).set(e, s), s;
    const l = `g_${n(this, vn)}_transfer_map_${oe(this, Ta)._++}`, h = b(this, U, To).call(this, l);
    n(this, U, Be).set(e, h), n(this, U, Be).set(o, h);
    const c = b(this, U, xo).call(this, l);
    return b(this, U, kh).call(this, i, r, a, c), h;
  }
  addHCMFilter(e, s) {
    var A;
    const i = `${e}-${s}`, r = "base";
    let a = n(this, U, Rh).get(r);
    if ((a == null ? void 0 : a.key) === i || (a ? ((A = a.filter) == null || A.remove(), a.key = i, a.url = "none", a.filter = null) : (a = {
      key: i,
      url: "none",
      filter: null
    }, n(this, U, Rh).set(r, a)), !e || !s))
      return a.url;
    const o = b(this, U, Lh).call(this, e);
    e = V.makeHexColor(...o);
    const l = b(this, U, Lh).call(this, s);
    if (s = V.makeHexColor(...l), n(this, U, Co).style.color = "", e === "#000000" && s === "#ffffff" || e === s)
      return a.url;
    const h = new Array(256);
    for (let y = 0; y <= 255; y++) {
      const v = y / 255;
      h[y] = v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
    }
    const c = h.join(","), u = `g_${n(this, vn)}_hcm_filter`, f = a.filter = b(this, U, xo).call(this, u);
    b(this, U, kh).call(this, c, c, c, f), b(this, U, op).call(this, f);
    const m = (y, v) => {
      const w = o[y] / 255, S = l[y] / 255, E = new Array(v + 1);
      for (let _ = 0; _ <= v; _++)
        E[_] = w + _ / v * (S - w);
      return E.join(",");
    };
    return b(this, U, kh).call(this, m(0, 5), m(1, 5), m(2, 5), f), a.url = b(this, U, To).call(this, u), a.url;
  }
  addAlphaFilter(e) {
    let s = n(this, U, Be).get(e);
    if (s)
      return s;
    const [i] = b(this, U, hu).call(this, [e]), r = `alpha_${i}`;
    if (s = n(this, U, Be).get(r), s)
      return n(this, U, Be).set(e, s), s;
    const a = `g_${n(this, vn)}_alpha_map_${oe(this, Ta)._++}`, o = b(this, U, To).call(this, a);
    n(this, U, Be).set(e, o), n(this, U, Be).set(r, o);
    const l = b(this, U, xo).call(this, a);
    return b(this, U, lp).call(this, i, l), o;
  }
  addLuminosityFilter(e) {
    let s = n(this, U, Be).get(e || "luminosity");
    if (s)
      return s;
    let i, r;
    if (e ? ([i] = b(this, U, hu).call(this, [e]), r = `luminosity_${i}`) : r = "luminosity", s = n(this, U, Be).get(r), s)
      return n(this, U, Be).set(e, s), s;
    const a = `g_${n(this, vn)}_luminosity_map_${oe(this, Ta)._++}`, o = b(this, U, To).call(this, a);
    n(this, U, Be).set(e, o), n(this, U, Be).set(r, o);
    const l = b(this, U, xo).call(this, a);
    return b(this, U, bb).call(this, l), e && b(this, U, lp).call(this, i, l), o;
  }
  addHighlightHCMFilter(e, s, i, r, a) {
    var S;
    const o = `${s}-${i}-${r}-${a}`;
    let l = n(this, U, Rh).get(e);
    if ((l == null ? void 0 : l.key) === o || (l ? ((S = l.filter) == null || S.remove(), l.key = o, l.url = "none", l.filter = null) : (l = {
      key: o,
      url: "none",
      filter: null
    }, n(this, U, Rh).set(e, l)), !s || !i))
      return l.url;
    const [h, c] = [s, i].map(b(this, U, Lh).bind(this));
    let u = Math.round(0.2126 * h[0] + 0.7152 * h[1] + 0.0722 * h[2]), f = Math.round(0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]), [m, A] = [r, a].map(b(this, U, Lh).bind(this));
    f < u && ([u, f, m, A] = [f, u, A, m]), n(this, U, Co).style.color = "";
    const y = (E, _, C) => {
      const T = new Array(256), x = (f - u) / C, R = E / 255, M = (_ - E) / (255 * C);
      let D = 0;
      for (let k = 0; k <= C; k++) {
        const N = Math.round(u + k * x), X = R + k * M;
        for (let B = D; B <= N; B++)
          T[B] = X;
        D = N + 1;
      }
      for (let k = D; k < 256; k++)
        T[k] = T[D - 1];
      return T.join(",");
    }, v = `g_${n(this, vn)}_hcm_${e}_filter`, w = l.filter = b(this, U, xo).call(this, v);
    return b(this, U, op).call(this, w), b(this, U, kh).call(this, y(m[0], A[0], 5), y(m[1], A[1], 5), y(m[2], A[2], 5), w), l.url = b(this, U, To).call(this, v), l.url;
  }
  destroy(e = !1) {
    var s, i, r, a;
    e && ((s = n(this, Ca)) != null && s.size) || ((i = n(this, wn)) == null || i.parentNode.parentNode.remove(), p(this, wn, null), (r = n(this, ol)) == null || r.clear(), p(this, ol, null), (a = n(this, Ca)) == null || a.clear(), p(this, Ca, null), p(this, Ta, 0));
  }
}
_a = new WeakMap(), ol = new WeakMap(), wn = new WeakMap(), vn = new WeakMap(), $e = new WeakMap(), Ca = new WeakMap(), Ta = new WeakMap(), U = new WeakSet(), Be = function() {
  return n(this, ol) || p(this, ol, /* @__PURE__ */ new Map());
}, Rh = function() {
  return n(this, Ca) || p(this, Ca, /* @__PURE__ */ new Map());
}, Co = function() {
  if (!n(this, wn)) {
    const e = n(this, $e).createElement("div"), {
      style: s
    } = e;
    s.visibility = "hidden", s.contain = "strict", s.width = s.height = 0, s.position = "absolute", s.top = s.left = 0, s.zIndex = -1;
    const i = n(this, $e).createElementNS(sn, "svg");
    i.setAttribute("width", 0), i.setAttribute("height", 0), p(this, wn, n(this, $e).createElementNS(sn, "defs")), e.append(i), i.append(n(this, wn)), n(this, $e).body.append(e);
  }
  return n(this, wn);
}, hu = function(e) {
  if (e.length === 1) {
    const h = e[0], c = new Array(256);
    for (let f = 0; f < 256; f++)
      c[f] = h[f] / 255;
    const u = c.join(",");
    return [u, u, u];
  }
  const [s, i, r] = e, a = new Array(256), o = new Array(256), l = new Array(256);
  for (let h = 0; h < 256; h++)
    a[h] = s[h] / 255, o[h] = i[h] / 255, l[h] = r[h] / 255;
  return [a.join(","), o.join(","), l.join(",")];
}, To = function(e) {
  if (n(this, _a) === void 0) {
    p(this, _a, "");
    const s = n(this, $e).URL;
    s !== n(this, $e).baseURI && (Nd(s) ? J('#createUrl: ignore "data:"-URL for performance reasons.') : p(this, _a, ug(s, "")));
  }
  return `url(${n(this, _a)}#${e})`;
}, bb = function(e) {
  const s = n(this, $e).createElementNS(sn, "feColorMatrix");
  s.setAttribute("type", "matrix"), s.setAttribute("values", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.3 0.59 0.11 0 0"), e.append(s);
}, op = function(e) {
  const s = n(this, $e).createElementNS(sn, "feColorMatrix");
  s.setAttribute("type", "matrix"), s.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), e.append(s);
}, xo = function(e) {
  const s = n(this, $e).createElementNS(sn, "filter");
  return s.setAttribute("color-interpolation-filters", "sRGB"), s.setAttribute("id", e), n(this, U, Co).append(s), s;
}, Mh = function(e, s, i) {
  const r = n(this, $e).createElementNS(sn, s);
  r.setAttribute("type", "discrete"), r.setAttribute("tableValues", i), e.append(r);
}, kh = function(e, s, i, r) {
  const a = n(this, $e).createElementNS(sn, "feComponentTransfer");
  r.append(a), b(this, U, Mh).call(this, a, "feFuncR", e), b(this, U, Mh).call(this, a, "feFuncG", s), b(this, U, Mh).call(this, a, "feFuncB", i);
}, lp = function(e, s) {
  const i = n(this, $e).createElementNS(sn, "feComponentTransfer");
  s.append(i), b(this, U, Mh).call(this, i, "feFuncA", e);
}, Lh = function(e) {
  return n(this, U, Co).style.color = e, gh(getComputedStyle(n(this, U, Co)).getPropertyValue("color"));
};
class yb {
  constructor({
    baseUrl: t = null
  }) {
    this.baseUrl = t;
  }
  async fetch({
    filename: t
  }) {
    if (!this.baseUrl)
      throw new Error("Ensure that the `standardFontDataUrl` API parameter is provided.");
    if (!t)
      throw new Error("Font filename must be specified.");
    const e = `${this.baseUrl}${t}`;
    return this._fetch(e).catch((s) => {
      throw new Error(`Unable to load font data at: ${e}`);
    });
  }
  async _fetch(t) {
    Dt("Abstract method `_fetch` called.");
  }
}
class Gg extends yb {
  async _fetch(t) {
    const e = await ph(t, "arraybuffer");
    return new Uint8Array(e);
  }
}
class Ab {
  constructor({
    baseUrl: t = null
  }) {
    this.baseUrl = t;
  }
  async fetch({
    filename: t
  }) {
    if (!this.baseUrl)
      throw new Error("Ensure that the `wasmUrl` API parameter is provided.");
    if (!t)
      throw new Error("Wasm filename must be specified.");
    const e = `${this.baseUrl}${t}`;
    return this._fetch(e).catch((s) => {
      throw new Error(`Unable to load wasm data at: ${e}`);
    });
  }
  async _fetch(t) {
    Dt("Abstract method `_fetch` called.");
  }
}
class jg extends Ab {
  async _fetch(t) {
    const e = await ph(t, "arraybuffer");
    return new Uint8Array(e);
  }
}
ss && J("Please use the `legacy` build in Node.js environments.");
async function yg(d) {
  const e = await process.getBuiltinModule("fs").promises.readFile(d);
  return new Uint8Array(e);
}
class My extends mb {
}
class ky extends pb {
  _createCanvas(t, e) {
    return process.getBuiltinModule("module").createRequire(import.meta.url)("@napi-rs/canvas").createCanvas(t, e);
  }
}
class Ly extends gb {
  async _fetch(t) {
    return yg(t);
  }
}
class Dy extends yb {
  async _fetch(t) {
    return yg(t);
  }
}
class Iy extends Ab {
  async _fetch(t) {
    return yg(t);
  }
}
const Eo = "__forcedDependency", {
  floor: Wg,
  ceil: Xg
} = Math;
function Kd(d, t, e, s, i, r) {
  d[t * 4 + 0] = Math.min(d[t * 4 + 0], e), d[t * 4 + 1] = Math.min(d[t * 4 + 1], s), d[t * 4 + 2] = Math.max(d[t * 4 + 2], i), d[t * 4 + 3] = Math.max(d[t * 4 + 3], r);
}
const hp = new Uint32Array(new Uint8Array([255, 255, 0, 0]).buffer)[0];
var ll, gr;
class Fy {
  constructor(t, e) {
    g(this, ll);
    g(this, gr);
    p(this, ll, t), p(this, gr, e);
  }
  get length() {
    return n(this, ll).length;
  }
  isEmpty(t) {
    return n(this, ll)[t] === hp;
  }
  minX(t) {
    return n(this, gr)[t * 4 + 0] / 256;
  }
  minY(t) {
    return n(this, gr)[t * 4 + 1] / 256;
  }
  maxX(t) {
    return (n(this, gr)[t * 4 + 2] + 1) / 256;
  }
  maxY(t) {
    return (n(this, gr)[t * 4 + 3] + 1) / 256;
  }
}
ll = new WeakMap(), gr = new WeakMap();
const Zd = (d, t) => {
  if (!d)
    return;
  let e = d.get(t);
  return e || (e = {
    dependencies: /* @__PURE__ */ new Set(),
    isRenderingOperation: !1
  }, d.set(t, e)), e;
};
var cs, ds, xa, fi, Pa, En, At, St, Sn, us, Pc, hl, Ra, Ma, _n, Ve, Bi, Rc, cp;
class Ny {
  constructor(t, e, s = !1) {
    g(this, Rc);
    g(this, cs, {
      __proto__: null
    });
    g(this, ds, {
      __proto__: null,
      transform: [],
      moveText: [],
      sameLineText: [],
      [Eo]: []
    });
    g(this, xa, /* @__PURE__ */ new Map());
    g(this, fi, []);
    g(this, Pa, []);
    g(this, En, [[1, 0, 0, 1, 0, 0]]);
    g(this, At, [-1 / 0, -1 / 0, 1 / 0, 1 / 0]);
    g(this, St, new Float64Array([1 / 0, 1 / 0, -1 / 0, -1 / 0]));
    g(this, Sn, -1);
    g(this, us, /* @__PURE__ */ new Set());
    g(this, Pc, /* @__PURE__ */ new Map());
    g(this, hl, /* @__PURE__ */ new Map());
    g(this, Ra);
    g(this, Ma);
    g(this, _n);
    g(this, Ve);
    g(this, Bi);
    p(this, Ra, t.width), p(this, Ma, t.height), b(this, Rc, cp).call(this, e), s && p(this, Bi, /* @__PURE__ */ new Map());
  }
  growOperationsCount(t) {
    t >= n(this, Ve).length && b(this, Rc, cp).call(this, t, n(this, Ve));
  }
  save(t) {
    return p(this, cs, {
      __proto__: n(this, cs)
    }), p(this, ds, {
      __proto__: n(this, ds),
      transform: {
        __proto__: n(this, ds).transform
      },
      moveText: {
        __proto__: n(this, ds).moveText
      },
      sameLineText: {
        __proto__: n(this, ds).sameLineText
      },
      [Eo]: {
        __proto__: n(this, ds)[Eo]
      }
    }), p(this, At, {
      __proto__: n(this, At)
    }), n(this, fi).push(t), this;
  }
  restore(t) {
    var i;
    const e = Object.getPrototypeOf(n(this, cs));
    if (e === null)
      return this;
    p(this, cs, e), p(this, ds, Object.getPrototypeOf(n(this, ds))), p(this, At, Object.getPrototypeOf(n(this, At)));
    const s = n(this, fi).pop();
    return s !== void 0 && ((i = Zd(n(this, Bi), t)) == null || i.dependencies.add(s), n(this, Ve)[t] = n(this, Ve)[s]), this;
  }
  recordOpenMarker(t) {
    return n(this, fi).push(t), this;
  }
  getOpenMarker() {
    return n(this, fi).length === 0 ? null : n(this, fi).at(-1);
  }
  recordCloseMarker(t) {
    var s;
    const e = n(this, fi).pop();
    return e !== void 0 && ((s = Zd(n(this, Bi), t)) == null || s.dependencies.add(e), n(this, Ve)[t] = n(this, Ve)[e]), this;
  }
  beginMarkedContent(t) {
    return n(this, Pa).push(t), this;
  }
  endMarkedContent(t) {
    var s;
    const e = n(this, Pa).pop();
    return e !== void 0 && ((s = Zd(n(this, Bi), t)) == null || s.dependencies.add(e), n(this, Ve)[t] = n(this, Ve)[e]), this;
  }
  pushBaseTransform(t) {
    return n(this, En).push(V.multiplyByDOMMatrix(n(this, En).at(-1), t.getTransform())), this;
  }
  popBaseTransform() {
    return n(this, En).length > 1 && n(this, En).pop(), this;
  }
  recordSimpleData(t, e) {
    return n(this, cs)[t] = e, this;
  }
  recordIncrementalData(t, e) {
    return n(this, ds)[t].push(e), this;
  }
  resetIncrementalData(t, e) {
    return n(this, ds)[t].length = 0, this;
  }
  recordNamedData(t, e) {
    return n(this, xa).set(t, e), this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    n(this, cs)[t] = n(this, xa).get(e) ?? s;
  }
  recordFutureForcedDependency(t, e) {
    return this.recordIncrementalData(Eo, e), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    for (const e of t)
      e in n(this, cs) && this.recordFutureForcedDependency(e, n(this, cs)[e]);
    return this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    for (const t of n(this, us))
      this.recordFutureForcedDependency(Eo, t);
    return this;
  }
  resetBBox(t) {
    return n(this, Sn) !== t && (p(this, Sn, t), n(this, St)[0] = 1 / 0, n(this, St)[1] = 1 / 0, n(this, St)[2] = -1 / 0, n(this, St)[3] = -1 / 0), this;
  }
  recordClipBox(t, e, s, i, r, a) {
    const o = V.multiplyByDOMMatrix(n(this, En).at(-1), e.getTransform()), l = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
    V.axialAlignedBoundingBox([s, r, i, a], o, l);
    const h = V.intersect(n(this, At), l);
    return h ? (n(this, At)[0] = h[0], n(this, At)[1] = h[1], n(this, At)[2] = h[2], n(this, At)[3] = h[3]) : (n(this, At)[0] = n(this, At)[1] = 1 / 0, n(this, At)[2] = n(this, At)[3] = -1 / 0), this;
  }
  recordBBox(t, e, s, i, r, a) {
    const o = n(this, At);
    if (o[0] === 1 / 0)
      return this;
    const l = V.multiplyByDOMMatrix(n(this, En).at(-1), e.getTransform());
    if (o[0] === -1 / 0)
      return V.axialAlignedBoundingBox([s, r, i, a], l, n(this, St)), this;
    const h = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
    return V.axialAlignedBoundingBox([s, r, i, a], l, h), n(this, St)[0] = Math.min(n(this, St)[0], Math.max(h[0], o[0])), n(this, St)[1] = Math.min(n(this, St)[1], Math.max(h[1], o[1])), n(this, St)[2] = Math.max(n(this, St)[2], Math.min(h[2], o[2])), n(this, St)[3] = Math.max(n(this, St)[3], Math.min(h[3], o[3])), this;
  }
  recordCharacterBBox(t, e, s, i = 1, r = 0, a = 0, o) {
    const l = s.bbox;
    let h, c;
    if (l && (h = l[2] !== l[0] && l[3] !== l[1] && n(this, hl).get(s), h !== !1 && (c = [0, 0, 0, 0], V.axialAlignedBoundingBox(l, s.fontMatrix, c), (i !== 1 || r !== 0 || a !== 0) && V.scaleMinMax([i, 0, 0, -i, r, a], c), h)))
      return this.recordBBox(t, e, c[0], c[2], c[1], c[3]);
    if (!o)
      return this.recordFullPageBBox(t);
    const u = o();
    return l && c && h === void 0 && (h = c[0] <= r - u.actualBoundingBoxLeft && c[2] >= r + u.actualBoundingBoxRight && c[1] <= a - u.actualBoundingBoxAscent && c[3] >= a + u.actualBoundingBoxDescent, n(this, hl).set(s, h), h) ? this.recordBBox(t, e, c[0], c[2], c[1], c[3]) : this.recordBBox(t, e, r - u.actualBoundingBoxLeft, r + u.actualBoundingBoxRight, a - u.actualBoundingBoxAscent, a + u.actualBoundingBoxDescent);
  }
  recordFullPageBBox(t) {
    return n(this, St)[0] = Math.max(0, n(this, At)[0]), n(this, St)[1] = Math.max(0, n(this, At)[1]), n(this, St)[2] = Math.min(n(this, Ra), n(this, At)[2]), n(this, St)[3] = Math.min(n(this, Ma), n(this, At)[3]), this;
  }
  getSimpleIndex(t) {
    return n(this, cs)[t];
  }
  recordDependencies(t, e) {
    const s = n(this, us), i = n(this, cs), r = n(this, ds);
    for (const a of e)
      a in n(this, cs) ? s.add(i[a]) : a in r && r[a].forEach(s.add, s);
    return this;
  }
  recordNamedDependency(t, e) {
    return n(this, xa).has(e) && n(this, us).add(n(this, xa).get(e)), this;
  }
  recordOperation(t, e = !1) {
    if (this.recordDependencies(t, [Eo]), n(this, Bi)) {
      const s = Zd(n(this, Bi), t), {
        dependencies: i
      } = s;
      n(this, us).forEach(i.add, i), n(this, fi).forEach(i.add, i), n(this, Pa).forEach(i.add, i), i.delete(t), s.isRenderingOperation = !0;
    }
    if (n(this, Sn) === t) {
      const s = Wg(n(this, St)[0] * 256 / n(this, Ra)), i = Wg(n(this, St)[1] * 256 / n(this, Ma)), r = Xg(n(this, St)[2] * 256 / n(this, Ra)), a = Xg(n(this, St)[3] * 256 / n(this, Ma));
      Kd(n(this, _n), t, s, i, r, a);
      for (const o of n(this, us))
        o !== t && Kd(n(this, _n), o, s, i, r, a);
      for (const o of n(this, fi))
        o !== t && Kd(n(this, _n), o, s, i, r, a);
      for (const o of n(this, Pa))
        o !== t && Kd(n(this, _n), o, s, i, r, a);
      e || (n(this, us).clear(), p(this, Sn, -1));
    }
    return this;
  }
  recordShowTextOperation(t, e = !1) {
    const s = Array.from(n(this, us));
    this.recordOperation(t, e), this.recordIncrementalData("sameLineText", t);
    for (const i of s)
      this.recordIncrementalData("sameLineText", i);
    return this;
  }
  bboxToClipBoxDropOperation(t, e = !1) {
    return n(this, Sn) === t && (p(this, Sn, -1), n(this, At)[0] = Math.max(n(this, At)[0], n(this, St)[0]), n(this, At)[1] = Math.max(n(this, At)[1], n(this, St)[1]), n(this, At)[2] = Math.min(n(this, At)[2], n(this, St)[2]), n(this, At)[3] = Math.min(n(this, At)[3], n(this, St)[3]), e || n(this, us).clear()), this;
  }
  _takePendingDependencies() {
    const t = n(this, us);
    return p(this, us, /* @__PURE__ */ new Set()), t;
  }
  _extractOperation(t) {
    const e = n(this, Pc).get(t);
    return n(this, Pc).delete(t), e;
  }
  _pushPendingDependencies(t) {
    for (const e of t)
      n(this, us).add(e);
  }
  take() {
    return n(this, hl).clear(), new Fy(n(this, Ve), n(this, _n));
  }
  takeDebugMetadata() {
    return n(this, Bi);
  }
}
cs = new WeakMap(), ds = new WeakMap(), xa = new WeakMap(), fi = new WeakMap(), Pa = new WeakMap(), En = new WeakMap(), At = new WeakMap(), St = new WeakMap(), Sn = new WeakMap(), us = new WeakMap(), Pc = new WeakMap(), hl = new WeakMap(), Ra = new WeakMap(), Ma = new WeakMap(), _n = new WeakMap(), Ve = new WeakMap(), Bi = new WeakMap(), Rc = new WeakSet(), cp = function(t, e) {
  const s = new ArrayBuffer(t * 4);
  p(this, _n, new Uint8ClampedArray(s)), p(this, Ve, new Uint32Array(s)), e && e.length > 0 ? (n(this, Ve).set(e), n(this, Ve).fill(hp, e.length)) : n(this, Ve).fill(hp);
};
var Mt, qt, pi, cl, dl;
const Rg = class Rg {
  constructor(t, e, s) {
    g(this, Mt);
    g(this, qt);
    g(this, pi);
    g(this, cl, 0);
    g(this, dl, 0);
    if (t instanceof Rg && n(t, pi) === !!s)
      return t;
    p(this, Mt, t), p(this, qt, e), p(this, pi, !!s);
  }
  growOperationsCount() {
    throw new Error("Unreachable");
  }
  save(t) {
    return oe(this, dl)._++, n(this, Mt).save(n(this, qt)), this;
  }
  restore(t) {
    return n(this, dl) > 0 && (n(this, Mt).restore(n(this, qt)), oe(this, dl)._--), this;
  }
  recordOpenMarker(t) {
    return oe(this, cl)._++, this;
  }
  getOpenMarker() {
    return n(this, cl) > 0 ? n(this, qt) : n(this, Mt).getOpenMarker();
  }
  recordCloseMarker(t) {
    return oe(this, cl)._--, this;
  }
  beginMarkedContent(t) {
    return this;
  }
  endMarkedContent(t) {
    return this;
  }
  pushBaseTransform(t) {
    return n(this, Mt).pushBaseTransform(t), this;
  }
  popBaseTransform() {
    return n(this, Mt).popBaseTransform(), this;
  }
  recordSimpleData(t, e) {
    return n(this, Mt).recordSimpleData(t, n(this, qt)), this;
  }
  recordIncrementalData(t, e) {
    return n(this, Mt).recordIncrementalData(t, n(this, qt)), this;
  }
  resetIncrementalData(t, e) {
    return n(this, Mt).resetIncrementalData(t, n(this, qt)), this;
  }
  recordNamedData(t, e) {
    return this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    return n(this, Mt).recordSimpleDataFromNamed(t, e, n(this, qt)), this;
  }
  recordFutureForcedDependency(t, e) {
    return n(this, Mt).recordFutureForcedDependency(t, n(this, qt)), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    return n(this, Mt).inheritSimpleDataAsFutureForcedDependencies(t), this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    return n(this, Mt).inheritPendingDependenciesAsFutureForcedDependencies(), this;
  }
  resetBBox(t) {
    return n(this, pi) || n(this, Mt).resetBBox(n(this, qt)), this;
  }
  recordClipBox(t, e, s, i, r, a) {
    return n(this, pi) || n(this, Mt).recordClipBox(n(this, qt), e, s, i, r, a), this;
  }
  recordBBox(t, e, s, i, r, a) {
    return n(this, pi) || n(this, Mt).recordBBox(n(this, qt), e, s, i, r, a), this;
  }
  recordCharacterBBox(t, e, s, i, r, a, o) {
    return n(this, pi) || n(this, Mt).recordCharacterBBox(n(this, qt), e, s, i, r, a, o), this;
  }
  recordFullPageBBox(t) {
    return n(this, pi) || n(this, Mt).recordFullPageBBox(n(this, qt)), this;
  }
  getSimpleIndex(t) {
    return n(this, Mt).getSimpleIndex(t);
  }
  recordDependencies(t, e) {
    return n(this, Mt).recordDependencies(n(this, qt), e), this;
  }
  recordNamedDependency(t, e) {
    return n(this, Mt).recordNamedDependency(n(this, qt), e), this;
  }
  recordOperation(t) {
    return n(this, Mt).recordOperation(n(this, qt), !0), this;
  }
  recordShowTextOperation(t) {
    return n(this, Mt).recordShowTextOperation(n(this, qt), !0), this;
  }
  bboxToClipBoxDropOperation(t) {
    return n(this, pi) || n(this, Mt).bboxToClipBoxDropOperation(n(this, qt), !0), this;
  }
  take() {
    throw new Error("Unreachable");
  }
  takeDebugMetadata() {
    throw new Error("Unreachable");
  }
};
Mt = new WeakMap(), qt = new WeakMap(), pi = new WeakMap(), cl = new WeakMap(), dl = new WeakMap();
let Ou = Rg;
const js = {
  stroke: ["path", "transform", "filter", "strokeColor", "strokeAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "dash"],
  fill: ["path", "transform", "filter", "fillColor", "fillAlpha", "globalCompositeOperation", "SMask"],
  imageXObject: ["transform", "SMask", "filter", "fillAlpha", "strokeAlpha", "globalCompositeOperation"],
  rawFillPath: ["filter", "fillColor", "fillAlpha"],
  showText: ["transform", "leading", "charSpacing", "wordSpacing", "hScale", "textRise", "moveText", "textMatrix", "font", "fontObj", "filter", "fillColor", "textRenderingMode", "SMask", "fillAlpha", "strokeAlpha", "globalCompositeOperation", "sameLineText"],
  transform: ["transform"],
  transformAndFill: ["transform", "fillColor"]
}, De = {
  FILL: "Fill",
  STROKE: "Stroke",
  SHADING: "Shading"
};
function dp(d, t) {
  if (!t)
    return;
  const e = t[2] - t[0], s = t[3] - t[1], i = new Path2D();
  i.rect(t[0], t[1], e, s), d.clip(i);
}
class Ag {
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern() {
    Dt("Abstract method `getPattern` called.");
  }
}
class Oy extends Ag {
  constructor(t) {
    super(), this._type = t[1], this._bbox = t[2], this._colorStops = t[3], this._p0 = t[4], this._p1 = t[5], this._r0 = t[6], this._r1 = t[7], this.matrix = null;
  }
  _createGradient(t) {
    let e;
    this._type === "axial" ? e = t.createLinearGradient(this._p0[0], this._p0[1], this._p1[0], this._p1[1]) : this._type === "radial" && (e = t.createRadialGradient(this._p0[0], this._p0[1], this._r0, this._p1[0], this._p1[1], this._r1));
    for (const s of this._colorStops)
      e.addColorStop(s[0], s[1]);
    return e;
  }
  getPattern(t, e, s, i) {
    let r;
    if (i === De.STROKE || i === De.FILL) {
      const a = e.current.getClippedPathBoundingBox(i, Vt(t)) || [0, 0, 0, 0], o = Math.ceil(a[2] - a[0]) || 1, l = Math.ceil(a[3] - a[1]) || 1, h = e.cachedCanvases.getCanvas("pattern", o, l), c = h.context;
      c.clearRect(0, 0, c.canvas.width, c.canvas.height), c.beginPath(), c.rect(0, 0, c.canvas.width, c.canvas.height), c.translate(-a[0], -a[1]), s = V.transform(s, [1, 0, 0, 1, a[0], a[1]]), c.transform(...e.baseTransform), this.matrix && c.transform(...this.matrix), dp(c, this._bbox), c.fillStyle = this._createGradient(c), c.fill(), r = t.createPattern(h.canvas, "no-repeat");
      const u = new DOMMatrix(s);
      r.setTransform(u);
    } else
      dp(t, this._bbox), r = this._createGradient(t);
    return r;
  }
}
function kf(d, t, e, s, i, r, a, o) {
  const l = t.coords, h = t.colors, c = d.data, u = d.width * 4;
  let f;
  l[e + 1] > l[s + 1] && (f = e, e = s, s = f, f = r, r = a, a = f), l[s + 1] > l[i + 1] && (f = s, s = i, i = f, f = a, a = o, o = f), l[e + 1] > l[s + 1] && (f = e, e = s, s = f, f = r, r = a, a = f);
  const m = (l[e] + t.offsetX) * t.scaleX, A = (l[e + 1] + t.offsetY) * t.scaleY, y = (l[s] + t.offsetX) * t.scaleX, v = (l[s + 1] + t.offsetY) * t.scaleY, w = (l[i] + t.offsetX) * t.scaleX, S = (l[i + 1] + t.offsetY) * t.scaleY;
  if (A >= S)
    return;
  const E = h[r], _ = h[r + 1], C = h[r + 2], T = h[a], x = h[a + 1], R = h[a + 2], M = h[o], D = h[o + 1], k = h[o + 2], N = Math.round(A), X = Math.round(S);
  let B, Y, O, H, st, at, Jt, qe;
  for (let lt = N; lt <= X; lt++) {
    if (lt < v) {
      const ct = lt < A ? 0 : (A - lt) / (A - v);
      B = m - (m - y) * ct, Y = E - (E - T) * ct, O = _ - (_ - x) * ct, H = C - (C - R) * ct;
    } else {
      let ct;
      lt > S ? ct = 1 : v === S ? ct = 0 : ct = (v - lt) / (v - S), B = y - (y - w) * ct, Y = T - (T - M) * ct, O = x - (x - D) * ct, H = R - (R - k) * ct;
    }
    let tt;
    lt < A ? tt = 0 : lt > S ? tt = 1 : tt = (A - lt) / (A - S), st = m - (m - w) * tt, at = E - (E - M) * tt, Jt = _ - (_ - D) * tt, qe = C - (C - k) * tt;
    const vt = Math.round(Math.min(B, st)), ie = Math.round(Math.max(B, st));
    let fe = u * lt + vt * 4;
    for (let ct = vt; ct <= ie; ct++)
      tt = (B - ct) / (B - st), tt < 0 ? tt = 0 : tt > 1 && (tt = 1), c[fe++] = Y - (Y - at) * tt | 0, c[fe++] = O - (O - Jt) * tt | 0, c[fe++] = H - (H - qe) * tt | 0, c[fe++] = 255;
  }
}
function By(d, t, e) {
  const s = t.coords, i = t.colors;
  let r, a;
  switch (t.type) {
    case "lattice":
      const o = t.verticesPerRow, l = Math.floor(s.length / o) - 1, h = o - 1;
      for (r = 0; r < l; r++) {
        let c = r * o;
        for (let u = 0; u < h; u++, c++)
          kf(d, e, s[c], s[c + 1], s[c + o], i[c], i[c + 1], i[c + o]), kf(d, e, s[c + o + 1], s[c + 1], s[c + o], i[c + o + 1], i[c + 1], i[c + o]);
      }
      break;
    case "triangles":
      for (r = 0, a = s.length; r < a; r += 3)
        kf(d, e, s[r], s[r + 1], s[r + 2], i[r], i[r + 1], i[r + 2]);
      break;
    default:
      throw new Error("illegal figure");
  }
}
class Hy extends Ag {
  constructor(t) {
    super(), this._coords = t[2], this._colors = t[3], this._figures = t[4], this._bounds = t[5], this._bbox = t[6], this._background = t[7], this.matrix = null;
  }
  _createMeshCanvas(t, e, s) {
    const o = Math.floor(this._bounds[0]), l = Math.floor(this._bounds[1]), h = Math.ceil(this._bounds[2]) - o, c = Math.ceil(this._bounds[3]) - l, u = Math.min(Math.ceil(Math.abs(h * t[0] * 1.1)), 3e3), f = Math.min(Math.ceil(Math.abs(c * t[1] * 1.1)), 3e3), m = h / u, A = c / f, y = {
      coords: this._coords,
      colors: this._colors,
      offsetX: -o,
      offsetY: -l,
      scaleX: 1 / m,
      scaleY: 1 / A
    }, v = u + 4, w = f + 4, S = s.getCanvas("mesh", v, w), E = S.context, _ = E.createImageData(u, f);
    if (e) {
      const T = _.data;
      for (let x = 0, R = T.length; x < R; x += 4)
        T[x] = e[0], T[x + 1] = e[1], T[x + 2] = e[2], T[x + 3] = 255;
    }
    for (const T of this._figures)
      By(_, T, y);
    return E.putImageData(_, 2, 2), {
      canvas: S.canvas,
      offsetX: o - 2 * m,
      offsetY: l - 2 * A,
      scaleX: m,
      scaleY: A
    };
  }
  isModifyingCurrentTransform() {
    return !0;
  }
  getPattern(t, e, s, i) {
    dp(t, this._bbox);
    const r = new Float32Array(2);
    if (i === De.SHADING)
      V.singularValueDecompose2dScale(Vt(t), r);
    else if (this.matrix) {
      V.singularValueDecompose2dScale(this.matrix, r);
      const [o, l] = r;
      V.singularValueDecompose2dScale(e.baseTransform, r), r[0] *= o, r[1] *= l;
    } else
      V.singularValueDecompose2dScale(e.baseTransform, r);
    const a = this._createMeshCanvas(r, i === De.SHADING ? null : this._background, e.cachedCanvases);
    return i !== De.SHADING && (t.setTransform(...e.baseTransform), this.matrix && t.transform(...this.matrix)), t.translate(a.offsetX, a.offsetY), t.scale(a.scaleX, a.scaleY), t.createPattern(a.canvas, "no-repeat");
  }
}
class Uy extends Ag {
  getPattern() {
    return "hotpink";
  }
}
function $y(d) {
  switch (d[0]) {
    case "RadialAxial":
      return new Oy(d);
    case "Mesh":
      return new Hy(d);
    case "Dummy":
      return new Uy();
  }
  throw new Error(`Unknown IR type: ${d[0]}`);
}
const qg = {
  COLORED: 1,
  UNCOLORED: 2
}, tf = class tf {
  constructor(t, e, s, i) {
    this.color = t[1], this.operatorList = t[2], this.matrix = t[3], this.bbox = t[4], this.xstep = t[5], this.ystep = t[6], this.paintType = t[7], this.tilingType = t[8], this.ctx = e, this.canvasGraphicsFactory = s, this.baseTransform = i;
  }
  createPatternCanvas(t, e) {
    var at, Jt;
    const {
      bbox: s,
      operatorList: i,
      paintType: r,
      tilingType: a,
      color: o,
      canvasGraphicsFactory: l
    } = this;
    let {
      xstep: h,
      ystep: c
    } = this;
    h = Math.abs(h), c = Math.abs(c), ff("TilingType: " + a);
    const u = s[0], f = s[1], m = s[2], A = s[3], y = m - u, v = A - f, w = new Float32Array(2);
    V.singularValueDecompose2dScale(this.matrix, w);
    const [S, E] = w;
    V.singularValueDecompose2dScale(this.baseTransform, w);
    const _ = S * w[0], C = E * w[1];
    let T = y, x = v, R = !1, M = !1;
    const D = Math.ceil(h * _), k = Math.ceil(c * C), N = Math.ceil(y * _), X = Math.ceil(v * C);
    D >= N ? T = h : R = !0, k >= X ? x = c : M = !0;
    const B = this.getSizeAndScale(T, this.ctx.canvas.width, _), Y = this.getSizeAndScale(x, this.ctx.canvas.height, C), O = t.cachedCanvases.getCanvas("pattern", B.size, Y.size), H = O.context, st = l.createCanvasGraphics(H, e);
    if (st.groupLevel = t.groupLevel, this.setFillAndStrokeStyleToContext(st, r, o), H.translate(-B.scale * u, -Y.scale * f), st.transform(0, B.scale, 0, 0, Y.scale, 0, 0), H.save(), (at = st.dependencyTracker) == null || at.save(), this.clipBbox(st, u, f, m, A), st.baseTransform = Vt(st.ctx), st.executeOperatorList(i), st.endDrawing(), (Jt = st.dependencyTracker) == null || Jt.restore(), H.restore(), R || M) {
      const qe = O.canvas;
      R && (T = h), M && (x = c);
      const lt = this.getSizeAndScale(T, this.ctx.canvas.width, _), tt = this.getSizeAndScale(x, this.ctx.canvas.height, C), vt = lt.size, ie = tt.size, fe = t.cachedCanvases.getCanvas("pattern-workaround", vt, ie), ct = fe.context, bs = R ? Math.floor(y / h) : 0, Ye = M ? Math.floor(v / c) : 0;
      for (let Vs = 0; Vs <= bs; Vs++)
        for (let Ce = 0; Ce <= Ye; Ce++)
          ct.drawImage(qe, vt * Vs, ie * Ce, vt, ie, 0, 0, vt, ie);
      return {
        canvas: fe.canvas,
        scaleX: lt.scale,
        scaleY: tt.scale,
        offsetX: u,
        offsetY: f
      };
    }
    return {
      canvas: O.canvas,
      scaleX: B.scale,
      scaleY: Y.scale,
      offsetX: u,
      offsetY: f
    };
  }
  getSizeAndScale(t, e, s) {
    const i = Math.max(tf.MAX_PATTERN_SIZE, e);
    let r = Math.ceil(t * s);
    return r >= i ? r = i : s = r / t, {
      scale: s,
      size: r
    };
  }
  clipBbox(t, e, s, i, r) {
    const a = i - e, o = r - s;
    t.ctx.rect(e, s, a, o), V.axialAlignedBoundingBox([e, s, i, r], Vt(t.ctx), t.current.minMax), t.clip(), t.endPath();
  }
  setFillAndStrokeStyleToContext(t, e, s) {
    const i = t.ctx, r = t.current;
    switch (e) {
      case qg.COLORED:
        const {
          fillStyle: a,
          strokeStyle: o
        } = this.ctx;
        i.fillStyle = r.fillColor = a, i.strokeStyle = r.strokeColor = o;
        break;
      case qg.UNCOLORED:
        i.fillStyle = i.strokeStyle = s, r.fillColor = r.strokeColor = s;
        break;
      default:
        throw new ly(`Unsupported paint type: ${e}`);
    }
  }
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern(t, e, s, i, r) {
    let a = s;
    i !== De.SHADING && (a = V.transform(a, e.baseTransform), this.matrix && (a = V.transform(a, this.matrix)));
    const o = this.createPatternCanvas(e, r);
    let l = new DOMMatrix(a);
    l = l.translate(o.offsetX, o.offsetY), l = l.scale(1 / o.scaleX, 1 / o.scaleY);
    const h = t.createPattern(o.canvas, "repeat");
    return h.setTransform(l), h;
  }
};
L(tf, "MAX_PATTERN_SIZE", 3e3);
let up = tf;
function Vy({
  src: d,
  srcPos: t = 0,
  dest: e,
  width: s,
  height: i,
  nonBlackColor: r = 4294967295,
  inverseDecode: a = !1
}) {
  const o = _e.isLittleEndian ? 4278190080 : 255, [l, h] = a ? [r, o] : [o, r], c = s >> 3, u = s & 7, f = d.length;
  e = new Uint32Array(e.buffer);
  let m = 0;
  for (let A = 0; A < i; A++) {
    for (const v = t + c; t < v; t++) {
      const w = t < f ? d[t] : 255;
      e[m++] = w & 128 ? h : l, e[m++] = w & 64 ? h : l, e[m++] = w & 32 ? h : l, e[m++] = w & 16 ? h : l, e[m++] = w & 8 ? h : l, e[m++] = w & 4 ? h : l, e[m++] = w & 2 ? h : l, e[m++] = w & 1 ? h : l;
    }
    if (u === 0)
      continue;
    const y = t < f ? d[t++] : 255;
    for (let v = 0; v < u; v++)
      e[m++] = y & 1 << 7 - v ? h : l;
  }
  return {
    srcPos: t,
    destPos: m
  };
}
const Yg = 16, Kg = 100, zy = 15, Zg = 10, ms = 16, Lf = new DOMMatrix(), Bs = new Float32Array(2), ko = new Float32Array([1 / 0, 1 / 0, -1 / 0, -1 / 0]);
function Gy(d, t) {
  if (d._removeMirroring)
    throw new Error("Context is already forwarding operations.");
  d.__originalSave = d.save, d.__originalRestore = d.restore, d.__originalRotate = d.rotate, d.__originalScale = d.scale, d.__originalTranslate = d.translate, d.__originalTransform = d.transform, d.__originalSetTransform = d.setTransform, d.__originalResetTransform = d.resetTransform, d.__originalClip = d.clip, d.__originalMoveTo = d.moveTo, d.__originalLineTo = d.lineTo, d.__originalBezierCurveTo = d.bezierCurveTo, d.__originalRect = d.rect, d.__originalClosePath = d.closePath, d.__originalBeginPath = d.beginPath, d._removeMirroring = () => {
    d.save = d.__originalSave, d.restore = d.__originalRestore, d.rotate = d.__originalRotate, d.scale = d.__originalScale, d.translate = d.__originalTranslate, d.transform = d.__originalTransform, d.setTransform = d.__originalSetTransform, d.resetTransform = d.__originalResetTransform, d.clip = d.__originalClip, d.moveTo = d.__originalMoveTo, d.lineTo = d.__originalLineTo, d.bezierCurveTo = d.__originalBezierCurveTo, d.rect = d.__originalRect, d.closePath = d.__originalClosePath, d.beginPath = d.__originalBeginPath, delete d._removeMirroring;
  }, d.save = function() {
    t.save(), this.__originalSave();
  }, d.restore = function() {
    t.restore(), this.__originalRestore();
  }, d.translate = function(e, s) {
    t.translate(e, s), this.__originalTranslate(e, s);
  }, d.scale = function(e, s) {
    t.scale(e, s), this.__originalScale(e, s);
  }, d.transform = function(e, s, i, r, a, o) {
    t.transform(e, s, i, r, a, o), this.__originalTransform(e, s, i, r, a, o);
  }, d.setTransform = function(e, s, i, r, a, o) {
    t.setTransform(e, s, i, r, a, o), this.__originalSetTransform(e, s, i, r, a, o);
  }, d.resetTransform = function() {
    t.resetTransform(), this.__originalResetTransform();
  }, d.rotate = function(e) {
    t.rotate(e), this.__originalRotate(e);
  }, d.clip = function(e) {
    t.clip(e), this.__originalClip(e);
  }, d.moveTo = function(e, s) {
    t.moveTo(e, s), this.__originalMoveTo(e, s);
  }, d.lineTo = function(e, s) {
    t.lineTo(e, s), this.__originalLineTo(e, s);
  }, d.bezierCurveTo = function(e, s, i, r, a, o) {
    t.bezierCurveTo(e, s, i, r, a, o), this.__originalBezierCurveTo(e, s, i, r, a, o);
  }, d.rect = function(e, s, i, r) {
    t.rect(e, s, i, r), this.__originalRect(e, s, i, r);
  }, d.closePath = function() {
    t.closePath(), this.__originalClosePath();
  }, d.beginPath = function() {
    t.beginPath(), this.__originalBeginPath();
  };
}
class jy {
  constructor(t) {
    this.canvasFactory = t, this.cache = /* @__PURE__ */ Object.create(null);
  }
  getCanvas(t, e, s) {
    let i;
    return this.cache[t] !== void 0 ? (i = this.cache[t], this.canvasFactory.reset(i, e, s)) : (i = this.canvasFactory.create(e, s), this.cache[t] = i), i;
  }
  delete(t) {
    delete this.cache[t];
  }
  clear() {
    for (const t in this.cache) {
      const e = this.cache[t];
      this.canvasFactory.destroy(e), delete this.cache[t];
    }
  }
}
function Jd(d, t, e, s, i, r, a, o, l, h) {
  const [c, u, f, m, A, y] = Vt(d);
  if (u === 0 && f === 0) {
    const S = a * c + A, E = Math.round(S), _ = o * m + y, C = Math.round(_), T = (a + l) * c + A, x = Math.abs(Math.round(T) - E) || 1, R = (o + h) * m + y, M = Math.abs(Math.round(R) - C) || 1;
    return d.setTransform(Math.sign(c), 0, 0, Math.sign(m), E, C), d.drawImage(t, e, s, i, r, 0, 0, x, M), d.setTransform(c, u, f, m, A, y), [x, M];
  }
  if (c === 0 && m === 0) {
    const S = o * f + A, E = Math.round(S), _ = a * u + y, C = Math.round(_), T = (o + h) * f + A, x = Math.abs(Math.round(T) - E) || 1, R = (a + l) * u + y, M = Math.abs(Math.round(R) - C) || 1;
    return d.setTransform(0, Math.sign(u), Math.sign(f), 0, E, C), d.drawImage(t, e, s, i, r, 0, 0, M, x), d.setTransform(c, u, f, m, A, y), [M, x];
  }
  d.drawImage(t, e, s, i, r, a, o, l, h);
  const v = Math.hypot(c, u), w = Math.hypot(f, m);
  return [v * l, w * h];
}
class Jg {
  constructor(t, e, s) {
    L(this, "alphaIsShape", !1);
    L(this, "fontSize", 0);
    L(this, "fontSizeScale", 1);
    L(this, "textMatrix", null);
    L(this, "textMatrixScale", 1);
    L(this, "fontMatrix", Bf);
    L(this, "leading", 0);
    L(this, "x", 0);
    L(this, "y", 0);
    L(this, "lineX", 0);
    L(this, "lineY", 0);
    L(this, "charSpacing", 0);
    L(this, "wordSpacing", 0);
    L(this, "textHScale", 1);
    L(this, "textRenderingMode", xe.FILL);
    L(this, "textRise", 0);
    L(this, "fillColor", "#000000");
    L(this, "strokeColor", "#000000");
    L(this, "patternFill", !1);
    L(this, "patternStroke", !1);
    L(this, "fillAlpha", 1);
    L(this, "strokeAlpha", 1);
    L(this, "lineWidth", 1);
    L(this, "activeSMask", null);
    L(this, "transferMaps", "none");
    s == null || s(this), this.clipBox = new Float32Array([0, 0, t, e]), this.minMax = ko.slice();
  }
  clone() {
    const t = Object.create(this);
    return t.clipBox = this.clipBox.slice(), t.minMax = this.minMax.slice(), t;
  }
  getPathBoundingBox(t = De.FILL, e = null) {
    const s = this.minMax.slice();
    if (t === De.STROKE) {
      e || Dt("Stroke bounding box must include transform."), V.singularValueDecompose2dScale(e, Bs);
      const i = Bs[0] * this.lineWidth / 2, r = Bs[1] * this.lineWidth / 2;
      s[0] -= i, s[1] -= r, s[2] += i, s[3] += r;
    }
    return s;
  }
  updateClipFromPath() {
    const t = V.intersect(this.clipBox, this.getPathBoundingBox());
    this.startNewPathAndClipBox(t || [0, 0, 0, 0]);
  }
  isEmptyClip() {
    return this.minMax[0] === 1 / 0;
  }
  startNewPathAndClipBox(t) {
    this.clipBox.set(t, 0), this.minMax.set(ko, 0);
  }
  getClippedPathBoundingBox(t = De.FILL, e = null) {
    return V.intersect(this.clipBox, this.getPathBoundingBox(t, e));
  }
}
function Qg(d, t) {
  if (t instanceof ImageData) {
    d.putImageData(t, 0, 0);
    return;
  }
  const e = t.height, s = t.width, i = e % ms, r = (e - i) / ms, a = i === 0 ? r : r + 1, o = d.createImageData(s, ms);
  let l = 0, h;
  const c = t.data, u = o.data;
  let f, m, A, y;
  if (t.kind === zh.GRAYSCALE_1BPP) {
    const v = c.byteLength, w = new Uint32Array(u.buffer, 0, u.byteLength >> 2), S = w.length, E = s + 7 >> 3, _ = 4294967295, C = _e.isLittleEndian ? 4278190080 : 255;
    for (f = 0; f < a; f++) {
      for (A = f < r ? ms : i, h = 0, m = 0; m < A; m++) {
        const T = v - l;
        let x = 0;
        const R = T > E ? s : T * 8 - 7, M = R & -8;
        let D = 0, k = 0;
        for (; x < M; x += 8)
          k = c[l++], w[h++] = k & 128 ? _ : C, w[h++] = k & 64 ? _ : C, w[h++] = k & 32 ? _ : C, w[h++] = k & 16 ? _ : C, w[h++] = k & 8 ? _ : C, w[h++] = k & 4 ? _ : C, w[h++] = k & 2 ? _ : C, w[h++] = k & 1 ? _ : C;
        for (; x < R; x++)
          D === 0 && (k = c[l++], D = 128), w[h++] = k & D ? _ : C, D >>= 1;
      }
      for (; h < S; )
        w[h++] = 0;
      d.putImageData(o, 0, f * ms);
    }
  } else if (t.kind === zh.RGBA_32BPP) {
    for (m = 0, y = s * ms * 4, f = 0; f < r; f++)
      u.set(c.subarray(l, l + y)), l += y, d.putImageData(o, 0, m), m += ms;
    f < a && (y = s * i * 4, u.set(c.subarray(l, l + y)), d.putImageData(o, 0, m));
  } else if (t.kind === zh.RGB_24BPP)
    for (A = ms, y = s * A, f = 0; f < a; f++) {
      for (f >= r && (A = i, y = s * A), h = 0, m = y; m--; )
        u[h++] = c[l++], u[h++] = c[l++], u[h++] = c[l++], u[h++] = 255;
      d.putImageData(o, 0, f * ms);
    }
  else
    throw new Error(`bad image kind: ${t.kind}`);
}
function tm(d, t) {
  if (t.bitmap) {
    d.drawImage(t.bitmap, 0, 0);
    return;
  }
  const e = t.height, s = t.width, i = e % ms, r = (e - i) / ms, a = i === 0 ? r : r + 1, o = d.createImageData(s, ms);
  let l = 0;
  const h = t.data, c = o.data;
  for (let u = 0; u < a; u++) {
    const f = u < r ? ms : i;
    ({
      srcPos: l
    } = Vy({
      src: h,
      srcPos: l,
      dest: c,
      width: s,
      height: f,
      nonBlackColor: 0
    })), d.putImageData(o, 0, u * ms);
  }
}
function yh(d, t) {
  const e = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
  for (const s of e)
    d[s] !== void 0 && (t[s] = d[s]);
  d.setLineDash !== void 0 && (t.setLineDash(d.getLineDash()), t.lineDashOffset = d.lineDashOffset);
}
function Qd(d) {
  d.strokeStyle = d.fillStyle = "#000000", d.fillRule = "nonzero", d.globalAlpha = 1, d.lineWidth = 1, d.lineCap = "butt", d.lineJoin = "miter", d.miterLimit = 10, d.globalCompositeOperation = "source-over", d.font = "10px sans-serif", d.setLineDash !== void 0 && (d.setLineDash([]), d.lineDashOffset = 0);
  const {
    filter: t
  } = d;
  t !== "none" && t !== "" && (d.filter = "none");
}
function em(d, t) {
  if (t)
    return !0;
  V.singularValueDecompose2dScale(d, Bs);
  const e = Math.fround(Si.pixelRatio * jn.PDF_TO_CSS_UNITS);
  return Bs[0] <= e && Bs[1] <= e;
}
const Wy = ["butt", "round", "square"], Xy = ["miter", "round", "bevel"], qy = {}, sm = {};
var _i, fp, pp, gp;
const Mg = class Mg {
  constructor(t, e, s, i, r, {
    optionalContentConfig: a,
    markedContentStack: o = null
  }, l, h, c) {
    g(this, _i);
    this.ctx = t, this.current = new Jg(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.res = null, this.xobjs = null, this.commonObjs = e, this.objs = s, this.canvasFactory = i, this.filterFactory = r, this.groupStack = [], this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.smaskCounter = 0, this.tempSMask = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = o || [], this.optionalContentConfig = a, this.cachedCanvases = new jy(this.canvasFactory), this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = l, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = h, this._cachedScaleForStroking = [-1, 0], this._cachedGetSinglePixelWidth = null, this._cachedBitmapsMap = /* @__PURE__ */ new Map(), this.dependencyTracker = c ?? null;
  }
  getObject(t, e, s = null) {
    var i;
    return typeof e == "string" ? ((i = this.dependencyTracker) == null || i.recordNamedDependency(t, e), e.startsWith("g_") ? this.commonObjs.get(e) : this.objs.get(e)) : s;
  }
  beginDrawing({
    transform: t,
    viewport: e,
    transparency: s = !1,
    background: i = null
  }) {
    const r = this.ctx.canvas.width, a = this.ctx.canvas.height, o = this.ctx.fillStyle;
    if (this.ctx.fillStyle = i || "#ffffff", this.ctx.fillRect(0, 0, r, a), this.ctx.fillStyle = o, s) {
      const l = this.cachedCanvases.getCanvas("transparent", r, a);
      this.compositeCtx = this.ctx, this.transparentCanvas = l.canvas, this.ctx = l.context, this.ctx.save(), this.ctx.transform(...Vt(this.compositeCtx));
    }
    this.ctx.save(), Qd(this.ctx), t && (this.ctx.transform(...t), this.outputScaleX = t[0], this.outputScaleY = t[0]), this.ctx.transform(...e.transform), this.viewportScale = e.scale, this.baseTransform = Vt(this.ctx);
  }
  executeOperatorList(t, e, s, i, r) {
    var w;
    const a = t.argsArray, o = t.fnArray;
    let l = e || 0;
    const h = a.length;
    if (h === l)
      return l;
    const c = h - l > Zg && typeof s == "function", u = c ? Date.now() + zy : 0;
    let f = 0;
    const m = this.commonObjs, A = this.objs;
    let y, v;
    for (; ; ) {
      if (i !== void 0 && l === i.nextBreakPoint)
        return i.breakIt(l, s), l;
      if (!r || r(l))
        if (y = o[l], v = a[l] ?? null, y !== dh.dependency)
          v === null ? this[y](l) : this[y](l, ...v);
        else
          for (const S of v) {
            (w = this.dependencyTracker) == null || w.recordNamedData(S, l);
            const E = S.startsWith("g_") ? m : A;
            if (!E.has(S))
              return E.get(S, s), l;
          }
      if (l++, l === h)
        return l;
      if (c && ++f > Zg) {
        if (Date.now() > u)
          return s(), l;
        f = 0;
      }
    }
  }
  endDrawing() {
    b(this, _i, fp).call(this), this.cachedCanvases.clear(), this.cachedPatterns.clear();
    for (const t of this._cachedBitmapsMap.values()) {
      for (const e of t.values())
        typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement && (e.width = e.height = 0);
      t.clear();
    }
    this._cachedBitmapsMap.clear(), b(this, _i, pp).call(this);
  }
  _scaleImage(t, e) {
    const s = t.width ?? t.displayWidth, i = t.height ?? t.displayHeight;
    let r = Math.max(Math.hypot(e[0], e[1]), 1), a = Math.max(Math.hypot(e[2], e[3]), 1), o = s, l = i, h = "prescale1", c, u;
    for (; r > 2 && o > 1 || a > 2 && l > 1; ) {
      let f = o, m = l;
      r > 2 && o > 1 && (f = o >= 16384 ? Math.floor(o / 2) - 1 || 1 : Math.ceil(o / 2), r /= o / f), a > 2 && l > 1 && (m = l >= 16384 ? Math.floor(l / 2) - 1 || 1 : Math.ceil(l) / 2, a /= l / m), c = this.cachedCanvases.getCanvas(h, f, m), u = c.context, u.clearRect(0, 0, f, m), u.drawImage(t, 0, 0, o, l, 0, 0, f, m), t = c.canvas, o = f, l = m, h = h === "prescale1" ? "prescale2" : "prescale1";
    }
    return {
      img: t,
      paintWidth: o,
      paintHeight: l
    };
  }
  _createMaskCanvas(t, e) {
    var D, k;
    const s = this.ctx, {
      width: i,
      height: r
    } = e, a = this.current.fillColor, o = this.current.patternFill, l = Vt(s);
    let h, c, u, f;
    if ((e.bitmap || e.data) && e.count > 1) {
      const N = e.bitmap || e.data.buffer;
      c = JSON.stringify(o ? l : [l.slice(0, 4), a]), h = this._cachedBitmapsMap.get(N), h || (h = /* @__PURE__ */ new Map(), this._cachedBitmapsMap.set(N, h));
      const X = h.get(c);
      if (X && !o) {
        const B = Math.round(Math.min(l[0], l[2]) + l[4]), Y = Math.round(Math.min(l[1], l[3]) + l[5]);
        return (D = this.dependencyTracker) == null || D.recordDependencies(t, js.transformAndFill), {
          canvas: X,
          offsetX: B,
          offsetY: Y
        };
      }
      u = X;
    }
    u || (f = this.cachedCanvases.getCanvas("maskCanvas", i, r), tm(f.context, e));
    let m = V.transform(l, [1 / i, 0, 0, -1 / r, 0, 0]);
    m = V.transform(m, [1, 0, 0, 1, 0, -r]);
    const A = ko.slice();
    V.axialAlignedBoundingBox([0, 0, i, r], m, A);
    const [y, v, w, S] = A, E = Math.round(w - y) || 1, _ = Math.round(S - v) || 1, C = this.cachedCanvases.getCanvas("fillCanvas", E, _), T = C.context, x = y, R = v;
    T.translate(-x, -R), T.transform(...m), u || (u = this._scaleImage(f.canvas, Ci(T)), u = u.img, h && o && h.set(c, u)), T.imageSmoothingEnabled = em(Vt(T), e.interpolate), Jd(T, u, 0, 0, u.width, u.height, 0, 0, i, r), T.globalCompositeOperation = "source-in";
    const M = V.transform(Ci(T), [1, 0, 0, 1, -x, -R]);
    return T.fillStyle = o ? a.getPattern(s, this, M, De.FILL, t) : a, T.fillRect(0, 0, i, r), h && !o && (this.cachedCanvases.delete("fillCanvas"), h.set(c, C.canvas)), (k = this.dependencyTracker) == null || k.recordDependencies(t, js.transformAndFill), {
      canvas: C.canvas,
      offsetX: Math.round(x),
      offsetY: Math.round(R)
    };
  }
  setLineWidth(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("lineWidth", t), e !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = e, this.ctx.lineWidth = e;
  }
  setLineCap(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("lineCap", t), this.ctx.lineCap = Wy[e];
  }
  setLineJoin(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("lineJoin", t), this.ctx.lineJoin = Xy[e];
  }
  setMiterLimit(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("miterLimit", t), this.ctx.miterLimit = e;
  }
  setDash(t, e, s) {
    var r;
    (r = this.dependencyTracker) == null || r.recordSimpleData("dash", t);
    const i = this.ctx;
    i.setLineDash !== void 0 && (i.setLineDash(e), i.lineDashOffset = s);
  }
  setRenderingIntent(t, e) {
  }
  setFlatness(t, e) {
  }
  setGState(t, e) {
    var s, i, r, a, o;
    for (const [l, h] of e)
      switch (l) {
        case "LW":
          this.setLineWidth(t, h);
          break;
        case "LC":
          this.setLineCap(t, h);
          break;
        case "LJ":
          this.setLineJoin(t, h);
          break;
        case "ML":
          this.setMiterLimit(t, h);
          break;
        case "D":
          this.setDash(t, h[0], h[1]);
          break;
        case "RI":
          this.setRenderingIntent(t, h);
          break;
        case "FL":
          this.setFlatness(t, h);
          break;
        case "Font":
          this.setFont(t, h[0], h[1]);
          break;
        case "CA":
          (s = this.dependencyTracker) == null || s.recordSimpleData("strokeAlpha", t), this.current.strokeAlpha = h;
          break;
        case "ca":
          (i = this.dependencyTracker) == null || i.recordSimpleData("fillAlpha", t), this.ctx.globalAlpha = this.current.fillAlpha = h;
          break;
        case "BM":
          (r = this.dependencyTracker) == null || r.recordSimpleData("globalCompositeOperation", t), this.ctx.globalCompositeOperation = h;
          break;
        case "SMask":
          (a = this.dependencyTracker) == null || a.recordSimpleData("SMask", t), this.current.activeSMask = h ? this.tempSMask : null, this.tempSMask = null, this.checkSMaskState();
          break;
        case "TR":
          (o = this.dependencyTracker) == null || o.recordSimpleData("filter", t), this.ctx.filter = this.current.transferMaps = this.filterFactory.addFilter(h);
          break;
      }
  }
  get inSMaskMode() {
    return !!this.suspendedCtx;
  }
  checkSMaskState() {
    const t = this.inSMaskMode;
    this.current.activeSMask && !t ? this.beginSMaskMode() : !this.current.activeSMask && t && this.endSMaskMode();
  }
  beginSMaskMode(t) {
    if (this.inSMaskMode)
      throw new Error("beginSMaskMode called while already in smask mode");
    const e = this.ctx.canvas.width, s = this.ctx.canvas.height, i = "smaskGroupAt" + this.groupLevel, r = this.cachedCanvases.getCanvas(i, e, s);
    this.suspendedCtx = this.ctx;
    const a = this.ctx = r.context;
    a.setTransform(this.suspendedCtx.getTransform()), yh(this.suspendedCtx, a), Gy(a, this.suspendedCtx), this.setGState(t, [["BM", "source-over"]]);
  }
  endSMaskMode() {
    if (!this.inSMaskMode)
      throw new Error("endSMaskMode called while not in smask mode");
    this.ctx._removeMirroring(), yh(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null;
  }
  compose(t) {
    if (!this.current.activeSMask)
      return;
    t ? (t[0] = Math.floor(t[0]), t[1] = Math.floor(t[1]), t[2] = Math.ceil(t[2]), t[3] = Math.ceil(t[3])) : t = [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
    const e = this.current.activeSMask, s = this.suspendedCtx;
    this.composeSMask(s, e, this.ctx, t), this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore();
  }
  composeSMask(t, e, s, i) {
    const r = i[0], a = i[1], o = i[2] - r, l = i[3] - a;
    o === 0 || l === 0 || (this.genericComposeSMask(e.context, s, o, l, e.subtype, e.backdrop, e.transferMap, r, a, e.offsetX, e.offsetY), t.save(), t.globalAlpha = 1, t.globalCompositeOperation = "source-over", t.setTransform(1, 0, 0, 1, 0, 0), t.drawImage(s.canvas, 0, 0), t.restore());
  }
  genericComposeSMask(t, e, s, i, r, a, o, l, h, c, u) {
    let f = t.canvas, m = l - c, A = h - u;
    if (a)
      if (m < 0 || A < 0 || m + s > f.width || A + i > f.height) {
        const v = this.cachedCanvases.getCanvas("maskExtension", s, i), w = v.context;
        w.drawImage(f, -m, -A), w.globalCompositeOperation = "destination-atop", w.fillStyle = a, w.fillRect(0, 0, s, i), w.globalCompositeOperation = "source-over", f = v.canvas, m = A = 0;
      } else {
        t.save(), t.globalAlpha = 1, t.setTransform(1, 0, 0, 1, 0, 0);
        const v = new Path2D();
        v.rect(m, A, s, i), t.clip(v), t.globalCompositeOperation = "destination-atop", t.fillStyle = a, t.fillRect(m, A, s, i), t.restore();
      }
    e.save(), e.globalAlpha = 1, e.setTransform(1, 0, 0, 1, 0, 0), r === "Alpha" && o ? e.filter = this.filterFactory.addAlphaFilter(o) : r === "Luminosity" && (e.filter = this.filterFactory.addLuminosityFilter(o));
    const y = new Path2D();
    y.rect(l, h, s, i), e.clip(y), e.globalCompositeOperation = "destination-in", e.drawImage(f, m, A, s, i, l, h, s, i), e.restore();
  }
  save(t) {
    var s;
    this.inSMaskMode && yh(this.ctx, this.suspendedCtx), this.ctx.save();
    const e = this.current;
    this.stateStack.push(e), this.current = e.clone(), (s = this.dependencyTracker) == null || s.save(t);
  }
  restore(t) {
    var e;
    if ((e = this.dependencyTracker) == null || e.restore(t), this.stateStack.length === 0) {
      this.inSMaskMode && this.endSMaskMode();
      return;
    }
    this.current = this.stateStack.pop(), this.ctx.restore(), this.inSMaskMode && yh(this.suspendedCtx, this.ctx), this.checkSMaskState(), this.pendingClip = null, this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
  }
  transform(t, e, s, i, r, a, o) {
    var l;
    (l = this.dependencyTracker) == null || l.recordIncrementalData("transform", t), this.ctx.transform(e, s, i, r, a, o), this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
  }
  constructPath(t, e, s, i) {
    let [r] = s;
    if (!i) {
      r || (r = s[0] = new Path2D()), this[e](t, r);
      return;
    }
    if (this.dependencyTracker !== null) {
      const a = e === dh.stroke ? this.current.lineWidth / 2 : 0;
      this.dependencyTracker.resetBBox(t).recordBBox(t, this.ctx, i[0] - a, i[2] + a, i[1] - a, i[3] + a).recordDependencies(t, ["transform"]);
    }
    if (!(r instanceof Path2D)) {
      const a = s[0] = new Path2D();
      for (let o = 0, l = r.length; o < l; )
        switch (r[o++]) {
          case Wd.moveTo:
            a.moveTo(r[o++], r[o++]);
            break;
          case Wd.lineTo:
            a.lineTo(r[o++], r[o++]);
            break;
          case Wd.curveTo:
            a.bezierCurveTo(r[o++], r[o++], r[o++], r[o++], r[o++], r[o++]);
            break;
          case Wd.closePath:
            a.closePath();
            break;
          default:
            J(`Unrecognized drawing path operator: ${r[o - 1]}`);
            break;
        }
      r = a;
    }
    V.axialAlignedBoundingBox(i, Vt(this.ctx), this.current.minMax), this[e](t, r), this._pathStartIdx = t;
  }
  closePath(t) {
    this.ctx.closePath();
  }
  stroke(t, e, s = !0) {
    var a;
    const i = this.ctx, r = this.current.strokeColor;
    if (i.globalAlpha = this.current.strokeAlpha, this.contentVisible)
      if (typeof r == "object" && (r != null && r.getPattern)) {
        const o = r.isModifyingCurrentTransform() ? i.getTransform() : null;
        if (i.save(), i.strokeStyle = r.getPattern(i, this, Ci(i), De.STROKE, t), o) {
          const l = new Path2D();
          l.addPath(e, i.getTransform().invertSelf().multiplySelf(o)), e = l;
        }
        this.rescaleAndStroke(e, !1), i.restore();
      } else
        this.rescaleAndStroke(e, !0);
    (a = this.dependencyTracker) == null || a.recordDependencies(t, js.stroke), s && this.consumePath(t, e, this.current.getClippedPathBoundingBox(De.STROKE, Vt(this.ctx))), i.globalAlpha = this.current.fillAlpha;
  }
  closeStroke(t, e) {
    this.stroke(t, e);
  }
  fill(t, e, s = !0) {
    var h, c, u;
    const i = this.ctx, r = this.current.fillColor, a = this.current.patternFill;
    let o = !1;
    if (a) {
      const f = r.isModifyingCurrentTransform() ? i.getTransform() : null;
      if ((h = this.dependencyTracker) == null || h.save(t), i.save(), i.fillStyle = r.getPattern(i, this, Ci(i), De.FILL, t), f) {
        const m = new Path2D();
        m.addPath(e, i.getTransform().invertSelf().multiplySelf(f)), e = m;
      }
      o = !0;
    }
    const l = this.current.getClippedPathBoundingBox();
    this.contentVisible && l !== null && (this.pendingEOFill ? (i.fill(e, "evenodd"), this.pendingEOFill = !1) : i.fill(e)), (c = this.dependencyTracker) == null || c.recordDependencies(t, js.fill), o && (i.restore(), (u = this.dependencyTracker) == null || u.restore(t)), s && this.consumePath(t, e, l);
  }
  eoFill(t, e) {
    this.pendingEOFill = !0, this.fill(t, e);
  }
  fillStroke(t, e) {
    this.fill(t, e, !1), this.stroke(t, e, !1), this.consumePath(t, e);
  }
  eoFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  closeFillStroke(t, e) {
    this.fillStroke(t, e);
  }
  closeEOFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  endPath(t, e) {
    this.consumePath(t, e);
  }
  rawFillPath(t, e) {
    var s;
    this.ctx.fill(e), (s = this.dependencyTracker) == null || s.recordDependencies(t, js.rawFillPath).recordOperation(t);
  }
  clip(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordFutureForcedDependency("clipMode", t), this.pendingClip = qy;
  }
  eoClip(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordFutureForcedDependency("clipMode", t), this.pendingClip = sm;
  }
  beginText(t) {
    var e;
    this.current.textMatrix = null, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0, (e = this.dependencyTracker) == null || e.recordOpenMarker(t).resetIncrementalData("sameLineText").resetIncrementalData("moveText", t);
  }
  endText(t) {
    const e = this.pendingTextPaths, s = this.ctx;
    if (this.dependencyTracker) {
      const {
        dependencyTracker: i
      } = this;
      e !== void 0 && i.recordFutureForcedDependency("textClip", i.getOpenMarker()).recordFutureForcedDependency("textClip", t), i.recordCloseMarker(t);
    }
    if (e !== void 0) {
      const i = new Path2D(), r = s.getTransform().invertSelf();
      for (const {
        transform: a,
        x: o,
        y: l,
        fontSize: h,
        path: c
      } of e)
        c && i.addPath(c, new DOMMatrix(a).preMultiplySelf(r).translate(o, l).scale(h, -h));
      s.clip(i);
    }
    delete this.pendingTextPaths;
  }
  setCharSpacing(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("charSpacing", t), this.current.charSpacing = e;
  }
  setWordSpacing(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("wordSpacing", t), this.current.wordSpacing = e;
  }
  setHScale(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("hScale", t), this.current.textHScale = e / 100;
  }
  setLeading(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("leading", t), this.current.leading = -e;
  }
  setFont(t, e, s) {
    var u, f;
    (u = this.dependencyTracker) == null || u.recordSimpleData("font", t).recordSimpleDataFromNamed("fontObj", e, t);
    const i = this.commonObjs.get(e), r = this.current;
    if (!i)
      throw new Error(`Can't find font for ${e}`);
    if (r.fontMatrix = i.fontMatrix || Bf, (r.fontMatrix[0] === 0 || r.fontMatrix[3] === 0) && J("Invalid font matrix for font " + e), s < 0 ? (s = -s, r.fontDirection = -1) : r.fontDirection = 1, this.current.font = i, this.current.fontSize = s, i.isType3Font)
      return;
    const a = i.loadedName || "sans-serif", o = ((f = i.systemFontInfo) == null ? void 0 : f.css) || `"${a}", ${i.fallbackName}`;
    let l = "normal";
    i.black ? l = "900" : i.bold && (l = "bold");
    const h = i.italic ? "italic" : "normal";
    let c = s;
    s < Yg ? c = Yg : s > Kg && (c = Kg), this.current.fontSizeScale = s / c, this.ctx.font = `${h} ${l} ${c}px ${o}`;
  }
  setTextRenderingMode(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("textRenderingMode", t), this.current.textRenderingMode = e;
  }
  setTextRise(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("textRise", t), this.current.textRise = e;
  }
  moveText(t, e, s) {
    var i;
    (i = this.dependencyTracker) == null || i.resetIncrementalData("sameLineText").recordIncrementalData("moveText", t), this.current.x = this.current.lineX += e, this.current.y = this.current.lineY += s;
  }
  setLeadingMoveText(t, e, s) {
    this.setLeading(t, -s), this.moveText(t, e, s);
  }
  setTextMatrix(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("textMatrix", t);
    const {
      current: s
    } = this;
    s.textMatrix = e, s.textMatrixScale = Math.hypot(e[0], e[1]), s.x = s.lineX = 0, s.y = s.lineY = 0;
  }
  nextLine(t) {
    var e;
    this.moveText(t, 0, this.current.leading), (e = this.dependencyTracker) == null || e.recordIncrementalData("moveText", this.dependencyTracker.getSimpleIndex("leading") ?? t);
  }
  paintChar(t, e, s, i, r, a) {
    var w, S, E, _;
    const o = this.ctx, l = this.current, h = l.font, c = l.textRenderingMode, u = l.fontSize / l.fontSizeScale, f = c & xe.FILL_STROKE_MASK, m = !!(c & xe.ADD_TO_PATH_FLAG), A = l.patternFill && !h.missingFile, y = l.patternStroke && !h.missingFile;
    let v;
    if ((h.disableFontFace || m || A || y) && !h.missingFile && (v = h.getPathGenerator(this.commonObjs, e)), v && (h.disableFontFace || A || y)) {
      o.save(), o.translate(s, i), o.scale(u, -u), (w = this.dependencyTracker) == null || w.recordCharacterBBox(t, o, h);
      let C;
      if (f === xe.FILL || f === xe.FILL_STROKE)
        if (r) {
          C = o.getTransform(), o.setTransform(...r);
          const T = b(this, _i, gp).call(this, v, C, r);
          o.fill(T);
        } else
          o.fill(v);
      if (f === xe.STROKE || f === xe.FILL_STROKE)
        if (a) {
          C || (C = o.getTransform()), o.setTransform(...a);
          const {
            a: T,
            b: x,
            c: R,
            d: M
          } = C, D = V.inverseTransform(a), k = V.transform([T, x, R, M, 0, 0], D);
          V.singularValueDecompose2dScale(k, Bs), o.lineWidth *= Math.max(Bs[0], Bs[1]) / u, o.stroke(b(this, _i, gp).call(this, v, C, a));
        } else
          o.lineWidth /= u, o.stroke(v);
      o.restore();
    } else
      (f === xe.FILL || f === xe.FILL_STROKE) && (o.fillText(e, s, i), (S = this.dependencyTracker) == null || S.recordCharacterBBox(t, o, h, u, s, i, () => o.measureText(e))), (f === xe.STROKE || f === xe.FILL_STROKE) && (this.dependencyTracker && ((E = this.dependencyTracker) == null || E.recordCharacterBBox(t, o, h, u, s, i, () => o.measureText(e)).recordDependencies(t, js.stroke)), o.strokeText(e, s, i));
    m && ((this.pendingTextPaths || (this.pendingTextPaths = [])).push({
      transform: Vt(o),
      x: s,
      y: i,
      fontSize: u,
      path: v
    }), (_ = this.dependencyTracker) == null || _.recordCharacterBBox(t, o, h, u, s, i));
  }
  get isFontSubpixelAAEnabled() {
    const {
      context: t
    } = this.cachedCanvases.getCanvas("isFontSubpixelAAEnabled", 10, 10);
    t.scale(1.5, 1), t.fillText("I", 0, 10);
    const e = t.getImageData(0, 0, 10, 10).data;
    let s = !1;
    for (let i = 3; i < e.length; i += 4)
      if (e[i] > 0 && e[i] < 255) {
        s = !0;
        break;
      }
    return it(this, "isFontSubpixelAAEnabled", s);
  }
  showText(t, e) {
    var R, M, D, k;
    this.dependencyTracker && (this.dependencyTracker.recordDependencies(t, js.showText).resetBBox(t), this.current.textRenderingMode & xe.ADD_TO_PATH_FLAG && this.dependencyTracker.recordFutureForcedDependency("textClip", t).inheritPendingDependenciesAsFutureForcedDependencies());
    const s = this.current, i = s.font;
    if (i.isType3Font) {
      this.showType3Text(t, e), (R = this.dependencyTracker) == null || R.recordShowTextOperation(t);
      return;
    }
    const r = s.fontSize;
    if (r === 0) {
      (M = this.dependencyTracker) == null || M.recordOperation(t);
      return;
    }
    const a = this.ctx, o = s.fontSizeScale, l = s.charSpacing, h = s.wordSpacing, c = s.fontDirection, u = s.textHScale * c, f = e.length, m = i.vertical, A = m ? 1 : -1, y = i.defaultVMetrics, v = r * s.fontMatrix[0], w = s.textRenderingMode === xe.FILL && !i.disableFontFace && !s.patternFill;
    a.save(), s.textMatrix && a.transform(...s.textMatrix), a.translate(s.x, s.y + s.textRise), c > 0 ? a.scale(u, -1) : a.scale(u, 1);
    let S, E;
    if (s.patternFill) {
      a.save();
      const N = s.fillColor.getPattern(a, this, Ci(a), De.FILL, t);
      S = Vt(a), a.restore(), a.fillStyle = N;
    }
    if (s.patternStroke) {
      a.save();
      const N = s.strokeColor.getPattern(a, this, Ci(a), De.STROKE, t);
      E = Vt(a), a.restore(), a.strokeStyle = N;
    }
    let _ = s.lineWidth;
    const C = s.textMatrixScale;
    if (C === 0 || _ === 0) {
      const N = s.textRenderingMode & xe.FILL_STROKE_MASK;
      (N === xe.STROKE || N === xe.FILL_STROKE) && (_ = this.getSinglePixelWidth());
    } else
      _ /= C;
    if (o !== 1 && (a.scale(o, o), _ /= o), a.lineWidth = _, i.isInvalidPDFjsFont) {
      const N = [];
      let X = 0;
      for (const Y of e)
        N.push(Y.unicode), X += Y.width;
      const B = N.join("");
      if (a.fillText(B, 0, 0), this.dependencyTracker !== null) {
        const Y = a.measureText(B);
        this.dependencyTracker.recordBBox(t, this.ctx, -Y.actualBoundingBoxLeft, Y.actualBoundingBoxRight, -Y.actualBoundingBoxAscent, Y.actualBoundingBoxDescent).recordShowTextOperation(t);
      }
      s.x += X * v * u, a.restore(), this.compose();
      return;
    }
    let T = 0, x;
    for (x = 0; x < f; ++x) {
      const N = e[x];
      if (typeof N == "number") {
        T += A * N * r / 1e3;
        continue;
      }
      let X = !1;
      const B = (N.isSpace ? h : 0) + l, Y = N.fontChar, O = N.accent;
      let H, st, at = N.width;
      if (m) {
        const lt = N.vmetric || y, tt = -(N.vmetric ? lt[1] : at * 0.5) * v, vt = lt[2] * v;
        at = lt ? -lt[0] : at, H = tt / o, st = (T + vt) / o;
      } else
        H = T / o, st = 0;
      let Jt;
      if (i.remeasure && at > 0) {
        Jt = a.measureText(Y);
        const lt = Jt.width * 1e3 / r * o;
        if (at < lt && this.isFontSubpixelAAEnabled) {
          const tt = at / lt;
          X = !0, a.save(), a.scale(tt, 1), H /= tt;
        } else at !== lt && (H += (at - lt) / 2e3 * r / o);
      }
      if (this.contentVisible && (N.isInFont || i.missingFile)) {
        if (w && !O)
          a.fillText(Y, H, st), (D = this.dependencyTracker) == null || D.recordCharacterBBox(t, a, Jt ? {
            bbox: null
          } : i, r / o, H, st, () => Jt ?? a.measureText(Y));
        else if (this.paintChar(t, Y, H, st, S, E), O) {
          const lt = H + r * O.offset.x / o, tt = st - r * O.offset.y / o;
          this.paintChar(t, O.fontChar, lt, tt, S, E);
        }
      }
      const qe = m ? at * v - B * c : at * v + B * c;
      T += qe, X && a.restore();
    }
    m ? s.y -= T : s.x += T * u, a.restore(), this.compose(), (k = this.dependencyTracker) == null || k.recordShowTextOperation(t);
  }
  showType3Text(t, e) {
    const s = this.ctx, i = this.current, r = i.font, a = i.fontSize, o = i.fontDirection, l = r.vertical ? 1 : -1, h = i.charSpacing, c = i.wordSpacing, u = i.textHScale * o, f = i.fontMatrix || Bf, m = e.length, A = i.textRenderingMode === xe.INVISIBLE;
    let y, v, w, S;
    if (A || a === 0)
      return;
    this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null, s.save(), i.textMatrix && s.transform(...i.textMatrix), s.translate(i.x, i.y + i.textRise), s.scale(u, o);
    const E = this.dependencyTracker;
    for (this.dependencyTracker = E ? new Ou(E, t) : null, y = 0; y < m; ++y) {
      if (v = e[y], typeof v == "number") {
        S = l * v * a / 1e3, this.ctx.translate(S, 0), i.x += S * u;
        continue;
      }
      const _ = (v.isSpace ? c : 0) + h, C = r.charProcOperatorList[v.operatorListId];
      C ? this.contentVisible && (this.save(), s.scale(a, a), s.transform(...f), this.executeOperatorList(C), this.restore()) : J(`Type3 character "${v.operatorListId}" is not available.`);
      const T = [v.width, 0];
      V.applyTransform(T, f), w = T[0] * a + _, s.translate(w, 0), i.x += w * u;
    }
    s.restore(), E && (this.dependencyTracker = E);
  }
  setCharWidth(t, e, s) {
  }
  setCharWidthAndBounds(t, e, s, i, r, a, o) {
    var h;
    const l = new Path2D();
    l.rect(i, r, a - i, o - r), this.ctx.clip(l), (h = this.dependencyTracker) == null || h.recordBBox(t, this.ctx, i, a, r, o).recordClipBox(t, this.ctx, i, a, r, o), this.endPath(t);
  }
  getColorN_Pattern(t, e) {
    let s;
    if (e[0] === "TilingPattern") {
      const i = this.baseTransform || Vt(this.ctx), r = {
        createCanvasGraphics: (a, o) => new Mg(a, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
          optionalContentConfig: this.optionalContentConfig,
          markedContentStack: this.markedContentStack
        }, void 0, void 0, this.dependencyTracker ? new Ou(this.dependencyTracker, o, !0) : null)
      };
      s = new up(e, this.ctx, r, i);
    } else
      s = this._getPattern(t, e[1], e[2]);
    return s;
  }
  setStrokeColorN(t, ...e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("strokeColor", t), this.current.strokeColor = this.getColorN_Pattern(t, e), this.current.patternStroke = !0;
  }
  setFillColorN(t, ...e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("fillColor", t), this.current.fillColor = this.getColorN_Pattern(t, e), this.current.patternFill = !0;
  }
  setStrokeRGBColor(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = e, this.current.patternStroke = !1;
  }
  setStrokeTransparent(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = "transparent", this.current.patternStroke = !1;
  }
  setFillRGBColor(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = e, this.current.patternFill = !1;
  }
  setFillTransparent(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = "transparent", this.current.patternFill = !1;
  }
  _getPattern(t, e, s = null) {
    let i;
    return this.cachedPatterns.has(e) ? i = this.cachedPatterns.get(e) : (i = $y(this.getObject(t, e)), this.cachedPatterns.set(e, i)), s && (i.matrix = s), i;
  }
  shadingFill(t, e) {
    var a;
    if (!this.contentVisible)
      return;
    const s = this.ctx;
    this.save(t);
    const i = this._getPattern(t, e);
    s.fillStyle = i.getPattern(s, this, Ci(s), De.SHADING, t);
    const r = Ci(s);
    if (r) {
      const {
        width: o,
        height: l
      } = s.canvas, h = ko.slice();
      V.axialAlignedBoundingBox([0, 0, o, l], r, h);
      const [c, u, f, m] = h;
      this.ctx.fillRect(c, u, f - c, m - u);
    } else
      this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
    (a = this.dependencyTracker) == null || a.resetBBox(t).recordFullPageBBox(t).recordDependencies(t, js.transform).recordDependencies(t, js.fill).recordOperation(t), this.compose(this.current.getClippedPathBoundingBox()), this.restore(t);
  }
  beginInlineImage() {
    Dt("Should not call beginInlineImage");
  }
  beginImageData() {
    Dt("Should not call beginImageData");
  }
  paintFormXObjectBegin(t, e, s) {
    var i;
    if (this.contentVisible && (this.save(t), this.baseTransformStack.push(this.baseTransform), e && this.transform(t, ...e), this.baseTransform = Vt(this.ctx), s)) {
      V.axialAlignedBoundingBox(s, this.baseTransform, this.current.minMax);
      const [r, a, o, l] = s, h = new Path2D();
      h.rect(r, a, o - r, l - a), this.ctx.clip(h), (i = this.dependencyTracker) == null || i.recordClipBox(t, this.ctx, r, o, a, l), this.endPath(t);
    }
  }
  paintFormXObjectEnd(t) {
    this.contentVisible && (this.restore(t), this.baseTransform = this.baseTransformStack.pop());
  }
  beginGroup(t, e) {
    var E;
    if (!this.contentVisible)
      return;
    this.save(t), this.inSMaskMode && (this.endSMaskMode(), this.current.activeSMask = null);
    const s = this.ctx;
    e.isolated || ff("TODO: Support non-isolated groups."), e.knockout && J("Knockout groups not supported.");
    const i = Vt(s);
    if (e.matrix && s.transform(...e.matrix), !e.bbox)
      throw new Error("Bounding box is required.");
    let r = ko.slice();
    V.axialAlignedBoundingBox(e.bbox, Vt(s), r);
    const a = [0, 0, s.canvas.width, s.canvas.height];
    r = V.intersect(r, a) || [0, 0, 0, 0];
    const o = Math.floor(r[0]), l = Math.floor(r[1]), h = Math.max(Math.ceil(r[2]) - o, 1), c = Math.max(Math.ceil(r[3]) - l, 1);
    this.current.startNewPathAndClipBox([0, 0, h, c]);
    let u = "groupAt" + this.groupLevel;
    e.smask && (u += "_smask_" + this.smaskCounter++ % 2);
    const f = this.cachedCanvases.getCanvas(u, h, c), m = f.context;
    m.translate(-o, -l), m.transform(...i);
    let A = new Path2D();
    const [y, v, w, S] = e.bbox;
    if (A.rect(y, v, w - y, S - v), e.matrix) {
      const _ = new Path2D();
      _.addPath(A, new DOMMatrix(e.matrix)), A = _;
    }
    m.clip(A), e.smask && this.smaskStack.push({
      canvas: f.canvas,
      context: m,
      offsetX: o,
      offsetY: l,
      subtype: e.smask.subtype,
      backdrop: e.smask.backdrop,
      transferMap: e.smask.transferMap || null,
      startTransformInverse: null
    }), (!e.smask || this.dependencyTracker) && (s.setTransform(1, 0, 0, 1, 0, 0), s.translate(o, l), s.save()), yh(s, m), this.ctx = m, (E = this.dependencyTracker) == null || E.inheritSimpleDataAsFutureForcedDependencies(["fillAlpha", "strokeAlpha", "globalCompositeOperation"]).pushBaseTransform(s), this.setGState(t, [["BM", "source-over"], ["ca", 1], ["CA", 1]]), this.groupStack.push(s), this.groupLevel++;
  }
  endGroup(t, e) {
    var r;
    if (!this.contentVisible)
      return;
    this.groupLevel--;
    const s = this.ctx, i = this.groupStack.pop();
    if (this.ctx = i, this.ctx.imageSmoothingEnabled = !1, (r = this.dependencyTracker) == null || r.popBaseTransform(), e.smask)
      this.tempSMask = this.smaskStack.pop(), this.restore(t), this.dependencyTracker && this.ctx.restore();
    else {
      this.ctx.restore();
      const a = Vt(this.ctx);
      this.restore(t), this.ctx.save(), this.ctx.setTransform(...a);
      const o = ko.slice();
      V.axialAlignedBoundingBox([0, 0, s.canvas.width, s.canvas.height], a, o), this.ctx.drawImage(s.canvas, 0, 0), this.ctx.restore(), this.compose(o);
    }
  }
  beginAnnotation(t, e, s, i, r, a) {
    if (b(this, _i, fp).call(this), Qd(this.ctx), this.ctx.save(), this.save(t), this.baseTransform && this.ctx.setTransform(...this.baseTransform), s) {
      const o = s[2] - s[0], l = s[3] - s[1];
      if (a && this.annotationCanvasMap) {
        i = i.slice(), i[4] -= s[0], i[5] -= s[1], s = s.slice(), s[0] = s[1] = 0, s[2] = o, s[3] = l, V.singularValueDecompose2dScale(Vt(this.ctx), Bs);
        const {
          viewportScale: h
        } = this, c = Math.ceil(o * this.outputScaleX * h), u = Math.ceil(l * this.outputScaleY * h);
        this.annotationCanvas = this.canvasFactory.create(c, u);
        const {
          canvas: f,
          context: m
        } = this.annotationCanvas;
        this.annotationCanvasMap.set(e, f), this.annotationCanvas.savedCtx = this.ctx, this.ctx = m, this.ctx.save(), this.ctx.setTransform(Bs[0], 0, 0, -Bs[1], 0, l * Bs[1]), Qd(this.ctx);
      } else {
        Qd(this.ctx), this.endPath(t);
        const h = new Path2D();
        h.rect(s[0], s[1], o, l), this.ctx.clip(h);
      }
    }
    this.current = new Jg(this.ctx.canvas.width, this.ctx.canvas.height), this.transform(t, ...i), this.transform(t, ...r);
  }
  endAnnotation(t) {
    this.annotationCanvas && (this.ctx.restore(), b(this, _i, pp).call(this), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas);
  }
  paintImageMaskXObject(t, e) {
    var o;
    if (!this.contentVisible)
      return;
    const s = e.count;
    e = this.getObject(t, e.data, e), e.count = s;
    const i = this.ctx, r = this._createMaskCanvas(t, e), a = r.canvas;
    i.save(), i.setTransform(1, 0, 0, 1, 0, 0), i.drawImage(a, r.offsetX, r.offsetY), (o = this.dependencyTracker) == null || o.resetBBox(t).recordBBox(t, this.ctx, r.offsetX, r.offsetX + a.width, r.offsetY, r.offsetY + a.height).recordOperation(t), i.restore(), this.compose();
  }
  paintImageMaskXObjectRepeat(t, e, s, i = 0, r = 0, a, o) {
    var u, f, m;
    if (!this.contentVisible)
      return;
    e = this.getObject(t, e.data, e);
    const l = this.ctx;
    l.save();
    const h = Vt(l);
    l.transform(s, i, r, a, 0, 0);
    const c = this._createMaskCanvas(t, e);
    l.setTransform(1, 0, 0, 1, c.offsetX - h[4], c.offsetY - h[5]), (u = this.dependencyTracker) == null || u.resetBBox(t);
    for (let A = 0, y = o.length; A < y; A += 2) {
      const v = V.transform(h, [s, i, r, a, o[A], o[A + 1]]);
      l.drawImage(c.canvas, v[4], v[5]), (f = this.dependencyTracker) == null || f.recordBBox(t, this.ctx, v[4], v[4] + c.canvas.width, v[5], v[5] + c.canvas.height);
    }
    l.restore(), this.compose(), (m = this.dependencyTracker) == null || m.recordOperation(t);
  }
  paintImageMaskXObjectGroup(t, e) {
    var a, o, l;
    if (!this.contentVisible)
      return;
    const s = this.ctx, i = this.current.fillColor, r = this.current.patternFill;
    (a = this.dependencyTracker) == null || a.resetBBox(t).recordDependencies(t, js.transformAndFill);
    for (const h of e) {
      const {
        data: c,
        width: u,
        height: f,
        transform: m
      } = h, A = this.cachedCanvases.getCanvas("maskCanvas", u, f), y = A.context;
      y.save();
      const v = this.getObject(t, c, h);
      tm(y, v), y.globalCompositeOperation = "source-in", y.fillStyle = r ? i.getPattern(y, this, Ci(s), De.FILL, t) : i, y.fillRect(0, 0, u, f), y.restore(), s.save(), s.transform(...m), s.scale(1, -1), Jd(s, A.canvas, 0, 0, u, f, 0, -1, 1, 1), (o = this.dependencyTracker) == null || o.recordBBox(t, s, 0, u, 0, f), s.restore();
    }
    this.compose(), (l = this.dependencyTracker) == null || l.recordOperation(t);
  }
  paintImageXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.getObject(t, e);
    if (!s) {
      J("Dependent image isn't ready yet");
      return;
    }
    this.paintInlineImageXObject(t, s);
  }
  paintImageXObjectRepeat(t, e, s, i, r) {
    if (!this.contentVisible)
      return;
    const a = this.getObject(t, e);
    if (!a) {
      J("Dependent image isn't ready yet");
      return;
    }
    const o = a.width, l = a.height, h = [];
    for (let c = 0, u = r.length; c < u; c += 2)
      h.push({
        transform: [s, 0, 0, i, r[c], r[c + 1]],
        x: 0,
        y: 0,
        w: o,
        h: l
      });
    this.paintInlineImageXObjectGroup(t, a, h);
  }
  applyTransferMapsToCanvas(t) {
    return this.current.transferMaps !== "none" && (t.filter = this.current.transferMaps, t.drawImage(t.canvas, 0, 0), t.filter = "none"), t.canvas;
  }
  applyTransferMapsToBitmap(t) {
    if (this.current.transferMaps === "none")
      return t.bitmap;
    const {
      bitmap: e,
      width: s,
      height: i
    } = t, r = this.cachedCanvases.getCanvas("inlineImage", s, i), a = r.context;
    return a.filter = this.current.transferMaps, a.drawImage(e, 0, 0), a.filter = "none", r.canvas;
  }
  paintInlineImageXObject(t, e) {
    var h;
    if (!this.contentVisible)
      return;
    const s = e.width, i = e.height, r = this.ctx;
    this.save(t);
    const {
      filter: a
    } = r;
    a !== "none" && a !== "" && (r.filter = "none"), r.scale(1 / s, -1 / i);
    let o;
    if (e.bitmap)
      o = this.applyTransferMapsToBitmap(e);
    else if (typeof HTMLElement == "function" && e instanceof HTMLElement || !e.data)
      o = e;
    else {
      const u = this.cachedCanvases.getCanvas("inlineImage", s, i).context;
      Qg(u, e), o = this.applyTransferMapsToCanvas(u);
    }
    const l = this._scaleImage(o, Ci(r));
    r.imageSmoothingEnabled = em(Vt(r), e.interpolate), (h = this.dependencyTracker) == null || h.resetBBox(t).recordBBox(t, r, 0, s, -i, 0).recordDependencies(t, js.imageXObject).recordOperation(t), Jd(r, l.img, 0, 0, l.paintWidth, l.paintHeight, 0, -i, s, i), this.compose(), this.restore(t);
  }
  paintInlineImageXObjectGroup(t, e, s) {
    var a, o, l;
    if (!this.contentVisible)
      return;
    const i = this.ctx;
    let r;
    if (e.bitmap)
      r = e.bitmap;
    else {
      const h = e.width, c = e.height, f = this.cachedCanvases.getCanvas("inlineImage", h, c).context;
      Qg(f, e), r = this.applyTransferMapsToCanvas(f);
    }
    (a = this.dependencyTracker) == null || a.resetBBox(t);
    for (const h of s)
      i.save(), i.transform(...h.transform), i.scale(1, -1), Jd(i, r, h.x, h.y, h.w, h.h, 0, -1, 1, 1), (o = this.dependencyTracker) == null || o.recordBBox(t, i, 0, 1, -1, 0), i.restore();
    (l = this.dependencyTracker) == null || l.recordOperation(t), this.compose();
  }
  paintSolidColorImageMask(t) {
    var e;
    this.contentVisible && ((e = this.dependencyTracker) == null || e.resetBBox(t).recordBBox(t, this.ctx, 0, 1, 0, 1).recordDependencies(t, js.fill).recordOperation(t), this.ctx.fillRect(0, 0, 1, 1), this.compose());
  }
  markPoint(t, e) {
  }
  markPointProps(t, e, s) {
  }
  beginMarkedContent(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.beginMarkedContent(t), this.markedContentStack.push({
      visible: !0
    });
  }
  beginMarkedContentProps(t, e, s) {
    var i;
    (i = this.dependencyTracker) == null || i.beginMarkedContent(t), e === "OC" ? this.markedContentStack.push({
      visible: this.optionalContentConfig.isVisible(s)
    }) : this.markedContentStack.push({
      visible: !0
    }), this.contentVisible = this.isContentVisible();
  }
  endMarkedContent(t) {
    var e;
    (e = this.dependencyTracker) == null || e.endMarkedContent(t), this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
  }
  beginCompat(t) {
  }
  endCompat(t) {
  }
  consumePath(t, e, s) {
    var a, o;
    const i = this.current.isEmptyClip();
    this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(s);
    const r = this.ctx;
    this.pendingClip ? (i || (this.pendingClip === sm ? r.clip(e, "evenodd") : r.clip(e)), this.pendingClip = null, (a = this.dependencyTracker) == null || a.bboxToClipBoxDropOperation(t).recordFutureForcedDependency("clipPath", t)) : (o = this.dependencyTracker) == null || o.recordOperation(t), this.current.startNewPathAndClipBox(this.current.clipBox);
  }
  getSinglePixelWidth() {
    if (!this._cachedGetSinglePixelWidth) {
      const t = Vt(this.ctx);
      if (t[1] === 0 && t[2] === 0)
        this._cachedGetSinglePixelWidth = 1 / Math.min(Math.abs(t[0]), Math.abs(t[3]));
      else {
        const e = Math.abs(t[0] * t[3] - t[2] * t[1]), s = Math.hypot(t[0], t[2]), i = Math.hypot(t[1], t[3]);
        this._cachedGetSinglePixelWidth = Math.max(s, i) / e;
      }
    }
    return this._cachedGetSinglePixelWidth;
  }
  getScaleForStroking() {
    if (this._cachedScaleForStroking[0] === -1) {
      const {
        lineWidth: t
      } = this.current, {
        a: e,
        b: s,
        c: i,
        d: r
      } = this.ctx.getTransform();
      let a, o;
      if (s === 0 && i === 0) {
        const l = Math.abs(e), h = Math.abs(r);
        if (l === h)
          if (t === 0)
            a = o = 1 / l;
          else {
            const c = l * t;
            a = o = c < 1 ? 1 / c : 1;
          }
        else if (t === 0)
          a = 1 / l, o = 1 / h;
        else {
          const c = l * t, u = h * t;
          a = c < 1 ? 1 / c : 1, o = u < 1 ? 1 / u : 1;
        }
      } else {
        const l = Math.abs(e * r - s * i), h = Math.hypot(e, s), c = Math.hypot(i, r);
        if (t === 0)
          a = c / l, o = h / l;
        else {
          const u = t * l;
          a = c > u ? c / u : 1, o = h > u ? h / u : 1;
        }
      }
      this._cachedScaleForStroking[0] = a, this._cachedScaleForStroking[1] = o;
    }
    return this._cachedScaleForStroking;
  }
  rescaleAndStroke(t, e) {
    const {
      ctx: s,
      current: {
        lineWidth: i
      }
    } = this, [r, a] = this.getScaleForStroking();
    if (r === a) {
      s.lineWidth = (i || 1) * r, s.stroke(t);
      return;
    }
    const o = s.getLineDash();
    e && s.save(), s.scale(r, a), Lf.a = 1 / r, Lf.d = 1 / a;
    const l = new Path2D();
    if (l.addPath(t, Lf), o.length > 0) {
      const h = Math.max(r, a);
      s.setLineDash(o.map((c) => c / h)), s.lineDashOffset /= h;
    }
    s.lineWidth = i || 1, s.stroke(l), e && s.restore();
  }
  isContentVisible() {
    for (let t = this.markedContentStack.length - 1; t >= 0; t--)
      if (!this.markedContentStack[t].visible)
        return !1;
    return !0;
  }
};
_i = new WeakSet(), fp = function() {
  for (; this.stateStack.length || this.inSMaskMode; )
    this.restore();
  this.current.activeSMask = null, this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.transparentCanvas = null);
}, pp = function() {
  if (this.pageColors) {
    const t = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
    if (t !== "none") {
      const e = this.ctx.filter;
      this.ctx.filter = t, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = e;
    }
  }
}, gp = function(t, e, s) {
  const i = new Path2D();
  return i.addPath(t, new DOMMatrix(s).invertSelf().multiplySelf(e)), i;
};
let No = Mg;
for (const d in dh)
  No.prototype[d] !== void 0 && (No.prototype[dh[d]] = No.prototype[d]);
var ul, fl, Mc, pl, cu;
const Do = class Do {
  constructor(t) {
    g(this, pl);
    g(this, ul);
    g(this, fl);
    g(this, Mc);
    p(this, ul, t), p(this, fl, new DataView(n(this, ul))), p(this, Mc, new TextDecoder());
  }
  static write(t) {
    const e = new TextEncoder(), s = {};
    let i = 0;
    for (const h of Do.strings) {
      const c = e.encode(t[h]);
      s[h] = c, i += 4 + c.length;
    }
    const r = new ArrayBuffer(i), a = new Uint8Array(r), o = new DataView(r);
    let l = 0;
    for (const h of Do.strings) {
      const c = s[h], u = c.length;
      o.setUint32(l, u), a.set(c, l + 4), l += 4 + u;
    }
    return dt(l === r.byteLength, "CssFontInfo.write: Buffer overflow"), r;
  }
  get fontFamily() {
    return b(this, pl, cu).call(this, 0);
  }
  get fontWeight() {
    return b(this, pl, cu).call(this, 1);
  }
  get italicAngle() {
    return b(this, pl, cu).call(this, 2);
  }
};
ul = new WeakMap(), fl = new WeakMap(), Mc = new WeakMap(), pl = new WeakSet(), cu = function(t) {
  dt(t < Do.strings.length, "Invalid string index");
  let e = 0;
  for (let i = 0; i < t; i++)
    e += n(this, fl).getUint32(e) + 4;
  const s = n(this, fl).getUint32(e);
  return n(this, Mc).decode(new Uint8Array(n(this, ul), e + 4, s));
}, L(Do, "strings", ["fontFamily", "fontWeight", "italicAngle"]);
let Bu = Do;
var mr, Hi, ka, La, Dh;
const Io = class Io {
  constructor(t) {
    g(this, La);
    g(this, mr);
    g(this, Hi);
    g(this, ka);
    p(this, mr, t), p(this, Hi, new DataView(n(this, mr))), p(this, ka, new TextDecoder());
  }
  static write(t) {
    const e = new TextEncoder(), s = {};
    let i = 0;
    for (const f of Io.strings) {
      const m = e.encode(t[f]);
      s[f] = m, i += 4 + m.length;
    }
    i += 4;
    let r, a, o = 1 + i;
    t.style && (r = e.encode(t.style.style), a = e.encode(t.style.weight), o += 4 + r.length + 4 + a.length);
    const l = new ArrayBuffer(o), h = new Uint8Array(l), c = new DataView(l);
    let u = 0;
    c.setUint8(u++, t.guessFallback ? 1 : 0), c.setUint32(u, 0), u += 4, i = 0;
    for (const f of Io.strings) {
      const m = s[f], A = m.length;
      i += 4 + A, c.setUint32(u, A), h.set(m, u + 4), u += 4 + A;
    }
    return c.setUint32(u - i - 4, i), t.style && (c.setUint32(u, r.length), h.set(r, u + 4), u += 4 + r.length, c.setUint32(u, a.length), h.set(a, u + 4), u += 4 + a.length), dt(u <= l.byteLength, "SubstitionInfo.write: Buffer overflow"), l.transferToFixedLength(u);
  }
  get guessFallback() {
    return n(this, Hi).getUint8(0) !== 0;
  }
  get css() {
    return b(this, La, Dh).call(this, 0);
  }
  get loadedName() {
    return b(this, La, Dh).call(this, 1);
  }
  get baseFontName() {
    return b(this, La, Dh).call(this, 2);
  }
  get src() {
    return b(this, La, Dh).call(this, 3);
  }
  get style() {
    let t = 1;
    t += 4 + n(this, Hi).getUint32(t);
    const e = n(this, Hi).getUint32(t), s = n(this, ka).decode(new Uint8Array(n(this, mr), t + 4, e));
    t += 4 + e;
    const i = n(this, Hi).getUint32(t), r = n(this, ka).decode(new Uint8Array(n(this, mr), t + 4, i));
    return {
      style: s,
      weight: r
    };
  }
};
mr = new WeakMap(), Hi = new WeakMap(), ka = new WeakMap(), La = new WeakSet(), Dh = function(t) {
  dt(t < Io.strings.length, "Invalid string index");
  let e = 5;
  for (let i = 0; i < t; i++)
    e += n(this, Hi).getUint32(e) + 4;
  const s = n(this, Hi).getUint32(e);
  return n(this, ka).decode(new Uint8Array(n(this, mr), e + 4, s));
}, L(Io, "strings", ["css", "loadedName", "baseFontName", "src"]);
let Hu = Io;
var gl, ml, bl, yl, Ss, Ui, kc, _t, Zt, li, du, Ih;
const et = class et {
  constructor({
    data: t,
    extra: e
  }) {
    g(this, Zt);
    g(this, Ui);
    g(this, kc);
    g(this, _t);
    p(this, Ui, t), p(this, kc, new TextDecoder()), p(this, _t, new DataView(n(this, Ui))), e && Object.assign(this, e);
  }
  get black() {
    return b(this, Zt, li).call(this, 0);
  }
  get bold() {
    return b(this, Zt, li).call(this, 1);
  }
  get disableFontFace() {
    return b(this, Zt, li).call(this, 2);
  }
  get fontExtraProperties() {
    return b(this, Zt, li).call(this, 3);
  }
  get isInvalidPDFjsFont() {
    return b(this, Zt, li).call(this, 4);
  }
  get isType3Font() {
    return b(this, Zt, li).call(this, 5);
  }
  get italic() {
    return b(this, Zt, li).call(this, 6);
  }
  get missingFile() {
    return b(this, Zt, li).call(this, 7);
  }
  get remeasure() {
    return b(this, Zt, li).call(this, 8);
  }
  get vertical() {
    return b(this, Zt, li).call(this, 9);
  }
  get ascent() {
    return b(this, Zt, du).call(this, 0);
  }
  get defaultWidth() {
    return b(this, Zt, du).call(this, 1);
  }
  get descent() {
    return b(this, Zt, du).call(this, 2);
  }
  get bbox() {
    let t = n(et, ml);
    if (n(this, _t).getUint8(t) === 0)
      return;
    t += 1;
    const s = [];
    for (let i = 0; i < 4; i++)
      s.push(n(this, _t).getInt16(t, !0)), t += 2;
    return s;
  }
  get fontMatrix() {
    let t = n(et, bl);
    if (n(this, _t).getUint8(t) === 0)
      return;
    t += 1;
    const s = [];
    for (let i = 0; i < 6; i++)
      s.push(n(this, _t).getFloat64(t, !0)), t += 8;
    return s;
  }
  get defaultVMetrics() {
    let t = n(et, yl);
    if (n(this, _t).getUint8(t) === 0)
      return;
    t += 1;
    const s = [];
    for (let i = 0; i < 3; i++)
      s.push(n(this, _t).getInt16(t, !0)), t += 2;
    return s;
  }
  get fallbackName() {
    return b(this, Zt, Ih).call(this, 0);
  }
  get loadedName() {
    return b(this, Zt, Ih).call(this, 1);
  }
  get mimetype() {
    return b(this, Zt, Ih).call(this, 2);
  }
  get name() {
    return b(this, Zt, Ih).call(this, 3);
  }
  get data() {
    let t = n(et, Ss);
    const e = n(this, _t).getUint32(t);
    t += 4 + e;
    const s = n(this, _t).getUint32(t);
    t += 4 + s;
    const i = n(this, _t).getUint32(t);
    t += 4 + i;
    const r = n(this, _t).getUint32(t);
    if (r !== 0)
      return new Uint8Array(n(this, Ui), t + 4, r);
  }
  clearData() {
    let t = n(et, Ss);
    const e = n(this, _t).getUint32(t);
    t += 4 + e;
    const s = n(this, _t).getUint32(t);
    t += 4 + s;
    const i = n(this, _t).getUint32(t);
    t += 4 + i;
    const r = n(this, _t).getUint32(t);
    new Uint8Array(n(this, Ui), t + 4, r).fill(0), n(this, _t).setUint32(t, 0);
  }
  get cssFontInfo() {
    let t = n(et, Ss);
    const e = n(this, _t).getUint32(t);
    t += 4 + e;
    const s = n(this, _t).getUint32(t);
    t += 4 + s;
    const i = n(this, _t).getUint32(t);
    if (i === 0)
      return null;
    const r = new Uint8Array(i);
    return r.set(new Uint8Array(n(this, Ui), t + 4, i)), new Bu(r.buffer);
  }
  get systemFontInfo() {
    let t = n(et, Ss);
    const e = n(this, _t).getUint32(t);
    t += 4 + e;
    const s = n(this, _t).getUint32(t);
    if (s === 0)
      return null;
    const i = new Uint8Array(s);
    return i.set(new Uint8Array(n(this, Ui), t + 4, s)), new Hu(i.buffer);
  }
  static write(t) {
    const e = t.systemFontInfo ? Hu.write(t.systemFontInfo) : null, s = t.cssFontInfo ? Bu.write(t.cssFontInfo) : null, i = new TextEncoder(), r = {};
    let a = 0;
    for (const y of et.strings)
      r[y] = i.encode(t[y]), a += 4 + r[y].length;
    const o = n(et, Ss) + 4 + a + 4 + (e ? e.byteLength : 0) + 4 + (s ? s.byteLength : 0) + 4 + (t.data ? t.data.length : 0), l = new ArrayBuffer(o), h = new Uint8Array(l), c = new DataView(l);
    let u = 0;
    const f = et.bools.length;
    let m = 0, A = 0;
    for (let y = 0; y < f; y++) {
      const v = t[et.bools[y]];
      m |= (v === void 0 ? 0 : v ? 2 : 1) << A, A += 2, (A === 8 || y === f - 1) && (c.setUint8(u++, m), m = 0, A = 0);
    }
    dt(u === n(et, gl), "FontInfo.write: Boolean properties offset mismatch");
    for (const y of et.numbers)
      c.setFloat64(u, t[y]), u += 8;
    if (dt(u === n(et, ml), "FontInfo.write: Number properties offset mismatch"), t.bbox) {
      c.setUint8(u++, 4);
      for (const y of t.bbox)
        c.setInt16(u, y, !0), u += 2;
    } else
      c.setUint8(u++, 0), u += 8;
    if (dt(u === n(et, bl), "FontInfo.write: BBox properties offset mismatch"), t.fontMatrix) {
      c.setUint8(u++, 6);
      for (const y of t.fontMatrix)
        c.setFloat64(u, y, !0), u += 8;
    } else
      c.setUint8(u++, 0), u += 48;
    if (dt(u === n(et, yl), "FontInfo.write: FontMatrix properties offset mismatch"), t.defaultVMetrics) {
      c.setUint8(u++, 1);
      for (const y of t.defaultVMetrics)
        c.setInt16(u, y, !0), u += 2;
    } else
      c.setUint8(u++, 0), u += 6;
    dt(u === n(et, Ss), "FontInfo.write: DefaultVMetrics properties offset mismatch"), c.setUint32(n(et, Ss), 0), u += 4;
    for (const y of et.strings) {
      const v = r[y], w = v.length;
      c.setUint32(u, w), h.set(v, u + 4), u += 4 + w;
    }
    if (c.setUint32(n(et, Ss), u - n(et, Ss) - 4), !e)
      c.setUint32(u, 0), u += 4;
    else {
      const y = e.byteLength;
      c.setUint32(u, y), dt(u + 4 + y <= l.byteLength, "FontInfo.write: Buffer overflow at systemFontInfo"), h.set(new Uint8Array(e), u + 4), u += 4 + y;
    }
    if (!s)
      c.setUint32(u, 0), u += 4;
    else {
      const y = s.byteLength;
      c.setUint32(u, y), dt(u + 4 + y <= l.byteLength, "FontInfo.write: Buffer overflow at cssFontInfo"), h.set(new Uint8Array(s), u + 4), u += 4 + y;
    }
    return t.data === void 0 ? (c.setUint32(u, 0), u += 4) : (c.setUint32(u, t.data.length), h.set(t.data, u + 4), u += 4 + t.data.length), dt(u <= l.byteLength, "FontInfo.write: Buffer overflow"), l.transferToFixedLength(u);
  }
};
gl = new WeakMap(), ml = new WeakMap(), bl = new WeakMap(), yl = new WeakMap(), Ss = new WeakMap(), Ui = new WeakMap(), kc = new WeakMap(), _t = new WeakMap(), Zt = new WeakSet(), li = function(t) {
  dt(t < et.bools.length, "Invalid boolean index");
  const e = Math.floor(t / 4), s = t * 2 % 8, i = n(this, _t).getUint8(e) >> s & 3;
  return i === 0 ? void 0 : i === 2;
}, du = function(t) {
  return dt(t < et.numbers.length, "Invalid number index"), n(this, _t).getFloat64(n(et, gl) + t * 8);
}, Ih = function(t) {
  dt(t < et.strings.length, "Invalid string index");
  let e = n(et, Ss) + 4;
  for (let r = 0; r < t; r++)
    e += n(this, _t).getUint32(e) + 4;
  const s = n(this, _t).getUint32(e), i = new Uint8Array(s);
  return i.set(new Uint8Array(n(this, Ui), e + 4, s)), n(this, kc).decode(i);
}, L(et, "bools", ["black", "bold", "disableFontFace", "fontExtraProperties", "isInvalidPDFjsFont", "isType3Font", "italic", "missingFile", "remeasure", "vertical"]), L(et, "numbers", ["ascent", "defaultWidth", "descent"]), L(et, "strings", ["fallbackName", "loadedName", "mimetype", "name"]), g(et, gl, Math.ceil(et.bools.length * 2 / 8)), g(et, ml, n(et, gl) + et.numbers.length * 8), g(et, bl, n(et, ml) + 1 + 8), g(et, yl, n(et, bl) + 1 + 48), g(et, Ss, n(et, yl) + 1 + 6);
let mp = et;
var Lc, Dc;
class ni {
  static get workerPort() {
    return n(this, Lc);
  }
  static set workerPort(t) {
    if (!(typeof Worker < "u" && t instanceof Worker) && t !== null)
      throw new Error("Invalid `workerPort` type.");
    p(this, Lc, t);
  }
  static get workerSrc() {
    return n(this, Dc);
  }
  static set workerSrc(t) {
    if (typeof t != "string")
      throw new Error("Invalid `workerSrc` type.");
    p(this, Dc, t);
  }
}
Lc = new WeakMap(), Dc = new WeakMap(), g(ni, Lc, null), g(ni, Dc, "");
var Al, Ic;
class Yy {
  constructor({
    parsedData: t,
    rawData: e
  }) {
    g(this, Al);
    g(this, Ic);
    p(this, Al, t), p(this, Ic, e);
  }
  getRaw() {
    return n(this, Ic);
  }
  get(t) {
    return n(this, Al).get(t) ?? null;
  }
  [Symbol.iterator]() {
    return n(this, Al).entries();
  }
}
Al = new WeakMap(), Ic = new WeakMap();
const Po = Symbol("INTERNAL");
var Fc, Nc, Oc, wl;
class Ky {
  constructor(t, {
    name: e,
    intent: s,
    usage: i,
    rbGroups: r
  }) {
    g(this, Fc, !1);
    g(this, Nc, !1);
    g(this, Oc, !1);
    g(this, wl, !0);
    p(this, Fc, !!(t & Os.DISPLAY)), p(this, Nc, !!(t & Os.PRINT)), this.name = e, this.intent = s, this.usage = i, this.rbGroups = r;
  }
  get visible() {
    if (n(this, Oc))
      return n(this, wl);
    if (!n(this, wl))
      return !1;
    const {
      print: t,
      view: e
    } = this.usage;
    return n(this, Fc) ? (e == null ? void 0 : e.viewState) !== "OFF" : n(this, Nc) ? (t == null ? void 0 : t.printState) !== "OFF" : !0;
  }
  _setVisible(t, e, s = !1) {
    t !== Po && Dt("Internal method `_setVisible` called."), p(this, Oc, s), p(this, wl, e);
  }
}
Fc = new WeakMap(), Nc = new WeakMap(), Oc = new WeakMap(), wl = new WeakMap();
var br, Ct, vl, El, Bc, bp;
class Zy {
  constructor(t, e = Os.DISPLAY) {
    g(this, Bc);
    g(this, br, null);
    g(this, Ct, /* @__PURE__ */ new Map());
    g(this, vl, null);
    g(this, El, null);
    if (this.renderingIntent = e, this.name = null, this.creator = null, t !== null) {
      this.name = t.name, this.creator = t.creator, p(this, El, t.order);
      for (const s of t.groups)
        n(this, Ct).set(s.id, new Ky(e, s));
      if (t.baseState === "OFF")
        for (const s of n(this, Ct).values())
          s._setVisible(Po, !1);
      for (const s of t.on)
        n(this, Ct).get(s)._setVisible(Po, !0);
      for (const s of t.off)
        n(this, Ct).get(s)._setVisible(Po, !1);
      p(this, vl, this.getHash());
    }
  }
  isVisible(t) {
    if (n(this, Ct).size === 0)
      return !0;
    if (!t)
      return ff("Optional content group not defined."), !0;
    if (t.type === "OCG")
      return n(this, Ct).has(t.id) ? n(this, Ct).get(t.id).visible : (J(`Optional content group not found: ${t.id}`), !0);
    if (t.type === "OCMD") {
      if (t.expression)
        return b(this, Bc, bp).call(this, t.expression);
      if (!t.policy || t.policy === "AnyOn") {
        for (const e of t.ids) {
          if (!n(this, Ct).has(e))
            return J(`Optional content group not found: ${e}`), !0;
          if (n(this, Ct).get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOn") {
        for (const e of t.ids) {
          if (!n(this, Ct).has(e))
            return J(`Optional content group not found: ${e}`), !0;
          if (!n(this, Ct).get(e).visible)
            return !1;
        }
        return !0;
      } else if (t.policy === "AnyOff") {
        for (const e of t.ids) {
          if (!n(this, Ct).has(e))
            return J(`Optional content group not found: ${e}`), !0;
          if (!n(this, Ct).get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOff") {
        for (const e of t.ids) {
          if (!n(this, Ct).has(e))
            return J(`Optional content group not found: ${e}`), !0;
          if (n(this, Ct).get(e).visible)
            return !1;
        }
        return !0;
      }
      return J(`Unknown optional content policy ${t.policy}.`), !0;
    }
    return J(`Unknown group type ${t.type}.`), !0;
  }
  setVisibility(t, e = !0, s = !0) {
    var r;
    const i = n(this, Ct).get(t);
    if (!i) {
      J(`Optional content group not found: ${t}`);
      return;
    }
    if (s && e && i.rbGroups.length)
      for (const a of i.rbGroups)
        for (const o of a)
          o !== t && ((r = n(this, Ct).get(o)) == null || r._setVisible(Po, !1, !0));
    i._setVisible(Po, !!e, !0), p(this, br, null);
  }
  setOCGState({
    state: t,
    preserveRB: e
  }) {
    let s;
    for (const i of t) {
      switch (i) {
        case "ON":
        case "OFF":
        case "Toggle":
          s = i;
          continue;
      }
      const r = n(this, Ct).get(i);
      if (r)
        switch (s) {
          case "ON":
            this.setVisibility(i, !0, e);
            break;
          case "OFF":
            this.setVisibility(i, !1, e);
            break;
          case "Toggle":
            this.setVisibility(i, !r.visible, e);
            break;
        }
    }
    p(this, br, null);
  }
  get hasInitialVisibility() {
    return n(this, vl) === null || this.getHash() === n(this, vl);
  }
  getOrder() {
    return n(this, Ct).size ? n(this, El) ? n(this, El).slice() : [...n(this, Ct).keys()] : null;
  }
  getGroup(t) {
    return n(this, Ct).get(t) || null;
  }
  getHash() {
    if (n(this, br) !== null)
      return n(this, br);
    const t = new ob();
    for (const [e, s] of n(this, Ct))
      t.update(`${e}:${s.visible}`);
    return p(this, br, t.hexdigest());
  }
  [Symbol.iterator]() {
    return n(this, Ct).entries();
  }
}
br = new WeakMap(), Ct = new WeakMap(), vl = new WeakMap(), El = new WeakMap(), Bc = new WeakSet(), bp = function(t) {
  const e = t.length;
  if (e < 2)
    return !0;
  const s = t[0];
  for (let i = 1; i < e; i++) {
    const r = t[i];
    let a;
    if (Array.isArray(r))
      a = b(this, Bc, bp).call(this, r);
    else if (n(this, Ct).has(r))
      a = n(this, Ct).get(r).visible;
    else
      return J(`Optional content group not found: ${r}`), !0;
    switch (s) {
      case "And":
        if (!a)
          return !1;
        break;
      case "Or":
        if (a)
          return !0;
        break;
      case "Not":
        return !a;
      default:
        return !0;
    }
  }
  return s === "And";
};
class Jy {
  constructor(t, {
    disableRange: e = !1,
    disableStream: s = !1
  }) {
    dt(t, 'PDFDataTransportStream - missing required "pdfDataRangeTransport" argument.');
    const {
      length: i,
      initialData: r,
      progressiveDone: a,
      contentDispositionFilename: o
    } = t;
    if (this._queuedChunks = [], this._progressiveDone = a, this._contentDispositionFilename = o, (r == null ? void 0 : r.length) > 0) {
      const l = r instanceof Uint8Array && r.byteLength === r.buffer.byteLength ? r.buffer : new Uint8Array(r).buffer;
      this._queuedChunks.push(l);
    }
    this._pdfDataRangeTransport = t, this._isStreamingSupported = !s, this._isRangeSupported = !e, this._contentLength = i, this._fullRequestReader = null, this._rangeReaders = [], t.addRangeListener((l, h) => {
      this._onReceiveData({
        begin: l,
        chunk: h
      });
    }), t.addProgressListener((l, h) => {
      this._onProgress({
        loaded: l,
        total: h
      });
    }), t.addProgressiveReadListener((l) => {
      this._onReceiveData({
        chunk: l
      });
    }), t.addProgressiveDoneListener(() => {
      this._onProgressiveDone();
    }), t.transportReady();
  }
  _onReceiveData({
    begin: t,
    chunk: e
  }) {
    const s = e instanceof Uint8Array && e.byteLength === e.buffer.byteLength ? e.buffer : new Uint8Array(e).buffer;
    if (t === void 0)
      this._fullRequestReader ? this._fullRequestReader._enqueue(s) : this._queuedChunks.push(s);
    else {
      const i = this._rangeReaders.some(function(r) {
        return r._begin !== t ? !1 : (r._enqueue(s), !0);
      });
      dt(i, "_onReceiveData - no `PDFDataTransportStreamRangeReader` instance found.");
    }
  }
  get _progressiveDataLength() {
    var t;
    return ((t = this._fullRequestReader) == null ? void 0 : t._loaded) ?? 0;
  }
  _onProgress(t) {
    var e, s, i, r;
    t.total === void 0 ? (s = (e = this._rangeReaders[0]) == null ? void 0 : e.onProgress) == null || s.call(e, {
      loaded: t.loaded
    }) : (r = (i = this._fullRequestReader) == null ? void 0 : i.onProgress) == null || r.call(i, {
      loaded: t.loaded,
      total: t.total
    });
  }
  _onProgressiveDone() {
    var t;
    (t = this._fullRequestReader) == null || t.progressiveDone(), this._progressiveDone = !0;
  }
  _removeRangeReader(t) {
    const e = this._rangeReaders.indexOf(t);
    e >= 0 && this._rangeReaders.splice(e, 1);
  }
  getFullReader() {
    dt(!this._fullRequestReader, "PDFDataTransportStream.getFullReader can only be called once.");
    const t = this._queuedChunks;
    return this._queuedChunks = null, new Qy(this, t, this._progressiveDone, this._contentDispositionFilename);
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const s = new tA(this, t, e);
    return this._pdfDataRangeTransport.requestDataRange(t, e), this._rangeReaders.push(s), s;
  }
  cancelAllRequests(t) {
    var e;
    (e = this._fullRequestReader) == null || e.cancel(t);
    for (const s of this._rangeReaders.slice(0))
      s.cancel(t);
    this._pdfDataRangeTransport.abort();
  }
}
class Qy {
  constructor(t, e, s = !1, i = null) {
    this._stream = t, this._done = s || !1, this._filename = gf(i) ? i : null, this._queuedChunks = e || [], this._loaded = 0;
    for (const r of this._queuedChunks)
      this._loaded += r.byteLength;
    this._requests = [], this._headersReady = Promise.resolve(), t._fullRequestReader = this, this.onProgress = null;
  }
  _enqueue(t) {
    this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._queuedChunks.push(t), this._loaded += t.byteLength);
  }
  get headersReady() {
    return this._headersReady;
  }
  get filename() {
    return this._filename;
  }
  get isRangeSupported() {
    return this._stream._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._stream._isStreamingSupported;
  }
  get contentLength() {
    return this._stream._contentLength;
  }
  async read() {
    if (this._queuedChunks.length > 0)
      return {
        value: this._queuedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0;
  }
  progressiveDone() {
    this._done || (this._done = !0);
  }
}
class tA {
  constructor(t, e, s) {
    this._stream = t, this._begin = e, this._end = s, this._queuedChunk = null, this._requests = [], this._done = !1, this.onProgress = null;
  }
  _enqueue(t) {
    if (!this._done) {
      if (this._requests.length === 0)
        this._queuedChunk = t;
      else {
        this._requests.shift().resolve({
          value: t,
          done: !1
        });
        for (const s of this._requests)
          s.resolve({
            value: void 0,
            done: !0
          });
        this._requests.length = 0;
      }
      this._done = !0, this._stream._removeRangeReader(this);
    }
  }
  get isStreamingSupported() {
    return !1;
  }
  async read() {
    if (this._queuedChunk) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._stream._removeRangeReader(this);
  }
}
function eA(d) {
  let t = !0, e = s("filename\\*", "i").exec(d);
  if (e) {
    e = e[1];
    let c = o(e);
    return c = unescape(c), c = l(c), c = h(c), r(c);
  }
  if (e = a(d), e) {
    const c = h(e);
    return r(c);
  }
  if (e = s("filename", "i").exec(d), e) {
    e = e[1];
    let c = o(e);
    return c = h(c), r(c);
  }
  function s(c, u) {
    return new RegExp("(?:^|;)\\s*" + c + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', u);
  }
  function i(c, u) {
    if (c) {
      if (!/^[\x00-\xFF]+$/.test(u))
        return u;
      try {
        const f = new TextDecoder(c, {
          fatal: !0
        }), m = Id(u);
        u = f.decode(m), t = !1;
      } catch {
      }
    }
    return u;
  }
  function r(c) {
    return t && /[\x80-\xff]/.test(c) && (c = i("utf-8", c), t && (c = i("iso-8859-1", c))), c;
  }
  function a(c) {
    const u = [];
    let f;
    const m = s("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
    for (; (f = m.exec(c)) !== null; ) {
      let [, y, v, w] = f;
      if (y = parseInt(y, 10), y in u) {
        if (y === 0)
          break;
        continue;
      }
      u[y] = [v, w];
    }
    const A = [];
    for (let y = 0; y < u.length && y in u; ++y) {
      let [v, w] = u[y];
      w = o(w), v && (w = unescape(w), y === 0 && (w = l(w))), A.push(w);
    }
    return A.join("");
  }
  function o(c) {
    if (c.startsWith('"')) {
      const u = c.slice(1).split('\\"');
      for (let f = 0; f < u.length; ++f) {
        const m = u[f].indexOf('"');
        m !== -1 && (u[f] = u[f].slice(0, m), u.length = f + 1), u[f] = u[f].replaceAll(/\\(.)/g, "$1");
      }
      c = u.join('"');
    }
    return c;
  }
  function l(c) {
    const u = c.indexOf("'");
    if (u === -1)
      return c;
    const f = c.slice(0, u), A = c.slice(u + 1).replace(/^[^']*'/, "");
    return i(f, A);
  }
  function h(c) {
    return !c.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(c) ? c : c.replaceAll(/=\?([\w-]*)\?([QqBb])\?((?:[^?]|\?(?!=))*)\?=/g, function(u, f, m, A) {
      if (m === "q" || m === "Q")
        return A = A.replaceAll("_", " "), A = A.replaceAll(/=([0-9a-fA-F]{2})/g, function(y, v) {
          return String.fromCharCode(parseInt(v, 16));
        }), i(f, A);
      try {
        A = atob(A);
      } catch {
      }
      return i(f, A);
    });
  }
  return "";
}
function wb(d, t) {
  const e = new Headers();
  if (!d || !t || typeof t != "object")
    return e;
  for (const s in t) {
    const i = t[s];
    i !== void 0 && e.append(s, i);
  }
  return e;
}
function mf(d) {
  var t;
  return ((t = URL.parse(d)) == null ? void 0 : t.origin) ?? null;
}
function vb({
  responseHeaders: d,
  isHttp: t,
  rangeChunkSize: e,
  disableRange: s
}) {
  const i = {
    allowRangeRequests: !1,
    suggestedLength: void 0
  }, r = parseInt(d.get("Content-Length"), 10);
  return !Number.isInteger(r) || (i.suggestedLength = r, r <= 2 * e) || s || !t || d.get("Accept-Ranges") !== "bytes" || (d.get("Content-Encoding") || "identity") !== "identity" || (i.allowRangeRequests = !0), i;
}
function Eb(d) {
  const t = d.get("Content-Disposition");
  if (t) {
    let e = eA(t);
    if (e.includes("%"))
      try {
        e = decodeURIComponent(e);
      } catch {
      }
    if (gf(e))
      return e;
  }
  return null;
}
function Bd(d, t) {
  return new jh(`Unexpected server response (${d}) while retrieving PDF "${t}".`, d, d === 404 || d === 0 && t.startsWith("file:"));
}
function Sb(d) {
  return d === 200 || d === 206;
}
function _b(d, t, e) {
  return {
    method: "GET",
    headers: d,
    signal: e.signal,
    mode: "cors",
    credentials: t ? "include" : "same-origin",
    redirect: "follow"
  };
}
function Cb(d) {
  return d instanceof Uint8Array ? d.buffer : d instanceof ArrayBuffer ? d : (J(`getArrayBuffer - unexpected data format: ${d}`), new Uint8Array(d).buffer);
}
class sA {
  constructor(t) {
    L(this, "_responseOrigin", null);
    this.source = t, this.isHttp = /^https?:/i.test(t.url), this.headers = wb(this.isHttp, t.httpHeaders), this._fullRequestReader = null, this._rangeRequestReaders = [];
  }
  get _progressiveDataLength() {
    var t;
    return ((t = this._fullRequestReader) == null ? void 0 : t._loaded) ?? 0;
  }
  getFullReader() {
    return dt(!this._fullRequestReader, "PDFFetchStream.getFullReader can only be called once."), this._fullRequestReader = new iA(this), this._fullRequestReader;
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const s = new nA(this, t, e);
    return this._rangeRequestReaders.push(s), s;
  }
  cancelAllRequests(t) {
    var e;
    (e = this._fullRequestReader) == null || e.cancel(t);
    for (const s of this._rangeRequestReaders.slice(0))
      s.cancel(t);
  }
}
class iA {
  constructor(t) {
    this._stream = t, this._reader = null, this._loaded = 0, this._filename = null;
    const e = t.source;
    this._withCredentials = e.withCredentials || !1, this._contentLength = e.length, this._headersCapability = Promise.withResolvers(), this._disableRange = e.disableRange || !1, this._rangeChunkSize = e.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._abortController = new AbortController(), this._isStreamingSupported = !e.disableStream, this._isRangeSupported = !e.disableRange;
    const s = new Headers(t.headers), i = e.url;
    fetch(i, _b(s, this._withCredentials, this._abortController)).then((r) => {
      if (t._responseOrigin = mf(r.url), !Sb(r.status))
        throw Bd(r.status, i);
      this._reader = r.body.getReader(), this._headersCapability.resolve();
      const a = r.headers, {
        allowRangeRequests: o,
        suggestedLength: l
      } = vb({
        responseHeaders: a,
        isHttp: t.isHttp,
        rangeChunkSize: this._rangeChunkSize,
        disableRange: this._disableRange
      });
      this._isRangeSupported = o, this._contentLength = l || this._contentLength, this._filename = Eb(a), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new Gn("Streaming is disabled."));
    }).catch(this._headersCapability.reject), this.onProgress = null;
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  get filename() {
    return this._filename;
  }
  get contentLength() {
    return this._contentLength;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    var s;
    await this._headersCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.byteLength, (s = this.onProgress) == null || s.call(this, {
      loaded: this._loaded,
      total: this._contentLength
    }), {
      value: Cb(t),
      done: !1
    });
  }
  cancel(t) {
    var e;
    (e = this._reader) == null || e.cancel(t), this._abortController.abort();
  }
}
class nA {
  constructor(t, e, s) {
    this._stream = t, this._reader = null, this._loaded = 0;
    const i = t.source;
    this._withCredentials = i.withCredentials || !1, this._readCapability = Promise.withResolvers(), this._isStreamingSupported = !i.disableStream, this._abortController = new AbortController();
    const r = new Headers(t.headers);
    r.append("Range", `bytes=${e}-${s - 1}`);
    const a = i.url;
    fetch(a, _b(r, this._withCredentials, this._abortController)).then((o) => {
      const l = mf(o.url);
      if (l !== t._responseOrigin)
        throw new Error(`Expected range response-origin "${l}" to match "${t._responseOrigin}".`);
      if (!Sb(o.status))
        throw Bd(o.status, a);
      this._readCapability.resolve(), this._reader = o.body.getReader();
    }).catch(this._readCapability.reject), this.onProgress = null;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    var s;
    await this._readCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.byteLength, (s = this.onProgress) == null || s.call(this, {
      loaded: this._loaded
    }), {
      value: Cb(t),
      done: !1
    });
  }
  cancel(t) {
    var e;
    (e = this._reader) == null || e.cancel(t), this._abortController.abort();
  }
}
const Df = 200, If = 206;
function rA(d) {
  const t = d.response;
  return typeof t != "string" ? t : Id(t).buffer;
}
class aA {
  constructor({
    url: t,
    httpHeaders: e,
    withCredentials: s
  }) {
    L(this, "_responseOrigin", null);
    this.url = t, this.isHttp = /^https?:/i.test(t), this.headers = wb(this.isHttp, e), this.withCredentials = s || !1, this.currXhrId = 0, this.pendingRequests = /* @__PURE__ */ Object.create(null);
  }
  request(t) {
    const e = new XMLHttpRequest(), s = this.currXhrId++, i = this.pendingRequests[s] = {
      xhr: e
    };
    e.open("GET", this.url), e.withCredentials = this.withCredentials;
    for (const [r, a] of this.headers)
      e.setRequestHeader(r, a);
    return this.isHttp && "begin" in t && "end" in t ? (e.setRequestHeader("Range", `bytes=${t.begin}-${t.end - 1}`), i.expectedStatus = If) : i.expectedStatus = Df, e.responseType = "arraybuffer", dt(t.onError, "Expected `onError` callback to be provided."), e.onerror = () => {
      t.onError(e.status);
    }, e.onreadystatechange = this.onStateChange.bind(this, s), e.onprogress = this.onProgress.bind(this, s), i.onHeadersReceived = t.onHeadersReceived, i.onDone = t.onDone, i.onError = t.onError, i.onProgress = t.onProgress, e.send(null), s;
  }
  onProgress(t, e) {
    var i;
    const s = this.pendingRequests[t];
    s && ((i = s.onProgress) == null || i.call(s, e));
  }
  onStateChange(t, e) {
    const s = this.pendingRequests[t];
    if (!s)
      return;
    const i = s.xhr;
    if (i.readyState >= 2 && s.onHeadersReceived && (s.onHeadersReceived(), delete s.onHeadersReceived), i.readyState !== 4 || !(t in this.pendingRequests))
      return;
    if (delete this.pendingRequests[t], i.status === 0 && this.isHttp) {
      s.onError(i.status);
      return;
    }
    const r = i.status || Df;
    if (!(r === Df && s.expectedStatus === If) && r !== s.expectedStatus) {
      s.onError(i.status);
      return;
    }
    const o = rA(i);
    if (r === If) {
      const l = i.getResponseHeader("Content-Range"), h = /bytes (\d+)-(\d+)\/(\d+)/.exec(l);
      h ? s.onDone({
        begin: parseInt(h[1], 10),
        chunk: o
      }) : (J('Missing or invalid "Content-Range" header.'), s.onError(0));
    } else o ? s.onDone({
      begin: 0,
      chunk: o
    }) : s.onError(i.status);
  }
  getRequestXhr(t) {
    return this.pendingRequests[t].xhr;
  }
  isPendingRequest(t) {
    return t in this.pendingRequests;
  }
  abortRequest(t) {
    const e = this.pendingRequests[t].xhr;
    delete this.pendingRequests[t], e.abort();
  }
}
class oA {
  constructor(t) {
    this._source = t, this._manager = new aA(t), this._rangeChunkSize = t.rangeChunkSize, this._fullRequestReader = null, this._rangeRequestReaders = [];
  }
  _onRangeRequestReaderClosed(t) {
    const e = this._rangeRequestReaders.indexOf(t);
    e >= 0 && this._rangeRequestReaders.splice(e, 1);
  }
  getFullReader() {
    return dt(!this._fullRequestReader, "PDFNetworkStream.getFullReader can only be called once."), this._fullRequestReader = new lA(this._manager, this._source), this._fullRequestReader;
  }
  getRangeReader(t, e) {
    const s = new hA(this._manager, t, e);
    return s.onClosed = this._onRangeRequestReaderClosed.bind(this), this._rangeRequestReaders.push(s), s;
  }
  cancelAllRequests(t) {
    var e;
    (e = this._fullRequestReader) == null || e.cancel(t);
    for (const s of this._rangeRequestReaders.slice(0))
      s.cancel(t);
  }
}
class lA {
  constructor(t, e) {
    this._manager = t, this._url = e.url, this._fullRequestId = t.request({
      onHeadersReceived: this._onHeadersReceived.bind(this),
      onDone: this._onDone.bind(this),
      onError: this._onError.bind(this),
      onProgress: this._onProgress.bind(this)
    }), this._headersCapability = Promise.withResolvers(), this._disableRange = e.disableRange || !1, this._contentLength = e.length, this._rangeChunkSize = e.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !1, this._isRangeSupported = !1, this._cachedChunks = [], this._requests = [], this._done = !1, this._storedError = void 0, this._filename = null, this.onProgress = null;
  }
  _onHeadersReceived() {
    const t = this._fullRequestId, e = this._manager.getRequestXhr(t);
    this._manager._responseOrigin = mf(e.responseURL);
    const s = e.getAllResponseHeaders(), i = new Headers(s ? s.trimStart().replace(/[^\S ]+$/, "").split(/[\r\n]+/).map((o) => {
      const [l, ...h] = o.split(": ");
      return [l, h.join(": ")];
    }) : []), {
      allowRangeRequests: r,
      suggestedLength: a
    } = vb({
      responseHeaders: i,
      isHttp: this._manager.isHttp,
      rangeChunkSize: this._rangeChunkSize,
      disableRange: this._disableRange
    });
    r && (this._isRangeSupported = !0), this._contentLength = a || this._contentLength, this._filename = Eb(i), this._isRangeSupported && this._manager.abortRequest(t), this._headersCapability.resolve();
  }
  _onDone(t) {
    if (t && (this._requests.length > 0 ? this._requests.shift().resolve({
      value: t.chunk,
      done: !1
    }) : this._cachedChunks.push(t.chunk)), this._done = !0, !(this._cachedChunks.length > 0)) {
      for (const e of this._requests)
        e.resolve({
          value: void 0,
          done: !0
        });
      this._requests.length = 0;
    }
  }
  _onError(t) {
    this._storedError = Bd(t, this._url), this._headersCapability.reject(this._storedError);
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._cachedChunks.length = 0;
  }
  _onProgress(t) {
    var e;
    (e = this.onProgress) == null || e.call(this, {
      loaded: t.loaded,
      total: t.lengthComputable ? t.total : this._contentLength
    });
  }
  get filename() {
    return this._filename;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  get contentLength() {
    return this._contentLength;
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  async read() {
    if (await this._headersCapability.promise, this._storedError)
      throw this._storedError;
    if (this._cachedChunks.length > 0)
      return {
        value: this._cachedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this._headersCapability.reject(t);
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._manager.isPendingRequest(this._fullRequestId) && this._manager.abortRequest(this._fullRequestId), this._fullRequestReader = null;
  }
}
class hA {
  constructor(t, e, s) {
    this._manager = t, this._url = t.url, this._requestId = t.request({
      begin: e,
      end: s,
      onHeadersReceived: this._onHeadersReceived.bind(this),
      onDone: this._onDone.bind(this),
      onError: this._onError.bind(this),
      onProgress: this._onProgress.bind(this)
    }), this._requests = [], this._queuedChunk = null, this._done = !1, this._storedError = void 0, this.onProgress = null, this.onClosed = null;
  }
  _onHeadersReceived() {
    var e;
    const t = mf((e = this._manager.getRequestXhr(this._requestId)) == null ? void 0 : e.responseURL);
    t !== this._manager._responseOrigin && (this._storedError = new Error(`Expected range response-origin "${t}" to match "${this._manager._responseOrigin}".`), this._onError(0));
  }
  _close() {
    var t;
    (t = this.onClosed) == null || t.call(this, this);
  }
  _onDone(t) {
    const e = t.chunk;
    this._requests.length > 0 ? this._requests.shift().resolve({
      value: e,
      done: !1
    }) : this._queuedChunk = e, this._done = !0;
    for (const s of this._requests)
      s.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._close();
  }
  _onError(t) {
    this._storedError ?? (this._storedError = Bd(t, this._url));
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._queuedChunk = null;
  }
  _onProgress(t) {
    var e;
    this.isStreamingSupported || (e = this.onProgress) == null || e.call(this, {
      loaded: t.loaded
    });
  }
  get isStreamingSupported() {
    return !1;
  }
  async read() {
    if (this._storedError)
      throw this._storedError;
    if (this._queuedChunk !== null) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._manager.isPendingRequest(this._requestId) && this._manager.abortRequest(this._requestId), this._close();
  }
}
const cA = /^[a-z][a-z0-9\-+.]+:/i;
function dA(d) {
  if (cA.test(d))
    return new URL(d);
  const t = process.getBuiltinModule("url");
  return new URL(t.pathToFileURL(d));
}
class uA {
  constructor(t) {
    this.source = t, this.url = dA(t.url), dt(this.url.protocol === "file:", "PDFNodeStream only supports file:// URLs."), this._fullRequestReader = null, this._rangeRequestReaders = [];
  }
  get _progressiveDataLength() {
    var t;
    return ((t = this._fullRequestReader) == null ? void 0 : t._loaded) ?? 0;
  }
  getFullReader() {
    return dt(!this._fullRequestReader, "PDFNodeStream.getFullReader can only be called once."), this._fullRequestReader = new fA(this), this._fullRequestReader;
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const s = new pA(this, t, e);
    return this._rangeRequestReaders.push(s), s;
  }
  cancelAllRequests(t) {
    var e;
    (e = this._fullRequestReader) == null || e.cancel(t);
    for (const s of this._rangeRequestReaders.slice(0))
      s.cancel(t);
  }
}
class fA {
  constructor(t) {
    this._url = t.url, this._done = !1, this._storedError = null, this.onProgress = null;
    const e = t.source;
    this._contentLength = e.length, this._loaded = 0, this._filename = null, this._disableRange = e.disableRange || !1, this._rangeChunkSize = e.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !e.disableStream, this._isRangeSupported = !e.disableRange, this._readableStream = null, this._readCapability = Promise.withResolvers(), this._headersCapability = Promise.withResolvers();
    const s = process.getBuiltinModule("fs");
    s.promises.lstat(this._url).then((i) => {
      this._contentLength = i.size, this._setReadableStream(s.createReadStream(this._url)), this._headersCapability.resolve();
    }, (i) => {
      i.code === "ENOENT" && (i = Bd(0, this._url.href)), this._storedError = i, this._headersCapability.reject(i);
    });
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  get filename() {
    return this._filename;
  }
  get contentLength() {
    return this._contentLength;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    var s;
    if (await this._readCapability.promise, this._done)
      return {
        value: void 0,
        done: !0
      };
    if (this._storedError)
      throw this._storedError;
    const t = this._readableStream.read();
    return t === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += t.length, (s = this.onProgress) == null || s.call(this, {
      loaded: this._loaded,
      total: this._contentLength
    }), {
      value: new Uint8Array(t).buffer,
      done: !1
    });
  }
  cancel(t) {
    if (!this._readableStream) {
      this._error(t);
      return;
    }
    this._readableStream.destroy(t);
  }
  _error(t) {
    this._storedError = t, this._readCapability.resolve();
  }
  _setReadableStream(t) {
    this._readableStream = t, t.on("readable", () => {
      this._readCapability.resolve();
    }), t.on("end", () => {
      t.destroy(), this._done = !0, this._readCapability.resolve();
    }), t.on("error", (e) => {
      this._error(e);
    }), !this._isStreamingSupported && this._isRangeSupported && this._error(new Gn("streaming is disabled")), this._storedError && this._readableStream.destroy(this._storedError);
  }
}
class pA {
  constructor(t, e, s) {
    this._url = t.url, this._done = !1, this._storedError = null, this.onProgress = null, this._loaded = 0, this._readableStream = null, this._readCapability = Promise.withResolvers();
    const i = t.source;
    this._isStreamingSupported = !i.disableStream;
    const r = process.getBuiltinModule("fs");
    this._setReadableStream(r.createReadStream(this._url, {
      start: e,
      end: s - 1
    }));
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    var s;
    if (await this._readCapability.promise, this._done)
      return {
        value: void 0,
        done: !0
      };
    if (this._storedError)
      throw this._storedError;
    const t = this._readableStream.read();
    return t === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += t.length, (s = this.onProgress) == null || s.call(this, {
      loaded: this._loaded
    }), {
      value: new Uint8Array(t).buffer,
      done: !1
    });
  }
  cancel(t) {
    if (!this._readableStream) {
      this._error(t);
      return;
    }
    this._readableStream.destroy(t);
  }
  _error(t) {
    this._storedError = t, this._readCapability.resolve();
  }
  _setReadableStream(t) {
    this._readableStream = t, t.on("readable", () => {
      this._readCapability.resolve();
    }), t.on("end", () => {
      t.destroy(), this._done = !0, this._readCapability.resolve();
    }), t.on("error", (e) => {
      this._error(e);
    }), this._storedError && this._readableStream.destroy(this._storedError);
  }
}
const Ah = Symbol("INITIAL_DATA");
var _s, Hc, yp;
class Tb {
  constructor() {
    g(this, Hc);
    g(this, _s, /* @__PURE__ */ Object.create(null));
  }
  get(t, e = null) {
    if (e) {
      const i = b(this, Hc, yp).call(this, t);
      return i.promise.then(() => e(i.data)), null;
    }
    const s = n(this, _s)[t];
    if (!s || s.data === Ah)
      throw new Error(`Requesting object that isn't resolved yet ${t}.`);
    return s.data;
  }
  has(t) {
    const e = n(this, _s)[t];
    return !!e && e.data !== Ah;
  }
  delete(t) {
    const e = n(this, _s)[t];
    return !e || e.data === Ah ? !1 : (delete n(this, _s)[t], !0);
  }
  resolve(t, e = null) {
    const s = b(this, Hc, yp).call(this, t);
    s.data = e, s.resolve();
  }
  clear() {
    var t;
    for (const e in n(this, _s)) {
      const {
        data: s
      } = n(this, _s)[e];
      (t = s == null ? void 0 : s.bitmap) == null || t.close();
    }
    p(this, _s, /* @__PURE__ */ Object.create(null));
  }
  *[Symbol.iterator]() {
    for (const t in n(this, _s)) {
      const {
        data: e
      } = n(this, _s)[t];
      e !== Ah && (yield [t, e]);
    }
  }
}
_s = new WeakMap(), Hc = new WeakSet(), yp = function(t) {
  var e;
  return (e = n(this, _s))[t] || (e[t] = {
    ...Promise.withResolvers(),
    data: Ah
  });
};
const gA = 1e5, im = 30;
var ym, yr, fs, Uc, $c, Da, Cn, Vc, zc, Ia, Sl, _l, Ar, Cl, Gc, Tl, Fa, jc, Wc, Kt, xl, Na, Xc, wr, Pl, Xn, xb, Pb, Ap, Us, uu, wp, Rb, Mb;
let Yh = (Kt = class {
  constructor({
    textContentSource: t,
    container: e,
    viewport: s
  }) {
    g(this, Xn);
    g(this, yr, Promise.withResolvers());
    g(this, fs, null);
    g(this, Uc, !1);
    g(this, $c, !!((ym = globalThis.FontInspector) != null && ym.enabled));
    g(this, Da, null);
    g(this, Cn, null);
    g(this, Vc, 0);
    g(this, zc, 0);
    g(this, Ia, null);
    g(this, Sl, null);
    g(this, _l, 0);
    g(this, Ar, 0);
    g(this, Cl, /* @__PURE__ */ Object.create(null));
    g(this, Gc, []);
    g(this, Tl, null);
    g(this, Fa, []);
    g(this, jc, /* @__PURE__ */ new WeakMap());
    g(this, Wc, null);
    var l;
    if (t instanceof ReadableStream)
      p(this, Tl, t);
    else if (typeof t == "object")
      p(this, Tl, new ReadableStream({
        start(h) {
          h.enqueue(t), h.close();
        }
      }));
    else
      throw new Error('No "textContentSource" parameter specified.');
    p(this, fs, p(this, Sl, e)), p(this, Ar, s.scale * Si.pixelRatio), p(this, _l, s.rotation), p(this, Cn, {
      div: null,
      properties: null,
      ctx: null
    });
    const {
      pageWidth: i,
      pageHeight: r,
      pageX: a,
      pageY: o
    } = s.rawDims;
    p(this, Wc, [1, 0, 0, -1, -a, o + r]), p(this, zc, i), p(this, Vc, r), b(l = Kt, Us, Rb).call(l), jr(e, s), n(this, yr).promise.finally(() => {
      n(Kt, Pl).delete(this), p(this, Cn, null), p(this, Cl, null);
    }).catch(() => {
    });
  }
  static get fontFamilyMap() {
    const {
      isWindows: t,
      isFirefox: e
    } = _e.platform;
    return it(this, "fontFamilyMap", /* @__PURE__ */ new Map([["sans-serif", `${t && e ? "Calibri, " : ""}sans-serif`], ["monospace", `${t && e ? "Lucida Console, " : ""}monospace`]]));
  }
  render() {
    const t = () => {
      n(this, Ia).read().then(({
        value: e,
        done: s
      }) => {
        if (s) {
          n(this, yr).resolve();
          return;
        }
        n(this, Da) ?? p(this, Da, e.lang), Object.assign(n(this, Cl), e.styles), b(this, Xn, xb).call(this, e.items), t();
      }, n(this, yr).reject);
    };
    return p(this, Ia, n(this, Tl).getReader()), n(Kt, Pl).add(this), t(), n(this, yr).promise;
  }
  update({
    viewport: t,
    onBefore: e = null
  }) {
    var r;
    const s = t.scale * Si.pixelRatio, i = t.rotation;
    if (i !== n(this, _l) && (e == null || e(), p(this, _l, i), jr(n(this, Sl), {
      rotation: i
    })), s !== n(this, Ar)) {
      e == null || e(), p(this, Ar, s);
      const a = {
        div: null,
        properties: null,
        ctx: b(r = Kt, Us, uu).call(r, n(this, Da))
      };
      for (const o of n(this, Fa))
        a.properties = n(this, jc).get(o), a.div = o, b(this, Xn, Ap).call(this, a);
    }
  }
  cancel() {
    var e;
    const t = new Gn("TextLayer task cancelled.");
    (e = n(this, Ia)) == null || e.cancel(t).catch(() => {
    }), p(this, Ia, null), n(this, yr).reject(t);
  }
  get textDivs() {
    return n(this, Fa);
  }
  get textContentItemsStr() {
    return n(this, Gc);
  }
  static cleanup() {
    if (!(n(this, Pl).size > 0)) {
      n(this, xl).clear();
      for (const {
        canvas: t
      } of n(this, Na).values())
        t.remove();
      n(this, Na).clear();
    }
  }
}, yr = new WeakMap(), fs = new WeakMap(), Uc = new WeakMap(), $c = new WeakMap(), Da = new WeakMap(), Cn = new WeakMap(), Vc = new WeakMap(), zc = new WeakMap(), Ia = new WeakMap(), Sl = new WeakMap(), _l = new WeakMap(), Ar = new WeakMap(), Cl = new WeakMap(), Gc = new WeakMap(), Tl = new WeakMap(), Fa = new WeakMap(), jc = new WeakMap(), Wc = new WeakMap(), xl = new WeakMap(), Na = new WeakMap(), Xc = new WeakMap(), wr = new WeakMap(), Pl = new WeakMap(), Xn = new WeakSet(), xb = function(t) {
  var i, r;
  if (n(this, Uc))
    return;
  (r = n(this, Cn)).ctx ?? (r.ctx = b(i = Kt, Us, uu).call(i, n(this, Da)));
  const e = n(this, Fa), s = n(this, Gc);
  for (const a of t) {
    if (e.length > gA) {
      J("Ignoring additional textDivs for performance reasons."), p(this, Uc, !0);
      return;
    }
    if (a.str === void 0) {
      if (a.type === "beginMarkedContentProps" || a.type === "beginMarkedContent") {
        const o = n(this, fs);
        p(this, fs, document.createElement("span")), n(this, fs).classList.add("markedContent"), a.id && n(this, fs).setAttribute("id", `${a.id}`), o.append(n(this, fs));
      } else a.type === "endMarkedContent" && p(this, fs, n(this, fs).parentNode);
      continue;
    }
    s.push(a.str), b(this, Xn, Pb).call(this, a);
  }
}, Pb = function(t) {
  var y;
  const e = document.createElement("span"), s = {
    angle: 0,
    canvasWidth: 0,
    hasText: t.str !== "",
    hasEOL: t.hasEOL,
    fontSize: 0
  };
  n(this, Fa).push(e);
  const i = V.transform(n(this, Wc), t.transform);
  let r = Math.atan2(i[1], i[0]);
  const a = n(this, Cl)[t.fontName];
  a.vertical && (r += Math.PI / 2);
  let o = n(this, $c) && a.fontSubstitution || a.fontFamily;
  o = Kt.fontFamilyMap.get(o) || o;
  const l = Math.hypot(i[2], i[3]), h = l * b(y = Kt, Us, Mb).call(y, o, a, n(this, Da));
  let c, u;
  r === 0 ? (c = i[4], u = i[5] - h) : (c = i[4] + h * Math.sin(r), u = i[5] - h * Math.cos(r));
  const f = "calc(var(--total-scale-factor) *", m = e.style;
  n(this, fs) === n(this, Sl) ? (m.left = `${(100 * c / n(this, zc)).toFixed(2)}%`, m.top = `${(100 * u / n(this, Vc)).toFixed(2)}%`) : (m.left = `${f}${c.toFixed(2)}px)`, m.top = `${f}${u.toFixed(2)}px)`), m.fontSize = `${f}${(n(Kt, wr) * l).toFixed(2)}px)`, m.fontFamily = o, s.fontSize = l, e.setAttribute("role", "presentation"), e.textContent = t.str, e.dir = t.dir, n(this, $c) && (e.dataset.fontName = a.fontSubstitutionLoadedName || t.fontName), r !== 0 && (s.angle = r * (180 / Math.PI));
  let A = !1;
  if (t.str.length > 1)
    A = !0;
  else if (t.str !== " " && t.transform[0] !== t.transform[3]) {
    const v = Math.abs(t.transform[0]), w = Math.abs(t.transform[3]);
    v !== w && Math.max(v, w) / Math.min(v, w) > 1.5 && (A = !0);
  }
  if (A && (s.canvasWidth = a.vertical ? t.height : t.width), n(this, jc).set(e, s), n(this, Cn).div = e, n(this, Cn).properties = s, b(this, Xn, Ap).call(this, n(this, Cn)), s.hasText && n(this, fs).append(e), s.hasEOL) {
    const v = document.createElement("br");
    v.setAttribute("role", "presentation"), n(this, fs).append(v);
  }
}, Ap = function(t) {
  var o;
  const {
    div: e,
    properties: s,
    ctx: i
  } = t, {
    style: r
  } = e;
  let a = "";
  if (n(Kt, wr) > 1 && (a = `scale(${1 / n(Kt, wr)})`), s.canvasWidth !== 0 && s.hasText) {
    const {
      fontFamily: l
    } = r, {
      canvasWidth: h,
      fontSize: c
    } = s;
    b(o = Kt, Us, wp).call(o, i, c * n(this, Ar), l);
    const {
      width: u
    } = i.measureText(e.textContent);
    u > 0 && (a = `scaleX(${h * n(this, Ar) / u}) ${a}`);
  }
  s.angle !== 0 && (a = `rotate(${s.angle}deg) ${a}`), a.length > 0 && (r.transform = a);
}, Us = new WeakSet(), uu = function(t = null) {
  let e = n(this, Na).get(t || (t = ""));
  if (!e) {
    const s = document.createElement("canvas");
    s.className = "hiddenCanvasElement", s.lang = t, document.body.append(s), e = s.getContext("2d", {
      alpha: !1,
      willReadFrequently: !0
    }), n(this, Na).set(t, e), n(this, Xc).set(e, {
      size: 0,
      family: ""
    });
  }
  return e;
}, wp = function(t, e, s) {
  const i = n(this, Xc).get(t);
  e === i.size && s === i.family || (t.font = `${e}px ${s}`, i.size = e, i.family = s);
}, Rb = function() {
  if (n(this, wr) !== null)
    return;
  const t = document.createElement("div");
  t.style.opacity = 0, t.style.lineHeight = 1, t.style.fontSize = "1px", t.style.position = "absolute", t.textContent = "X", document.body.append(t), p(this, wr, t.getBoundingClientRect().height), t.remove();
}, Mb = function(t, e, s) {
  const i = n(this, xl).get(t);
  if (i)
    return i;
  const r = b(this, Us, uu).call(this, s);
  r.canvas.width = r.canvas.height = im, b(this, Us, wp).call(this, r, im, t);
  const a = r.measureText(""), o = a.fontBoundingBoxAscent, l = Math.abs(a.fontBoundingBoxDescent);
  r.canvas.width = r.canvas.height = 0;
  let h = 0.8;
  return o ? h = o / (o + l) : (_e.platform.isFirefox && J("Enable the `dom.textMetrics.fontBoundingBox.enabled` preference in `about:config` to improve TextLayer rendering."), e.ascent ? h = e.ascent : e.descent && (h = 1 + e.descent)), n(this, xl).set(t, h), h;
}, g(Kt, Us), g(Kt, xl, /* @__PURE__ */ new Map()), g(Kt, Na, /* @__PURE__ */ new Map()), g(Kt, Xc, /* @__PURE__ */ new WeakMap()), g(Kt, wr, null), g(Kt, Pl, /* @__PURE__ */ new Set()), Kt);
const mA = 100;
function wg(d = {}) {
  typeof d == "string" || d instanceof URL ? d = {
    url: d
  } : (d instanceof ArrayBuffer || ArrayBuffer.isView(d)) && (d = {
    data: d
  });
  const t = new vp(), {
    docId: e
  } = t, s = d.url ? _y(d.url) : null, i = d.data ? Cy(d.data) : null, r = d.httpHeaders || null, a = d.withCredentials === !0, o = d.password ?? null, l = d.range instanceof vg ? d.range : null, h = Number.isInteger(d.rangeChunkSize) && d.rangeChunkSize > 0 ? d.rangeChunkSize : 2 ** 16;
  let c = d.worker instanceof uh ? d.worker : null;
  const u = d.verbosity, f = typeof d.docBaseUrl == "string" && !Nd(d.docBaseUrl) ? d.docBaseUrl : null, m = qd(d.cMapUrl), A = d.cMapPacked !== !1, y = d.CMapReaderFactory || (ss ? Ly : zg), v = qd(d.iccUrl), w = qd(d.standardFontDataUrl), S = d.StandardFontDataFactory || (ss ? Dy : Gg), E = qd(d.wasmUrl), _ = d.WasmFactory || (ss ? Iy : jg), C = d.stopAtErrors !== !0, T = Number.isInteger(d.maxImageSize) && d.maxImageSize > -1 ? d.maxImageSize : -1, x = d.isEvalSupported !== !1, R = typeof d.isOffscreenCanvasSupported == "boolean" ? d.isOffscreenCanvasSupported : !ss, M = typeof d.isImageDecoderSupported == "boolean" ? d.isImageDecoderSupported : !ss && (_e.platform.isFirefox || !globalThis.chrome), D = Number.isInteger(d.canvasMaxAreaInBytes) ? d.canvasMaxAreaInBytes : -1, k = typeof d.disableFontFace == "boolean" ? d.disableFontFace : ss, N = d.fontExtraProperties === !0, X = d.enableXfa === !0, B = d.ownerDocument || globalThis.document, Y = d.disableRange === !0, O = d.disableStream === !0, H = d.disableAutoFetch === !0, st = d.pdfBug === !0, at = d.CanvasFactory || (ss ? ky : Py), Jt = d.FilterFactory || (ss ? My : Ry), qe = d.enableHWA === !0, lt = d.useWasm !== !1, tt = l ? l.length : d.length ?? NaN, vt = typeof d.useSystemFonts == "boolean" ? d.useSystemFonts : !ss && !k, ie = typeof d.useWorkerFetch == "boolean" ? d.useWorkerFetch : !!(y === zg && S === Gg && _ === jg && m && w && E && Eh(m, document.baseURI) && Eh(w, document.baseURI) && Eh(E, document.baseURI)), fe = null;
  ry(u);
  const ct = {
    canvasFactory: new at({
      ownerDocument: B,
      enableHWA: qe
    }),
    filterFactory: new Jt({
      docId: e,
      ownerDocument: B
    }),
    cMapReaderFactory: ie ? null : new y({
      baseUrl: m,
      isCompressed: A
    }),
    standardFontDataFactory: ie ? null : new S({
      baseUrl: w
    }),
    wasmFactory: ie ? null : new _({
      baseUrl: E
    })
  };
  c || (c = uh.create({
    verbosity: u,
    port: ni.workerPort
  }), t._worker = c);
  const bs = {
    docId: e,
    apiVersion: "5.4.296",
    data: i,
    password: o,
    disableAutoFetch: H,
    rangeChunkSize: h,
    length: tt,
    docBaseUrl: f,
    enableXfa: X,
    evaluatorOptions: {
      maxImageSize: T,
      disableFontFace: k,
      ignoreErrors: C,
      isEvalSupported: x,
      isOffscreenCanvasSupported: R,
      isImageDecoderSupported: M,
      canvasMaxAreaInBytes: D,
      fontExtraProperties: N,
      useSystemFonts: vt,
      useWasm: lt,
      useWorkerFetch: ie,
      cMapUrl: m,
      iccUrl: v,
      standardFontDataUrl: w,
      wasmUrl: E
    }
  }, Ye = {
    ownerDocument: B,
    pdfBug: st,
    styleElement: fe,
    loadingParams: {
      disableAutoFetch: H,
      enableXfa: X
    }
  };
  return c.promise.then(function() {
    if (t.destroyed)
      throw new Error("Loading aborted");
    if (c.destroyed)
      throw new Error("Worker was destroyed");
    const Vs = c.messageHandler.sendWithPromise("GetDocRequest", bs, i ? [i.buffer] : null);
    let Ce;
    if (l)
      Ce = new Jy(l, {
        disableRange: Y,
        disableStream: O
      });
    else if (!i) {
      if (!s)
        throw new Error("getDocument - no `url` parameter provided.");
      const xt = Eh(s) ? sA : ss ? uA : oA;
      Ce = new xt({
        url: s,
        length: tt,
        httpHeaders: r,
        withCredentials: a,
        rangeChunkSize: h,
        disableRange: Y,
        disableStream: O
      });
    }
    return Vs.then((xt) => {
      if (t.destroyed)
        throw new Error("Loading aborted");
      if (c.destroyed)
        throw new Error("Worker was destroyed");
      const Pt = new Ph(e, xt, c.port), jt = new AA(Pt, t, Ce, Ye, ct, qe);
      t._transport = jt, Pt.send("Ready", null);
    });
  }).catch(t._capability.reject), t;
}
var ef;
const sf = class sf {
  constructor() {
    L(this, "_capability", Promise.withResolvers());
    L(this, "_transport", null);
    L(this, "_worker", null);
    L(this, "docId", `d${oe(sf, ef)._++}`);
    L(this, "destroyed", !1);
    L(this, "onPassword", null);
    L(this, "onProgress", null);
  }
  get promise() {
    return this._capability.promise;
  }
  async destroy() {
    var t, e, s, i;
    this.destroyed = !0;
    try {
      (t = this._worker) != null && t.port && (this._worker._pendingDestroy = !0), await ((e = this._transport) == null ? void 0 : e.destroy());
    } catch (r) {
      throw (s = this._worker) != null && s.port && delete this._worker._pendingDestroy, r;
    }
    this._transport = null, (i = this._worker) == null || i.destroy(), this._worker = null;
  }
  async getData() {
    return this._transport.getData();
  }
};
ef = new WeakMap(), g(sf, ef, 0);
let vp = sf;
var Oa, qc, Yc, Kc, Zc, Am;
let vg = (Am = class {
  constructor(t, e, s = !1, i = null) {
    g(this, Oa, Promise.withResolvers());
    g(this, qc, []);
    g(this, Yc, []);
    g(this, Kc, []);
    g(this, Zc, []);
    this.length = t, this.initialData = e, this.progressiveDone = s, this.contentDispositionFilename = i;
  }
  addRangeListener(t) {
    n(this, Zc).push(t);
  }
  addProgressListener(t) {
    n(this, Kc).push(t);
  }
  addProgressiveReadListener(t) {
    n(this, Yc).push(t);
  }
  addProgressiveDoneListener(t) {
    n(this, qc).push(t);
  }
  onDataRange(t, e) {
    for (const s of n(this, Zc))
      s(t, e);
  }
  onDataProgress(t, e) {
    n(this, Oa).promise.then(() => {
      for (const s of n(this, Kc))
        s(t, e);
    });
  }
  onDataProgressiveRead(t) {
    n(this, Oa).promise.then(() => {
      for (const e of n(this, Yc))
        e(t);
    });
  }
  onDataProgressiveDone() {
    n(this, Oa).promise.then(() => {
      for (const t of n(this, qc))
        t();
    });
  }
  transportReady() {
    n(this, Oa).resolve();
  }
  requestDataRange(t, e) {
    Dt("Abstract method PDFDataRangeTransport.requestDataRange");
  }
  abort() {
  }
}, Oa = new WeakMap(), qc = new WeakMap(), Yc = new WeakMap(), Kc = new WeakMap(), Zc = new WeakMap(), Am);
class bA {
  constructor(t, e) {
    this._pdfInfo = t, this._transport = e;
  }
  get annotationStorage() {
    return this._transport.annotationStorage;
  }
  get canvasFactory() {
    return this._transport.canvasFactory;
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get numPages() {
    return this._pdfInfo.numPages;
  }
  get fingerprints() {
    return this._pdfInfo.fingerprints;
  }
  get isPureXfa() {
    return it(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  get allXfaHtml() {
    return this._transport._htmlForXfa;
  }
  getPage(t) {
    return this._transport.getPage(t);
  }
  getPageIndex(t) {
    return this._transport.getPageIndex(t);
  }
  getDestinations() {
    return this._transport.getDestinations();
  }
  getDestination(t) {
    return this._transport.getDestination(t);
  }
  getPageLabels() {
    return this._transport.getPageLabels();
  }
  getPageLayout() {
    return this._transport.getPageLayout();
  }
  getPageMode() {
    return this._transport.getPageMode();
  }
  getViewerPreferences() {
    return this._transport.getViewerPreferences();
  }
  getOpenAction() {
    return this._transport.getOpenAction();
  }
  getAttachments() {
    return this._transport.getAttachments();
  }
  getAnnotationsByType(t, e) {
    return this._transport.getAnnotationsByType(t, e);
  }
  getJSActions() {
    return this._transport.getDocJSActions();
  }
  getOutline() {
    return this._transport.getOutline();
  }
  getOptionalContentConfig({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getOptionalContentConfig(e);
  }
  getPermissions() {
    return this._transport.getPermissions();
  }
  getMetadata() {
    return this._transport.getMetadata();
  }
  getMarkInfo() {
    return this._transport.getMarkInfo();
  }
  getData() {
    return this._transport.getData();
  }
  saveDocument() {
    return this._transport.saveDocument();
  }
  getDownloadInfo() {
    return this._transport.downloadInfoCapability.promise;
  }
  cleanup(t = !1) {
    return this._transport.startCleanup(t || this.isPureXfa);
  }
  destroy() {
    return this.loadingTask.destroy();
  }
  cachedPageNumber(t) {
    return this._transport.cachedPageNumber(t);
  }
  get loadingParams() {
    return this._transport.loadingParams;
  }
  get loadingTask() {
    return this._transport.loadingTask;
  }
  getFieldObjects() {
    return this._transport.getFieldObjects();
  }
  hasJSActions() {
    return this._transport.hasJSActions();
  }
  getCalculationOrderIds() {
    return this._transport.getCalculationOrderIds();
  }
}
var Tn, Ba, Fh;
class yA {
  constructor(t, e, s, i = !1) {
    g(this, Ba);
    g(this, Tn, !1);
    this._pageIndex = t, this._pageInfo = e, this._transport = s, this._stats = i ? new Ng() : null, this._pdfBug = i, this.commonObjs = s.commonObjs, this.objs = new Tb(), this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1, this.recordedBBoxes = null;
  }
  get pageNumber() {
    return this._pageIndex + 1;
  }
  get rotate() {
    return this._pageInfo.rotate;
  }
  get ref() {
    return this._pageInfo.ref;
  }
  get userUnit() {
    return this._pageInfo.userUnit;
  }
  get view() {
    return this._pageInfo.view;
  }
  getViewport({
    scale: t,
    rotation: e = this.rotate,
    offsetX: s = 0,
    offsetY: i = 0,
    dontFlip: r = !1
  } = {}) {
    return new Fd({
      viewBox: this.view,
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: i,
      dontFlip: r
    });
  }
  getAnnotations({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getAnnotations(this._pageIndex, e);
  }
  getJSActions() {
    return this._transport.getPageJSActions(this._pageIndex);
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get isPureXfa() {
    return it(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  async getXfa() {
    var t;
    return ((t = this._transport._htmlForXfa) == null ? void 0 : t.children[this._pageIndex]) || null;
  }
  render({
    canvasContext: t,
    canvas: e = t.canvas,
    viewport: s,
    intent: i = "display",
    annotationMode: r = Zi.ENABLE,
    transform: a = null,
    background: o = null,
    optionalContentConfigPromise: l = null,
    annotationCanvasMap: h = null,
    pageColors: c = null,
    printAnnotationStorage: u = null,
    isEditing: f = !1,
    recordOperations: m = !1,
    operationsFilter: A = null
  }) {
    var M, D, k;
    (M = this._stats) == null || M.time("Overall");
    const y = this._transport.getRenderingIntent(i, r, u, f), {
      renderingIntent: v,
      cacheKey: w
    } = y;
    p(this, Tn, !1), l || (l = this._transport.getOptionalContentConfig(v));
    let S = this._intentStates.get(w);
    S || (S = /* @__PURE__ */ Object.create(null), this._intentStates.set(w, S)), S.streamReaderCancelTimeout && (clearTimeout(S.streamReaderCancelTimeout), S.streamReaderCancelTimeout = null);
    const E = !!(v & Os.PRINT);
    S.displayReadyCapability || (S.displayReadyCapability = Promise.withResolvers(), S.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, (D = this._stats) == null || D.time("Page Request"), this._pumpOperatorList(y));
    const _ = !!(this._pdfBug && ((k = globalThis.StepperManager) != null && k.enabled)), C = !this.recordedBBoxes && (m || _), T = (N) => {
      var X, B;
      if (S.renderTasks.delete(x), C) {
        const Y = (X = x.gfx) == null ? void 0 : X.dependencyTracker.take();
        Y && (x.stepper && x.stepper.setOperatorBBoxes(Y, x.gfx.dependencyTracker.takeDebugMetadata()), m && (this.recordedBBoxes = Y));
      }
      E && p(this, Tn, !0), b(this, Ba, Fh).call(this), N ? (x.capability.reject(N), this._abortOperatorList({
        intentState: S,
        reason: N instanceof Error ? N : new Error(N)
      })) : x.capability.resolve(), this._stats && (this._stats.timeEnd("Rendering"), this._stats.timeEnd("Overall"), (B = globalThis.Stats) != null && B.enabled && globalThis.Stats.add(this.pageNumber, this._stats));
    }, x = new Ep({
      callback: T,
      params: {
        canvas: e,
        canvasContext: t,
        dependencyTracker: C ? new Ny(e, S.operatorList.length, _) : null,
        viewport: s,
        transform: a,
        background: o
      },
      objs: this.objs,
      commonObjs: this.commonObjs,
      annotationCanvasMap: h,
      operatorList: S.operatorList,
      pageIndex: this._pageIndex,
      canvasFactory: this._transport.canvasFactory,
      filterFactory: this._transport.filterFactory,
      useRequestAnimationFrame: !E,
      pdfBug: this._pdfBug,
      pageColors: c,
      enableHWA: this._transport.enableHWA,
      operationsFilter: A
    });
    (S.renderTasks || (S.renderTasks = /* @__PURE__ */ new Set())).add(x);
    const R = x.task;
    return Promise.all([S.displayReadyCapability.promise, l]).then(([N, X]) => {
      var B;
      if (this.destroyed) {
        T();
        return;
      }
      if ((B = this._stats) == null || B.time("Rendering"), !(X.renderingIntent & v))
        throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");
      x.initializeGraphics({
        transparency: N,
        optionalContentConfig: X
      }), x.operatorListChanged();
    }).catch(T), R;
  }
  getOperatorList({
    intent: t = "display",
    annotationMode: e = Zi.ENABLE,
    printAnnotationStorage: s = null,
    isEditing: i = !1
  } = {}) {
    var h;
    function r() {
      o.operatorList.lastChunk && (o.opListReadCapability.resolve(o.operatorList), o.renderTasks.delete(l));
    }
    const a = this._transport.getRenderingIntent(t, e, s, i, !0);
    let o = this._intentStates.get(a.cacheKey);
    o || (o = /* @__PURE__ */ Object.create(null), this._intentStates.set(a.cacheKey, o));
    let l;
    return o.opListReadCapability || (l = /* @__PURE__ */ Object.create(null), l.operatorListChanged = r, o.opListReadCapability = Promise.withResolvers(), (o.renderTasks || (o.renderTasks = /* @__PURE__ */ new Set())).add(l), o.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, (h = this._stats) == null || h.time("Page Request"), this._pumpOperatorList(a)), o.opListReadCapability.promise;
  }
  streamTextContent({
    includeMarkedContent: t = !1,
    disableNormalization: e = !1
  } = {}) {
    return this._transport.messageHandler.sendWithStream("GetTextContent", {
      pageIndex: this._pageIndex,
      includeMarkedContent: t === !0,
      disableNormalization: e === !0
    }, {
      highWaterMark: 100,
      size(i) {
        return i.items.length;
      }
    });
  }
  getTextContent(t = {}) {
    if (this._transport._htmlForXfa)
      return this.getXfa().then((s) => Wh.textContent(s));
    const e = this.streamTextContent(t);
    return new Promise(function(s, i) {
      function r() {
        a.read().then(function({
          value: l,
          done: h
        }) {
          if (h) {
            s(o);
            return;
          }
          o.lang ?? (o.lang = l.lang), Object.assign(o.styles, l.styles), o.items.push(...l.items), r();
        }, i);
      }
      const a = e.getReader(), o = {
        items: [],
        styles: /* @__PURE__ */ Object.create(null),
        lang: null
      };
      r();
    });
  }
  getStructTree() {
    return this._transport.getStructTree(this._pageIndex);
  }
  _destroy() {
    this.destroyed = !0;
    const t = [];
    for (const e of this._intentStates.values())
      if (this._abortOperatorList({
        intentState: e,
        reason: new Error("Page was destroyed."),
        force: !0
      }), !e.opListReadCapability)
        for (const s of e.renderTasks)
          t.push(s.completed), s.cancel();
    return this.objs.clear(), p(this, Tn, !1), Promise.all(t);
  }
  cleanup(t = !1) {
    p(this, Tn, !0);
    const e = b(this, Ba, Fh).call(this);
    return t && e && this._stats && (this._stats = new Ng()), e;
  }
  _startRenderPage(t, e) {
    var i, r;
    const s = this._intentStates.get(e);
    s && ((i = this._stats) == null || i.timeEnd("Page Request"), (r = s.displayReadyCapability) == null || r.resolve(t));
  }
  _renderPageChunk(t, e) {
    for (let s = 0, i = t.length; s < i; s++)
      e.operatorList.fnArray.push(t.fnArray[s]), e.operatorList.argsArray.push(t.argsArray[s]);
    e.operatorList.lastChunk = t.lastChunk, e.operatorList.separateAnnots = t.separateAnnots;
    for (const s of e.renderTasks)
      s.operatorListChanged();
    t.lastChunk && b(this, Ba, Fh).call(this);
  }
  _pumpOperatorList({
    renderingIntent: t,
    cacheKey: e,
    annotationStorageSerializable: s,
    modifiedIds: i
  }) {
    const {
      map: r,
      transfer: a
    } = s, l = this._transport.messageHandler.sendWithStream("GetOperatorList", {
      pageIndex: this._pageIndex,
      intent: t,
      cacheKey: e,
      annotationStorage: r,
      modifiedIds: i
    }, a).getReader(), h = this._intentStates.get(e);
    h.streamReader = l;
    const c = () => {
      l.read().then(({
        value: u,
        done: f
      }) => {
        if (f) {
          h.streamReader = null;
          return;
        }
        this._transport.destroyed || (this._renderPageChunk(u, h), c());
      }, (u) => {
        if (h.streamReader = null, !this._transport.destroyed) {
          if (h.operatorList) {
            h.operatorList.lastChunk = !0;
            for (const f of h.renderTasks)
              f.operatorListChanged();
            b(this, Ba, Fh).call(this);
          }
          if (h.displayReadyCapability)
            h.displayReadyCapability.reject(u);
          else if (h.opListReadCapability)
            h.opListReadCapability.reject(u);
          else
            throw u;
        }
      });
    };
    c();
  }
  _abortOperatorList({
    intentState: t,
    reason: e,
    force: s = !1
  }) {
    if (t.streamReader) {
      if (t.streamReaderCancelTimeout && (clearTimeout(t.streamReaderCancelTimeout), t.streamReaderCancelTimeout = null), !s) {
        if (t.renderTasks.size > 0)
          return;
        if (e instanceof pf) {
          let i = mA;
          e.extraDelay > 0 && e.extraDelay < 1e3 && (i += e.extraDelay), t.streamReaderCancelTimeout = setTimeout(() => {
            t.streamReaderCancelTimeout = null, this._abortOperatorList({
              intentState: t,
              reason: e,
              force: !0
            });
          }, i);
          return;
        }
      }
      if (t.streamReader.cancel(new Gn(e.message)).catch(() => {
      }), t.streamReader = null, !this._transport.destroyed) {
        for (const [i, r] of this._intentStates)
          if (r === t) {
            this._intentStates.delete(i);
            break;
          }
        this.cleanup();
      }
    }
  }
  get stats() {
    return this._stats;
  }
}
Tn = new WeakMap(), Ba = new WeakSet(), Fh = function() {
  if (!n(this, Tn) || this.destroyed)
    return !1;
  for (const {
    renderTasks: t,
    operatorList: e
  } of this._intentStates.values())
    if (t.size > 0 || !e.lastChunk)
      return !1;
  return this._intentStates.clear(), this.objs.clear(), p(this, Tn, !1), !0;
};
var vr, gi, xn, Ha, nf, Ua, $a, is, fu, kb, Lb, Nh, Rl, pu;
const Bt = class Bt {
  constructor({
    name: t = null,
    port: e = null,
    verbosity: s = ay()
  } = {}) {
    g(this, is);
    g(this, vr, Promise.withResolvers());
    g(this, gi, null);
    g(this, xn, null);
    g(this, Ha, null);
    if (this.name = t, this.destroyed = !1, this.verbosity = s, e) {
      if (n(Bt, $a).has(e))
        throw new Error("Cannot use more than one PDFWorker per port.");
      n(Bt, $a).set(e, this), b(this, is, kb).call(this, e);
    } else
      b(this, is, Lb).call(this);
  }
  get promise() {
    return n(this, vr).promise;
  }
  get port() {
    return n(this, xn);
  }
  get messageHandler() {
    return n(this, gi);
  }
  destroy() {
    var t, e;
    this.destroyed = !0, (t = n(this, Ha)) == null || t.terminate(), p(this, Ha, null), n(Bt, $a).delete(n(this, xn)), p(this, xn, null), (e = n(this, gi)) == null || e.destroy(), p(this, gi, null);
  }
  static create(t) {
    const e = n(this, $a).get(t == null ? void 0 : t.port);
    if (e) {
      if (e._pendingDestroy)
        throw new Error("PDFWorker.create - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
      return e;
    }
    return new Bt(t);
  }
  static get workerSrc() {
    if (ni.workerSrc)
      return ni.workerSrc;
    throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
  }
  static get _setupFakeWorkerGlobal() {
    return it(this, "_setupFakeWorkerGlobal", (async () => n(this, Rl, pu) ? n(this, Rl, pu) : (await import(
      /*webpackIgnore: true*/
      /*@vite-ignore*/
      this.workerSrc
    )).WorkerMessageHandler)());
  }
};
vr = new WeakMap(), gi = new WeakMap(), xn = new WeakMap(), Ha = new WeakMap(), nf = new WeakMap(), Ua = new WeakMap(), $a = new WeakMap(), is = new WeakSet(), fu = function() {
  n(this, vr).resolve(), n(this, gi).send("configure", {
    verbosity: this.verbosity
  });
}, kb = function(t) {
  p(this, xn, t), p(this, gi, new Ph("main", "worker", t)), n(this, gi).on("ready", () => {
  }), b(this, is, fu).call(this);
}, Lb = function() {
  if (n(Bt, Ua) || n(Bt, Rl, pu)) {
    b(this, is, Nh).call(this);
    return;
  }
  let {
    workerSrc: t
  } = Bt;
  try {
    Bt._isSameOrigin(window.location, t) || (t = Bt._createCDNWrapper(new URL(t, window.location).href));
    const e = new Worker(t, {
      type: "module"
    }), s = new Ph("main", "worker", e), i = () => {
      r.abort(), s.destroy(), e.terminate(), this.destroyed ? n(this, vr).reject(new Error("Worker was destroyed")) : b(this, is, Nh).call(this);
    }, r = new AbortController();
    e.addEventListener("error", () => {
      n(this, Ha) || i();
    }, {
      signal: r.signal
    }), s.on("test", (o) => {
      if (r.abort(), this.destroyed || !o) {
        i();
        return;
      }
      p(this, gi, s), p(this, xn, e), p(this, Ha, e), b(this, is, fu).call(this);
    }), s.on("ready", (o) => {
      if (r.abort(), this.destroyed) {
        i();
        return;
      }
      try {
        a();
      } catch {
        b(this, is, Nh).call(this);
      }
    });
    const a = () => {
      const o = new Uint8Array();
      s.send("test", o, [o.buffer]);
    };
    a();
    return;
  } catch {
    ff("The worker has been disabled.");
  }
  b(this, is, Nh).call(this);
}, Nh = function() {
  n(Bt, Ua) || (J("Setting up fake worker."), p(Bt, Ua, !0)), Bt._setupFakeWorkerGlobal.then((t) => {
    if (this.destroyed) {
      n(this, vr).reject(new Error("Worker was destroyed"));
      return;
    }
    const e = new xy();
    p(this, xn, e);
    const s = `fake${oe(Bt, nf)._++}`, i = new Ph(s + "_worker", s, e);
    t.setup(i, e), p(this, gi, new Ph(s, s + "_worker", e)), b(this, is, fu).call(this);
  }).catch((t) => {
    n(this, vr).reject(new Error(`Setting up fake worker failed: "${t.message}".`));
  });
}, Rl = new WeakSet(), pu = function() {
  var t;
  try {
    return ((t = globalThis.pdfjsWorker) == null ? void 0 : t.WorkerMessageHandler) || null;
  } catch {
    return null;
  }
}, g(Bt, Rl), g(Bt, nf, 0), g(Bt, Ua, !1), g(Bt, $a, /* @__PURE__ */ new WeakMap()), ss && (p(Bt, Ua, !0), ni.workerSrc || (ni.workerSrc = "./pdf.worker.mjs")), Bt._isSameOrigin = (t, e) => {
  const s = URL.parse(t);
  if (!(s != null && s.origin) || s.origin === "null")
    return !1;
  const i = new URL(e, s);
  return s.origin === i.origin;
}, Bt._createCDNWrapper = (t) => {
  const e = `await import("${t}");`;
  return URL.createObjectURL(new Blob([e], {
    type: "text/javascript"
  }));
}, Bt.fromPort = (t) => {
  if (gy("`PDFWorker.fromPort` - please use `PDFWorker.create` instead."), !(t != null && t.port))
    throw new Error("PDFWorker.fromPort - invalid method signature.");
  return Bt.create(t);
};
let uh = Bt;
var Pn, $i, Ml, kl, Rn, Va, Oh;
class AA {
  constructor(t, e, s, i, r, a) {
    g(this, Va);
    g(this, Pn, /* @__PURE__ */ new Map());
    g(this, $i, /* @__PURE__ */ new Map());
    g(this, Ml, /* @__PURE__ */ new Map());
    g(this, kl, /* @__PURE__ */ new Map());
    g(this, Rn, null);
    this.messageHandler = t, this.loadingTask = e, this.commonObjs = new Tb(), this.fontLoader = new Ey({
      ownerDocument: i.ownerDocument,
      styleElement: i.styleElement
    }), this.loadingParams = i.loadingParams, this._params = i, this.canvasFactory = r.canvasFactory, this.filterFactory = r.filterFactory, this.cMapReaderFactory = r.cMapReaderFactory, this.standardFontDataFactory = r.standardFontDataFactory, this.wasmFactory = r.wasmFactory, this.destroyed = !1, this.destroyCapability = null, this._networkStream = s, this._fullReader = null, this._lastProgress = null, this.downloadInfoCapability = Promise.withResolvers(), this.enableHWA = a, this.setupMessageHandler();
  }
  get annotationStorage() {
    return it(this, "annotationStorage", new bg());
  }
  getRenderingIntent(t, e = Zi.ENABLE, s = null, i = !1, r = !1) {
    let a = Os.DISPLAY, o = rp;
    switch (t) {
      case "any":
        a = Os.ANY;
        break;
      case "display":
        break;
      case "print":
        a = Os.PRINT;
        break;
      default:
        J(`getRenderingIntent - invalid intent: ${t}`);
    }
    const l = a & Os.PRINT && s instanceof hb ? s : this.annotationStorage;
    switch (e) {
      case Zi.DISABLE:
        a += Os.ANNOTATIONS_DISABLE;
        break;
      case Zi.ENABLE:
        break;
      case Zi.ENABLE_FORMS:
        a += Os.ANNOTATIONS_FORMS;
        break;
      case Zi.ENABLE_STORAGE:
        a += Os.ANNOTATIONS_STORAGE, o = l.serializable;
        break;
      default:
        J(`getRenderingIntent - invalid annotationMode: ${e}`);
    }
    i && (a += Os.IS_EDITING), r && (a += Os.OPLIST);
    const {
      ids: h,
      hash: c
    } = l.modifiedIds, u = [a, o.hash, c];
    return {
      renderingIntent: a,
      cacheKey: u.join("_"),
      annotationStorageSerializable: o,
      modifiedIds: h
    };
  }
  destroy() {
    var s;
    if (this.destroyCapability)
      return this.destroyCapability.promise;
    this.destroyed = !0, this.destroyCapability = Promise.withResolvers(), (s = n(this, Rn)) == null || s.reject(new Error("Worker was destroyed during onPassword callback"));
    const t = [];
    for (const i of n(this, $i).values())
      t.push(i._destroy());
    n(this, $i).clear(), n(this, Ml).clear(), n(this, kl).clear(), this.hasOwnProperty("annotationStorage") && this.annotationStorage.resetModified();
    const e = this.messageHandler.sendWithPromise("Terminate", null);
    return t.push(e), Promise.all(t).then(() => {
      var i, r;
      this.commonObjs.clear(), this.fontLoader.clear(), n(this, Pn).clear(), this.filterFactory.destroy(), Yh.cleanup(), (i = this._networkStream) == null || i.cancelAllRequests(new Gn("Worker was terminated.")), (r = this.messageHandler) == null || r.destroy(), this.messageHandler = null, this.destroyCapability.resolve();
    }, this.destroyCapability.reject), this.destroyCapability.promise;
  }
  setupMessageHandler() {
    const {
      messageHandler: t,
      loadingTask: e
    } = this;
    t.on("GetReader", (s, i) => {
      dt(this._networkStream, "GetReader - no `IPDFStream` instance available."), this._fullReader = this._networkStream.getFullReader(), this._fullReader.onProgress = (r) => {
        this._lastProgress = {
          loaded: r.loaded,
          total: r.total
        };
      }, i.onPull = () => {
        this._fullReader.read().then(function({
          value: r,
          done: a
        }) {
          if (a) {
            i.close();
            return;
          }
          dt(r instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), i.enqueue(new Uint8Array(r), 1, [r]);
        }).catch((r) => {
          i.error(r);
        });
      }, i.onCancel = (r) => {
        this._fullReader.cancel(r), i.ready.catch((a) => {
          if (!this.destroyed)
            throw a;
        });
      };
    }), t.on("ReaderHeadersReady", async (s) => {
      var o;
      await this._fullReader.headersReady;
      const {
        isStreamingSupported: i,
        isRangeSupported: r,
        contentLength: a
      } = this._fullReader;
      return (!i || !r) && (this._lastProgress && ((o = e.onProgress) == null || o.call(e, this._lastProgress)), this._fullReader.onProgress = (l) => {
        var h;
        (h = e.onProgress) == null || h.call(e, {
          loaded: l.loaded,
          total: l.total
        });
      }), {
        isStreamingSupported: i,
        isRangeSupported: r,
        contentLength: a
      };
    }), t.on("GetRangeReader", (s, i) => {
      dt(this._networkStream, "GetRangeReader - no `IPDFStream` instance available.");
      const r = this._networkStream.getRangeReader(s.begin, s.end);
      if (!r) {
        i.close();
        return;
      }
      i.onPull = () => {
        r.read().then(function({
          value: a,
          done: o
        }) {
          if (o) {
            i.close();
            return;
          }
          dt(a instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), i.enqueue(new Uint8Array(a), 1, [a]);
        }).catch((a) => {
          i.error(a);
        });
      }, i.onCancel = (a) => {
        r.cancel(a), i.ready.catch((o) => {
          if (!this.destroyed)
            throw o;
        });
      };
    }), t.on("GetDoc", ({
      pdfInfo: s
    }) => {
      this._numPages = s.numPages, this._htmlForXfa = s.htmlForXfa, delete s.htmlForXfa, e._capability.resolve(new bA(s, this));
    }), t.on("DocException", (s) => {
      e._capability.reject(os(s));
    }), t.on("PasswordRequest", (s) => {
      p(this, Rn, Promise.withResolvers());
      try {
        if (!e.onPassword)
          throw os(s);
        const i = (r) => {
          r instanceof Error ? n(this, Rn).reject(r) : n(this, Rn).resolve({
            password: r
          });
        };
        e.onPassword(i, s.code);
      } catch (i) {
        n(this, Rn).reject(i);
      }
      return n(this, Rn).promise;
    }), t.on("DataLoaded", (s) => {
      var i;
      (i = e.onProgress) == null || i.call(e, {
        loaded: s.length,
        total: s.length
      }), this.downloadInfoCapability.resolve(s);
    }), t.on("StartRenderPage", (s) => {
      if (this.destroyed)
        return;
      n(this, $i).get(s.pageIndex)._startRenderPage(s.transparency, s.cacheKey);
    }), t.on("commonobj", ([s, i, r]) => {
      var a;
      if (this.destroyed || this.commonObjs.has(s))
        return null;
      switch (i) {
        case "Font":
          if ("error" in r) {
            const u = r.error;
            J(`Error during font loading: ${u}`), this.commonObjs.resolve(s, u);
            break;
          }
          const o = new mp(r), l = this._params.pdfBug && ((a = globalThis.FontInspector) != null && a.enabled) ? (u, f) => globalThis.FontInspector.fontAdded(u, f) : null, h = new Sy(o, l, r.extra, r.charProcOperatorList);
          this.fontLoader.bind(h).catch(() => t.sendWithPromise("FontFallback", {
            id: s
          })).finally(() => {
            !h.fontExtraProperties && h.data && h.clearData(), this.commonObjs.resolve(s, h);
          });
          break;
        case "CopyLocalImage":
          const {
            imageRef: c
          } = r;
          dt(c, "The imageRef must be defined.");
          for (const u of n(this, $i).values())
            for (const [, f] of u.objs)
              if ((f == null ? void 0 : f.ref) === c)
                return f.dataLen ? (this.commonObjs.resolve(s, structuredClone(f)), f.dataLen) : null;
          break;
        case "FontPath":
        case "Image":
        case "Pattern":
          this.commonObjs.resolve(s, r);
          break;
        default:
          throw new Error(`Got unknown common object type ${i}`);
      }
      return null;
    }), t.on("obj", ([s, i, r, a]) => {
      var l;
      if (this.destroyed)
        return;
      const o = n(this, $i).get(i);
      if (!o.objs.has(s)) {
        if (o._intentStates.size === 0) {
          (l = a == null ? void 0 : a.bitmap) == null || l.close();
          return;
        }
        switch (r) {
          case "Image":
          case "Pattern":
            o.objs.resolve(s, a);
            break;
          default:
            throw new Error(`Got unknown object type ${r}`);
        }
      }
    }), t.on("DocProgress", (s) => {
      var i;
      this.destroyed || (i = e.onProgress) == null || i.call(e, {
        loaded: s.loaded,
        total: s.total
      });
    }), t.on("FetchBinaryData", async (s) => {
      if (this.destroyed)
        throw new Error("Worker was destroyed.");
      const i = this[s.type];
      if (!i)
        throw new Error(`${s.type} not initialized, see the \`useWorkerFetch\` parameter.`);
      return i.fetch(s);
    });
  }
  getData() {
    return this.messageHandler.sendWithPromise("GetData", null);
  }
  saveDocument() {
    var s;
    this.annotationStorage.size <= 0 && J("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
    const {
      map: t,
      transfer: e
    } = this.annotationStorage.serializable;
    return this.messageHandler.sendWithPromise("SaveDocument", {
      isPureXfa: !!this._htmlForXfa,
      numPages: this._numPages,
      annotationStorage: t,
      filename: ((s = this._fullReader) == null ? void 0 : s.filename) ?? null
    }, e).finally(() => {
      this.annotationStorage.resetModified();
    });
  }
  getPage(t) {
    if (!Number.isInteger(t) || t <= 0 || t > this._numPages)
      return Promise.reject(new Error("Invalid page request."));
    const e = t - 1, s = n(this, Ml).get(e);
    if (s)
      return s;
    const i = this.messageHandler.sendWithPromise("GetPage", {
      pageIndex: e
    }).then((r) => {
      if (this.destroyed)
        throw new Error("Transport destroyed");
      r.refStr && n(this, kl).set(r.refStr, t);
      const a = new yA(e, r, this, this._params.pdfBug);
      return n(this, $i).set(e, a), a;
    });
    return n(this, Ml).set(e, i), i;
  }
  getPageIndex(t) {
    return ap(t) ? this.messageHandler.sendWithPromise("GetPageIndex", {
      num: t.num,
      gen: t.gen
    }) : Promise.reject(new Error("Invalid pageIndex request."));
  }
  getAnnotations(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotations", {
      pageIndex: t,
      intent: e
    });
  }
  getFieldObjects() {
    return b(this, Va, Oh).call(this, "GetFieldObjects");
  }
  hasJSActions() {
    return b(this, Va, Oh).call(this, "HasJSActions");
  }
  getCalculationOrderIds() {
    return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
  }
  getDestinations() {
    return this.messageHandler.sendWithPromise("GetDestinations", null);
  }
  getDestination(t) {
    return typeof t != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
      id: t
    });
  }
  getPageLabels() {
    return this.messageHandler.sendWithPromise("GetPageLabels", null);
  }
  getPageLayout() {
    return this.messageHandler.sendWithPromise("GetPageLayout", null);
  }
  getPageMode() {
    return this.messageHandler.sendWithPromise("GetPageMode", null);
  }
  getViewerPreferences() {
    return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
  }
  getOpenAction() {
    return this.messageHandler.sendWithPromise("GetOpenAction", null);
  }
  getAttachments() {
    return this.messageHandler.sendWithPromise("GetAttachments", null);
  }
  getAnnotationsByType(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotationsByType", {
      types: t,
      pageIndexesToSkip: e
    });
  }
  getDocJSActions() {
    return b(this, Va, Oh).call(this, "GetDocJSActions");
  }
  getPageJSActions(t) {
    return this.messageHandler.sendWithPromise("GetPageJSActions", {
      pageIndex: t
    });
  }
  getStructTree(t) {
    return this.messageHandler.sendWithPromise("GetStructTree", {
      pageIndex: t
    });
  }
  getOutline() {
    return this.messageHandler.sendWithPromise("GetOutline", null);
  }
  getOptionalContentConfig(t) {
    return b(this, Va, Oh).call(this, "GetOptionalContentConfig").then((e) => new Zy(e, t));
  }
  getPermissions() {
    return this.messageHandler.sendWithPromise("GetPermissions", null);
  }
  getMetadata() {
    const t = "GetMetadata", e = n(this, Pn).get(t);
    if (e)
      return e;
    const s = this.messageHandler.sendWithPromise(t, null).then((i) => {
      var r, a;
      return {
        info: i[0],
        metadata: i[1] ? new Yy(i[1]) : null,
        contentDispositionFilename: ((r = this._fullReader) == null ? void 0 : r.filename) ?? null,
        contentLength: ((a = this._fullReader) == null ? void 0 : a.contentLength) ?? null
      };
    });
    return n(this, Pn).set(t, s), s;
  }
  getMarkInfo() {
    return this.messageHandler.sendWithPromise("GetMarkInfo", null);
  }
  async startCleanup(t = !1) {
    if (!this.destroyed) {
      await this.messageHandler.sendWithPromise("Cleanup", null);
      for (const e of n(this, $i).values())
        if (!e.cleanup())
          throw new Error(`startCleanup: Page ${e.pageNumber} is currently rendering.`);
      this.commonObjs.clear(), t || this.fontLoader.clear(), n(this, Pn).clear(), this.filterFactory.destroy(!0), Yh.cleanup();
    }
  }
  cachedPageNumber(t) {
    if (!ap(t))
      return null;
    const e = t.gen === 0 ? `${t.num}R` : `${t.num}R${t.gen}`;
    return n(this, kl).get(e) ?? null;
  }
}
Pn = new WeakMap(), $i = new WeakMap(), Ml = new WeakMap(), kl = new WeakMap(), Rn = new WeakMap(), Va = new WeakSet(), Oh = function(t, e = null) {
  const s = n(this, Pn).get(t);
  if (s)
    return s;
  const i = this.messageHandler.sendWithPromise(t, e);
  return n(this, Pn).set(t, i), i;
};
var Er;
class wA {
  constructor(t) {
    g(this, Er, null);
    L(this, "onContinue", null);
    L(this, "onError", null);
    p(this, Er, t);
  }
  get promise() {
    return n(this, Er).capability.promise;
  }
  cancel(t = 0) {
    n(this, Er).cancel(null, t);
  }
  get separateAnnots() {
    const {
      separateAnnots: t
    } = n(this, Er).operatorList;
    if (!t)
      return !1;
    const {
      annotationCanvasMap: e
    } = n(this, Er);
    return t.form || t.canvas && (e == null ? void 0 : e.size) > 0;
  }
}
Er = new WeakMap();
var Sr, za;
const ia = class ia {
  constructor({
    callback: t,
    params: e,
    objs: s,
    commonObjs: i,
    annotationCanvasMap: r,
    operatorList: a,
    pageIndex: o,
    canvasFactory: l,
    filterFactory: h,
    useRequestAnimationFrame: c = !1,
    pdfBug: u = !1,
    pageColors: f = null,
    enableHWA: m = !1,
    operationsFilter: A = null
  }) {
    g(this, Sr, null);
    this.callback = t, this.params = e, this.objs = s, this.commonObjs = i, this.annotationCanvasMap = r, this.operatorListIdx = null, this.operatorList = a, this._pageIndex = o, this.canvasFactory = l, this.filterFactory = h, this._pdfBug = u, this.pageColors = f, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = c === !0 && typeof window < "u", this.cancelled = !1, this.capability = Promise.withResolvers(), this.task = new wA(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = e.canvas, this._canvasContext = e.canvas ? null : e.canvasContext, this._enableHWA = m, this._dependencyTracker = e.dependencyTracker, this._operationsFilter = A;
  }
  get completed() {
    return this.capability.promise.catch(function() {
    });
  }
  initializeGraphics({
    transparency: t = !1,
    optionalContentConfig: e
  }) {
    var l, h;
    if (this.cancelled)
      return;
    if (this._canvas) {
      if (n(ia, za).has(this._canvas))
        throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
      n(ia, za).add(this._canvas);
    }
    this._pdfBug && ((l = globalThis.StepperManager) != null && l.enabled) && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint());
    const {
      viewport: s,
      transform: i,
      background: r,
      dependencyTracker: a
    } = this.params, o = this._canvasContext || this._canvas.getContext("2d", {
      alpha: !1,
      willReadFrequently: !this._enableHWA
    });
    this.gfx = new No(o, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
      optionalContentConfig: e
    }, this.annotationCanvasMap, this.pageColors, a), this.gfx.beginDrawing({
      transform: i,
      viewport: s,
      transparency: t,
      background: r
    }), this.operatorListIdx = 0, this.graphicsReady = !0, (h = this.graphicsReadyCallback) == null || h.call(this);
  }
  cancel(t = null, e = 0) {
    var s, i, r;
    this.running = !1, this.cancelled = !0, (s = this.gfx) == null || s.endDrawing(), n(this, Sr) && (window.cancelAnimationFrame(n(this, Sr)), p(this, Sr, null)), n(ia, za).delete(this._canvas), t || (t = new pf(`Rendering cancelled, page ${this._pageIndex + 1}`, e)), this.callback(t), (r = (i = this.task).onError) == null || r.call(i, t);
  }
  operatorListChanged() {
    var t, e;
    if (!this.graphicsReady) {
      this.graphicsReadyCallback || (this.graphicsReadyCallback = this._continueBound);
      return;
    }
    (t = this.gfx.dependencyTracker) == null || t.growOperationsCount(this.operatorList.fnArray.length), (e = this.stepper) == null || e.updateOperatorList(this.operatorList), !this.running && this._continue();
  }
  _continue() {
    this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
  }
  _scheduleNext() {
    this._useRequestAnimationFrame ? p(this, Sr, window.requestAnimationFrame(() => {
      p(this, Sr, null), this._nextBound().catch(this._cancelBound);
    })) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
  }
  async _next() {
    this.cancelled || (this.operatorListIdx = this.gfx.executeOperatorList(this.operatorList, this.operatorListIdx, this._continueBound, this.stepper, this._operationsFilter), this.operatorListIdx === this.operatorList.argsArray.length && (this.running = !1, this.operatorList.lastChunk && (this.gfx.endDrawing(), n(ia, za).delete(this._canvas), this.callback())));
  }
};
Sr = new WeakMap(), za = new WeakMap(), g(ia, za, /* @__PURE__ */ new WeakSet());
let Ep = ia;
const Kh = "5.4.296", Db = "f56dc8601";
var Cs, Ga, Ll, de, Jc, Dl, Mn, Qc, _r, mi, td, Tt, Sp, _p, Cp, Qr, Ib, Kn;
const ls = class ls {
  constructor({
    editor: t = null,
    uiManager: e = null
  }) {
    g(this, Tt);
    g(this, Cs, null);
    g(this, Ga, null);
    g(this, Ll);
    g(this, de, null);
    g(this, Jc, !1);
    g(this, Dl, !1);
    g(this, Mn, null);
    g(this, Qc);
    g(this, _r, null);
    g(this, mi, null);
    var s, i;
    t ? (p(this, Dl, !1), p(this, Mn, t)) : p(this, Dl, !0), p(this, mi, (t == null ? void 0 : t._uiManager) || e), p(this, Qc, n(this, mi)._eventBus), p(this, Ll, ((s = t == null ? void 0 : t.color) == null ? void 0 : s.toUpperCase()) || ((i = n(this, mi)) == null ? void 0 : i.highlightColors.values().next().value) || "#FFFF98"), n(ls, td) || p(ls, td, Object.freeze({
      blue: "pdfjs-editor-colorpicker-blue",
      green: "pdfjs-editor-colorpicker-green",
      pink: "pdfjs-editor-colorpicker-pink",
      red: "pdfjs-editor-colorpicker-red",
      yellow: "pdfjs-editor-colorpicker-yellow"
    }));
  }
  static get _keyboardManager() {
    return it(this, "_keyboardManager", new Od([[["Escape", "mac+Escape"], ls.prototype._hideDropdownFromKeyboard], [[" ", "mac+ "], ls.prototype._colorSelectFromKeyboard], [["ArrowDown", "ArrowRight", "mac+ArrowDown", "mac+ArrowRight"], ls.prototype._moveToNext], [["ArrowUp", "ArrowLeft", "mac+ArrowUp", "mac+ArrowLeft"], ls.prototype._moveToPrevious], [["Home", "mac+Home"], ls.prototype._moveToBeginning], [["End", "mac+End"], ls.prototype._moveToEnd]]));
  }
  renderButton() {
    const t = p(this, Cs, document.createElement("button"));
    t.className = "colorPicker", t.tabIndex = "0", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-button"), t.ariaHasPopup = "true", n(this, Mn) && (t.ariaControls = `${n(this, Mn).id}_colorpicker_dropdown`);
    const e = n(this, mi)._signal;
    t.addEventListener("click", b(this, Tt, Qr).bind(this), {
      signal: e
    }), t.addEventListener("keydown", b(this, Tt, Cp).bind(this), {
      signal: e
    });
    const s = p(this, Ga, document.createElement("span"));
    return s.className = "swatch", s.ariaHidden = "true", s.style.backgroundColor = n(this, Ll), t.append(s), t;
  }
  renderMainDropdown() {
    const t = p(this, de, b(this, Tt, Sp).call(this));
    return t.ariaOrientation = "horizontal", t.ariaLabelledBy = "highlightColorPickerLabel", t;
  }
  _colorSelectFromKeyboard(t) {
    if (t.target === n(this, Cs)) {
      b(this, Tt, Qr).call(this, t);
      return;
    }
    const e = t.target.getAttribute("data-color");
    e && b(this, Tt, _p).call(this, e, t);
  }
  _moveToNext(t) {
    var e, s;
    if (!n(this, Tt, Kn)) {
      b(this, Tt, Qr).call(this, t);
      return;
    }
    if (t.target === n(this, Cs)) {
      (e = n(this, de).firstChild) == null || e.focus();
      return;
    }
    (s = t.target.nextSibling) == null || s.focus();
  }
  _moveToPrevious(t) {
    var e, s;
    if (t.target === ((e = n(this, de)) == null ? void 0 : e.firstChild) || t.target === n(this, Cs)) {
      n(this, Tt, Kn) && this._hideDropdownFromKeyboard();
      return;
    }
    n(this, Tt, Kn) || b(this, Tt, Qr).call(this, t), (s = t.target.previousSibling) == null || s.focus();
  }
  _moveToBeginning(t) {
    var e;
    if (!n(this, Tt, Kn)) {
      b(this, Tt, Qr).call(this, t);
      return;
    }
    (e = n(this, de).firstChild) == null || e.focus();
  }
  _moveToEnd(t) {
    var e;
    if (!n(this, Tt, Kn)) {
      b(this, Tt, Qr).call(this, t);
      return;
    }
    (e = n(this, de).lastChild) == null || e.focus();
  }
  hideDropdown() {
    var t, e;
    (t = n(this, de)) == null || t.classList.add("hidden"), n(this, Cs).ariaExpanded = "false", (e = n(this, _r)) == null || e.abort(), p(this, _r, null);
  }
  _hideDropdownFromKeyboard() {
    var t;
    if (!n(this, Dl)) {
      if (!n(this, Tt, Kn)) {
        (t = n(this, Mn)) == null || t.unselect();
        return;
      }
      this.hideDropdown(), n(this, Cs).focus({
        preventScroll: !0,
        focusVisible: n(this, Jc)
      });
    }
  }
  updateColor(t) {
    if (n(this, Ga) && (n(this, Ga).style.backgroundColor = t), !n(this, de))
      return;
    const e = n(this, mi).highlightColors.values();
    for (const s of n(this, de).children)
      s.ariaSelected = e.next().value === t.toUpperCase();
  }
  destroy() {
    var t, e;
    (t = n(this, Cs)) == null || t.remove(), p(this, Cs, null), p(this, Ga, null), (e = n(this, de)) == null || e.remove(), p(this, de, null);
  }
};
Cs = new WeakMap(), Ga = new WeakMap(), Ll = new WeakMap(), de = new WeakMap(), Jc = new WeakMap(), Dl = new WeakMap(), Mn = new WeakMap(), Qc = new WeakMap(), _r = new WeakMap(), mi = new WeakMap(), td = new WeakMap(), Tt = new WeakSet(), Sp = function() {
  const t = document.createElement("div"), e = n(this, mi)._signal;
  t.addEventListener("contextmenu", $s, {
    signal: e
  }), t.className = "dropdown", t.role = "listbox", t.ariaMultiSelectable = "false", t.ariaOrientation = "vertical", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-dropdown"), n(this, Mn) && (t.id = `${n(this, Mn).id}_colorpicker_dropdown`);
  for (const [s, i] of n(this, mi).highlightColors) {
    const r = document.createElement("button");
    r.tabIndex = "0", r.role = "option", r.setAttribute("data-color", i), r.title = s, r.setAttribute("data-l10n-id", n(ls, td)[s]);
    const a = document.createElement("span");
    r.append(a), a.className = "swatch", a.style.backgroundColor = i, r.ariaSelected = i === n(this, Ll), r.addEventListener("click", b(this, Tt, _p).bind(this, i), {
      signal: e
    }), t.append(r);
  }
  return t.addEventListener("keydown", b(this, Tt, Cp).bind(this), {
    signal: e
  }), t;
}, _p = function(t, e) {
  e.stopPropagation(), n(this, Qc).dispatch("switchannotationeditorparams", {
    source: this,
    type: ht.HIGHLIGHT_COLOR,
    value: t
  }), this.updateColor(t);
}, Cp = function(t) {
  ls._keyboardManager.exec(this, t);
}, Qr = function(t) {
  if (n(this, Tt, Kn)) {
    this.hideDropdown();
    return;
  }
  if (p(this, Jc, t.detail === 0), n(this, _r) || (p(this, _r, new AbortController()), window.addEventListener("pointerdown", b(this, Tt, Ib).bind(this), {
    signal: n(this, mi).combinedSignal(n(this, _r))
  })), n(this, Cs).ariaExpanded = "true", n(this, de)) {
    n(this, de).classList.remove("hidden");
    return;
  }
  const e = p(this, de, b(this, Tt, Sp).call(this));
  n(this, Cs).append(e);
}, Ib = function(t) {
  var e;
  (e = n(this, de)) != null && e.contains(t.target) || this.hideDropdown();
}, Kn = function() {
  return n(this, de) && !n(this, de).classList.contains("hidden");
}, g(ls, td, null);
let Zh = ls;
var Vi, ed, Il, sd;
const na = class na {
  constructor(t) {
    g(this, Vi, null);
    g(this, ed, null);
    g(this, Il, null);
    p(this, ed, t), p(this, Il, t._uiManager), n(na, sd) || p(na, sd, Object.freeze({
      freetext: "pdfjs-editor-color-picker-free-text-input",
      ink: "pdfjs-editor-color-picker-ink-input"
    }));
  }
  renderButton() {
    if (n(this, Vi))
      return n(this, Vi);
    const {
      editorType: t,
      colorType: e,
      colorValue: s
    } = n(this, ed), i = p(this, Vi, document.createElement("input"));
    return i.type = "color", i.value = s || "#000000", i.className = "basicColorPicker", i.tabIndex = 0, i.setAttribute("data-l10n-id", n(na, sd)[t]), i.addEventListener("input", () => {
      n(this, Il).updateParams(e, i.value);
    }, {
      signal: n(this, Il)._signal
    }), i;
  }
  update(t) {
    n(this, Vi) && (n(this, Vi).value = t);
  }
  destroy() {
    var t;
    (t = n(this, Vi)) == null || t.remove(), p(this, Vi, null);
  }
  hideDropdown() {
  }
};
Vi = new WeakMap(), ed = new WeakMap(), Il = new WeakMap(), sd = new WeakMap(), g(na, sd, null);
let Uu = na;
function nm(d) {
  return Math.floor(Math.max(0, Math.min(1, d)) * 255).toString(16).padStart(2, "0");
}
function wh(d) {
  return Math.max(0, Math.min(255, 255 * d));
}
class rm {
  static CMYK_G([t, e, s, i]) {
    return ["G", 1 - Math.min(1, 0.3 * t + 0.59 * s + 0.11 * e + i)];
  }
  static G_CMYK([t]) {
    return ["CMYK", 0, 0, 0, 1 - t];
  }
  static G_RGB([t]) {
    return ["RGB", t, t, t];
  }
  static G_rgb([t]) {
    return t = wh(t), [t, t, t];
  }
  static G_HTML([t]) {
    const e = nm(t);
    return `#${e}${e}${e}`;
  }
  static RGB_G([t, e, s]) {
    return ["G", 0.3 * t + 0.59 * e + 0.11 * s];
  }
  static RGB_rgb(t) {
    return t.map(wh);
  }
  static RGB_HTML(t) {
    return `#${t.map(nm).join("")}`;
  }
  static T_HTML() {
    return "#00000000";
  }
  static T_rgb() {
    return [null];
  }
  static CMYK_RGB([t, e, s, i]) {
    return ["RGB", 1 - Math.min(1, t + i), 1 - Math.min(1, s + i), 1 - Math.min(1, e + i)];
  }
  static CMYK_rgb([t, e, s, i]) {
    return [wh(1 - Math.min(1, t + i)), wh(1 - Math.min(1, s + i)), wh(1 - Math.min(1, e + i))];
  }
  static CMYK_HTML(t) {
    const e = this.CMYK_RGB(t).slice(1);
    return this.RGB_HTML(e);
  }
  static RGB_CMYK([t, e, s]) {
    const i = 1 - t, r = 1 - e, a = 1 - s, o = Math.min(i, r, a);
    return ["CMYK", i, r, a, o];
  }
}
class vA {
  create(t, e, s = !1) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid SVG dimensions");
    const i = this._createSVG("svg:svg");
    return i.setAttribute("version", "1.1"), s || (i.setAttribute("width", `${t}px`), i.setAttribute("height", `${e}px`)), i.setAttribute("preserveAspectRatio", "none"), i.setAttribute("viewBox", `0 0 ${t} ${e}`), i;
  }
  createElement(t) {
    if (typeof t != "string")
      throw new Error("Invalid SVG element type");
    return this._createSVG(t);
  }
  _createSVG(t) {
    Dt("Abstract method `_createSVG` called.");
  }
}
class Jh extends vA {
  _createSVG(t) {
    return document.createElementNS(sn, t);
  }
}
const EA = 9, yo = /* @__PURE__ */ new WeakSet(), SA = (/* @__PURE__ */ new Date()).getTimezoneOffset() * 60 * 1e3;
class am {
  static create(t) {
    switch (t.data.annotationType) {
      case te.LINK:
        return new Eg(t);
      case te.TEXT:
        return new CA(t);
      case te.WIDGET:
        switch (t.data.fieldType) {
          case "Tx":
            return new TA(t);
          case "Btn":
            return t.data.radioButton ? new Ob(t) : t.data.checkBox ? new PA(t) : new RA(t);
          case "Ch":
            return new MA(t);
          case "Sig":
            return new xA(t);
        }
        return new vo(t);
      case te.POPUP:
        return new xp(t);
      case te.FREETEXT:
        return new Vb(t);
      case te.LINE:
        return new LA(t);
      case te.SQUARE:
        return new DA(t);
      case te.CIRCLE:
        return new IA(t);
      case te.POLYLINE:
        return new zb(t);
      case te.CARET:
        return new NA(t);
      case te.INK:
        return new Sg(t);
      case te.POLYGON:
        return new FA(t);
      case te.HIGHLIGHT:
        return new Gb(t);
      case te.UNDERLINE:
        return new OA(t);
      case te.SQUIGGLY:
        return new BA(t);
      case te.STRIKEOUT:
        return new HA(t);
      case te.STAMP:
        return new jb(t);
      case te.FILEATTACHMENT:
        return new UA(t);
      default:
        return new Gt(t);
    }
  }
}
var ja, Fl, ti, id, Tp;
const kg = class kg {
  constructor(t, {
    isRenderable: e = !1,
    ignoreBorder: s = !1,
    createQuadrilaterals: i = !1
  } = {}) {
    g(this, id);
    g(this, ja, null);
    g(this, Fl, !1);
    g(this, ti, null);
    this.isRenderable = e, this.data = t.data, this.layer = t.layer, this.linkService = t.linkService, this.downloadManager = t.downloadManager, this.imageResourcesPath = t.imageResourcesPath, this.renderForms = t.renderForms, this.svgFactory = t.svgFactory, this.annotationStorage = t.annotationStorage, this.enableComment = t.enableComment, this.enableScripting = t.enableScripting, this.hasJSActions = t.hasJSActions, this._fieldObjects = t.fieldObjects, this.parent = t.parent, e && (this.container = this._createContainer(s)), i && this._createQuadrilaterals();
  }
  static _hasPopupData({
    contentsObj: t,
    richText: e
  }) {
    return !!(t != null && t.str || e != null && e.str);
  }
  get _isEditable() {
    return this.data.isEditable;
  }
  get hasPopupData() {
    return kg._hasPopupData(this.data) || this.enableComment && !!this.commentText;
  }
  get commentData() {
    var s;
    const {
      data: t
    } = this, e = (s = this.annotationStorage) == null ? void 0 : s.getEditor(t.id);
    return e ? e.getData() : t;
  }
  get hasCommentButton() {
    return this.enableComment && this.hasPopupElement;
  }
  get commentButtonPosition() {
    var o;
    const t = (o = this.annotationStorage) == null ? void 0 : o.getEditor(this.data.id);
    if (t)
      return t.commentButtonPositionInPage;
    const {
      quadPoints: e,
      inkLists: s,
      rect: i
    } = this.data;
    let r = -1 / 0, a = -1 / 0;
    if ((e == null ? void 0 : e.length) >= 8) {
      for (let l = 0; l < e.length; l += 8)
        e[l + 1] > a ? (a = e[l + 1], r = e[l + 2]) : e[l + 1] === a && (r = Math.max(r, e[l + 2]));
      return [r, a];
    }
    if ((s == null ? void 0 : s.length) >= 1) {
      for (const l of s)
        for (let h = 0, c = l.length; h < c; h += 2)
          l[h + 1] > a ? (a = l[h + 1], r = l[h]) : l[h + 1] === a && (r = Math.max(r, l[h]));
      if (r !== 1 / 0)
        return [r, a];
    }
    return i ? [i[2], i[3]] : null;
  }
  _normalizePoint(t) {
    const {
      page: {
        view: e
      },
      viewport: {
        rawDims: {
          pageWidth: s,
          pageHeight: i,
          pageX: r,
          pageY: a
        }
      }
    } = this.parent;
    return t[1] = e[3] - t[1] + e[1], t[0] = 100 * (t[0] - r) / s, t[1] = 100 * (t[1] - a) / i, t;
  }
  get commentText() {
    var e, s, i;
    const {
      data: t
    } = this;
    return ((s = (e = this.annotationStorage.getRawValue(`${Gh}${t.id}`)) == null ? void 0 : e.popup) == null ? void 0 : s.contents) || ((i = t.contentsObj) == null ? void 0 : i.str) || "";
  }
  set commentText(t) {
    const {
      data: e
    } = this, s = {
      deleted: !t,
      contents: t || ""
    };
    this.annotationStorage.updateEditor(e.id, {
      popup: s
    }) || this.annotationStorage.setValue(`${Gh}${e.id}`, {
      id: e.id,
      annotationType: e.annotationType,
      pageIndex: this.parent.page._pageIndex,
      popup: s,
      popupRef: e.popupRef,
      modificationDate: /* @__PURE__ */ new Date()
    }), t || this.removePopup();
  }
  removePopup() {
    var t, e;
    (e = ((t = n(this, ti)) == null ? void 0 : t.popup) || this.popup) == null || e.remove(), p(this, ti, this.popup = null);
  }
  updateEdited(t) {
    var r;
    if (!this.container)
      return;
    t.rect && (n(this, ja) || p(this, ja, {
      rect: this.data.rect.slice(0)
    }));
    const {
      rect: e,
      popup: s
    } = t;
    e && b(this, id, Tp).call(this, e);
    let i = ((r = n(this, ti)) == null ? void 0 : r.popup) || this.popup;
    !i && (s != null && s.text) && (this._createPopup(s), i = n(this, ti).popup), i && (i.updateEdited(t), s != null && s.deleted && (i.remove(), p(this, ti, null), this.popup = null));
  }
  resetEdited() {
    var t;
    n(this, ja) && (b(this, id, Tp).call(this, n(this, ja).rect), (t = n(this, ti)) == null || t.popup.resetEdited(), p(this, ja, null));
  }
  _createContainer(t) {
    const {
      data: e,
      parent: {
        page: s,
        viewport: i
      }
    } = this, r = document.createElement("section");
    r.setAttribute("data-annotation-id", e.id), !(this instanceof vo) && !(this instanceof Eg) && (r.tabIndex = 0);
    const {
      style: a
    } = r;
    if (a.zIndex = this.parent.zIndex, this.parent.zIndex += 2, e.alternativeText && (r.title = e.alternativeText), e.noRotate && r.classList.add("norotate"), !e.rect || this instanceof xp) {
      const {
        rotation: y
      } = e;
      return !e.hasOwnCanvas && y !== 0 && this.setRotation(y, r), r;
    }
    const {
      width: o,
      height: l
    } = this;
    if (!t && e.borderStyle.width > 0) {
      a.borderWidth = `${e.borderStyle.width}px`;
      const y = e.borderStyle.horizontalCornerRadius, v = e.borderStyle.verticalCornerRadius;
      if (y > 0 || v > 0) {
        const S = `calc(${y}px * var(--total-scale-factor)) / calc(${v}px * var(--total-scale-factor))`;
        a.borderRadius = S;
      } else if (this instanceof Ob) {
        const S = `calc(${o}px * var(--total-scale-factor)) / calc(${l}px * var(--total-scale-factor))`;
        a.borderRadius = S;
      }
      switch (e.borderStyle.style) {
        case So.SOLID:
          a.borderStyle = "solid";
          break;
        case So.DASHED:
          a.borderStyle = "dashed";
          break;
        case So.BEVELED:
          J("Unimplemented border style: beveled");
          break;
        case So.INSET:
          J("Unimplemented border style: inset");
          break;
        case So.UNDERLINE:
          a.borderBottomStyle = "solid";
          break;
      }
      const w = e.borderColor || null;
      w ? (p(this, Fl, !0), a.borderColor = V.makeHexColor(w[0] | 0, w[1] | 0, w[2] | 0)) : a.borderWidth = 0;
    }
    const h = V.normalizeRect([e.rect[0], s.view[3] - e.rect[1] + s.view[1], e.rect[2], s.view[3] - e.rect[3] + s.view[1]]), {
      pageWidth: c,
      pageHeight: u,
      pageX: f,
      pageY: m
    } = i.rawDims;
    a.left = `${100 * (h[0] - f) / c}%`, a.top = `${100 * (h[1] - m) / u}%`;
    const {
      rotation: A
    } = e;
    return e.hasOwnCanvas || A === 0 ? (a.width = `${100 * o / c}%`, a.height = `${100 * l / u}%`) : this.setRotation(A, r), r;
  }
  setRotation(t, e = this.container) {
    if (!this.data.rect)
      return;
    const {
      pageWidth: s,
      pageHeight: i
    } = this.parent.viewport.rawDims;
    let {
      width: r,
      height: a
    } = this;
    t % 180 !== 0 && ([r, a] = [a, r]), e.style.width = `${100 * r / s}%`, e.style.height = `${100 * a / i}%`, e.setAttribute("data-main-rotation", (360 - t) % 360);
  }
  get _commonActions() {
    const t = (e, s, i) => {
      const r = i.detail[e], a = r[0], o = r.slice(1);
      i.target.style[s] = rm[`${a}_HTML`](o), this.annotationStorage.setValue(this.data.id, {
        [s]: rm[`${a}_rgb`](o)
      });
    };
    return it(this, "_commonActions", {
      display: (e) => {
        const {
          display: s
        } = e.detail, i = s % 2 === 1;
        this.container.style.visibility = i ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noView: i,
          noPrint: s === 1 || s === 2
        });
      },
      print: (e) => {
        this.annotationStorage.setValue(this.data.id, {
          noPrint: !e.detail.print
        });
      },
      hidden: (e) => {
        const {
          hidden: s
        } = e.detail;
        this.container.style.visibility = s ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noPrint: s,
          noView: s
        });
      },
      focus: (e) => {
        setTimeout(() => e.target.focus({
          preventScroll: !1
        }), 0);
      },
      userName: (e) => {
        e.target.title = e.detail.userName;
      },
      readonly: (e) => {
        e.target.disabled = e.detail.readonly;
      },
      required: (e) => {
        this._setRequired(e.target, e.detail.required);
      },
      bgColor: (e) => {
        t("bgColor", "backgroundColor", e);
      },
      fillColor: (e) => {
        t("fillColor", "backgroundColor", e);
      },
      fgColor: (e) => {
        t("fgColor", "color", e);
      },
      textColor: (e) => {
        t("textColor", "color", e);
      },
      borderColor: (e) => {
        t("borderColor", "borderColor", e);
      },
      strokeColor: (e) => {
        t("strokeColor", "borderColor", e);
      },
      rotation: (e) => {
        const s = e.detail.rotation;
        this.setRotation(s), this.annotationStorage.setValue(this.data.id, {
          rotation: s
        });
      }
    });
  }
  _dispatchEventFromSandbox(t, e) {
    const s = this._commonActions;
    for (const i of Object.keys(e.detail)) {
      const r = t[i] || s[i];
      r == null || r(e);
    }
  }
  _setDefaultPropertiesFromJS(t) {
    if (!this.enableScripting)
      return;
    const e = this.annotationStorage.getRawValue(this.data.id);
    if (!e)
      return;
    const s = this._commonActions;
    for (const [i, r] of Object.entries(e)) {
      const a = s[i];
      if (a) {
        const o = {
          detail: {
            [i]: r
          },
          target: t
        };
        a(o), delete e[i];
      }
    }
  }
  _createQuadrilaterals() {
    if (!this.container)
      return;
    const {
      quadPoints: t
    } = this.data;
    if (!t)
      return;
    const [e, s, i, r] = this.data.rect.map((y) => Math.fround(y));
    if (t.length === 8) {
      const [y, v, w, S] = t.subarray(2, 6);
      if (i === y && r === v && e === w && s === S)
        return;
    }
    const {
      style: a
    } = this.container;
    let o;
    if (n(this, Fl)) {
      const {
        borderColor: y,
        borderWidth: v
      } = a;
      a.borderWidth = 0, o = ["url('data:image/svg+xml;utf8,", '<svg xmlns="http://www.w3.org/2000/svg"', ' preserveAspectRatio="none" viewBox="0 0 1 1">', `<g fill="transparent" stroke="${y}" stroke-width="${v}">`], this.container.classList.add("hasBorder");
    }
    const l = i - e, h = r - s, {
      svgFactory: c
    } = this, u = c.createElement("svg");
    u.classList.add("quadrilateralsContainer"), u.setAttribute("width", 0), u.setAttribute("height", 0), u.role = "none";
    const f = c.createElement("defs");
    u.append(f);
    const m = c.createElement("clipPath"), A = `clippath_${this.data.id}`;
    m.setAttribute("id", A), m.setAttribute("clipPathUnits", "objectBoundingBox"), f.append(m);
    for (let y = 2, v = t.length; y < v; y += 8) {
      const w = t[y], S = t[y + 1], E = t[y + 2], _ = t[y + 3], C = c.createElement("rect"), T = (E - e) / l, x = (r - S) / h, R = (w - E) / l, M = (S - _) / h;
      C.setAttribute("x", T), C.setAttribute("y", x), C.setAttribute("width", R), C.setAttribute("height", M), m.append(C), o == null || o.push(`<rect vector-effect="non-scaling-stroke" x="${T}" y="${x}" width="${R}" height="${M}"/>`);
    }
    n(this, Fl) && (o.push("</g></svg>')"), a.backgroundImage = o.join("")), this.container.append(u), this.container.style.clipPath = `url(#${A})`;
  }
  _createPopup(t = null) {
    const {
      data: e
    } = this;
    let s, i;
    t ? (s = {
      str: t.text
    }, i = t.date) : (s = e.contentsObj, i = e.modificationDate);
    const r = p(this, ti, new xp({
      data: {
        color: e.color,
        titleObj: e.titleObj,
        modificationDate: i,
        contentsObj: s,
        richText: e.richText,
        parentRect: e.rect,
        borderStyle: 0,
        id: `popup_${e.id}`,
        rotation: e.rotation,
        noRotate: !0
      },
      linkService: this.linkService,
      parent: this.parent,
      elements: [this]
    }));
    this.parent._commentManager || this.parent.div.append(r.render());
  }
  get hasPopupElement() {
    return !!(n(this, ti) || this.popup || this.data.popupRef);
  }
  get extraPopupElement() {
    return n(this, ti);
  }
  render() {
    Dt("Abstract method `AnnotationElement.render` called");
  }
  _getElementsByName(t, e = null) {
    const s = [];
    if (this._fieldObjects) {
      const i = this._fieldObjects[t];
      if (i)
        for (const {
          page: r,
          id: a,
          exportValues: o
        } of i) {
          if (r === -1 || a === e)
            continue;
          const l = typeof o == "string" ? o : null, h = document.querySelector(`[data-element-id="${a}"]`);
          if (h && !yo.has(h)) {
            J(`_getElementsByName - element not allowed: ${a}`);
            continue;
          }
          s.push({
            id: a,
            exportValue: l,
            domElement: h
          });
        }
      return s;
    }
    for (const i of document.getElementsByName(t)) {
      const {
        exportValue: r
      } = i, a = i.getAttribute("data-element-id");
      a !== e && yo.has(i) && s.push({
        id: a,
        exportValue: r,
        domElement: i
      });
    }
    return s;
  }
  show() {
    var t;
    this.container && (this.container.hidden = !1), (t = this.popup) == null || t.maybeShow();
  }
  hide() {
    var t;
    this.container && (this.container.hidden = !0), (t = this.popup) == null || t.forceHide();
  }
  getElementsToTriggerPopup() {
    return this.container;
  }
  addHighlightArea() {
    const t = this.getElementsToTriggerPopup();
    if (Array.isArray(t))
      for (const e of t)
        e.classList.add("highlightArea");
    else
      t.classList.add("highlightArea");
  }
  _editOnDoubleClick() {
    if (!this._isEditable)
      return;
    const {
      annotationEditorType: t,
      data: {
        id: e
      }
    } = this;
    this.container.addEventListener("dblclick", () => {
      var s;
      (s = this.linkService.eventBus) == null || s.dispatch("switchannotationeditormode", {
        source: this,
        mode: t,
        editId: e,
        mustEnterInEditMode: !0
      });
    });
  }
  get width() {
    return this.data.rect[2] - this.data.rect[0];
  }
  get height() {
    return this.data.rect[3] - this.data.rect[1];
  }
};
ja = new WeakMap(), Fl = new WeakMap(), ti = new WeakMap(), id = new WeakSet(), Tp = function(t) {
  const {
    container: {
      style: e
    },
    data: {
      rect: s,
      rotation: i
    },
    parent: {
      viewport: {
        rawDims: {
          pageWidth: r,
          pageHeight: a,
          pageX: o,
          pageY: l
        }
      }
    }
  } = this;
  s == null || s.splice(0, 4, ...t), e.left = `${100 * (t[0] - o) / r}%`, e.top = `${100 * (a - t[3] + l) / a}%`, i === 0 ? (e.width = `${100 * (t[2] - t[0]) / r}%`, e.height = `${100 * (t[3] - t[1]) / a}%`) : this.setRotation(i);
};
let Gt = kg;
class _A extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.editor = t.editor;
  }
  render() {
    return this.container.className = "editorAnnotation", this.container;
  }
  createOrUpdatePopup() {
    const {
      editor: t
    } = this;
    t.hasComment && (this._createPopup(t.comment), this.extraPopupElement.popup.renderCommentButton());
  }
  get hasCommentButton() {
    return this.enableComment && this.editor.hasComment;
  }
  get commentButtonPosition() {
    return this.editor.commentButtonPositionInPage;
  }
  get commentText() {
    return this.editor.comment.text;
  }
  set commentText(t) {
    this.editor.comment = t, t || this.removePopup();
  }
  get commentData() {
    return this.editor.getData();
  }
  remove() {
    this.container.remove(), this.container = null, this.removePopup();
  }
}
var Hs, ta, Fb, Nb;
class Eg extends Gt {
  constructor(e, s = null) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !!(s != null && s.ignoreBorder),
      createQuadrilaterals: !0
    });
    g(this, Hs);
    this.isTooltipOnly = e.data.isTooltipOnly;
  }
  render() {
    const {
      data: e,
      linkService: s
    } = this, i = document.createElement("a");
    i.setAttribute("data-element-id", e.id);
    let r = !1;
    return e.url ? (s.addLinkAttributes(i, e.url, e.newWindow), r = !0) : e.action ? (this._bindNamedAction(i, e.action, e.overlaidText), r = !0) : e.attachment ? (b(this, Hs, Fb).call(this, i, e.attachment, e.overlaidText, e.attachmentDest), r = !0) : e.setOCGState ? (b(this, Hs, Nb).call(this, i, e.setOCGState, e.overlaidText), r = !0) : e.dest ? (this._bindLink(i, e.dest, e.overlaidText), r = !0) : (e.actions && (e.actions.Action || e.actions["Mouse Up"] || e.actions["Mouse Down"]) && this.enableScripting && this.hasJSActions && (this._bindJSAction(i, e), r = !0), e.resetForm ? (this._bindResetFormAction(i, e.resetForm), r = !0) : this.isTooltipOnly && !r && (this._bindLink(i, ""), r = !0)), this.container.classList.add("linkAnnotation"), r && this.container.append(i), this.container;
  }
  _bindLink(e, s, i = "") {
    e.href = this.linkService.getDestinationHash(s), e.onclick = () => (s && this.linkService.goToDestination(s), !1), (s || s === "") && b(this, Hs, ta).call(this), i && (e.title = i);
  }
  _bindNamedAction(e, s, i = "") {
    e.href = this.linkService.getAnchorUrl(""), e.onclick = () => (this.linkService.executeNamedAction(s), !1), i && (e.title = i), b(this, Hs, ta).call(this);
  }
  _bindJSAction(e, s) {
    e.href = this.linkService.getAnchorUrl("");
    const i = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
    for (const r of Object.keys(s.actions)) {
      const a = i.get(r);
      a && (e[a] = () => {
        var o;
        return (o = this.linkService.eventBus) == null || o.dispatch("dispatcheventinsandbox", {
          source: this,
          detail: {
            id: s.id,
            name: r
          }
        }), !1;
      });
    }
    s.overlaidText && (e.title = s.overlaidText), e.onclick || (e.onclick = () => !1), b(this, Hs, ta).call(this);
  }
  _bindResetFormAction(e, s) {
    const i = e.onclick;
    if (i || (e.href = this.linkService.getAnchorUrl("")), b(this, Hs, ta).call(this), !this._fieldObjects) {
      J('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), i || (e.onclick = () => !1);
      return;
    }
    e.onclick = () => {
      var u;
      i == null || i();
      const {
        fields: r,
        refs: a,
        include: o
      } = s, l = [];
      if (r.length !== 0 || a.length !== 0) {
        const f = new Set(a);
        for (const m of r) {
          const A = this._fieldObjects[m] || [];
          for (const {
            id: y
          } of A)
            f.add(y);
        }
        for (const m of Object.values(this._fieldObjects))
          for (const A of m)
            f.has(A.id) === o && l.push(A);
      } else
        for (const f of Object.values(this._fieldObjects))
          l.push(...f);
      const h = this.annotationStorage, c = [];
      for (const f of l) {
        const {
          id: m
        } = f;
        switch (c.push(m), f.type) {
          case "text": {
            const y = f.defaultValue || "";
            h.setValue(m, {
              value: y
            });
            break;
          }
          case "checkbox":
          case "radiobutton": {
            const y = f.defaultValue === f.exportValues;
            h.setValue(m, {
              value: y
            });
            break;
          }
          case "combobox":
          case "listbox": {
            const y = f.defaultValue || "";
            h.setValue(m, {
              value: y
            });
            break;
          }
          default:
            continue;
        }
        const A = document.querySelector(`[data-element-id="${m}"]`);
        if (A) {
          if (!yo.has(A)) {
            J(`_bindResetFormAction - element not allowed: ${m}`);
            continue;
          }
        } else continue;
        A.dispatchEvent(new Event("resetform"));
      }
      return this.enableScripting && ((u = this.linkService.eventBus) == null || u.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: "app",
          ids: c,
          name: "ResetForm"
        }
      })), !1;
    };
  }
}
Hs = new WeakSet(), ta = function() {
  this.container.setAttribute("data-internal-link", "");
}, Fb = function(e, s, i = "", r = null) {
  e.href = this.linkService.getAnchorUrl(""), s.description ? e.title = s.description : i && (e.title = i), e.onclick = () => {
    var a;
    return (a = this.downloadManager) == null || a.openOrDownloadData(s.content, s.filename, r), !1;
  }, b(this, Hs, ta).call(this);
}, Nb = function(e, s, i = "") {
  e.href = this.linkService.getAnchorUrl(""), e.onclick = () => (this.linkService.executeSetOCGState(s), !1), i && (e.title = i), b(this, Hs, ta).call(this);
};
class CA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0
    });
  }
  render() {
    this.container.classList.add("textAnnotation");
    const t = document.createElement("img");
    return t.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", t.setAttribute("data-l10n-id", "pdfjs-text-annotation-type"), t.setAttribute("data-l10n-args", JSON.stringify({
      type: this.data.name
    })), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.append(t), this.container;
  }
}
class vo extends Gt {
  render() {
    return this.container;
  }
  showElementAndHideCanvas(t) {
    var e;
    this.data.hasOwnCanvas && (((e = t.previousSibling) == null ? void 0 : e.nodeName) === "CANVAS" && (t.previousSibling.hidden = !0), t.hidden = !1);
  }
  _getKeyModifier(t) {
    return _e.platform.isMac ? t.metaKey : t.ctrlKey;
  }
  _setEventListener(t, e, s, i, r) {
    s.includes("mouse") ? t.addEventListener(s, (a) => {
      var o;
      (o = this.linkService.eventBus) == null || o.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: i,
          value: r(a),
          shift: a.shiftKey,
          modifier: this._getKeyModifier(a)
        }
      });
    }) : t.addEventListener(s, (a) => {
      var o;
      if (s === "blur") {
        if (!e.focused || !a.relatedTarget)
          return;
        e.focused = !1;
      } else if (s === "focus") {
        if (e.focused)
          return;
        e.focused = !0;
      }
      r && ((o = this.linkService.eventBus) == null || o.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: i,
          value: r(a)
        }
      }));
    });
  }
  _setEventListeners(t, e, s, i) {
    var r, a, o;
    for (const [l, h] of s)
      (h === "Action" || (r = this.data.actions) != null && r[h]) && ((h === "Focus" || h === "Blur") && (e || (e = {
        focused: !1
      })), this._setEventListener(t, e, l, h, i), h === "Focus" && !((a = this.data.actions) != null && a.Blur) ? this._setEventListener(t, e, "blur", "Blur", null) : h === "Blur" && !((o = this.data.actions) != null && o.Focus) && this._setEventListener(t, e, "focus", "Focus", null));
  }
  _setBackgroundColor(t) {
    const e = this.data.backgroundColor || null;
    t.style.backgroundColor = e === null ? "transparent" : V.makeHexColor(e[0], e[1], e[2]);
  }
  _setTextStyle(t) {
    const e = ["left", "center", "right"], {
      fontColor: s
    } = this.data.defaultAppearanceData, i = this.data.defaultAppearanceData.fontSize || EA, r = t.style;
    let a;
    const o = 2, l = (h) => Math.round(10 * h) / 10;
    if (this.data.multiLine) {
      const h = Math.abs(this.data.rect[3] - this.data.rect[1] - o), c = Math.round(h / (xf * i)) || 1, u = h / c;
      a = Math.min(i, l(u / xf));
    } else {
      const h = Math.abs(this.data.rect[3] - this.data.rect[1] - o);
      a = Math.min(i, l(h / xf));
    }
    r.fontSize = `calc(${a}px * var(--total-scale-factor))`, r.color = V.makeHexColor(s[0], s[1], s[2]), this.data.textAlignment !== null && (r.textAlign = e[this.data.textAlignment]);
  }
  _setRequired(t, e) {
    e ? t.setAttribute("required", !0) : t.removeAttribute("required"), t.setAttribute("aria-required", e);
  }
}
class TA extends vo {
  constructor(t) {
    const e = t.renderForms || t.data.hasOwnCanvas || !t.data.hasAppearance && !!t.data.fieldValue;
    super(t, {
      isRenderable: e
    });
  }
  setPropertyOnSiblings(t, e, s, i) {
    const r = this.annotationStorage;
    for (const a of this._getElementsByName(t.name, t.id))
      a.domElement && (a.domElement[e] = s), r.setValue(a.id, {
        [i]: s
      });
  }
  render() {
    var i, r;
    const t = this.annotationStorage, e = this.data.id;
    this.container.classList.add("textWidgetAnnotation");
    let s = null;
    if (this.renderForms) {
      const a = t.getValue(e, {
        value: this.data.fieldValue
      });
      let o = a.value || "";
      const l = t.getValue(e, {
        charLimit: this.data.maxLen
      }).charLimit;
      l && o.length > l && (o = o.slice(0, l));
      let h = a.formattedValue || ((i = this.data.textContent) == null ? void 0 : i.join(`
`)) || null;
      h && this.data.comb && (h = h.replaceAll(/\s+/g, ""));
      const c = {
        userValue: o,
        formattedValue: h,
        lastCommittedValue: null,
        commitKey: 1,
        focused: !1
      };
      this.data.multiLine ? (s = document.createElement("textarea"), s.textContent = h ?? o, this.data.doNotScroll && (s.style.overflowY = "hidden")) : (s = document.createElement("input"), s.type = this.data.password ? "password" : "text", s.setAttribute("value", h ?? o), this.data.doNotScroll && (s.style.overflowX = "hidden")), this.data.hasOwnCanvas && (s.hidden = !0), yo.add(s), s.setAttribute("data-element-id", e), s.disabled = this.data.readOnly, s.name = this.data.fieldName, s.tabIndex = 0;
      const {
        datetimeFormat: u,
        datetimeType: f,
        timeStep: m
      } = this.data, A = !!f && this.enableScripting;
      u && (s.title = u), this._setRequired(s, this.data.required), l && (s.maxLength = l), s.addEventListener("input", (v) => {
        t.setValue(e, {
          value: v.target.value
        }), this.setPropertyOnSiblings(s, "value", v.target.value, "value"), c.formattedValue = null;
      }), s.addEventListener("resetform", (v) => {
        const w = this.data.defaultFieldValue ?? "";
        s.value = c.userValue = w, c.formattedValue = null;
      });
      let y = (v) => {
        const {
          formattedValue: w
        } = c;
        w != null && (v.target.value = w), v.target.scrollLeft = 0;
      };
      if (this.enableScripting && this.hasJSActions) {
        s.addEventListener("focus", (w) => {
          var E;
          if (c.focused)
            return;
          const {
            target: S
          } = w;
          if (A && (S.type = f, m && (S.step = m)), c.userValue) {
            const _ = c.userValue;
            if (A)
              if (f === "time") {
                const C = new Date(_), T = [C.getHours(), C.getMinutes(), C.getSeconds()];
                S.value = T.map((x) => x.toString().padStart(2, "0")).join(":");
              } else
                S.value = new Date(_ - SA).toISOString().split(f === "date" ? "T" : ".", 1)[0];
            else
              S.value = _;
          }
          c.lastCommittedValue = S.value, c.commitKey = 1, (E = this.data.actions) != null && E.Focus || (c.focused = !0);
        }), s.addEventListener("updatefromsandbox", (w) => {
          this.showElementAndHideCanvas(w.target);
          const S = {
            value(E) {
              c.userValue = E.detail.value ?? "", A || t.setValue(e, {
                value: c.userValue.toString()
              }), E.target.value = c.userValue;
            },
            formattedValue(E) {
              const {
                formattedValue: _
              } = E.detail;
              c.formattedValue = _, _ != null && E.target !== document.activeElement && (E.target.value = _);
              const C = {
                formattedValue: _
              };
              A && (C.value = _), t.setValue(e, C);
            },
            selRange(E) {
              E.target.setSelectionRange(...E.detail.selRange);
            },
            charLimit: (E) => {
              var x;
              const {
                charLimit: _
              } = E.detail, {
                target: C
              } = E;
              if (_ === 0) {
                C.removeAttribute("maxLength");
                return;
              }
              C.setAttribute("maxLength", _);
              let T = c.userValue;
              !T || T.length <= _ || (T = T.slice(0, _), C.value = c.userValue = T, t.setValue(e, {
                value: T
              }), (x = this.linkService.eventBus) == null || x.dispatch("dispatcheventinsandbox", {
                source: this,
                detail: {
                  id: e,
                  name: "Keystroke",
                  value: T,
                  willCommit: !0,
                  commitKey: 1,
                  selStart: C.selectionStart,
                  selEnd: C.selectionEnd
                }
              }));
            }
          };
          this._dispatchEventFromSandbox(S, w);
        }), s.addEventListener("keydown", (w) => {
          var _;
          c.commitKey = 1;
          let S = -1;
          if (w.key === "Escape" ? S = 0 : w.key === "Enter" && !this.data.multiLine ? S = 2 : w.key === "Tab" && (c.commitKey = 3), S === -1)
            return;
          const {
            value: E
          } = w.target;
          c.lastCommittedValue !== E && (c.lastCommittedValue = E, c.userValue = E, (_ = this.linkService.eventBus) == null || _.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: E,
              willCommit: !0,
              commitKey: S,
              selStart: w.target.selectionStart,
              selEnd: w.target.selectionEnd
            }
          }));
        });
        const v = y;
        y = null, s.addEventListener("blur", (w) => {
          var _, C;
          if (!c.focused || !w.relatedTarget)
            return;
          (_ = this.data.actions) != null && _.Blur || (c.focused = !1);
          const {
            target: S
          } = w;
          let {
            value: E
          } = S;
          if (A) {
            if (E && f === "time") {
              const T = E.split(":").map((x) => parseInt(x, 10));
              E = new Date(2e3, 0, 1, T[0], T[1], T[2] || 0).valueOf(), S.step = "";
            } else
              E.includes("T") || (E = `${E}T00:00`), E = new Date(E).valueOf();
            S.type = "text";
          }
          c.userValue = E, c.lastCommittedValue !== E && ((C = this.linkService.eventBus) == null || C.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: E,
              willCommit: !0,
              commitKey: c.commitKey,
              selStart: w.target.selectionStart,
              selEnd: w.target.selectionEnd
            }
          })), v(w);
        }), (r = this.data.actions) != null && r.Keystroke && s.addEventListener("beforeinput", (w) => {
          var M;
          c.lastCommittedValue = null;
          const {
            data: S,
            target: E
          } = w, {
            value: _,
            selectionStart: C,
            selectionEnd: T
          } = E;
          let x = C, R = T;
          switch (w.inputType) {
            case "deleteWordBackward": {
              const D = _.substring(0, C).match(/\w*[^\w]*$/);
              D && (x -= D[0].length);
              break;
            }
            case "deleteWordForward": {
              const D = _.substring(C).match(/^[^\w]*\w*/);
              D && (R += D[0].length);
              break;
            }
            case "deleteContentBackward":
              C === T && (x -= 1);
              break;
            case "deleteContentForward":
              C === T && (R += 1);
              break;
          }
          w.preventDefault(), (M = this.linkService.eventBus) == null || M.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: _,
              change: S || "",
              willCommit: !1,
              selStart: x,
              selEnd: R
            }
          });
        }), this._setEventListeners(s, c, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (w) => w.target.value);
      }
      if (y && s.addEventListener("blur", y), this.data.comb) {
        const w = (this.data.rect[2] - this.data.rect[0]) / l;
        s.classList.add("comb"), s.style.letterSpacing = `calc(${w}px * var(--total-scale-factor) - 1ch)`;
      }
    } else
      s = document.createElement("div"), s.textContent = this.data.fieldValue, s.style.verticalAlign = "middle", s.style.display = "table-cell", this.data.hasOwnCanvas && (s.hidden = !0);
    return this._setTextStyle(s), this._setBackgroundColor(s), this._setDefaultPropertiesFromJS(s), this.container.append(s), this.container;
  }
}
class xA extends vo {
  constructor(t) {
    super(t, {
      isRenderable: !!t.data.hasOwnCanvas
    });
  }
}
class PA extends vo {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    const t = this.annotationStorage, e = this.data, s = e.id;
    let i = t.getValue(s, {
      value: e.exportValue === e.fieldValue
    }).value;
    typeof i == "string" && (i = i !== "Off", t.setValue(s, {
      value: i
    })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
    const r = document.createElement("input");
    return yo.add(r), r.setAttribute("data-element-id", s), r.disabled = e.readOnly, this._setRequired(r, this.data.required), r.type = "checkbox", r.name = e.fieldName, i && r.setAttribute("checked", !0), r.setAttribute("exportValue", e.exportValue), r.tabIndex = 0, r.addEventListener("change", (a) => {
      const {
        name: o,
        checked: l
      } = a.target;
      for (const h of this._getElementsByName(o, s)) {
        const c = l && h.exportValue === e.exportValue;
        h.domElement && (h.domElement.checked = c), t.setValue(h.id, {
          value: c
        });
      }
      t.setValue(s, {
        value: l
      });
    }), r.addEventListener("resetform", (a) => {
      const o = e.defaultFieldValue || "Off";
      a.target.checked = o === e.exportValue;
    }), this.enableScripting && this.hasJSActions && (r.addEventListener("updatefromsandbox", (a) => {
      const o = {
        value(l) {
          l.target.checked = l.detail.value !== "Off", t.setValue(s, {
            value: l.target.checked
          });
        }
      };
      this._dispatchEventFromSandbox(o, a);
    }), this._setEventListeners(r, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (a) => a.target.checked)), this._setBackgroundColor(r), this._setDefaultPropertiesFromJS(r), this.container.append(r), this.container;
  }
}
class Ob extends vo {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("buttonWidgetAnnotation", "radioButton");
    const t = this.annotationStorage, e = this.data, s = e.id;
    let i = t.getValue(s, {
      value: e.fieldValue === e.buttonValue
    }).value;
    if (typeof i == "string" && (i = i !== e.buttonValue, t.setValue(s, {
      value: i
    })), i)
      for (const a of this._getElementsByName(e.fieldName, s))
        t.setValue(a.id, {
          value: !1
        });
    const r = document.createElement("input");
    if (yo.add(r), r.setAttribute("data-element-id", s), r.disabled = e.readOnly, this._setRequired(r, this.data.required), r.type = "radio", r.name = e.fieldName, i && r.setAttribute("checked", !0), r.tabIndex = 0, r.addEventListener("change", (a) => {
      const {
        name: o,
        checked: l
      } = a.target;
      for (const h of this._getElementsByName(o, s))
        t.setValue(h.id, {
          value: !1
        });
      t.setValue(s, {
        value: l
      });
    }), r.addEventListener("resetform", (a) => {
      const o = e.defaultFieldValue;
      a.target.checked = o != null && o === e.buttonValue;
    }), this.enableScripting && this.hasJSActions) {
      const a = e.buttonValue;
      r.addEventListener("updatefromsandbox", (o) => {
        const l = {
          value: (h) => {
            const c = a === h.detail.value;
            for (const u of this._getElementsByName(h.target.name)) {
              const f = c && u.id === s;
              u.domElement && (u.domElement.checked = f), t.setValue(u.id, {
                value: f
              });
            }
          }
        };
        this._dispatchEventFromSandbox(l, o);
      }), this._setEventListeners(r, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (o) => o.target.checked);
    }
    return this._setBackgroundColor(r), this._setDefaultPropertiesFromJS(r), this.container.append(r), this.container;
  }
}
class RA extends Eg {
  constructor(t) {
    super(t, {
      ignoreBorder: t.data.hasAppearance
    });
  }
  render() {
    const t = super.render();
    t.classList.add("buttonWidgetAnnotation", "pushButton");
    const e = t.lastChild;
    return this.enableScripting && this.hasJSActions && e && (this._setDefaultPropertiesFromJS(e), e.addEventListener("updatefromsandbox", (s) => {
      this._dispatchEventFromSandbox({}, s);
    })), t;
  }
}
class MA extends vo {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("choiceWidgetAnnotation");
    const t = this.annotationStorage, e = this.data.id, s = t.getValue(e, {
      value: this.data.fieldValue
    }), i = document.createElement("select");
    yo.add(i), i.setAttribute("data-element-id", e), i.disabled = this.data.readOnly, this._setRequired(i, this.data.required), i.name = this.data.fieldName, i.tabIndex = 0;
    let r = this.data.combo && this.data.options.length > 0;
    this.data.combo || (i.size = this.data.options.length, this.data.multiSelect && (i.multiple = !0)), i.addEventListener("resetform", (c) => {
      const u = this.data.defaultFieldValue;
      for (const f of i.options)
        f.selected = f.value === u;
    });
    for (const c of this.data.options) {
      const u = document.createElement("option");
      u.textContent = c.displayValue, u.value = c.exportValue, s.value.includes(c.exportValue) && (u.setAttribute("selected", !0), r = !1), i.append(u);
    }
    let a = null;
    if (r) {
      const c = document.createElement("option");
      c.value = " ", c.setAttribute("hidden", !0), c.setAttribute("selected", !0), i.prepend(c), a = () => {
        c.remove(), i.removeEventListener("input", a), a = null;
      }, i.addEventListener("input", a);
    }
    const o = (c) => {
      const u = c ? "value" : "textContent", {
        options: f,
        multiple: m
      } = i;
      return m ? Array.prototype.filter.call(f, (A) => A.selected).map((A) => A[u]) : f.selectedIndex === -1 ? null : f[f.selectedIndex][u];
    };
    let l = o(!1);
    const h = (c) => {
      const u = c.target.options;
      return Array.prototype.map.call(u, (f) => ({
        displayValue: f.textContent,
        exportValue: f.value
      }));
    };
    return this.enableScripting && this.hasJSActions ? (i.addEventListener("updatefromsandbox", (c) => {
      const u = {
        value(f) {
          a == null || a();
          const m = f.detail.value, A = new Set(Array.isArray(m) ? m : [m]);
          for (const y of i.options)
            y.selected = A.has(y.value);
          t.setValue(e, {
            value: o(!0)
          }), l = o(!1);
        },
        multipleSelection(f) {
          i.multiple = !0;
        },
        remove(f) {
          const m = i.options, A = f.detail.remove;
          m[A].selected = !1, i.remove(A), m.length > 0 && Array.prototype.findIndex.call(m, (v) => v.selected) === -1 && (m[0].selected = !0), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        clear(f) {
          for (; i.length !== 0; )
            i.remove(0);
          t.setValue(e, {
            value: null,
            items: []
          }), l = o(!1);
        },
        insert(f) {
          const {
            index: m,
            displayValue: A,
            exportValue: y
          } = f.detail.insert, v = i.children[m], w = document.createElement("option");
          w.textContent = A, w.value = y, v ? v.before(w) : i.append(w), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        items(f) {
          const {
            items: m
          } = f.detail;
          for (; i.length !== 0; )
            i.remove(0);
          for (const A of m) {
            const {
              displayValue: y,
              exportValue: v
            } = A, w = document.createElement("option");
            w.textContent = y, w.value = v, i.append(w);
          }
          i.options.length > 0 && (i.options[0].selected = !0), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        indices(f) {
          const m = new Set(f.detail.indices);
          for (const A of f.target.options)
            A.selected = m.has(A.index);
          t.setValue(e, {
            value: o(!0)
          }), l = o(!1);
        },
        editable(f) {
          f.target.disabled = !f.detail.editable;
        }
      };
      this._dispatchEventFromSandbox(u, c);
    }), i.addEventListener("input", (c) => {
      var m;
      const u = o(!0), f = o(!1);
      t.setValue(e, {
        value: u
      }), c.preventDefault(), (m = this.linkService.eventBus) == null || m.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: e,
          name: "Keystroke",
          value: l,
          change: f,
          changeEx: u,
          willCommit: !1,
          commitKey: 1,
          keyDown: !1
        }
      });
    }), this._setEventListeners(i, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (c) => c.target.value)) : i.addEventListener("input", function(c) {
      t.setValue(e, {
        value: o(!0)
      });
    }), this.data.combo && this._setTextStyle(i), this._setBackgroundColor(i), this._setDefaultPropertiesFromJS(i), this.container.append(i), this.container;
  }
}
var nd, Pp;
class xp extends Gt {
  constructor(e) {
    const {
      data: s,
      elements: i,
      parent: r
    } = e, a = !!r._commentManager;
    super(e, {
      isRenderable: !a && Gt._hasPopupData(s)
    });
    g(this, nd);
    if (this.elements = i, a && Gt._hasPopupData(s)) {
      const o = this.popup = b(this, nd, Pp).call(this);
      for (const l of i)
        l.popup = o;
    } else
      this.popup = null;
  }
  render() {
    const {
      container: e
    } = this;
    e.classList.add("popupAnnotation"), e.role = "comment";
    const s = this.popup = b(this, nd, Pp).call(this), i = [];
    for (const r of this.elements)
      r.popup = s, r.container.ariaHasPopup = "dialog", i.push(r.data.id), r.addHighlightArea();
    return this.container.setAttribute("aria-controls", i.map((r) => `${pg}${r}`).join(",")), this.container;
  }
}
nd = new WeakSet(), Pp = function() {
  return new kA({
    container: this.container,
    color: this.data.color,
    titleObj: this.data.titleObj,
    modificationDate: this.data.modificationDate || this.data.creationDate,
    contentsObj: this.data.contentsObj,
    richText: this.data.richText,
    rect: this.data.rect,
    parentRect: this.data.parentRect || null,
    parent: this.parent,
    elements: this.elements,
    open: this.data.open,
    commentManager: this.parent._commentManager
  });
};
var Ts, Cr, rf, af, Nl, Ol, Yt, zi, Tr, Wa, Bl, Hl, Gi, xs, kn, Ln, be, Dn, xr, rd, In, Ul, Xa, Pr, ze, Rr, rt, gu, Rp, Mp, kp, mu, Lp, Bb, Hb, Ub, $b, bu, yu, Dp;
class kA {
  constructor({
    container: t,
    color: e,
    elements: s,
    titleObj: i,
    modificationDate: r,
    contentsObj: a,
    richText: o,
    parent: l,
    rect: h,
    parentRect: c,
    open: u,
    commentManager: f = null
  }) {
    g(this, rt);
    g(this, Ts, null);
    g(this, Cr, b(this, rt, Ub).bind(this));
    g(this, rf, b(this, rt, Dp).bind(this));
    g(this, af, b(this, rt, yu).bind(this));
    g(this, Nl, b(this, rt, bu).bind(this));
    g(this, Ol, null);
    g(this, Yt, null);
    g(this, zi, null);
    g(this, Tr, null);
    g(this, Wa, null);
    g(this, Bl, null);
    g(this, Hl, null);
    g(this, Gi, !1);
    g(this, xs, null);
    g(this, kn, null);
    g(this, Ln, null);
    g(this, be, null);
    g(this, Dn, null);
    g(this, xr, null);
    g(this, rd, null);
    g(this, In, null);
    g(this, Ul, null);
    g(this, Xa, null);
    g(this, Pr, !1);
    g(this, ze, null);
    g(this, Rr, null);
    p(this, Yt, t), p(this, Ul, i), p(this, zi, a), p(this, In, o), p(this, Bl, l), p(this, Ol, e), p(this, rd, h), p(this, Hl, c), p(this, Wa, s), p(this, Ts, f), p(this, ze, s[0]), p(this, Tr, Xh.toDateObject(r)), this.trigger = s.flatMap((m) => m.getElementsToTriggerPopup()), f ? this.renderCommentButton() : (b(this, rt, gu).call(this), n(this, Yt).hidden = !0, u && b(this, rt, bu).call(this));
  }
  renderCommentButton() {
    if (n(this, be) || (n(this, Dn) || b(this, rt, Rp).call(this), !n(this, Dn)))
      return;
    const {
      signal: t
    } = p(this, kn, new AbortController()), e = !!n(this, ze).extraPopupElement, s = () => {
      n(this, Ts).toggleCommentPopup(this, !0, void 0, !e);
    }, i = () => {
      n(this, Ts).toggleCommentPopup(this, !1, !0, !e);
    }, r = () => {
      n(this, Ts).toggleCommentPopup(this, !1, !1);
    };
    if (e) {
      p(this, be, n(this, ze).container);
      for (const a of this.trigger)
        a.ariaHasPopup = "dialog", a.ariaControls = "commentPopup", a.addEventListener("keydown", n(this, Cr), {
          signal: t
        }), a.addEventListener("click", s, {
          signal: t
        }), a.addEventListener("pointerenter", i, {
          signal: t
        }), a.addEventListener("pointerleave", r, {
          signal: t
        }), a.classList.add("popupTriggerArea");
    } else {
      const a = p(this, be, document.createElement("button"));
      a.className = "annotationCommentButton";
      const o = n(this, ze).container;
      a.style.zIndex = o.style.zIndex + 1, a.tabIndex = 0, a.ariaHasPopup = "dialog", a.ariaControls = "commentPopup", a.setAttribute("data-l10n-id", "pdfjs-show-comment-button"), b(this, rt, kp).call(this), b(this, rt, Mp).call(this), a.addEventListener("keydown", n(this, Cr), {
        signal: t
      }), a.addEventListener("click", s, {
        signal: t
      }), a.addEventListener("pointerenter", i, {
        signal: t
      }), a.addEventListener("pointerleave", r, {
        signal: t
      }), o.after(a);
    }
  }
  get commentButtonColor() {
    const {
      color: t,
      opacity: e
    } = n(this, ze).commentData;
    return t ? n(this, Bl)._commentManager.makeCommentColor(t, e) : null;
  }
  focusCommentButton() {
    setTimeout(() => {
      var t;
      (t = n(this, be)) == null || t.focus();
    }, 0);
  }
  getData() {
    const {
      richText: t,
      color: e,
      opacity: s,
      creationDate: i,
      modificationDate: r
    } = n(this, ze).commentData;
    return {
      contentsObj: {
        str: this.comment
      },
      richText: t,
      color: e,
      opacity: s,
      creationDate: i,
      modificationDate: r
    };
  }
  get elementBeforePopup() {
    return n(this, be);
  }
  get comment() {
    return n(this, Rr) || p(this, Rr, n(this, ze).commentText), n(this, Rr);
  }
  set comment(t) {
    t !== this.comment && (n(this, ze).commentText = p(this, Rr, t));
  }
  get parentBoundingClientRect() {
    return n(this, ze).layer.getBoundingClientRect();
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    n(this, be) && (n(this, be).classList.toggle("selected", t), n(this, be).ariaExpanded = e);
  }
  setSelectedCommentButton(t) {
    n(this, be).classList.toggle("selected", t);
  }
  get commentPopupPosition() {
    if (n(this, xr))
      return n(this, xr);
    const {
      x: t,
      y: e,
      height: s
    } = n(this, be).getBoundingClientRect(), {
      x: i,
      y: r,
      width: a,
      height: o
    } = n(this, ze).layer.getBoundingClientRect();
    return [(t - i) / a, (e + s - r) / o];
  }
  set commentPopupPosition(t) {
    p(this, xr, t);
  }
  hasDefaultPopupPosition() {
    return n(this, xr) === null;
  }
  get commentButtonPosition() {
    return n(this, Dn);
  }
  get commentButtonWidth() {
    return n(this, be).getBoundingClientRect().width / this.parentBoundingClientRect.width;
  }
  editComment(t) {
    const [e, s] = n(this, xr) || this.commentButtonPosition.map((h) => h / 100), i = this.parentBoundingClientRect, {
      x: r,
      y: a,
      width: o,
      height: l
    } = i;
    n(this, Ts).showDialog(null, this, r + e * o, a + s * l, {
      ...t,
      parentDimensions: i
    });
  }
  render() {
    var s, i;
    if (n(this, xs))
      return;
    const t = p(this, xs, document.createElement("div"));
    if (t.className = "popup", n(this, Ol)) {
      const r = t.style.outlineColor = V.makeHexColor(...n(this, Ol));
      t.style.backgroundColor = `color-mix(in srgb, ${r} 30%, white)`;
    }
    const e = document.createElement("span");
    if (e.className = "header", (s = n(this, Ul)) != null && s.str) {
      const r = document.createElement("span");
      r.className = "title", e.append(r), {
        dir: r.dir,
        str: r.textContent
      } = n(this, Ul);
    }
    if (t.append(e), n(this, Tr)) {
      const r = document.createElement("time");
      r.className = "popupDate", r.setAttribute("data-l10n-id", "pdfjs-annotation-date-time-string"), r.setAttribute("data-l10n-args", JSON.stringify({
        dateObj: n(this, Tr).valueOf()
      })), r.dateTime = n(this, Tr).toISOString(), e.append(r);
    }
    mg({
      html: n(this, rt, mu) || n(this, zi).str,
      dir: (i = n(this, zi)) == null ? void 0 : i.dir,
      className: "popupContent"
    }, t), n(this, Yt).append(t);
  }
  updateEdited({
    rect: t,
    popup: e,
    deleted: s
  }) {
    var i;
    if (n(this, Ts)) {
      s ? (this.remove(), p(this, Rr, null)) : e && (e.deleted ? this.remove() : (b(this, rt, kp).call(this), p(this, Rr, e.text))), t && (p(this, Dn, null), b(this, rt, Rp).call(this), b(this, rt, Mp).call(this));
      return;
    }
    if (s || e != null && e.deleted) {
      this.remove();
      return;
    }
    b(this, rt, gu).call(this), n(this, Xa) || p(this, Xa, {
      contentsObj: n(this, zi),
      richText: n(this, In)
    }), t && p(this, Ln, null), e && e.text && (p(this, In, b(this, rt, Hb).call(this, e.text)), p(this, Tr, Xh.toDateObject(e.date)), p(this, zi, null)), (i = n(this, xs)) == null || i.remove(), p(this, xs, null);
  }
  resetEdited() {
    var t;
    n(this, Xa) && ({
      contentsObj: oe(this, zi)._,
      richText: oe(this, In)._
    } = n(this, Xa), p(this, Xa, null), (t = n(this, xs)) == null || t.remove(), p(this, xs, null), p(this, Ln, null));
  }
  remove() {
    var t, e, s;
    if ((t = n(this, kn)) == null || t.abort(), p(this, kn, null), (e = n(this, xs)) == null || e.remove(), p(this, xs, null), p(this, Pr, !1), p(this, Gi, !1), (s = n(this, be)) == null || s.remove(), p(this, be, null), this.trigger)
      for (const i of this.trigger)
        i.classList.remove("popupTriggerArea");
  }
  forceHide() {
    p(this, Pr, this.isVisible), n(this, Pr) && (n(this, Yt).hidden = !0);
  }
  maybeShow() {
    n(this, Ts) || (b(this, rt, gu).call(this), n(this, Pr) && (n(this, xs) || b(this, rt, yu).call(this), p(this, Pr, !1), n(this, Yt).hidden = !1));
  }
  get isVisible() {
    return n(this, Ts) ? !1 : n(this, Yt).hidden === !1;
  }
}
Ts = new WeakMap(), Cr = new WeakMap(), rf = new WeakMap(), af = new WeakMap(), Nl = new WeakMap(), Ol = new WeakMap(), Yt = new WeakMap(), zi = new WeakMap(), Tr = new WeakMap(), Wa = new WeakMap(), Bl = new WeakMap(), Hl = new WeakMap(), Gi = new WeakMap(), xs = new WeakMap(), kn = new WeakMap(), Ln = new WeakMap(), be = new WeakMap(), Dn = new WeakMap(), xr = new WeakMap(), rd = new WeakMap(), In = new WeakMap(), Ul = new WeakMap(), Xa = new WeakMap(), Pr = new WeakMap(), ze = new WeakMap(), Rr = new WeakMap(), rt = new WeakSet(), gu = function() {
  var e;
  if (n(this, kn))
    return;
  p(this, kn, new AbortController());
  const {
    signal: t
  } = n(this, kn);
  for (const s of this.trigger)
    s.addEventListener("click", n(this, Nl), {
      signal: t
    }), s.addEventListener("pointerenter", n(this, af), {
      signal: t
    }), s.addEventListener("pointerleave", n(this, rf), {
      signal: t
    }), s.classList.add("popupTriggerArea");
  for (const s of n(this, Wa))
    (e = s.container) == null || e.addEventListener("keydown", n(this, Cr), {
      signal: t
    });
}, Rp = function() {
  const t = n(this, Wa).find((e) => e.hasCommentButton);
  t && p(this, Dn, t._normalizePoint(t.commentButtonPosition));
}, Mp = function() {
  if (n(this, ze).extraPopupElement && !n(this, ze).editor)
    return;
  this.renderCommentButton();
  const [t, e] = n(this, Dn), {
    style: s
  } = n(this, be);
  s.left = `calc(${t}%)`, s.top = `calc(${e}% - var(--comment-button-dim))`;
}, kp = function() {
  n(this, ze).extraPopupElement || (this.renderCommentButton(), n(this, be).style.backgroundColor = this.commentButtonColor || "");
}, mu = function() {
  const t = n(this, In), e = n(this, zi);
  return t != null && t.str && (!(e != null && e.str) || e.str === t.str) && n(this, In).html || null;
}, Lp = function() {
  var t, e, s;
  return ((s = (e = (t = n(this, rt, mu)) == null ? void 0 : t.attributes) == null ? void 0 : e.style) == null ? void 0 : s.fontSize) || 0;
}, Bb = function() {
  var t, e, s;
  return ((s = (e = (t = n(this, rt, mu)) == null ? void 0 : t.attributes) == null ? void 0 : e.style) == null ? void 0 : s.color) || null;
}, Hb = function(t) {
  const e = [], s = {
    str: t,
    html: {
      name: "div",
      attributes: {
        dir: "auto"
      },
      children: [{
        name: "p",
        children: e
      }]
    }
  }, i = {
    style: {
      color: n(this, rt, Bb),
      fontSize: n(this, rt, Lp) ? `calc(${n(this, rt, Lp)}px * var(--total-scale-factor))` : ""
    }
  };
  for (const r of t.split(`
`))
    e.push({
      name: "span",
      value: r,
      attributes: i
    });
  return s;
}, Ub = function(t) {
  t.altKey || t.shiftKey || t.ctrlKey || t.metaKey || (t.key === "Enter" || t.key === "Escape" && n(this, Gi)) && b(this, rt, bu).call(this);
}, $b = function() {
  if (n(this, Ln) !== null)
    return;
  const {
    page: {
      view: t
    },
    viewport: {
      rawDims: {
        pageWidth: e,
        pageHeight: s,
        pageX: i,
        pageY: r
      }
    }
  } = n(this, Bl);
  let a = !!n(this, Hl), o = a ? n(this, Hl) : n(this, rd);
  for (const A of n(this, Wa))
    if (!o || V.intersect(A.data.rect, o) !== null) {
      o = A.data.rect, a = !0;
      break;
    }
  const l = V.normalizeRect([o[0], t[3] - o[1] + t[1], o[2], t[3] - o[3] + t[1]]), c = a ? o[2] - o[0] + 5 : 0, u = l[0] + c, f = l[1];
  p(this, Ln, [100 * (u - i) / e, 100 * (f - r) / s]);
  const {
    style: m
  } = n(this, Yt);
  m.left = `${n(this, Ln)[0]}%`, m.top = `${n(this, Ln)[1]}%`;
}, bu = function() {
  if (n(this, Ts)) {
    n(this, Ts).toggleCommentPopup(this, !1);
    return;
  }
  p(this, Gi, !n(this, Gi)), n(this, Gi) ? (b(this, rt, yu).call(this), n(this, Yt).addEventListener("click", n(this, Nl)), n(this, Yt).addEventListener("keydown", n(this, Cr))) : (b(this, rt, Dp).call(this), n(this, Yt).removeEventListener("click", n(this, Nl)), n(this, Yt).removeEventListener("keydown", n(this, Cr)));
}, yu = function() {
  n(this, xs) || this.render(), this.isVisible ? n(this, Gi) && n(this, Yt).classList.add("focused") : (b(this, rt, $b).call(this), n(this, Yt).hidden = !1, n(this, Yt).style.zIndex = parseInt(n(this, Yt).style.zIndex) + 1e3);
}, Dp = function() {
  n(this, Yt).classList.remove("focused"), !(n(this, Gi) || !this.isVisible) && (n(this, Yt).hidden = !0, n(this, Yt).style.zIndex = parseInt(n(this, Yt).style.zIndex) - 1e3);
};
class Vb extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.textContent = t.data.textContent, this.textPosition = t.data.textPosition, this.annotationEditorType = Z.FREETEXT;
  }
  render() {
    if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
      const t = document.createElement("div");
      t.classList.add("annotationTextContent"), t.setAttribute("role", "comment");
      for (const e of this.textContent) {
        const s = document.createElement("span");
        s.textContent = e, t.append(s);
      }
      this.container.append(t);
    }
    return !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
  }
}
var ad;
class LA extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, ad, null);
  }
  render() {
    this.container.classList.add("lineAnnotation");
    const {
      data: e,
      width: s,
      height: i
    } = this, r = this.svgFactory.create(s, i, !0), a = p(this, ad, this.svgFactory.createElement("svg:line"));
    return a.setAttribute("x1", e.rect[2] - e.lineCoordinates[0]), a.setAttribute("y1", e.rect[3] - e.lineCoordinates[1]), a.setAttribute("x2", e.rect[2] - e.lineCoordinates[2]), a.setAttribute("y2", e.rect[3] - e.lineCoordinates[3]), a.setAttribute("stroke-width", e.borderStyle.width || 1), a.setAttribute("stroke", "transparent"), a.setAttribute("fill", "transparent"), r.append(a), this.container.append(r), !e.popupRef && this.hasPopupData && this._createPopup(), this.container;
  }
  getElementsToTriggerPopup() {
    return n(this, ad);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
ad = new WeakMap();
var od;
class DA extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, od, null);
  }
  render() {
    this.container.classList.add("squareAnnotation");
    const {
      data: e,
      width: s,
      height: i
    } = this, r = this.svgFactory.create(s, i, !0), a = e.borderStyle.width, o = p(this, od, this.svgFactory.createElement("svg:rect"));
    return o.setAttribute("x", a / 2), o.setAttribute("y", a / 2), o.setAttribute("width", s - a), o.setAttribute("height", i - a), o.setAttribute("stroke-width", a || 1), o.setAttribute("stroke", "transparent"), o.setAttribute("fill", "transparent"), r.append(o), this.container.append(r), !e.popupRef && this.hasPopupData && this._createPopup(), this.container;
  }
  getElementsToTriggerPopup() {
    return n(this, od);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
od = new WeakMap();
var ld;
class IA extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, ld, null);
  }
  render() {
    this.container.classList.add("circleAnnotation");
    const {
      data: e,
      width: s,
      height: i
    } = this, r = this.svgFactory.create(s, i, !0), a = e.borderStyle.width, o = p(this, ld, this.svgFactory.createElement("svg:ellipse"));
    return o.setAttribute("cx", s / 2), o.setAttribute("cy", i / 2), o.setAttribute("rx", s / 2 - a / 2), o.setAttribute("ry", i / 2 - a / 2), o.setAttribute("stroke-width", a || 1), o.setAttribute("stroke", "transparent"), o.setAttribute("fill", "transparent"), r.append(o), this.container.append(r), !e.popupRef && this.hasPopupData && this._createPopup(), this.container;
  }
  getElementsToTriggerPopup() {
    return n(this, ld);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
ld = new WeakMap();
var hd;
class zb extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, hd, null);
    this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: e,
        vertices: s,
        borderStyle: i,
        popupRef: r
      },
      width: a,
      height: o
    } = this;
    if (!s)
      return this.container;
    const l = this.svgFactory.create(a, o, !0);
    let h = [];
    for (let u = 0, f = s.length; u < f; u += 2) {
      const m = s[u] - e[0], A = e[3] - s[u + 1];
      h.push(`${m},${A}`);
    }
    h = h.join(" ");
    const c = p(this, hd, this.svgFactory.createElement(this.svgElementName));
    return c.setAttribute("points", h), c.setAttribute("stroke-width", i.width || 1), c.setAttribute("stroke", "transparent"), c.setAttribute("fill", "transparent"), l.append(c), this.container.append(l), !r && this.hasPopupData && this._createPopup(), this.container;
  }
  getElementsToTriggerPopup() {
    return n(this, hd);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
hd = new WeakMap();
class FA extends zb {
  constructor(t) {
    super(t), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
  }
}
class NA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
  }
}
var cd, qa, dd, Ip;
class Sg extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, dd);
    g(this, cd, null);
    g(this, qa, []);
    this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = this.data.it === "InkHighlight" ? Z.HIGHLIGHT : Z.INK;
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: e,
        rotation: s,
        inkLists: i,
        borderStyle: r,
        popupRef: a
      }
    } = this, {
      transform: o,
      width: l,
      height: h
    } = b(this, dd, Ip).call(this, s, e), c = this.svgFactory.create(l, h, !0), u = p(this, cd, this.svgFactory.createElement("svg:g"));
    c.append(u), u.setAttribute("stroke-width", r.width || 1), u.setAttribute("stroke-linecap", "round"), u.setAttribute("stroke-linejoin", "round"), u.setAttribute("stroke-miterlimit", 10), u.setAttribute("stroke", "transparent"), u.setAttribute("fill", "transparent"), u.setAttribute("transform", o);
    for (let f = 0, m = i.length; f < m; f++) {
      const A = this.svgFactory.createElement(this.svgElementName);
      n(this, qa).push(A), A.setAttribute("points", i[f].join(",")), u.append(A);
    }
    return !a && this.hasPopupData && this._createPopup(), this.container.append(c), this._editOnDoubleClick(), this.container;
  }
  updateEdited(e) {
    super.updateEdited(e);
    const {
      thickness: s,
      points: i,
      rect: r
    } = e, a = n(this, cd);
    if (s >= 0 && a.setAttribute("stroke-width", s || 1), i)
      for (let o = 0, l = n(this, qa).length; o < l; o++)
        n(this, qa)[o].setAttribute("points", i[o].join(","));
    if (r) {
      const {
        transform: o,
        width: l,
        height: h
      } = b(this, dd, Ip).call(this, this.data.rotation, r);
      a.parentElement.setAttribute("viewBox", `0 0 ${l} ${h}`), a.setAttribute("transform", o);
    }
  }
  getElementsToTriggerPopup() {
    return n(this, qa);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
cd = new WeakMap(), qa = new WeakMap(), dd = new WeakSet(), Ip = function(e, s) {
  switch (e) {
    case 90:
      return {
        transform: `rotate(90) translate(${-s[0]},${s[1]}) scale(1,-1)`,
        width: s[3] - s[1],
        height: s[2] - s[0]
      };
    case 180:
      return {
        transform: `rotate(180) translate(${-s[2]},${s[1]}) scale(1,-1)`,
        width: s[2] - s[0],
        height: s[3] - s[1]
      };
    case 270:
      return {
        transform: `rotate(270) translate(${-s[2]},${s[3]}) scale(1,-1)`,
        width: s[3] - s[1],
        height: s[2] - s[0]
      };
    default:
      return {
        transform: `translate(${-s[0]},${s[3]}) scale(1,-1)`,
        width: s[2] - s[0],
        height: s[3] - s[1]
      };
  }
};
class Gb extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    }), this.annotationEditorType = Z.HIGHLIGHT;
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && this._createPopup(), this.container.classList.add("highlightAnnotation"), this._editOnDoubleClick(), t) {
      const s = document.createElement("mark");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class OA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && this._createPopup(), this.container.classList.add("underlineAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class BA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && this._createPopup(), this.container.classList.add("squigglyAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class HA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && this._createPopup(), this.container.classList.add("strikeoutAnnotation"), t) {
      const s = document.createElement("s");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class jb extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.annotationEditorType = Z.STAMP;
  }
  render() {
    return this.container.classList.add("stampAnnotation"), this.container.setAttribute("role", "img"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
  }
}
var ud, fd, Fp;
class UA extends Gt {
  constructor(e) {
    var i;
    super(e, {
      isRenderable: !0
    });
    g(this, fd);
    g(this, ud, null);
    const {
      file: s
    } = this.data;
    this.filename = s.filename, this.content = s.content, (i = this.linkService.eventBus) == null || i.dispatch("fileattachmentannotation", {
      source: this,
      ...s
    });
  }
  render() {
    this.container.classList.add("fileAttachmentAnnotation");
    const {
      container: e,
      data: s
    } = this;
    let i;
    s.hasAppearance || s.fillAlpha === 0 ? i = document.createElement("div") : (i = document.createElement("img"), i.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(s.name) ? "paperclip" : "pushpin"}.svg`, s.fillAlpha && s.fillAlpha < 1 && (i.style = `filter: opacity(${Math.round(s.fillAlpha * 100)}%);`)), i.addEventListener("dblclick", b(this, fd, Fp).bind(this)), p(this, ud, i);
    const {
      isMac: r
    } = _e.platform;
    return e.addEventListener("keydown", (a) => {
      a.key === "Enter" && (r ? a.metaKey : a.ctrlKey) && b(this, fd, Fp).call(this);
    }), !s.popupRef && this.hasPopupData ? this._createPopup() : i.classList.add("popupTriggerArea"), e.append(i), e;
  }
  getElementsToTriggerPopup() {
    return n(this, ud);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
ud = new WeakMap(), fd = new WeakSet(), Fp = function() {
  var e;
  (e = this.downloadManager) == null || e.openOrDownloadData(this.content, this.filename);
};
var $l, Ya, Vl, Mr, pd, Ka, qr, Np, Op, zl;
let _g = (zl = class {
  constructor({
    div: t,
    accessibilityManager: e,
    annotationCanvasMap: s,
    annotationEditorUIManager: i,
    page: r,
    viewport: a,
    structTreeLayer: o,
    commentManager: l,
    linkService: h,
    annotationStorage: c
  }) {
    g(this, qr);
    g(this, $l, null);
    g(this, Ya, null);
    g(this, Vl, null);
    g(this, Mr, /* @__PURE__ */ new Map());
    g(this, pd, null);
    g(this, Ka, null);
    this.div = t, p(this, $l, e), p(this, Ya, s), p(this, pd, o || null), p(this, Ka, h || null), p(this, Vl, c || new bg()), this.page = r, this.viewport = a, this.zIndex = 0, this._annotationEditorUIManager = i, this._commentManager = l || null;
  }
  hasEditableAnnotations() {
    return n(this, Mr).size > 0;
  }
  async render(t) {
    var a, o, l;
    const {
      annotations: e
    } = t, s = this.div;
    jr(s, this.viewport);
    const i = /* @__PURE__ */ new Map(), r = {
      data: null,
      layer: s,
      linkService: n(this, Ka),
      downloadManager: t.downloadManager,
      imageResourcesPath: t.imageResourcesPath || "",
      renderForms: t.renderForms !== !1,
      svgFactory: new Jh(),
      annotationStorage: n(this, Vl),
      enableComment: t.enableComment === !0,
      enableScripting: t.enableScripting === !0,
      hasJSActions: t.hasJSActions,
      fieldObjects: t.fieldObjects,
      parent: this,
      elements: null
    };
    for (const h of e) {
      if (h.noHTML)
        continue;
      const c = h.annotationType === te.POPUP;
      if (c) {
        const m = i.get(h.id);
        if (!m)
          continue;
        r.elements = m;
      } else if (h.rect[2] === h.rect[0] || h.rect[3] === h.rect[1])
        continue;
      r.data = h;
      const u = am.create(r);
      if (!u.isRenderable)
        continue;
      if (!c && h.popupRef) {
        const m = i.get(h.popupRef);
        m ? m.push(u) : i.set(h.popupRef, [u]);
      }
      const f = u.render();
      h.hidden && (f.style.visibility = "hidden"), await b(this, qr, Np).call(this, f, h.id, r.elements), (o = (a = u.extraPopupElement) == null ? void 0 : a.popup) == null || o.renderCommentButton(), u._isEditable && (n(this, Mr).set(u.data.id, u), (l = this._annotationEditorUIManager) == null || l.renderAnnotationElement(u));
    }
    b(this, qr, Op).call(this);
  }
  async addLinkAnnotations(t) {
    const e = {
      data: null,
      layer: this.div,
      linkService: n(this, Ka),
      svgFactory: new Jh(),
      parent: this
    };
    for (const s of t) {
      s.borderStyle || (s.borderStyle = zl._defaultBorderStyle), e.data = s;
      const i = am.create(e);
      if (!i.isRenderable)
        continue;
      const r = i.render();
      await b(this, qr, Np).call(this, r, s.id, null);
    }
  }
  update({
    viewport: t
  }) {
    const e = this.div;
    this.viewport = t, jr(e, {
      rotation: t.rotation
    }), b(this, qr, Op).call(this), e.hidden = !1;
  }
  getEditableAnnotations() {
    return Array.from(n(this, Mr).values());
  }
  getEditableAnnotation(t) {
    return n(this, Mr).get(t);
  }
  addFakeAnnotation(t) {
    var o;
    const {
      div: e
    } = this, {
      id: s,
      rotation: i
    } = t, r = new _A({
      data: {
        id: s,
        rect: t.getPDFRect(),
        rotation: i
      },
      editor: t,
      layer: e,
      parent: this,
      enableComment: !!this._commentManager,
      linkService: n(this, Ka),
      annotationStorage: n(this, Vl)
    }), a = r.render();
    return e.append(a), (o = n(this, $l)) == null || o.moveElementInDOM(e, a, a, !1), r.createOrUpdatePopup(), r;
  }
  static get _defaultBorderStyle() {
    return it(this, "_defaultBorderStyle", Object.freeze({
      width: 1,
      rawWidth: 1,
      style: So.SOLID,
      dashArray: [3],
      horizontalCornerRadius: 0,
      verticalCornerRadius: 0
    }));
  }
}, $l = new WeakMap(), Ya = new WeakMap(), Vl = new WeakMap(), Mr = new WeakMap(), pd = new WeakMap(), Ka = new WeakMap(), qr = new WeakSet(), Np = async function(t, e, s) {
  var o, l;
  const i = t.firstChild || t, r = i.id = `${pg}${e}`, a = await ((o = n(this, pd)) == null ? void 0 : o.getAriaAttributes(r));
  if (a)
    for (const [h, c] of a)
      i.setAttribute(h, c);
  s ? s.at(-1).container.after(t) : (this.div.append(t), (l = n(this, $l)) == null || l.moveElementInDOM(this.div, t, i, !1));
}, Op = function() {
  var e;
  if (!n(this, Ya))
    return;
  const t = this.div;
  for (const [s, i] of n(this, Ya)) {
    const r = t.querySelector(`[data-annotation-id="${s}"]`);
    if (!r)
      continue;
    i.className = "annotationContent";
    const {
      firstChild: a
    } = r;
    a ? a.nodeName === "CANVAS" ? a.replaceWith(i) : a.classList.contains("annotationContent") ? a.after(i) : a.before(i) : r.append(i);
    const o = n(this, Mr).get(s);
    o && (o._hasNoCanvas ? ((e = this._annotationEditorUIManager) == null || e.setMissingCanvas(s, r.id, i), o._hasNoCanvas = !1) : o.canvas = i);
  }
  n(this, Ya).clear();
}, zl);
const tu = /\r\n?|\n/g;
var Ps, gd, Za, Rs, ae, Wb, Xb, qb, Au, zn, wu, vu, Yb, Hp, Kb;
const Ot = class Ot extends Ft {
  constructor(e) {
    super({
      ...e,
      name: "freeTextEditor"
    });
    g(this, ae);
    g(this, Ps, "");
    g(this, gd, `${this.id}-editor`);
    g(this, Za, null);
    g(this, Rs);
    L(this, "_colorPicker", null);
    this.color = e.color || Ot._defaultColor || Ft._defaultLineColor, p(this, Rs, e.fontSize || Ot._defaultFontSize), this.annotationElementId || this._uiManager.a11yAlert("pdfjs-editor-freetext-added-alert");
  }
  static get _keyboardManager() {
    const e = Ot.prototype, s = (a) => a.isEmpty(), i = Wr.TRANSLATE_SMALL, r = Wr.TRANSLATE_BIG;
    return it(this, "_keyboardManager", new Od([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], e.commitOrRemove, {
      bubbles: !0
    }], [["ctrl+Enter", "mac+meta+Enter", "Escape", "mac+Escape"], e.commitOrRemove], [["ArrowLeft", "mac+ArrowLeft"], e._translateEmpty, {
      args: [-i, 0],
      checker: s
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], e._translateEmpty, {
      args: [-r, 0],
      checker: s
    }], [["ArrowRight", "mac+ArrowRight"], e._translateEmpty, {
      args: [i, 0],
      checker: s
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], e._translateEmpty, {
      args: [r, 0],
      checker: s
    }], [["ArrowUp", "mac+ArrowUp"], e._translateEmpty, {
      args: [0, -i],
      checker: s
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], e._translateEmpty, {
      args: [0, -r],
      checker: s
    }], [["ArrowDown", "mac+ArrowDown"], e._translateEmpty, {
      args: [0, i],
      checker: s
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], e._translateEmpty, {
      args: [0, r],
      checker: s
    }]]));
  }
  static initialize(e, s) {
    Ft.initialize(e, s);
    const i = getComputedStyle(document.documentElement);
    this._internalPadding = parseFloat(i.getPropertyValue("--freetext-padding"));
  }
  static updateDefaultParams(e, s) {
    switch (e) {
      case ht.FREETEXT_SIZE:
        Ot._defaultFontSize = s;
        break;
      case ht.FREETEXT_COLOR:
        Ot._defaultColor = s;
        break;
    }
  }
  updateParams(e, s) {
    switch (e) {
      case ht.FREETEXT_SIZE:
        b(this, ae, Wb).call(this, s);
        break;
      case ht.FREETEXT_COLOR:
        b(this, ae, Xb).call(this, s);
        break;
    }
  }
  static get defaultPropertiesToUpdate() {
    return [[ht.FREETEXT_SIZE, Ot._defaultFontSize], [ht.FREETEXT_COLOR, Ot._defaultColor || Ft._defaultLineColor]];
  }
  get propertiesToUpdate() {
    return [[ht.FREETEXT_SIZE, n(this, Rs)], [ht.FREETEXT_COLOR, this.color]];
  }
  get toolbarButtons() {
    return this._colorPicker || (this._colorPicker = new Uu(this)), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return ht.FREETEXT_COLOR;
  }
  onUpdatedColor() {
    var e;
    this.editorDiv.style.color = this.color, (e = this._colorPicker) == null || e.update(this.color), super.onUpdatedColor();
  }
  _translateEmpty(e, s) {
    this._uiManager.translateSelectedEditors(e, s, !0);
  }
  getInitialTranslation() {
    const e = this.parentScale;
    return [-Ot._internalPadding * e, -(Ot._internalPadding + n(this, Rs)) * e];
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
  }
  enableEditMode() {
    if (!super.enableEditMode())
      return !1;
    this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), p(this, Za, new AbortController());
    const e = this._uiManager.combinedSignal(n(this, Za));
    return this.editorDiv.addEventListener("keydown", this.editorDivKeydown.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("focus", this.editorDivFocus.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("blur", this.editorDivBlur.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("input", this.editorDivInput.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("paste", this.editorDivPaste.bind(this), {
      signal: e
    }), !0;
  }
  disableEditMode() {
    var e;
    return super.disableEditMode() ? (this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", n(this, gd)), this._isDraggable = !0, (e = n(this, Za)) == null || e.abort(), p(this, Za, null), this.div.focus({
      preventScroll: !0
    }), this.isEditing = !1, this.parent.div.classList.add("freetextEditing"), !0) : !1;
  }
  focusin(e) {
    this._focusEventsAllowed && (super.focusin(e), e.target !== this.editorDiv && this.editorDiv.focus());
  }
  onceAdded(e) {
    var s;
    this.width || (this.enableEditMode(), e && this.editorDiv.focus(), (s = this._initialOptions) != null && s.isCentered && this.center(), this._initialOptions = null);
  }
  isEmpty() {
    return !this.editorDiv || this.editorDiv.innerText.trim() === "";
  }
  remove() {
    this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freetextEditing")), super.remove();
  }
  commit() {
    if (!this.isInEditMode())
      return;
    super.commit(), this.disableEditMode();
    const e = n(this, Ps), s = p(this, Ps, b(this, ae, qb).call(this).trimEnd());
    if (e === s)
      return;
    const i = (r) => {
      if (p(this, Ps, r), !r) {
        this.remove();
        return;
      }
      b(this, ae, vu).call(this), this._uiManager.rebuild(this), b(this, ae, Au).call(this);
    };
    this.addCommands({
      cmd: () => {
        i(s);
      },
      undo: () => {
        i(e);
      },
      mustExec: !1
    }), b(this, ae, Au).call(this);
  }
  shouldGetKeyboardEvents() {
    return this.isInEditMode();
  }
  enterInEditMode() {
    this.enableEditMode(), this.editorDiv.focus();
  }
  keydown(e) {
    e.target === this.div && e.key === "Enter" && (this.enterInEditMode(), e.preventDefault());
  }
  editorDivKeydown(e) {
    Ot._keyboardManager.exec(this, e);
  }
  editorDivFocus(e) {
    this.isEditing = !0;
  }
  editorDivBlur(e) {
    this.isEditing = !1;
  }
  editorDivInput(e) {
    this.parent.div.classList.toggle("freetextEditing", this.isEmpty());
  }
  disableEditing() {
    this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
  }
  enableEditing() {
    this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
  }
  get canChangeContent() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let e, s;
    (this._isCopy || this.annotationElementId) && (e = this.x, s = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", n(this, gd)), this.editorDiv.setAttribute("data-l10n-id", "pdfjs-free-text2"), this.editorDiv.setAttribute("data-l10n-attrs", "default-content"), this.enableEditing(), this.editorDiv.contentEditable = !0;
    const {
      style: i
    } = this.editorDiv;
    if (i.fontSize = `calc(${n(this, Rs)}px * var(--total-scale-factor))`, i.color = this.color, this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), this._isCopy || this.annotationElementId) {
      const [r, a] = this.parentDimensions;
      if (this.annotationElementId) {
        const {
          position: o
        } = this._initialData;
        let [l, h] = this.getInitialTranslation();
        [l, h] = this.pageTranslationToScreen(l, h);
        const [c, u] = this.pageDimensions, [f, m] = this.pageTranslation;
        let A, y;
        switch (this.rotation) {
          case 0:
            A = e + (o[0] - f) / c, y = s + this.height - (o[1] - m) / u;
            break;
          case 90:
            A = e + (o[0] - f) / c, y = s - (o[1] - m) / u, [l, h] = [h, -l];
            break;
          case 180:
            A = e - this.width + (o[0] - f) / c, y = s - (o[1] - m) / u, [l, h] = [-l, -h];
            break;
          case 270:
            A = e + (o[0] - f - this.height * u) / c, y = s + (o[1] - m - this.width * c) / u, [l, h] = [-h, l];
            break;
        }
        this.setAt(A * r, y * a, l, h);
      } else
        this._moveAfterPaste(e, s);
      b(this, ae, vu).call(this), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
    } else
      this._isDraggable = !1, this.editorDiv.contentEditable = !0;
    return this.div;
  }
  editorDivPaste(e) {
    var A, y, v;
    const s = e.clipboardData || window.clipboardData, {
      types: i
    } = s;
    if (i.length === 1 && i[0] === "text/plain")
      return;
    e.preventDefault();
    const r = b(A = Ot, zn, Hp).call(A, s.getData("text") || "").replaceAll(tu, `
`);
    if (!r)
      return;
    const a = window.getSelection();
    if (!a.rangeCount)
      return;
    this.editorDiv.normalize(), a.deleteFromDocument();
    const o = a.getRangeAt(0);
    if (!r.includes(`
`)) {
      o.insertNode(document.createTextNode(r)), this.editorDiv.normalize(), a.collapseToStart();
      return;
    }
    const {
      startContainer: l,
      startOffset: h
    } = o, c = [], u = [];
    if (l.nodeType === Node.TEXT_NODE) {
      const w = l.parentElement;
      if (u.push(l.nodeValue.slice(h).replaceAll(tu, "")), w !== this.editorDiv) {
        let S = c;
        for (const E of this.editorDiv.childNodes) {
          if (E === w) {
            S = u;
            continue;
          }
          S.push(b(y = Ot, zn, wu).call(y, E));
        }
      }
      c.push(l.nodeValue.slice(0, h).replaceAll(tu, ""));
    } else if (l === this.editorDiv) {
      let w = c, S = 0;
      for (const E of this.editorDiv.childNodes)
        S++ === h && (w = u), w.push(b(v = Ot, zn, wu).call(v, E));
    }
    p(this, Ps, `${c.join(`
`)}${r}${u.join(`
`)}`), b(this, ae, vu).call(this);
    const f = new Range();
    let m = Math.sumPrecise(c.map((w) => w.length));
    for (const {
      firstChild: w
    } of this.editorDiv.childNodes)
      if (w.nodeType === Node.TEXT_NODE) {
        const S = w.nodeValue.length;
        if (m <= S) {
          f.setStart(w, m), f.setEnd(w, m);
          break;
        }
        m -= S;
      }
    a.removeAllRanges(), a.addRange(f);
  }
  get contentDiv() {
    return this.editorDiv;
  }
  getPDFRect() {
    const e = Ot._internalPadding * this.parentScale;
    return this.getRect(e, e);
  }
  static async deserialize(e, s, i) {
    var o;
    let r = null;
    if (e instanceof Vb) {
      const {
        data: {
          defaultAppearanceData: {
            fontSize: l,
            fontColor: h
          },
          rect: c,
          rotation: u,
          id: f,
          popupRef: m,
          richText: A,
          contentsObj: y,
          creationDate: v,
          modificationDate: w
        },
        textContent: S,
        textPosition: E,
        parent: {
          page: {
            pageNumber: _
          }
        }
      } = e;
      if (!S || S.length === 0)
        return null;
      r = e = {
        annotationType: Z.FREETEXT,
        color: Array.from(h),
        fontSize: l,
        value: S.join(`
`),
        position: E,
        pageIndex: _ - 1,
        rect: c.slice(0),
        rotation: u,
        annotationElementId: f,
        id: f,
        deleted: !1,
        popupRef: m,
        comment: (y == null ? void 0 : y.str) || null,
        richText: A,
        creationDate: v,
        modificationDate: w
      };
    }
    const a = await super.deserialize(e, s, i);
    return p(a, Rs, e.fontSize), a.color = V.makeHexColor(...e.color), p(a, Ps, b(o = Ot, zn, Hp).call(o, e.value)), a._initialData = r, e.comment && a.setCommentData(e), a;
  }
  serialize(e = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const s = Ft._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : this.color), i = Object.assign(super.serialize(e), {
      color: s,
      fontSize: n(this, Rs),
      value: b(this, ae, Yb).call(this)
    });
    return this.addComment(i), e ? (i.isCopy = !0, i) : this.annotationElementId && !b(this, ae, Kb).call(this, i) ? null : (i.id = this.annotationElementId, i);
  }
  renderAnnotationElement(e) {
    const s = super.renderAnnotationElement(e);
    if (!s)
      return null;
    const {
      style: i
    } = s;
    i.fontSize = `calc(${n(this, Rs)}px * var(--total-scale-factor))`, i.color = this.color, s.replaceChildren();
    for (const r of n(this, Ps).split(`
`)) {
      const a = document.createElement("div");
      a.append(r ? document.createTextNode(r) : document.createElement("br")), s.append(a);
    }
    return e.updateEdited({
      rect: this.getPDFRect(),
      popup: this._uiManager.hasCommentManager() || this.hasEditedComment ? this.comment : {
        text: n(this, Ps)
      }
    }), s;
  }
  resetAnnotationElement(e) {
    super.resetAnnotationElement(e), e.resetEdited();
  }
};
Ps = new WeakMap(), gd = new WeakMap(), Za = new WeakMap(), Rs = new WeakMap(), ae = new WeakSet(), Wb = function(e) {
  const s = (r) => {
    this.editorDiv.style.fontSize = `calc(${r}px * var(--total-scale-factor))`, this.translate(0, -(r - n(this, Rs)) * this.parentScale), p(this, Rs, r), b(this, ae, Au).call(this);
  }, i = n(this, Rs);
  this.addCommands({
    cmd: s.bind(this, e),
    undo: s.bind(this, i),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: ht.FREETEXT_SIZE,
    overwriteIfSameType: !0,
    keepUndo: !0
  });
}, Xb = function(e) {
  const s = (r) => {
    this.color = r, this.onUpdatedColor();
  }, i = this.color;
  this.addCommands({
    cmd: s.bind(this, e),
    undo: s.bind(this, i),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: ht.FREETEXT_COLOR,
    overwriteIfSameType: !0,
    keepUndo: !0
  });
}, qb = function() {
  var i;
  const e = [];
  this.editorDiv.normalize();
  let s = null;
  for (const r of this.editorDiv.childNodes)
    (s == null ? void 0 : s.nodeType) === Node.TEXT_NODE && r.nodeName === "BR" || (e.push(b(i = Ot, zn, wu).call(i, r)), s = r);
  return e.join(`
`);
}, Au = function() {
  const [e, s] = this.parentDimensions;
  let i;
  if (this.isAttachedToDOM)
    i = this.div.getBoundingClientRect();
  else {
    const {
      currentLayer: r,
      div: a
    } = this, o = a.style.display, l = a.classList.contains("hidden");
    a.classList.remove("hidden"), a.style.display = "hidden", r.div.append(this.div), i = a.getBoundingClientRect(), a.remove(), a.style.display = o, a.classList.toggle("hidden", l);
  }
  this.rotation % 180 === this.parentRotation % 180 ? (this.width = i.width / e, this.height = i.height / s) : (this.width = i.height / e, this.height = i.width / s), this.fixAndSetPosition();
}, zn = new WeakSet(), wu = function(e) {
  return (e.nodeType === Node.TEXT_NODE ? e.nodeValue : e.innerText).replaceAll(tu, "");
}, vu = function() {
  if (this.editorDiv.replaceChildren(), !!n(this, Ps))
    for (const e of n(this, Ps).split(`
`)) {
      const s = document.createElement("div");
      s.append(e ? document.createTextNode(e) : document.createElement("br")), this.editorDiv.append(s);
    }
}, Yb = function() {
  return n(this, Ps).replaceAll(" ", " ");
}, Hp = function(e) {
  return e.replaceAll(" ", " ");
}, Kb = function(e) {
  const {
    value: s,
    fontSize: i,
    color: r,
    pageIndex: a
  } = this._initialData;
  return this.hasEditedComment || this._hasBeenMoved || e.value !== s || e.fontSize !== i || e.color.some((o, l) => o !== r[l]) || e.pageIndex !== a;
}, g(Ot, zn), L(Ot, "_freeTextDefaultContent", ""), L(Ot, "_internalPadding", 0), L(Ot, "_defaultColor", null), L(Ot, "_defaultFontSize", 10), L(Ot, "_type", "freetext"), L(Ot, "_editorType", Z.FREETEXT);
let Bp = Ot;
class $ {
  toSVGPath() {
    Dt("Abstract method `toSVGPath` must be implemented.");
  }
  get box() {
    Dt("Abstract getter `box` must be implemented.");
  }
  serialize(t, e) {
    Dt("Abstract method `serialize` must be implemented.");
  }
  static _rescale(t, e, s, i, r, a) {
    a || (a = new Float32Array(t.length));
    for (let o = 0, l = t.length; o < l; o += 2)
      a[o] = e + t[o] * i, a[o + 1] = s + t[o + 1] * r;
    return a;
  }
  static _rescaleAndSwap(t, e, s, i, r, a) {
    a || (a = new Float32Array(t.length));
    for (let o = 0, l = t.length; o < l; o += 2)
      a[o] = e + t[o + 1] * i, a[o + 1] = s + t[o] * r;
    return a;
  }
  static _translate(t, e, s, i) {
    i || (i = new Float32Array(t.length));
    for (let r = 0, a = t.length; r < a; r += 2)
      i[r] = e + t[r], i[r + 1] = s + t[r + 1];
    return i;
  }
  static svgRound(t) {
    return Math.round(t * 1e4);
  }
  static _normalizePoint(t, e, s, i, r) {
    switch (r) {
      case 90:
        return [1 - e / s, t / i];
      case 180:
        return [1 - t / s, 1 - e / i];
      case 270:
        return [e / s, 1 - t / i];
      default:
        return [t / s, e / i];
    }
  }
  static _normalizePagePoint(t, e, s) {
    switch (s) {
      case 90:
        return [1 - e, t];
      case 180:
        return [1 - t, 1 - e];
      case 270:
        return [e, 1 - t];
      default:
        return [t, e];
    }
  }
  static createBezierPoints(t, e, s, i, r, a) {
    return [(t + 5 * s) / 6, (e + 5 * i) / 6, (5 * s + r) / 6, (5 * i + a) / 6, (s + r) / 2, (i + a) / 2];
  }
}
L($, "PRECISION", 1e-4);
var Ms, bi, Gl, jl, ji, ot, Ja, Qa, md, bd, Wl, Xl, kr, yd, of, lf, ue, Bh, Zb, Jb, Qb, t0, e0, s0;
const on = class on {
  constructor({
    x: t,
    y: e
  }, s, i, r, a, o = 0) {
    g(this, ue);
    g(this, Ms);
    g(this, bi, []);
    g(this, Gl);
    g(this, jl);
    g(this, ji, []);
    g(this, ot, new Float32Array(18));
    g(this, Ja);
    g(this, Qa);
    g(this, md);
    g(this, bd);
    g(this, Wl);
    g(this, Xl);
    g(this, kr, []);
    p(this, Ms, s), p(this, Xl, r * i), p(this, jl, a), n(this, ot).set([NaN, NaN, NaN, NaN, t, e], 6), p(this, Gl, o), p(this, bd, n(on, yd) * i), p(this, md, n(on, lf) * i), p(this, Wl, i), n(this, kr).push(t, e);
  }
  isEmpty() {
    return isNaN(n(this, ot)[8]);
  }
  add({
    x: t,
    y: e
  }) {
    var M;
    p(this, Ja, t), p(this, Qa, e);
    const [s, i, r, a] = n(this, Ms);
    let [o, l, h, c] = n(this, ot).subarray(8, 12);
    const u = t - h, f = e - c, m = Math.hypot(u, f);
    if (m < n(this, md))
      return !1;
    const A = m - n(this, bd), y = A / m, v = y * u, w = y * f;
    let S = o, E = l;
    o = h, l = c, h += v, c += w, (M = n(this, kr)) == null || M.push(t, e);
    const _ = -w / A, C = v / A, T = _ * n(this, Xl), x = C * n(this, Xl);
    return n(this, ot).set(n(this, ot).subarray(2, 8), 0), n(this, ot).set([h + T, c + x], 4), n(this, ot).set(n(this, ot).subarray(14, 18), 12), n(this, ot).set([h - T, c - x], 16), isNaN(n(this, ot)[6]) ? (n(this, ji).length === 0 && (n(this, ot).set([o + T, l + x], 2), n(this, ji).push(NaN, NaN, NaN, NaN, (o + T - s) / r, (l + x - i) / a), n(this, ot).set([o - T, l - x], 14), n(this, bi).push(NaN, NaN, NaN, NaN, (o - T - s) / r, (l - x - i) / a)), n(this, ot).set([S, E, o, l, h, c], 6), !this.isEmpty()) : (n(this, ot).set([S, E, o, l, h, c], 6), Math.abs(Math.atan2(E - l, S - o) - Math.atan2(w, v)) < Math.PI / 2 ? ([o, l, h, c] = n(this, ot).subarray(2, 6), n(this, ji).push(NaN, NaN, NaN, NaN, ((o + h) / 2 - s) / r, ((l + c) / 2 - i) / a), [o, l, S, E] = n(this, ot).subarray(14, 18), n(this, bi).push(NaN, NaN, NaN, NaN, ((S + o) / 2 - s) / r, ((E + l) / 2 - i) / a), !0) : ([S, E, o, l, h, c] = n(this, ot).subarray(0, 6), n(this, ji).push(((S + 5 * o) / 6 - s) / r, ((E + 5 * l) / 6 - i) / a, ((5 * o + h) / 6 - s) / r, ((5 * l + c) / 6 - i) / a, ((o + h) / 2 - s) / r, ((l + c) / 2 - i) / a), [h, c, o, l, S, E] = n(this, ot).subarray(12, 18), n(this, bi).push(((S + 5 * o) / 6 - s) / r, ((E + 5 * l) / 6 - i) / a, ((5 * o + h) / 6 - s) / r, ((5 * l + c) / 6 - i) / a, ((o + h) / 2 - s) / r, ((l + c) / 2 - i) / a), !0));
  }
  toSVGPath() {
    if (this.isEmpty())
      return "";
    const t = n(this, ji), e = n(this, bi);
    if (isNaN(n(this, ot)[6]) && !this.isEmpty())
      return b(this, ue, Zb).call(this);
    const s = [];
    s.push(`M${t[4]} ${t[5]}`);
    for (let i = 6; i < t.length; i += 6)
      isNaN(t[i]) ? s.push(`L${t[i + 4]} ${t[i + 5]}`) : s.push(`C${t[i]} ${t[i + 1]} ${t[i + 2]} ${t[i + 3]} ${t[i + 4]} ${t[i + 5]}`);
    b(this, ue, Qb).call(this, s);
    for (let i = e.length - 6; i >= 6; i -= 6)
      isNaN(e[i]) ? s.push(`L${e[i + 4]} ${e[i + 5]}`) : s.push(`C${e[i]} ${e[i + 1]} ${e[i + 2]} ${e[i + 3]} ${e[i + 4]} ${e[i + 5]}`);
    return b(this, ue, Jb).call(this, s), s.join(" ");
  }
  newFreeDrawOutline(t, e, s, i, r, a) {
    return new i0(t, e, s, i, r, a);
  }
  getOutlines() {
    var u;
    const t = n(this, ji), e = n(this, bi), s = n(this, ot), [i, r, a, o] = n(this, Ms), l = new Float32Array((((u = n(this, kr)) == null ? void 0 : u.length) ?? 0) + 2);
    for (let f = 0, m = l.length - 2; f < m; f += 2)
      l[f] = (n(this, kr)[f] - i) / a, l[f + 1] = (n(this, kr)[f + 1] - r) / o;
    if (l[l.length - 2] = (n(this, Ja) - i) / a, l[l.length - 1] = (n(this, Qa) - r) / o, isNaN(s[6]) && !this.isEmpty())
      return b(this, ue, t0).call(this, l);
    const h = new Float32Array(n(this, ji).length + 24 + n(this, bi).length);
    let c = t.length;
    for (let f = 0; f < c; f += 2) {
      if (isNaN(t[f])) {
        h[f] = h[f + 1] = NaN;
        continue;
      }
      h[f] = t[f], h[f + 1] = t[f + 1];
    }
    c = b(this, ue, s0).call(this, h, c);
    for (let f = e.length - 6; f >= 6; f -= 6)
      for (let m = 0; m < 6; m += 2) {
        if (isNaN(e[f + m])) {
          h[c] = h[c + 1] = NaN, c += 2;
          continue;
        }
        h[c] = e[f + m], h[c + 1] = e[f + m + 1], c += 2;
      }
    return b(this, ue, e0).call(this, h, c), this.newFreeDrawOutline(h, l, n(this, Ms), n(this, Wl), n(this, Gl), n(this, jl));
  }
};
Ms = new WeakMap(), bi = new WeakMap(), Gl = new WeakMap(), jl = new WeakMap(), ji = new WeakMap(), ot = new WeakMap(), Ja = new WeakMap(), Qa = new WeakMap(), md = new WeakMap(), bd = new WeakMap(), Wl = new WeakMap(), Xl = new WeakMap(), kr = new WeakMap(), yd = new WeakMap(), of = new WeakMap(), lf = new WeakMap(), ue = new WeakSet(), Bh = function() {
  const t = n(this, ot).subarray(4, 6), e = n(this, ot).subarray(16, 18), [s, i, r, a] = n(this, Ms);
  return [(n(this, Ja) + (t[0] - e[0]) / 2 - s) / r, (n(this, Qa) + (t[1] - e[1]) / 2 - i) / a, (n(this, Ja) + (e[0] - t[0]) / 2 - s) / r, (n(this, Qa) + (e[1] - t[1]) / 2 - i) / a];
}, Zb = function() {
  const [t, e, s, i] = n(this, Ms), [r, a, o, l] = b(this, ue, Bh).call(this);
  return `M${(n(this, ot)[2] - t) / s} ${(n(this, ot)[3] - e) / i} L${(n(this, ot)[4] - t) / s} ${(n(this, ot)[5] - e) / i} L${r} ${a} L${o} ${l} L${(n(this, ot)[16] - t) / s} ${(n(this, ot)[17] - e) / i} L${(n(this, ot)[14] - t) / s} ${(n(this, ot)[15] - e) / i} Z`;
}, Jb = function(t) {
  const e = n(this, bi);
  t.push(`L${e[4]} ${e[5]} Z`);
}, Qb = function(t) {
  const [e, s, i, r] = n(this, Ms), a = n(this, ot).subarray(4, 6), o = n(this, ot).subarray(16, 18), [l, h, c, u] = b(this, ue, Bh).call(this);
  t.push(`L${(a[0] - e) / i} ${(a[1] - s) / r} L${l} ${h} L${c} ${u} L${(o[0] - e) / i} ${(o[1] - s) / r}`);
}, t0 = function(t) {
  const e = n(this, ot), [s, i, r, a] = n(this, Ms), [o, l, h, c] = b(this, ue, Bh).call(this), u = new Float32Array(36);
  return u.set([NaN, NaN, NaN, NaN, (e[2] - s) / r, (e[3] - i) / a, NaN, NaN, NaN, NaN, (e[4] - s) / r, (e[5] - i) / a, NaN, NaN, NaN, NaN, o, l, NaN, NaN, NaN, NaN, h, c, NaN, NaN, NaN, NaN, (e[16] - s) / r, (e[17] - i) / a, NaN, NaN, NaN, NaN, (e[14] - s) / r, (e[15] - i) / a], 0), this.newFreeDrawOutline(u, t, n(this, Ms), n(this, Wl), n(this, Gl), n(this, jl));
}, e0 = function(t, e) {
  const s = n(this, bi);
  return t.set([NaN, NaN, NaN, NaN, s[4], s[5]], e), e += 6;
}, s0 = function(t, e) {
  const s = n(this, ot).subarray(4, 6), i = n(this, ot).subarray(16, 18), [r, a, o, l] = n(this, Ms), [h, c, u, f] = b(this, ue, Bh).call(this);
  return t.set([NaN, NaN, NaN, NaN, (s[0] - r) / o, (s[1] - a) / l, NaN, NaN, NaN, NaN, h, c, NaN, NaN, NaN, NaN, u, f, NaN, NaN, NaN, NaN, (i[0] - r) / o, (i[1] - a) / l], e), e += 24;
}, g(on, yd, 8), g(on, of, 2), g(on, lf, n(on, yd) + n(on, of));
let $u = on;
var ql, to, Fn, Ad, ks, wd, se, hf, n0;
class i0 extends $ {
  constructor(e, s, i, r, a, o) {
    super();
    g(this, hf);
    g(this, ql);
    g(this, to, new Float32Array(4));
    g(this, Fn);
    g(this, Ad);
    g(this, ks);
    g(this, wd);
    g(this, se);
    p(this, se, e), p(this, ks, s), p(this, ql, i), p(this, wd, r), p(this, Fn, a), p(this, Ad, o), this.firstPoint = [NaN, NaN], this.lastPoint = [NaN, NaN], b(this, hf, n0).call(this, o);
    const [l, h, c, u] = n(this, to);
    for (let f = 0, m = e.length; f < m; f += 2)
      e[f] = (e[f] - l) / c, e[f + 1] = (e[f + 1] - h) / u;
    for (let f = 0, m = s.length; f < m; f += 2)
      s[f] = (s[f] - l) / c, s[f + 1] = (s[f + 1] - h) / u;
  }
  toSVGPath() {
    const e = [`M${n(this, se)[4]} ${n(this, se)[5]}`];
    for (let s = 6, i = n(this, se).length; s < i; s += 6) {
      if (isNaN(n(this, se)[s])) {
        e.push(`L${n(this, se)[s + 4]} ${n(this, se)[s + 5]}`);
        continue;
      }
      e.push(`C${n(this, se)[s]} ${n(this, se)[s + 1]} ${n(this, se)[s + 2]} ${n(this, se)[s + 3]} ${n(this, se)[s + 4]} ${n(this, se)[s + 5]}`);
    }
    return e.push("Z"), e.join(" ");
  }
  serialize([e, s, i, r], a) {
    const o = i - e, l = r - s;
    let h, c;
    switch (a) {
      case 0:
        h = $._rescale(n(this, se), e, r, o, -l), c = $._rescale(n(this, ks), e, r, o, -l);
        break;
      case 90:
        h = $._rescaleAndSwap(n(this, se), e, s, o, l), c = $._rescaleAndSwap(n(this, ks), e, s, o, l);
        break;
      case 180:
        h = $._rescale(n(this, se), i, s, -o, l), c = $._rescale(n(this, ks), i, s, -o, l);
        break;
      case 270:
        h = $._rescaleAndSwap(n(this, se), i, r, -o, -l), c = $._rescaleAndSwap(n(this, ks), i, r, -o, -l);
        break;
    }
    return {
      outline: Array.from(h),
      points: [Array.from(c)]
    };
  }
  get box() {
    return n(this, to);
  }
  newOutliner(e, s, i, r, a, o = 0) {
    return new $u(e, s, i, r, a, o);
  }
  getNewOutline(e, s) {
    const [i, r, a, o] = n(this, to), [l, h, c, u] = n(this, ql), f = a * c, m = o * u, A = i * c + l, y = r * u + h, v = this.newOutliner({
      x: n(this, ks)[0] * f + A,
      y: n(this, ks)[1] * m + y
    }, n(this, ql), n(this, wd), e, n(this, Ad), s ?? n(this, Fn));
    for (let w = 2; w < n(this, ks).length; w += 2)
      v.add({
        x: n(this, ks)[w] * f + A,
        y: n(this, ks)[w + 1] * m + y
      });
    return v.getOutlines();
  }
}
ql = new WeakMap(), to = new WeakMap(), Fn = new WeakMap(), Ad = new WeakMap(), ks = new WeakMap(), wd = new WeakMap(), se = new WeakMap(), hf = new WeakSet(), n0 = function(e) {
  const s = n(this, se);
  let i = s[4], r = s[5];
  const a = [i, r, i, r];
  let o = i, l = r, h = i, c = r;
  const u = e ? Math.max : Math.min, f = new Float32Array(4);
  for (let A = 6, y = s.length; A < y; A += 6) {
    const v = s[A + 4], w = s[A + 5];
    isNaN(s[A]) ? (V.pointBoundingBox(v, w, a), l > w ? (o = v, l = w) : l === w && (o = u(o, v)), c < w ? (h = v, c = w) : c === w && (h = u(h, v))) : (f[0] = f[1] = 1 / 0, f[2] = f[3] = -1 / 0, V.bezierBoundingBox(i, r, ...s.slice(A, A + 6), f), V.rectBoundingBox(f[0], f[1], f[2], f[3], a), l > f[1] ? (o = f[0], l = f[1]) : l === f[1] && (o = u(o, f[0])), c < f[3] ? (h = f[2], c = f[3]) : c === f[3] && (h = u(h, f[2]))), i = v, r = w;
  }
  const m = n(this, to);
  m[0] = a[0] - n(this, Fn), m[1] = a[1] - n(this, Fn), m[2] = a[2] - a[0] + 2 * n(this, Fn), m[3] = a[3] - a[1] + 2 * n(this, Fn), this.firstPoint = [o, l], this.lastPoint = [h, c];
};
var vd, Ed, Sd, Lr, yi, ns, r0, Eu, a0, o0, $p;
class Up {
  constructor(t, e = 0, s = 0, i = !0) {
    g(this, ns);
    g(this, vd);
    g(this, Ed);
    g(this, Sd);
    g(this, Lr, []);
    g(this, yi, []);
    const r = [1 / 0, 1 / 0, -1 / 0, -1 / 0], a = 10 ** -4;
    for (const {
      x: y,
      y: v,
      width: w,
      height: S
    } of t) {
      const E = Math.floor((y - e) / a) * a, _ = Math.ceil((y + w + e) / a) * a, C = Math.floor((v - e) / a) * a, T = Math.ceil((v + S + e) / a) * a, x = [E, C, T, !0], R = [_, C, T, !1];
      n(this, Lr).push(x, R), V.rectBoundingBox(E, C, _, T, r);
    }
    const o = r[2] - r[0] + 2 * s, l = r[3] - r[1] + 2 * s, h = r[0] - s, c = r[1] - s;
    let u = i ? -1 / 0 : 1 / 0, f = 1 / 0;
    const m = n(this, Lr).at(i ? -1 : -2), A = [m[0], m[2]];
    for (const y of n(this, Lr)) {
      const [v, w, S, E] = y;
      !E && i ? w < f ? (f = w, u = v) : w === f && (u = Math.max(u, v)) : E && !i && (w < f ? (f = w, u = v) : w === f && (u = Math.min(u, v))), y[0] = (v - h) / o, y[1] = (w - c) / l, y[2] = (S - c) / l;
    }
    p(this, vd, new Float32Array([h, c, o, l])), p(this, Ed, [u, f]), p(this, Sd, A);
  }
  getOutlines() {
    n(this, Lr).sort((e, s) => e[0] - s[0] || e[1] - s[1] || e[2] - s[2]);
    const t = [];
    for (const e of n(this, Lr))
      e[3] ? (t.push(...b(this, ns, $p).call(this, e)), b(this, ns, a0).call(this, e)) : (b(this, ns, o0).call(this, e), t.push(...b(this, ns, $p).call(this, e)));
    return b(this, ns, r0).call(this, t);
  }
}
vd = new WeakMap(), Ed = new WeakMap(), Sd = new WeakMap(), Lr = new WeakMap(), yi = new WeakMap(), ns = new WeakSet(), r0 = function(t) {
  const e = [], s = /* @__PURE__ */ new Set();
  for (const a of t) {
    const [o, l, h] = a;
    e.push([o, l, a], [o, h, a]);
  }
  e.sort((a, o) => a[1] - o[1] || a[0] - o[0]);
  for (let a = 0, o = e.length; a < o; a += 2) {
    const l = e[a][2], h = e[a + 1][2];
    l.push(h), h.push(l), s.add(l), s.add(h);
  }
  const i = [];
  let r;
  for (; s.size > 0; ) {
    const a = s.values().next().value;
    let [o, l, h, c, u] = a;
    s.delete(a);
    let f = o, m = l;
    for (r = [o, h], i.push(r); ; ) {
      let A;
      if (s.has(c))
        A = c;
      else if (s.has(u))
        A = u;
      else
        break;
      s.delete(A), [o, l, h, c, u] = A, f !== o && (r.push(f, m, o, m === l ? l : h), f = o), m = m === l ? h : l;
    }
    r.push(f, m);
  }
  return new $A(i, n(this, vd), n(this, Ed), n(this, Sd));
}, Eu = function(t) {
  const e = n(this, yi);
  let s = 0, i = e.length - 1;
  for (; s <= i; ) {
    const r = s + i >> 1, a = e[r][0];
    if (a === t)
      return r;
    a < t ? s = r + 1 : i = r - 1;
  }
  return i + 1;
}, a0 = function([, t, e]) {
  const s = b(this, ns, Eu).call(this, t);
  n(this, yi).splice(s, 0, [t, e]);
}, o0 = function([, t, e]) {
  const s = b(this, ns, Eu).call(this, t);
  for (let i = s; i < n(this, yi).length; i++) {
    const [r, a] = n(this, yi)[i];
    if (r !== t)
      break;
    if (r === t && a === e) {
      n(this, yi).splice(i, 1);
      return;
    }
  }
  for (let i = s - 1; i >= 0; i--) {
    const [r, a] = n(this, yi)[i];
    if (r !== t)
      break;
    if (r === t && a === e) {
      n(this, yi).splice(i, 1);
      return;
    }
  }
}, $p = function(t) {
  const [e, s, i] = t, r = [[e, s, i]], a = b(this, ns, Eu).call(this, i);
  for (let o = 0; o < a; o++) {
    const [l, h] = n(this, yi)[o];
    for (let c = 0, u = r.length; c < u; c++) {
      const [, f, m] = r[c];
      if (!(h <= f || m <= l)) {
        if (f >= l) {
          if (m > h)
            r[c][1] = h;
          else {
            if (u === 1)
              return [];
            r.splice(c, 1), c--, u--;
          }
          continue;
        }
        r[c][2] = l, m > h && r.push([e, h, m]);
      }
    }
  }
  return r;
};
var _d, Yl;
class $A extends $ {
  constructor(e, s, i, r) {
    super();
    g(this, _d);
    g(this, Yl);
    p(this, Yl, e), p(this, _d, s), this.firstPoint = i, this.lastPoint = r;
  }
  toSVGPath() {
    const e = [];
    for (const s of n(this, Yl)) {
      let [i, r] = s;
      e.push(`M${i} ${r}`);
      for (let a = 2; a < s.length; a += 2) {
        const o = s[a], l = s[a + 1];
        o === i ? (e.push(`V${l}`), r = l) : l === r && (e.push(`H${o}`), i = o);
      }
      e.push("Z");
    }
    return e.join(" ");
  }
  serialize([e, s, i, r], a) {
    const o = [], l = i - e, h = r - s;
    for (const c of n(this, Yl)) {
      const u = new Array(c.length);
      for (let f = 0; f < c.length; f += 2)
        u[f] = e + c[f] * l, u[f + 1] = r - c[f + 1] * h;
      o.push(u);
    }
    return o;
  }
  get box() {
    return n(this, _d);
  }
  get classNamesForOutlining() {
    return ["highlightOutline"];
  }
}
_d = new WeakMap(), Yl = new WeakMap();
class Vp extends $u {
  newFreeDrawOutline(t, e, s, i, r, a) {
    return new VA(t, e, s, i, r, a);
  }
}
class VA extends i0 {
  newOutliner(t, e, s, i, r, a = 0) {
    return new Vp(t, e, s, i, r, a);
  }
}
var Kl, Cd, Nn, eo, Td, ps, xd, Pd, so, Ls, Ds, ke, Zl, Jl, Ge, Ql, ei, Rd, nt, zp, Su, l0, h0, c0, Gp, ea, ri, Ro, d0, _u, Cu, u0, f0, p0, g0, m0;
const mt = class mt extends Ft {
  constructor(e) {
    super({
      ...e,
      name: "highlightEditor"
    });
    g(this, nt);
    g(this, Kl, null);
    g(this, Cd, 0);
    g(this, Nn);
    g(this, eo, null);
    g(this, Td, null);
    g(this, ps, null);
    g(this, xd, null);
    g(this, Pd, 0);
    g(this, so, null);
    g(this, Ls, null);
    g(this, Ds, null);
    g(this, ke, !1);
    g(this, Zl, null);
    g(this, Jl, null);
    g(this, Ge, null);
    g(this, Ql, "");
    g(this, ei);
    g(this, Rd, "");
    this.color = e.color || mt._defaultColor, p(this, ei, e.thickness || mt._defaultThickness), this.opacity = e.opacity || mt._defaultOpacity, p(this, Nn, e.boxes || null), p(this, Rd, e.methodOfCreation || ""), p(this, Ql, e.text || ""), this._isDraggable = !1, this.defaultL10nId = "pdfjs-editor-highlight-editor", e.highlightId > -1 ? (p(this, ke, !0), b(this, nt, Su).call(this, e), b(this, nt, ea).call(this)) : n(this, Nn) && (p(this, Kl, e.anchorNode), p(this, Cd, e.anchorOffset), p(this, xd, e.focusNode), p(this, Pd, e.focusOffset), b(this, nt, zp).call(this), b(this, nt, ea).call(this), this.rotate(this.rotation)), this.annotationElementId || this._uiManager.a11yAlert("pdfjs-editor-highlight-added-alert");
  }
  static get _keyboardManager() {
    const e = mt.prototype;
    return it(this, "_keyboardManager", new Od([[["ArrowLeft", "mac+ArrowLeft"], e._moveCaret, {
      args: [0]
    }], [["ArrowRight", "mac+ArrowRight"], e._moveCaret, {
      args: [1]
    }], [["ArrowUp", "mac+ArrowUp"], e._moveCaret, {
      args: [2]
    }], [["ArrowDown", "mac+ArrowDown"], e._moveCaret, {
      args: [3]
    }]]));
  }
  get telemetryInitialData() {
    return {
      action: "added",
      type: n(this, ke) ? "free_highlight" : "highlight",
      color: this._uiManager.getNonHCMColorName(this.color),
      thickness: n(this, ei),
      methodOfCreation: n(this, Rd)
    };
  }
  get telemetryFinalData() {
    return {
      type: "highlight",
      color: this._uiManager.getNonHCMColorName(this.color)
    };
  }
  static computeTelemetryFinalData(e) {
    return {
      numberOfColors: e.get("color").size
    };
  }
  static initialize(e, s) {
    var i;
    Ft.initialize(e, s), mt._defaultColor || (mt._defaultColor = ((i = s.highlightColors) == null ? void 0 : i.values().next().value) || "#fff066");
  }
  static updateDefaultParams(e, s) {
    switch (e) {
      case ht.HIGHLIGHT_COLOR:
        mt._defaultColor = s;
        break;
      case ht.HIGHLIGHT_THICKNESS:
        mt._defaultThickness = s;
        break;
    }
  }
  translateInPage(e, s) {
  }
  get toolbarPosition() {
    return n(this, Jl);
  }
  get commentButtonPosition() {
    return n(this, Zl);
  }
  updateParams(e, s) {
    switch (e) {
      case ht.HIGHLIGHT_COLOR:
        b(this, nt, l0).call(this, s);
        break;
      case ht.HIGHLIGHT_THICKNESS:
        b(this, nt, h0).call(this, s);
        break;
    }
  }
  static get defaultPropertiesToUpdate() {
    return [[ht.HIGHLIGHT_COLOR, mt._defaultColor], [ht.HIGHLIGHT_THICKNESS, mt._defaultThickness]];
  }
  get propertiesToUpdate() {
    return [[ht.HIGHLIGHT_COLOR, this.color || mt._defaultColor], [ht.HIGHLIGHT_THICKNESS, n(this, ei) || mt._defaultThickness], [ht.HIGHLIGHT_FREE, n(this, ke)]];
  }
  onUpdatedColor() {
    var e, s;
    (e = this.parent) == null || e.drawLayer.updateProperties(n(this, Ds), {
      root: {
        fill: this.color,
        "fill-opacity": this.opacity
      }
    }), (s = n(this, Td)) == null || s.updateColor(this.color), super.onUpdatedColor();
  }
  get toolbarButtons() {
    return this._uiManager.highlightColors ? [["colorPicker", p(this, Td, new Zh({
      editor: this
    }))]] : super.toolbarButtons;
  }
  disableEditing() {
    super.disableEditing(), this.div.classList.toggle("disabled", !0);
  }
  enableEditing() {
    super.enableEditing(), this.div.classList.toggle("disabled", !1);
  }
  fixAndSetPosition() {
    return super.fixAndSetPosition(b(this, nt, Cu).call(this));
  }
  getBaseTranslation() {
    return [0, 0];
  }
  getRect(e, s) {
    return super.getRect(e, s, b(this, nt, Cu).call(this));
  }
  onceAdded(e) {
    this.annotationElementId || this.parent.addUndoableEditor(this), e && this.div.focus();
  }
  remove() {
    b(this, nt, Gp).call(this), this._reportTelemetry({
      action: "deleted"
    }), super.remove();
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (b(this, nt, ea).call(this), this.isAttachedToDOM || this.parent.add(this)));
  }
  setParent(e) {
    var i;
    let s = !1;
    this.parent && !e ? b(this, nt, Gp).call(this) : e && (b(this, nt, ea).call(this, e), s = !this.parent && ((i = this.div) == null ? void 0 : i.classList.contains("selectedEditor"))), super.setParent(e), this.show(this._isVisible), s && this.select();
  }
  rotate(e) {
    var r, a, o;
    const {
      drawLayer: s
    } = this.parent;
    let i;
    n(this, ke) ? (e = (e - this.rotation + 360) % 360, i = b(r = mt, ri, Ro).call(r, n(this, Ls).box, e)) : i = b(a = mt, ri, Ro).call(a, [this.x, this.y, this.width, this.height], e), s.updateProperties(n(this, Ds), {
      bbox: i,
      root: {
        "data-main-rotation": e
      }
    }), s.updateProperties(n(this, Ge), {
      bbox: b(o = mt, ri, Ro).call(o, n(this, ps).box, e),
      root: {
        "data-main-rotation": e
      }
    });
  }
  render() {
    if (this.div)
      return this.div;
    const e = super.render();
    n(this, Ql) && (e.setAttribute("aria-label", n(this, Ql)), e.setAttribute("role", "mark")), n(this, ke) ? e.classList.add("free") : this.div.addEventListener("keydown", b(this, nt, d0).bind(this), {
      signal: this._uiManager._signal
    });
    const s = p(this, so, document.createElement("div"));
    return e.append(s), s.setAttribute("aria-hidden", "true"), s.className = "internal", s.style.clipPath = n(this, eo), this.setDims(this.width, this.height), Om(this, n(this, so), ["pointerover", "pointerleave"]), this.enableEditing(), e;
  }
  pointerover() {
    var e;
    this.isSelected || (e = this.parent) == null || e.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        hovered: !0
      }
    });
  }
  pointerleave() {
    var e;
    this.isSelected || (e = this.parent) == null || e.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        hovered: !1
      }
    });
  }
  _moveCaret(e) {
    switch (this.parent.unselect(this), e) {
      case 0:
      case 2:
        b(this, nt, _u).call(this, !0);
        break;
      case 1:
      case 3:
        b(this, nt, _u).call(this, !1);
        break;
    }
  }
  select() {
    var e;
    super.select(), n(this, Ge) && ((e = this.parent) == null || e.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        hovered: !1,
        selected: !0
      }
    }));
  }
  unselect() {
    var e;
    super.unselect(), n(this, Ge) && ((e = this.parent) == null || e.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        selected: !1
      }
    }), n(this, ke) || b(this, nt, _u).call(this, !1));
  }
  get _mustFixPosition() {
    return !n(this, ke);
  }
  show(e = this._isVisible) {
    super.show(e), this.parent && (this.parent.drawLayer.updateProperties(n(this, Ds), {
      rootClass: {
        hidden: !e
      }
    }), this.parent.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        hidden: !e
      }
    }));
  }
  static startHighlighting(e, s, {
    target: i,
    x: r,
    y: a
  }) {
    const {
      x: o,
      y: l,
      width: h,
      height: c
    } = i.getBoundingClientRect(), u = new AbortController(), f = e.combinedSignal(u), m = (A) => {
      u.abort(), b(this, ri, g0).call(this, e, A);
    };
    window.addEventListener("blur", m, {
      signal: f
    }), window.addEventListener("pointerup", m, {
      signal: f
    }), window.addEventListener("pointerdown", zt, {
      capture: !0,
      passive: !1,
      signal: f
    }), window.addEventListener("contextmenu", $s, {
      signal: f
    }), i.addEventListener("pointermove", b(this, ri, p0).bind(this, e), {
      signal: f
    }), this._freeHighlight = new Vp({
      x: r,
      y: a
    }, [o, l, h, c], e.scale, this._defaultThickness / 2, s, 1e-3), {
      id: this._freeHighlightId,
      clipPathId: this._freeHighlightClipId
    } = e.drawLayer.draw({
      bbox: [0, 0, 1, 1],
      root: {
        viewBox: "0 0 1 1",
        fill: this._defaultColor,
        "fill-opacity": this._defaultOpacity
      },
      rootClass: {
        highlight: !0,
        free: !0
      },
      path: {
        d: this._freeHighlight.toSVGPath()
      }
    }, !0, !0);
  }
  static async deserialize(e, s, i) {
    var y, v, w, S;
    let r = null;
    if (e instanceof Gb) {
      const {
        data: {
          quadPoints: E,
          rect: _,
          rotation: C,
          id: T,
          color: x,
          opacity: R,
          popupRef: M,
          richText: D,
          contentsObj: k,
          creationDate: N,
          modificationDate: X
        },
        parent: {
          page: {
            pageNumber: B
          }
        }
      } = e;
      r = e = {
        annotationType: Z.HIGHLIGHT,
        color: Array.from(x),
        opacity: R,
        quadPoints: E,
        boxes: null,
        pageIndex: B - 1,
        rect: _.slice(0),
        rotation: C,
        annotationElementId: T,
        id: T,
        deleted: !1,
        popupRef: M,
        richText: D,
        comment: (k == null ? void 0 : k.str) || null,
        creationDate: N,
        modificationDate: X
      };
    } else if (e instanceof Sg) {
      const {
        data: {
          inkLists: E,
          rect: _,
          rotation: C,
          id: T,
          color: x,
          borderStyle: {
            rawWidth: R
          },
          popupRef: M,
          richText: D,
          contentsObj: k,
          creationDate: N,
          modificationDate: X
        },
        parent: {
          page: {
            pageNumber: B
          }
        }
      } = e;
      r = e = {
        annotationType: Z.HIGHLIGHT,
        color: Array.from(x),
        thickness: R,
        inkLists: E,
        boxes: null,
        pageIndex: B - 1,
        rect: _.slice(0),
        rotation: C,
        annotationElementId: T,
        id: T,
        deleted: !1,
        popupRef: M,
        richText: D,
        comment: (k == null ? void 0 : k.str) || null,
        creationDate: N,
        modificationDate: X
      };
    }
    const {
      color: a,
      quadPoints: o,
      inkLists: l,
      opacity: h
    } = e, c = await super.deserialize(e, s, i);
    c.color = V.makeHexColor(...a), c.opacity = h || 1, l && p(c, ei, e.thickness), c._initialData = r, e.comment && c.setCommentData(e);
    const [u, f] = c.pageDimensions, [m, A] = c.pageTranslation;
    if (o) {
      const E = p(c, Nn, []);
      for (let _ = 0; _ < o.length; _ += 8)
        E.push({
          x: (o[_] - m) / u,
          y: 1 - (o[_ + 1] - A) / f,
          width: (o[_ + 2] - o[_]) / u,
          height: (o[_ + 1] - o[_ + 5]) / f
        });
      b(y = c, nt, zp).call(y), b(v = c, nt, ea).call(v), c.rotate(c.rotation);
    } else if (l) {
      p(c, ke, !0);
      const E = l[0], _ = {
        x: E[0] - m,
        y: f - (E[1] - A)
      }, C = new Vp(_, [0, 0, u, f], 1, n(c, ei) / 2, !0, 1e-3);
      for (let R = 0, M = E.length; R < M; R += 2)
        _.x = E[R] - m, _.y = f - (E[R + 1] - A), C.add(_);
      const {
        id: T,
        clipPathId: x
      } = s.drawLayer.draw({
        bbox: [0, 0, 1, 1],
        root: {
          viewBox: "0 0 1 1",
          fill: c.color,
          "fill-opacity": c._defaultOpacity
        },
        rootClass: {
          highlight: !0,
          free: !0
        },
        path: {
          d: C.toSVGPath()
        }
      }, !0, !0);
      b(w = c, nt, Su).call(w, {
        highlightOutlines: C.getOutlines(),
        highlightId: T,
        clipPathId: x
      }), b(S = c, nt, ea).call(S), c.rotate(c.parentRotation);
    }
    return c;
  }
  serialize(e = !1) {
    if (this.isEmpty() || e)
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const s = Ft._colorManager.convert(this._uiManager.getNonHCMColor(this.color)), i = super.serialize(e);
    return Object.assign(i, {
      color: s,
      opacity: this.opacity,
      thickness: n(this, ei),
      quadPoints: b(this, nt, u0).call(this),
      outlines: b(this, nt, f0).call(this, i.rect)
    }), this.addComment(i), this.annotationElementId && !b(this, nt, m0).call(this, i) ? null : (i.id = this.annotationElementId, i);
  }
  renderAnnotationElement(e) {
    return this.deleted ? (e.hide(), null) : (e.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
  static canCreateNewEmptyEditor() {
    return !1;
  }
};
Kl = new WeakMap(), Cd = new WeakMap(), Nn = new WeakMap(), eo = new WeakMap(), Td = new WeakMap(), ps = new WeakMap(), xd = new WeakMap(), Pd = new WeakMap(), so = new WeakMap(), Ls = new WeakMap(), Ds = new WeakMap(), ke = new WeakMap(), Zl = new WeakMap(), Jl = new WeakMap(), Ge = new WeakMap(), Ql = new WeakMap(), ei = new WeakMap(), Rd = new WeakMap(), nt = new WeakSet(), zp = function() {
  const e = new Up(n(this, Nn), 1e-3);
  p(this, Ls, e.getOutlines()), [this.x, this.y, this.width, this.height] = n(this, Ls).box;
  const s = new Up(n(this, Nn), 25e-4, 1e-3, this._uiManager.direction === "ltr");
  p(this, ps, s.getOutlines());
  const {
    firstPoint: i
  } = n(this, Ls);
  p(this, Zl, [(i[0] - this.x) / this.width, (i[1] - this.y) / this.height]);
  const {
    lastPoint: r
  } = n(this, ps);
  p(this, Jl, [(r[0] - this.x) / this.width, (r[1] - this.y) / this.height]);
}, Su = function({
  highlightOutlines: e,
  highlightId: s,
  clipPathId: i
}) {
  var f, m;
  if (p(this, Ls, e), p(this, ps, e.getNewOutline(n(this, ei) / 2 + 1.5, 25e-4)), s >= 0)
    p(this, Ds, s), p(this, eo, i), this.parent.drawLayer.finalizeDraw(s, {
      bbox: e.box,
      path: {
        d: e.toSVGPath()
      }
    }), p(this, Ge, this.parent.drawLayer.drawOutline({
      rootClass: {
        highlightOutline: !0,
        free: !0
      },
      bbox: n(this, ps).box,
      path: {
        d: n(this, ps).toSVGPath()
      }
    }, !0));
  else if (this.parent) {
    const A = this.parent.viewport.rotation;
    this.parent.drawLayer.updateProperties(n(this, Ds), {
      bbox: b(f = mt, ri, Ro).call(f, n(this, Ls).box, (A - this.rotation + 360) % 360),
      path: {
        d: e.toSVGPath()
      }
    }), this.parent.drawLayer.updateProperties(n(this, Ge), {
      bbox: b(m = mt, ri, Ro).call(m, n(this, ps).box, A),
      path: {
        d: n(this, ps).toSVGPath()
      }
    });
  }
  const [a, o, l, h] = e.box;
  switch (this.rotation) {
    case 0:
      this.x = a, this.y = o, this.width = l, this.height = h;
      break;
    case 90: {
      const [A, y] = this.parentDimensions;
      this.x = o, this.y = 1 - a, this.width = l * y / A, this.height = h * A / y;
      break;
    }
    case 180:
      this.x = 1 - a, this.y = 1 - o, this.width = l, this.height = h;
      break;
    case 270: {
      const [A, y] = this.parentDimensions;
      this.x = 1 - o, this.y = a, this.width = l * y / A, this.height = h * A / y;
      break;
    }
  }
  const {
    firstPoint: c
  } = e;
  p(this, Zl, [(c[0] - a) / l, (c[1] - o) / h]);
  const {
    lastPoint: u
  } = n(this, ps);
  p(this, Jl, [(u[0] - a) / l, (u[1] - o) / h]);
}, l0 = function(e) {
  const s = (a, o) => {
    this.color = a, this.opacity = o, this.onUpdatedColor();
  }, i = this.color, r = this.opacity;
  this.addCommands({
    cmd: s.bind(this, e, mt._defaultOpacity),
    undo: s.bind(this, i, r),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: ht.HIGHLIGHT_COLOR,
    overwriteIfSameType: !0,
    keepUndo: !0
  }), this._reportTelemetry({
    action: "color_changed",
    color: this._uiManager.getNonHCMColorName(e)
  }, !0);
}, h0 = function(e) {
  const s = n(this, ei), i = (r) => {
    p(this, ei, r), b(this, nt, c0).call(this, r);
  };
  this.addCommands({
    cmd: i.bind(this, e),
    undo: i.bind(this, s),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: ht.INK_THICKNESS,
    overwriteIfSameType: !0,
    keepUndo: !0
  }), this._reportTelemetry({
    action: "thickness_changed",
    thickness: e
  }, !0);
}, c0 = function(e) {
  n(this, ke) && (b(this, nt, Su).call(this, {
    highlightOutlines: n(this, Ls).getNewOutline(e / 2)
  }), this.fixAndSetPosition(), this.setDims(this.width, this.height));
}, Gp = function() {
  n(this, Ds) === null || !this.parent || (this.parent.drawLayer.remove(n(this, Ds)), p(this, Ds, null), this.parent.drawLayer.remove(n(this, Ge)), p(this, Ge, null));
}, ea = function(e = this.parent) {
  n(this, Ds) === null && ({
    id: oe(this, Ds)._,
    clipPathId: oe(this, eo)._
  } = e.drawLayer.draw({
    bbox: n(this, Ls).box,
    root: {
      viewBox: "0 0 1 1",
      fill: this.color,
      "fill-opacity": this.opacity
    },
    rootClass: {
      highlight: !0,
      free: n(this, ke)
    },
    path: {
      d: n(this, Ls).toSVGPath()
    }
  }, !1, !0), p(this, Ge, e.drawLayer.drawOutline({
    rootClass: {
      highlightOutline: !0,
      free: n(this, ke)
    },
    bbox: n(this, ps).box,
    path: {
      d: n(this, ps).toSVGPath()
    }
  }, n(this, ke))), n(this, so) && (n(this, so).style.clipPath = n(this, eo)));
}, ri = new WeakSet(), Ro = function([e, s, i, r], a) {
  switch (a) {
    case 90:
      return [1 - s - r, e, r, i];
    case 180:
      return [1 - e - i, 1 - s - r, i, r];
    case 270:
      return [s, 1 - e - i, r, i];
  }
  return [e, s, i, r];
}, d0 = function(e) {
  mt._keyboardManager.exec(this, e);
}, _u = function(e) {
  if (!n(this, Kl))
    return;
  const s = window.getSelection();
  e ? s.setPosition(n(this, Kl), n(this, Cd)) : s.setPosition(n(this, xd), n(this, Pd));
}, Cu = function() {
  return n(this, ke) ? this.rotation : 0;
}, u0 = function() {
  if (n(this, ke))
    return null;
  const [e, s] = this.pageDimensions, [i, r] = this.pageTranslation, a = n(this, Nn), o = new Float32Array(a.length * 8);
  let l = 0;
  for (const {
    x: h,
    y: c,
    width: u,
    height: f
  } of a) {
    const m = h * e + i, A = (1 - c) * s + r;
    o[l] = o[l + 4] = m, o[l + 1] = o[l + 3] = A, o[l + 2] = o[l + 6] = m + u * e, o[l + 5] = o[l + 7] = A - f * s, l += 8;
  }
  return o;
}, f0 = function(e) {
  return n(this, Ls).serialize(e, b(this, nt, Cu).call(this));
}, p0 = function(e, s) {
  this._freeHighlight.add(s) && e.drawLayer.updateProperties(this._freeHighlightId, {
    path: {
      d: this._freeHighlight.toSVGPath()
    }
  });
}, g0 = function(e, s) {
  this._freeHighlight.isEmpty() ? e.drawLayer.remove(this._freeHighlightId) : e.createAndAddNewEditor(s, !1, {
    highlightId: this._freeHighlightId,
    highlightOutlines: this._freeHighlight.getOutlines(),
    clipPathId: this._freeHighlightClipId,
    methodOfCreation: "main_toolbar"
  }), this._freeHighlightId = -1, this._freeHighlight = null, this._freeHighlightClipId = "";
}, m0 = function(e) {
  const {
    color: s
  } = this._initialData;
  return this.hasEditedComment || e.color.some((i, r) => i !== s[r]);
}, g(mt, ri), L(mt, "_defaultColor", null), L(mt, "_defaultOpacity", 1), L(mt, "_defaultThickness", 12), L(mt, "_type", "highlight"), L(mt, "_editorType", Z.HIGHLIGHT), L(mt, "_freeHighlightId", -1), L(mt, "_freeHighlight", null), L(mt, "_freeHighlightClipId", "");
let Vu = mt;
var io;
class b0 {
  constructor() {
    g(this, io, /* @__PURE__ */ Object.create(null));
  }
  updateProperty(t, e) {
    this[t] = e, this.updateSVGProperty(t, e);
  }
  updateProperties(t) {
    if (t)
      for (const [e, s] of Object.entries(t))
        e.startsWith("_") || this.updateProperty(e, s);
  }
  updateSVGProperty(t, e) {
    n(this, io)[t] = e;
  }
  toSVGProperties() {
    const t = n(this, io);
    return p(this, io, /* @__PURE__ */ Object.create(null)), {
      root: t
    };
  }
  reset() {
    p(this, io, /* @__PURE__ */ Object.create(null));
  }
  updateAll(t = this) {
    this.updateProperties(t);
  }
  clone() {
    Dt("Not implemented");
  }
}
io = new WeakMap();
var Is, th, ye, no, ro, Dr, Ir, Fr, ao, pt, jp, Wp, Xp, Hh, y0, Tu, Uh, Mo;
const z = class z extends Ft {
  constructor(e) {
    super(e);
    g(this, pt);
    g(this, Is, null);
    g(this, th);
    L(this, "_colorPicker", null);
    L(this, "_drawId", null);
    p(this, th, e.mustBeCommitted || !1), this._addOutlines(e);
  }
  onUpdatedColor() {
    var e;
    (e = this._colorPicker) == null || e.update(this.color), super.onUpdatedColor();
  }
  _addOutlines(e) {
    e.drawOutlines && (b(this, pt, jp).call(this, e), b(this, pt, Hh).call(this));
  }
  static _mergeSVGProperties(e, s) {
    const i = new Set(Object.keys(e));
    for (const [r, a] of Object.entries(s))
      i.has(r) ? Object.assign(e[r], a) : e[r] = a;
    return e;
  }
  static getDefaultDrawingOptions(e) {
    Dt("Not implemented");
  }
  static get typesMap() {
    Dt("Not implemented");
  }
  static get isDrawer() {
    return !0;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  static updateDefaultParams(e, s) {
    const i = this.typesMap.get(e);
    i && this._defaultDrawingOptions.updateProperty(i, s), this._currentParent && (n(z, ye).updateProperty(i, s), this._currentParent.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  updateParams(e, s) {
    const i = this.constructor.typesMap.get(e);
    i && this._updateProperty(e, i, s);
  }
  static get defaultPropertiesToUpdate() {
    const e = [], s = this._defaultDrawingOptions;
    for (const [i, r] of this.typesMap)
      e.push([i, s[r]]);
    return e;
  }
  get propertiesToUpdate() {
    const e = [], {
      _drawingOptions: s
    } = this;
    for (const [i, r] of this.constructor.typesMap)
      e.push([i, s[r]]);
    return e;
  }
  _updateProperty(e, s, i) {
    const r = this._drawingOptions, a = r[s], o = (l) => {
      var c;
      r.updateProperty(s, l);
      const h = n(this, Is).updateProperty(s, l);
      h && b(this, pt, Uh).call(this, h), (c = this.parent) == null || c.drawLayer.updateProperties(this._drawId, r.toSVGProperties()), e === this.colorType && this.onUpdatedColor();
    };
    this.addCommands({
      cmd: o.bind(this, i),
      undo: o.bind(this, a),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: e,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _onResizing() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, z._mergeSVGProperties(n(this, Is).getPathResizingSVGProperties(b(this, pt, Tu).call(this)), {
      bbox: b(this, pt, Mo).call(this)
    }));
  }
  _onResized() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, z._mergeSVGProperties(n(this, Is).getPathResizedSVGProperties(b(this, pt, Tu).call(this)), {
      bbox: b(this, pt, Mo).call(this)
    }));
  }
  _onTranslating(e, s) {
    var i;
    (i = this.parent) == null || i.drawLayer.updateProperties(this._drawId, {
      bbox: b(this, pt, Mo).call(this)
    });
  }
  _onTranslated() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, z._mergeSVGProperties(n(this, Is).getPathTranslatedSVGProperties(b(this, pt, Tu).call(this), this.parentDimensions), {
      bbox: b(this, pt, Mo).call(this)
    }));
  }
  _onStartDragging() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !0
      }
    });
  }
  _onStopDragging() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !1
      }
    });
  }
  commit() {
    super.commit(), this.disableEditMode(), this.disableEditing();
  }
  disableEditing() {
    super.disableEditing(), this.div.classList.toggle("disabled", !0);
  }
  enableEditing() {
    super.enableEditing(), this.div.classList.toggle("disabled", !1);
  }
  getBaseTranslation() {
    return [0, 0];
  }
  get isResizable() {
    return !0;
  }
  onceAdded(e) {
    this.annotationElementId || this.parent.addUndoableEditor(this), this._isDraggable = !0, n(this, th) && (p(this, th, !1), this.commit(), this.parent.setSelected(this), e && this.isOnScreen && this.div.focus());
  }
  remove() {
    b(this, pt, Xp).call(this), super.remove();
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (b(this, pt, Hh).call(this), b(this, pt, Uh).call(this, n(this, Is).box), this.isAttachedToDOM || this.parent.add(this)));
  }
  setParent(e) {
    var i;
    let s = !1;
    this.parent && !e ? (this._uiManager.removeShouldRescale(this), b(this, pt, Xp).call(this)) : e && (this._uiManager.addShouldRescale(this), b(this, pt, Hh).call(this, e), s = !this.parent && ((i = this.div) == null ? void 0 : i.classList.contains("selectedEditor"))), super.setParent(e), s && this.select();
  }
  rotate() {
    this.parent && this.parent.drawLayer.updateProperties(this._drawId, z._mergeSVGProperties({
      bbox: b(this, pt, Mo).call(this)
    }, n(this, Is).updateRotation((this.parentRotation - this.rotation + 360) % 360)));
  }
  onScaleChanging() {
    this.parent && b(this, pt, Uh).call(this, n(this, Is).updateParentDimensions(this.parentDimensions, this.parent.scale));
  }
  static onScaleChangingWhenDrawing() {
  }
  render() {
    if (this.div)
      return this.div;
    let e, s;
    this._isCopy && (e = this.x, s = this.y);
    const i = super.render();
    i.classList.add("draw");
    const r = document.createElement("div");
    return i.append(r), r.setAttribute("aria-hidden", "true"), r.className = "internal", this.setDims(), this._uiManager.addShouldRescale(this), this.disableEditing(), this._isCopy && this._moveAfterPaste(e, s), i;
  }
  static createDrawerInstance(e, s, i, r, a) {
    Dt("Not implemented");
  }
  static startDrawing(e, s, i, r) {
    var v;
    const {
      target: a,
      offsetX: o,
      offsetY: l,
      pointerId: h,
      pointerType: c
    } = r;
    if (n(z, Ir) && n(z, Ir) !== c)
      return;
    const {
      viewport: {
        rotation: u
      }
    } = e, {
      width: f,
      height: m
    } = a.getBoundingClientRect(), A = p(z, no, new AbortController()), y = e.combinedSignal(A);
    if (n(z, Dr) || p(z, Dr, h), n(z, Ir) ?? p(z, Ir, c), window.addEventListener("pointerup", (w) => {
      var S;
      n(z, Dr) === w.pointerId ? this._endDraw(w) : (S = n(z, Fr)) == null || S.delete(w.pointerId);
    }, {
      signal: y
    }), window.addEventListener("pointercancel", (w) => {
      var S;
      n(z, Dr) === w.pointerId ? this._currentParent.endDrawingSession() : (S = n(z, Fr)) == null || S.delete(w.pointerId);
    }, {
      signal: y
    }), window.addEventListener("pointerdown", (w) => {
      n(z, Ir) === w.pointerType && ((n(z, Fr) || p(z, Fr, /* @__PURE__ */ new Set())).add(w.pointerId), n(z, ye).isCancellable() && (n(z, ye).removeLastElement(), n(z, ye).isEmpty() ? this._currentParent.endDrawingSession(!0) : this._endDraw(null)));
    }, {
      capture: !0,
      passive: !1,
      signal: y
    }), window.addEventListener("contextmenu", $s, {
      signal: y
    }), a.addEventListener("pointermove", this._drawMove.bind(this), {
      signal: y
    }), a.addEventListener("touchmove", (w) => {
      w.timeStamp === n(z, ao) && zt(w);
    }, {
      signal: y
    }), e.toggleDrawing(), (v = s._editorUndoBar) == null || v.hide(), n(z, ye)) {
      e.drawLayer.updateProperties(this._currentDrawId, n(z, ye).startNew(o, l, f, m, u));
      return;
    }
    s.updateUIForDefaultProperties(this), p(z, ye, this.createDrawerInstance(o, l, f, m, u)), p(z, ro, this.getDefaultDrawingOptions()), this._currentParent = e, {
      id: this._currentDrawId
    } = e.drawLayer.draw(this._mergeSVGProperties(n(z, ro).toSVGProperties(), n(z, ye).defaultSVGProperties), !0, !1);
  }
  static _drawMove(e) {
    var a;
    if (p(z, ao, -1), !n(z, ye))
      return;
    const {
      offsetX: s,
      offsetY: i,
      pointerId: r
    } = e;
    if (n(z, Dr) === r) {
      if (((a = n(z, Fr)) == null ? void 0 : a.size) >= 1) {
        this._endDraw(e);
        return;
      }
      this._currentParent.drawLayer.updateProperties(this._currentDrawId, n(z, ye).add(s, i)), p(z, ao, e.timeStamp), zt(e);
    }
  }
  static _cleanup(e) {
    e && (this._currentDrawId = -1, this._currentParent = null, p(z, ye, null), p(z, ro, null), p(z, Ir, null), p(z, ao, NaN)), n(z, no) && (n(z, no).abort(), p(z, no, null), p(z, Dr, NaN), p(z, Fr, null));
  }
  static _endDraw(e) {
    const s = this._currentParent;
    if (s) {
      if (s.toggleDrawing(!0), this._cleanup(!1), (e == null ? void 0 : e.target) === s.div && s.drawLayer.updateProperties(this._currentDrawId, n(z, ye).end(e.offsetX, e.offsetY)), this.supportMultipleDrawings) {
        const i = n(z, ye), r = this._currentDrawId, a = i.getLastElement();
        s.addCommands({
          cmd: () => {
            s.drawLayer.updateProperties(r, i.setLastElement(a));
          },
          undo: () => {
            s.drawLayer.updateProperties(r, i.removeLastElement());
          },
          mustExec: !1,
          type: ht.DRAW_STEP
        });
        return;
      }
      this.endDrawing(!1);
    }
  }
  static endDrawing(e) {
    const s = this._currentParent;
    if (!s)
      return null;
    if (s.toggleDrawing(!0), s.cleanUndoStack(ht.DRAW_STEP), !n(z, ye).isEmpty()) {
      const {
        pageDimensions: [i, r],
        scale: a
      } = s, o = s.createAndAddNewEditor({
        offsetX: 0,
        offsetY: 0
      }, !1, {
        drawId: this._currentDrawId,
        drawOutlines: n(z, ye).getOutlines(i * a, r * a, a, this._INNER_MARGIN),
        drawingOptions: n(z, ro),
        mustBeCommitted: !e
      });
      return this._cleanup(!0), o;
    }
    return s.drawLayer.remove(this._currentDrawId), this._cleanup(!0), null;
  }
  createDrawingOptions(e) {
  }
  static deserializeDraw(e, s, i, r, a, o) {
    Dt("Not implemented");
  }
  static async deserialize(e, s, i) {
    var u, f;
    const {
      rawDims: {
        pageWidth: r,
        pageHeight: a,
        pageX: o,
        pageY: l
      }
    } = s.viewport, h = this.deserializeDraw(o, l, r, a, this._INNER_MARGIN, e), c = await super.deserialize(e, s, i);
    return c.createDrawingOptions(e), b(u = c, pt, jp).call(u, {
      drawOutlines: h
    }), b(f = c, pt, Hh).call(f), c.onScaleChanging(), c.rotate(), c;
  }
  serializeDraw(e) {
    const [s, i] = this.pageTranslation, [r, a] = this.pageDimensions;
    return n(this, Is).serialize([s, i, r, a], e);
  }
  renderAnnotationElement(e) {
    return e.updateEdited({
      rect: this.getPDFRect()
    }), null;
  }
  static canCreateNewEmptyEditor() {
    return !1;
  }
};
Is = new WeakMap(), th = new WeakMap(), ye = new WeakMap(), no = new WeakMap(), ro = new WeakMap(), Dr = new WeakMap(), Ir = new WeakMap(), Fr = new WeakMap(), ao = new WeakMap(), pt = new WeakSet(), jp = function({
  drawOutlines: e,
  drawId: s,
  drawingOptions: i
}) {
  p(this, Is, e), this._drawingOptions || (this._drawingOptions = i), this.annotationElementId || this._uiManager.a11yAlert(`pdfjs-editor-${this.editorType}-added-alert`), s >= 0 ? (this._drawId = s, this.parent.drawLayer.finalizeDraw(s, e.defaultProperties)) : this._drawId = b(this, pt, Wp).call(this, e, this.parent), b(this, pt, Uh).call(this, e.box);
}, Wp = function(e, s) {
  const {
    id: i
  } = s.drawLayer.draw(z._mergeSVGProperties(this._drawingOptions.toSVGProperties(), e.defaultSVGProperties), !1, !1);
  return i;
}, Xp = function() {
  this._drawId === null || !this.parent || (this.parent.drawLayer.remove(this._drawId), this._drawId = null, this._drawingOptions.reset());
}, Hh = function(e = this.parent) {
  if (!(this._drawId !== null && this.parent === e)) {
    if (this._drawId !== null) {
      this.parent.drawLayer.updateParent(this._drawId, e.drawLayer);
      return;
    }
    this._drawingOptions.updateAll(), this._drawId = b(this, pt, Wp).call(this, n(this, Is), e);
  }
}, y0 = function([e, s, i, r]) {
  const {
    parentDimensions: [a, o],
    rotation: l
  } = this;
  switch (l) {
    case 90:
      return [s, 1 - e, i * (o / a), r * (a / o)];
    case 180:
      return [1 - e, 1 - s, i, r];
    case 270:
      return [1 - s, e, i * (o / a), r * (a / o)];
    default:
      return [e, s, i, r];
  }
}, Tu = function() {
  const {
    x: e,
    y: s,
    width: i,
    height: r,
    parentDimensions: [a, o],
    rotation: l
  } = this;
  switch (l) {
    case 90:
      return [1 - s, e, i * (a / o), r * (o / a)];
    case 180:
      return [1 - e, 1 - s, i, r];
    case 270:
      return [s, 1 - e, i * (a / o), r * (o / a)];
    default:
      return [e, s, i, r];
  }
}, Uh = function(e) {
  [this.x, this.y, this.width, this.height] = b(this, pt, y0).call(this, e), this.div && (this.fixAndSetPosition(), this.setDims()), this._onResized();
}, Mo = function() {
  const {
    x: e,
    y: s,
    width: i,
    height: r,
    rotation: a,
    parentRotation: o,
    parentDimensions: [l, h]
  } = this;
  switch ((a * 4 + o) / 90) {
    case 1:
      return [1 - s - r, e, r, i];
    case 2:
      return [1 - e - i, 1 - s - r, i, r];
    case 3:
      return [s, 1 - e - i, r, i];
    case 4:
      return [e, s - i * (l / h), r * (h / l), i * (l / h)];
    case 5:
      return [1 - s, e, i * (l / h), r * (h / l)];
    case 6:
      return [1 - e - r * (h / l), 1 - s, r * (h / l), i * (l / h)];
    case 7:
      return [s - i * (l / h), 1 - e - r * (h / l), i * (l / h), r * (h / l)];
    case 8:
      return [e - i, s - r, i, r];
    case 9:
      return [1 - s, e - i, r, i];
    case 10:
      return [1 - e, 1 - s, i, r];
    case 11:
      return [s - r, 1 - e, r, i];
    case 12:
      return [e - r * (h / l), s, r * (h / l), i * (l / h)];
    case 13:
      return [1 - s - i * (l / h), e - r * (h / l), i * (l / h), r * (h / l)];
    case 14:
      return [1 - e, 1 - s - i * (l / h), r * (h / l), i * (l / h)];
    case 15:
      return [s, 1 - e, i * (l / h), r * (h / l)];
    default:
      return [e, s, i, r];
  }
}, L(z, "_currentDrawId", -1), L(z, "_currentParent", null), g(z, ye, null), g(z, no, null), g(z, ro, null), g(z, Dr, NaN), g(z, Ir, null), g(z, Fr, null), g(z, ao, NaN), L(z, "_INNER_MARGIN", 3);
let zu = z;
var Wi, Ae, we, oo, eh, Qe, Le, si, lo, ho, co, sh, xu;
class zA {
  constructor(t, e, s, i, r, a) {
    g(this, sh);
    g(this, Wi, new Float64Array(6));
    g(this, Ae);
    g(this, we);
    g(this, oo);
    g(this, eh);
    g(this, Qe);
    g(this, Le, "");
    g(this, si, 0);
    g(this, lo, new Hd());
    g(this, ho);
    g(this, co);
    p(this, ho, s), p(this, co, i), p(this, oo, r), p(this, eh, a), [t, e] = b(this, sh, xu).call(this, t, e);
    const o = p(this, Ae, [NaN, NaN, NaN, NaN, t, e]);
    p(this, Qe, [t, e]), p(this, we, [{
      line: o,
      points: n(this, Qe)
    }]), n(this, Wi).set(o, 0);
  }
  updateProperty(t, e) {
    t === "stroke-width" && p(this, eh, e);
  }
  isEmpty() {
    return !n(this, we) || n(this, we).length === 0;
  }
  isCancellable() {
    return n(this, Qe).length <= 10;
  }
  add(t, e) {
    [t, e] = b(this, sh, xu).call(this, t, e);
    const [s, i, r, a] = n(this, Wi).subarray(2, 6), o = t - r, l = e - a;
    return Math.hypot(n(this, ho) * o, n(this, co) * l) <= 2 ? null : (n(this, Qe).push(t, e), isNaN(s) ? (n(this, Wi).set([r, a, t, e], 2), n(this, Ae).push(NaN, NaN, NaN, NaN, t, e), {
      path: {
        d: this.toSVGPath()
      }
    }) : (isNaN(n(this, Wi)[0]) && n(this, Ae).splice(6, 6), n(this, Wi).set([s, i, r, a, t, e], 0), n(this, Ae).push(...$.createBezierPoints(s, i, r, a, t, e)), {
      path: {
        d: this.toSVGPath()
      }
    }));
  }
  end(t, e) {
    const s = this.add(t, e);
    return s || (n(this, Qe).length === 2 ? {
      path: {
        d: this.toSVGPath()
      }
    } : null);
  }
  startNew(t, e, s, i, r) {
    p(this, ho, s), p(this, co, i), p(this, oo, r), [t, e] = b(this, sh, xu).call(this, t, e);
    const a = p(this, Ae, [NaN, NaN, NaN, NaN, t, e]);
    p(this, Qe, [t, e]);
    const o = n(this, we).at(-1);
    return o && (o.line = new Float32Array(o.line), o.points = new Float32Array(o.points)), n(this, we).push({
      line: a,
      points: n(this, Qe)
    }), n(this, Wi).set(a, 0), p(this, si, 0), this.toSVGPath(), null;
  }
  getLastElement() {
    return n(this, we).at(-1);
  }
  setLastElement(t) {
    return n(this, we) ? (n(this, we).push(t), p(this, Ae, t.line), p(this, Qe, t.points), p(this, si, 0), {
      path: {
        d: this.toSVGPath()
      }
    }) : n(this, lo).setLastElement(t);
  }
  removeLastElement() {
    if (!n(this, we))
      return n(this, lo).removeLastElement();
    n(this, we).pop(), p(this, Le, "");
    for (let t = 0, e = n(this, we).length; t < e; t++) {
      const {
        line: s,
        points: i
      } = n(this, we)[t];
      p(this, Ae, s), p(this, Qe, i), p(this, si, 0), this.toSVGPath();
    }
    return {
      path: {
        d: n(this, Le)
      }
    };
  }
  toSVGPath() {
    const t = $.svgRound(n(this, Ae)[4]), e = $.svgRound(n(this, Ae)[5]);
    if (n(this, Qe).length === 2)
      return p(this, Le, `${n(this, Le)} M ${t} ${e} Z`), n(this, Le);
    if (n(this, Qe).length <= 6) {
      const i = n(this, Le).lastIndexOf("M");
      p(this, Le, `${n(this, Le).slice(0, i)} M ${t} ${e}`), p(this, si, 6);
    }
    if (n(this, Qe).length === 4) {
      const i = $.svgRound(n(this, Ae)[10]), r = $.svgRound(n(this, Ae)[11]);
      return p(this, Le, `${n(this, Le)} L ${i} ${r}`), p(this, si, 12), n(this, Le);
    }
    const s = [];
    n(this, si) === 0 && (s.push(`M ${t} ${e}`), p(this, si, 6));
    for (let i = n(this, si), r = n(this, Ae).length; i < r; i += 6) {
      const [a, o, l, h, c, u] = n(this, Ae).slice(i, i + 6).map($.svgRound);
      s.push(`C${a} ${o} ${l} ${h} ${c} ${u}`);
    }
    return p(this, Le, n(this, Le) + s.join(" ")), p(this, si, n(this, Ae).length), n(this, Le);
  }
  getOutlines(t, e, s, i) {
    const r = n(this, we).at(-1);
    return r.line = new Float32Array(r.line), r.points = new Float32Array(r.points), n(this, lo).build(n(this, we), t, e, s, n(this, oo), n(this, eh), i), p(this, Wi, null), p(this, Ae, null), p(this, we, null), p(this, Le, null), n(this, lo);
  }
  get defaultSVGProperties() {
    return {
      root: {
        viewBox: "0 0 10000 10000"
      },
      rootClass: {
        draw: !0
      },
      bbox: [0, 0, 1, 1]
    };
  }
}
Wi = new WeakMap(), Ae = new WeakMap(), we = new WeakMap(), oo = new WeakMap(), eh = new WeakMap(), Qe = new WeakMap(), Le = new WeakMap(), si = new WeakMap(), lo = new WeakMap(), ho = new WeakMap(), co = new WeakMap(), sh = new WeakSet(), xu = function(t, e) {
  return $._normalizePoint(t, e, n(this, ho), n(this, co), n(this, oo));
};
var ts, Md, kd, Fs, Xi, qi, ih, nh, uo, Ie, rn, A0, w0, v0;
class Hd extends $ {
  constructor() {
    super(...arguments);
    g(this, Ie);
    g(this, ts);
    g(this, Md, 0);
    g(this, kd);
    g(this, Fs);
    g(this, Xi);
    g(this, qi);
    g(this, ih);
    g(this, nh);
    g(this, uo);
  }
  build(e, s, i, r, a, o, l) {
    p(this, Xi, s), p(this, qi, i), p(this, ih, r), p(this, nh, a), p(this, uo, o), p(this, kd, l ?? 0), p(this, Fs, e), b(this, Ie, w0).call(this);
  }
  get thickness() {
    return n(this, uo);
  }
  setLastElement(e) {
    return n(this, Fs).push(e), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  removeLastElement() {
    return n(this, Fs).pop(), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  toSVGPath() {
    const e = [];
    for (const {
      line: s
    } of n(this, Fs)) {
      if (e.push(`M${$.svgRound(s[4])} ${$.svgRound(s[5])}`), s.length === 6) {
        e.push("Z");
        continue;
      }
      if (s.length === 12 && isNaN(s[6])) {
        e.push(`L${$.svgRound(s[10])} ${$.svgRound(s[11])}`);
        continue;
      }
      for (let i = 6, r = s.length; i < r; i += 6) {
        const [a, o, l, h, c, u] = s.subarray(i, i + 6).map($.svgRound);
        e.push(`C${a} ${o} ${l} ${h} ${c} ${u}`);
      }
    }
    return e.join("");
  }
  serialize([e, s, i, r], a) {
    const o = [], l = [], [h, c, u, f] = b(this, Ie, A0).call(this);
    let m, A, y, v, w, S, E, _, C;
    switch (n(this, nh)) {
      case 0:
        C = $._rescale, m = e, A = s + r, y = i, v = -r, w = e + h * i, S = s + (1 - c - f) * r, E = e + (h + u) * i, _ = s + (1 - c) * r;
        break;
      case 90:
        C = $._rescaleAndSwap, m = e, A = s, y = i, v = r, w = e + c * i, S = s + h * r, E = e + (c + f) * i, _ = s + (h + u) * r;
        break;
      case 180:
        C = $._rescale, m = e + i, A = s, y = -i, v = r, w = e + (1 - h - u) * i, S = s + c * r, E = e + (1 - h) * i, _ = s + (c + f) * r;
        break;
      case 270:
        C = $._rescaleAndSwap, m = e + i, A = s + r, y = -i, v = -r, w = e + (1 - c - f) * i, S = s + (1 - h - u) * r, E = e + (1 - c) * i, _ = s + (1 - h) * r;
        break;
    }
    for (const {
      line: T,
      points: x
    } of n(this, Fs))
      o.push(C(T, m, A, y, v, a ? new Array(T.length) : null)), l.push(C(x, m, A, y, v, a ? new Array(x.length) : null));
    return {
      lines: o,
      points: l,
      rect: [w, S, E, _]
    };
  }
  static deserialize(e, s, i, r, a, {
    paths: {
      lines: o,
      points: l
    },
    rotation: h,
    thickness: c
  }) {
    const u = [];
    let f, m, A, y, v;
    switch (h) {
      case 0:
        v = $._rescale, f = -e / i, m = s / r + 1, A = 1 / i, y = -1 / r;
        break;
      case 90:
        v = $._rescaleAndSwap, f = -s / r, m = -e / i, A = 1 / r, y = 1 / i;
        break;
      case 180:
        v = $._rescale, f = e / i + 1, m = -s / r, A = -1 / i, y = 1 / r;
        break;
      case 270:
        v = $._rescaleAndSwap, f = s / r + 1, m = e / i + 1, A = -1 / r, y = -1 / i;
        break;
    }
    if (!o) {
      o = [];
      for (const S of l) {
        const E = S.length;
        if (E === 2) {
          o.push(new Float32Array([NaN, NaN, NaN, NaN, S[0], S[1]]));
          continue;
        }
        if (E === 4) {
          o.push(new Float32Array([NaN, NaN, NaN, NaN, S[0], S[1], NaN, NaN, NaN, NaN, S[2], S[3]]));
          continue;
        }
        const _ = new Float32Array(3 * (E - 2));
        o.push(_);
        let [C, T, x, R] = S.subarray(0, 4);
        _.set([NaN, NaN, NaN, NaN, C, T], 0);
        for (let M = 4; M < E; M += 2) {
          const D = S[M], k = S[M + 1];
          _.set($.createBezierPoints(C, T, x, R, D, k), (M - 2) * 3), [C, T, x, R] = [x, R, D, k];
        }
      }
    }
    for (let S = 0, E = o.length; S < E; S++)
      u.push({
        line: v(o[S].map((_) => _ ?? NaN), f, m, A, y),
        points: v(l[S].map((_) => _ ?? NaN), f, m, A, y)
      });
    const w = new this.prototype.constructor();
    return w.build(u, i, r, 1, h, c, a), w;
  }
  get box() {
    return n(this, ts);
  }
  updateProperty(e, s) {
    return e === "stroke-width" ? b(this, Ie, v0).call(this, s) : null;
  }
  updateParentDimensions([e, s], i) {
    const [r, a] = b(this, Ie, rn).call(this);
    p(this, Xi, e), p(this, qi, s), p(this, ih, i);
    const [o, l] = b(this, Ie, rn).call(this), h = o - r, c = l - a, u = n(this, ts);
    return u[0] -= h, u[1] -= c, u[2] += 2 * h, u[3] += 2 * c, u;
  }
  updateRotation(e) {
    return p(this, Md, e), {
      path: {
        transform: this.rotationTransform
      }
    };
  }
  get viewBox() {
    return n(this, ts).map($.svgRound).join(" ");
  }
  get defaultProperties() {
    const [e, s] = n(this, ts);
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${$.svgRound(e)} ${$.svgRound(s)}`
      }
    };
  }
  get rotationTransform() {
    const [, , e, s] = n(this, ts);
    let i = 0, r = 0, a = 0, o = 0, l = 0, h = 0;
    switch (n(this, Md)) {
      case 90:
        r = s / e, a = -e / s, l = e;
        break;
      case 180:
        i = -1, o = -1, l = e, h = s;
        break;
      case 270:
        r = -s / e, a = e / s, h = s;
        break;
      default:
        return "";
    }
    return `matrix(${i} ${r} ${a} ${o} ${$.svgRound(l)} ${$.svgRound(h)})`;
  }
  getPathResizingSVGProperties([e, s, i, r]) {
    const [a, o] = b(this, Ie, rn).call(this), [l, h, c, u] = n(this, ts);
    if (Math.abs(c - a) <= $.PRECISION || Math.abs(u - o) <= $.PRECISION) {
      const v = e + i / 2 - (l + c / 2), w = s + r / 2 - (h + u / 2);
      return {
        path: {
          "transform-origin": `${$.svgRound(e)} ${$.svgRound(s)}`,
          transform: `${this.rotationTransform} translate(${v} ${w})`
        }
      };
    }
    const f = (i - 2 * a) / (c - 2 * a), m = (r - 2 * o) / (u - 2 * o), A = c / i, y = u / r;
    return {
      path: {
        "transform-origin": `${$.svgRound(l)} ${$.svgRound(h)}`,
        transform: `${this.rotationTransform} scale(${A} ${y}) translate(${$.svgRound(a)} ${$.svgRound(o)}) scale(${f} ${m}) translate(${$.svgRound(-a)} ${$.svgRound(-o)})`
      }
    };
  }
  getPathResizedSVGProperties([e, s, i, r]) {
    const [a, o] = b(this, Ie, rn).call(this), l = n(this, ts), [h, c, u, f] = l;
    if (l[0] = e, l[1] = s, l[2] = i, l[3] = r, Math.abs(u - a) <= $.PRECISION || Math.abs(f - o) <= $.PRECISION) {
      const w = e + i / 2 - (h + u / 2), S = s + r / 2 - (c + f / 2);
      for (const {
        line: E,
        points: _
      } of n(this, Fs))
        $._translate(E, w, S, E), $._translate(_, w, S, _);
      return {
        root: {
          viewBox: this.viewBox
        },
        path: {
          "transform-origin": `${$.svgRound(e)} ${$.svgRound(s)}`,
          transform: this.rotationTransform || null,
          d: this.toSVGPath()
        }
      };
    }
    const m = (i - 2 * a) / (u - 2 * a), A = (r - 2 * o) / (f - 2 * o), y = -m * (h + a) + e + a, v = -A * (c + o) + s + o;
    if (m !== 1 || A !== 1 || y !== 0 || v !== 0)
      for (const {
        line: w,
        points: S
      } of n(this, Fs))
        $._rescale(w, y, v, m, A, w), $._rescale(S, y, v, m, A, S);
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${$.svgRound(e)} ${$.svgRound(s)}`,
        transform: this.rotationTransform || null,
        d: this.toSVGPath()
      }
    };
  }
  getPathTranslatedSVGProperties([e, s], i) {
    const [r, a] = i, o = n(this, ts), l = e - o[0], h = s - o[1];
    if (n(this, Xi) === r && n(this, qi) === a)
      for (const {
        line: c,
        points: u
      } of n(this, Fs))
        $._translate(c, l, h, c), $._translate(u, l, h, u);
    else {
      const c = n(this, Xi) / r, u = n(this, qi) / a;
      p(this, Xi, r), p(this, qi, a);
      for (const {
        line: f,
        points: m
      } of n(this, Fs))
        $._rescale(f, l, h, c, u, f), $._rescale(m, l, h, c, u, m);
      o[2] *= c, o[3] *= u;
    }
    return o[0] = e, o[1] = s, {
      root: {
        viewBox: this.viewBox
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${$.svgRound(e)} ${$.svgRound(s)}`
      }
    };
  }
  get defaultSVGProperties() {
    const e = n(this, ts);
    return {
      root: {
        viewBox: this.viewBox
      },
      rootClass: {
        draw: !0
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${$.svgRound(e[0])} ${$.svgRound(e[1])}`,
        transform: this.rotationTransform || null
      },
      bbox: e
    };
  }
}
ts = new WeakMap(), Md = new WeakMap(), kd = new WeakMap(), Fs = new WeakMap(), Xi = new WeakMap(), qi = new WeakMap(), ih = new WeakMap(), nh = new WeakMap(), uo = new WeakMap(), Ie = new WeakSet(), rn = function(e = n(this, uo)) {
  const s = n(this, kd) + e / 2 * n(this, ih);
  return n(this, nh) % 180 === 0 ? [s / n(this, Xi), s / n(this, qi)] : [s / n(this, qi), s / n(this, Xi)];
}, A0 = function() {
  const [e, s, i, r] = n(this, ts), [a, o] = b(this, Ie, rn).call(this, 0);
  return [e + a, s + o, i - 2 * a, r - 2 * o];
}, w0 = function() {
  const e = p(this, ts, new Float32Array([1 / 0, 1 / 0, -1 / 0, -1 / 0]));
  for (const {
    line: r
  } of n(this, Fs)) {
    if (r.length <= 12) {
      for (let l = 4, h = r.length; l < h; l += 6)
        V.pointBoundingBox(r[l], r[l + 1], e);
      continue;
    }
    let a = r[4], o = r[5];
    for (let l = 6, h = r.length; l < h; l += 6) {
      const [c, u, f, m, A, y] = r.subarray(l, l + 6);
      V.bezierBoundingBox(a, o, c, u, f, m, A, y, e), a = A, o = y;
    }
  }
  const [s, i] = b(this, Ie, rn).call(this);
  e[0] = je(e[0] - s, 0, 1), e[1] = je(e[1] - i, 0, 1), e[2] = je(e[2] + s, 0, 1), e[3] = je(e[3] + i, 0, 1), e[2] -= e[0], e[3] -= e[1];
}, v0 = function(e) {
  const [s, i] = b(this, Ie, rn).call(this);
  p(this, uo, e);
  const [r, a] = b(this, Ie, rn).call(this), [o, l] = [r - s, a - i], h = n(this, ts);
  return h[0] -= o, h[1] -= l, h[2] += 2 * o, h[3] += 2 * l, h;
};
class bf extends b0 {
  constructor(t) {
    super(), this._viewParameters = t, super.updateProperties({
      fill: "none",
      stroke: Ft._defaultLineColor,
      "stroke-opacity": 1,
      "stroke-width": 1,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-miterlimit": 10
    });
  }
  updateSVGProperty(t, e) {
    t === "stroke-width" && (e ?? (e = this["stroke-width"]), e *= this._viewParameters.realScale), super.updateSVGProperty(t, e);
  }
  clone() {
    const t = new bf(this._viewParameters);
    return t.updateAll(this), t;
  }
}
var cf, E0;
const Fo = class Fo extends zu {
  constructor(e) {
    super({
      ...e,
      name: "inkEditor"
    });
    g(this, cf);
    this._willKeepAspectRatio = !0, this.defaultL10nId = "pdfjs-editor-ink-editor";
  }
  static initialize(e, s) {
    Ft.initialize(e, s), this._defaultDrawingOptions = new bf(s.viewParameters);
  }
  static getDefaultDrawingOptions(e) {
    const s = this._defaultDrawingOptions.clone();
    return s.updateProperties(e), s;
  }
  static get supportMultipleDrawings() {
    return !0;
  }
  static get typesMap() {
    return it(this, "typesMap", /* @__PURE__ */ new Map([[ht.INK_THICKNESS, "stroke-width"], [ht.INK_COLOR, "stroke"], [ht.INK_OPACITY, "stroke-opacity"]]));
  }
  static createDrawerInstance(e, s, i, r, a) {
    return new zA(e, s, i, r, a, this._defaultDrawingOptions["stroke-width"]);
  }
  static deserializeDraw(e, s, i, r, a, o) {
    return Hd.deserialize(e, s, i, r, a, o);
  }
  static async deserialize(e, s, i) {
    let r = null;
    if (e instanceof Sg) {
      const {
        data: {
          inkLists: o,
          rect: l,
          rotation: h,
          id: c,
          color: u,
          opacity: f,
          borderStyle: {
            rawWidth: m
          },
          popupRef: A,
          richText: y,
          contentsObj: v,
          creationDate: w,
          modificationDate: S
        },
        parent: {
          page: {
            pageNumber: E
          }
        }
      } = e;
      r = e = {
        annotationType: Z.INK,
        color: Array.from(u),
        thickness: m,
        opacity: f,
        paths: {
          points: o
        },
        boxes: null,
        pageIndex: E - 1,
        rect: l.slice(0),
        rotation: h,
        annotationElementId: c,
        id: c,
        deleted: !1,
        popupRef: A,
        richText: y,
        comment: (v == null ? void 0 : v.str) || null,
        creationDate: w,
        modificationDate: S
      };
    }
    const a = await super.deserialize(e, s, i);
    return a._initialData = r, e.comment && a.setCommentData(e), a;
  }
  get toolbarButtons() {
    return this._colorPicker || (this._colorPicker = new Uu(this)), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return ht.INK_COLOR;
  }
  get color() {
    return this._drawingOptions.stroke;
  }
  get opacity() {
    return this._drawingOptions["stroke-opacity"];
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    super.onScaleChanging();
    const {
      _drawId: e,
      _drawingOptions: s,
      parent: i
    } = this;
    s.updateSVGProperty("stroke-width"), i.drawLayer.updateProperties(e, s.toSVGProperties());
  }
  static onScaleChangingWhenDrawing() {
    const e = this._currentParent;
    e && (super.onScaleChangingWhenDrawing(), this._defaultDrawingOptions.updateSVGProperty("stroke-width"), e.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  createDrawingOptions({
    color: e,
    thickness: s,
    opacity: i
  }) {
    this._drawingOptions = Fo.getDefaultDrawingOptions({
      stroke: V.makeHexColor(...e),
      "stroke-width": s,
      "stroke-opacity": i
    });
  }
  serialize(e = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const {
      lines: s,
      points: i
    } = this.serializeDraw(e), {
      _drawingOptions: {
        stroke: r,
        "stroke-opacity": a,
        "stroke-width": o
      }
    } = this, l = Object.assign(super.serialize(e), {
      color: Ft._colorManager.convert(r),
      opacity: a,
      thickness: o,
      paths: {
        lines: s,
        points: i
      }
    });
    return this.addComment(l), e ? (l.isCopy = !0, l) : this.annotationElementId && !b(this, cf, E0).call(this, l) ? null : (l.id = this.annotationElementId, l);
  }
  renderAnnotationElement(e) {
    if (this.deleted)
      return e.hide(), null;
    const {
      points: s,
      rect: i
    } = this.serializeDraw(!1);
    return e.updateEdited({
      rect: i,
      thickness: this._drawingOptions["stroke-width"],
      points: s,
      popup: this.comment
    }), null;
  }
};
cf = new WeakSet(), E0 = function(e) {
  const {
    color: s,
    thickness: i,
    opacity: r,
    pageIndex: a
  } = this._initialData;
  return this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized || e.color.some((o, l) => o !== s[l]) || e.thickness !== i || e.opacity !== r || e.pageIndex !== a;
}, L(Fo, "_type", "ink"), L(Fo, "_editorType", Z.INK), L(Fo, "_defaultDrawingOptions", null);
let qp = Fo;
class Yp extends Hd {
  toSVGPath() {
    let t = super.toSVGPath();
    return t.endsWith("Z") || (t += "Z"), t;
  }
}
const eu = 8, vh = 3;
var fo, bt, Kp, Ai, S0, _0, Zp, Pu, C0, T0, x0, Jp, Qp, P0;
class Ji {
  static extractContoursFromText(t, {
    fontFamily: e,
    fontStyle: s,
    fontWeight: i
  }, r, a, o, l) {
    let h = new OffscreenCanvas(1, 1), c = h.getContext("2d", {
      alpha: !1
    });
    const u = 200, f = c.font = `${s} ${i} ${u}px ${e}`, {
      actualBoundingBoxLeft: m,
      actualBoundingBoxRight: A,
      actualBoundingBoxAscent: y,
      actualBoundingBoxDescent: v,
      fontBoundingBoxAscent: w,
      fontBoundingBoxDescent: S,
      width: E
    } = c.measureText(t), _ = 1.5, C = Math.ceil(Math.max(Math.abs(m) + Math.abs(A) || 0, E) * _), T = Math.ceil(Math.max(Math.abs(y) + Math.abs(v) || u, Math.abs(w) + Math.abs(S) || u) * _);
    h = new OffscreenCanvas(C, T), c = h.getContext("2d", {
      alpha: !0,
      willReadFrequently: !0
    }), c.font = f, c.filter = "grayscale(1)", c.fillStyle = "white", c.fillRect(0, 0, C, T), c.fillStyle = "black", c.fillText(t, C * (_ - 1) / 2, T * (3 - _) / 2);
    const x = b(this, bt, Jp).call(this, c.getImageData(0, 0, C, T).data), R = b(this, bt, x0).call(this, x), M = b(this, bt, Qp).call(this, R), D = b(this, bt, Zp).call(this, x, C, T, M);
    return this.processDrawnLines({
      lines: {
        curves: D,
        width: C,
        height: T
      },
      pageWidth: r,
      pageHeight: a,
      rotation: o,
      innerMargin: l,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static process(t, e, s, i, r) {
    const [a, o, l] = b(this, bt, P0).call(this, t), [h, c] = b(this, bt, T0).call(this, a, o, l, Math.hypot(o, l) * n(this, fo).sigmaSFactor, n(this, fo).sigmaR, n(this, fo).kernelSize), u = b(this, bt, Qp).call(this, c), f = b(this, bt, Zp).call(this, h, o, l, u);
    return this.processDrawnLines({
      lines: {
        curves: f,
        width: o,
        height: l
      },
      pageWidth: e,
      pageHeight: s,
      rotation: i,
      innerMargin: r,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static processDrawnLines({
    lines: t,
    pageWidth: e,
    pageHeight: s,
    rotation: i,
    innerMargin: r,
    mustSmooth: a,
    areContours: o
  }) {
    i % 180 !== 0 && ([e, s] = [s, e]);
    const {
      curves: l,
      width: h,
      height: c
    } = t, u = t.thickness ?? 0, f = [], m = Math.min(e / h, s / c), A = m / e, y = m / s, v = [];
    for (const {
      points: S
    } of l) {
      const E = a ? b(this, bt, C0).call(this, S) : S;
      if (!E)
        continue;
      v.push(E);
      const _ = E.length, C = new Float32Array(_), T = new Float32Array(3 * (_ === 2 ? 2 : _ - 2));
      if (f.push({
        line: T,
        points: C
      }), _ === 2) {
        C[0] = E[0] * A, C[1] = E[1] * y, T.set([NaN, NaN, NaN, NaN, C[0], C[1]], 0);
        continue;
      }
      let [x, R, M, D] = E;
      x *= A, R *= y, M *= A, D *= y, C.set([x, R, M, D], 0), T.set([NaN, NaN, NaN, NaN, x, R], 0);
      for (let k = 4; k < _; k += 2) {
        const N = C[k] = E[k] * A, X = C[k + 1] = E[k + 1] * y;
        T.set($.createBezierPoints(x, R, M, D, N, X), (k - 2) * 3), [x, R, M, D] = [M, D, N, X];
      }
    }
    if (f.length === 0)
      return null;
    const w = o ? new Yp() : new Hd();
    return w.build(f, e, s, 1, i, o ? 0 : u, r), {
      outline: w,
      newCurves: v,
      areContours: o,
      thickness: u,
      width: h,
      height: c
    };
  }
  static async compressSignature({
    outlines: t,
    areContours: e,
    thickness: s,
    width: i,
    height: r
  }) {
    let a = 1 / 0, o = -1 / 0, l = 0;
    for (const E of t) {
      l += E.length;
      for (let _ = 2, C = E.length; _ < C; _++) {
        const T = E[_] - E[_ - 2];
        a = Math.min(a, T), o = Math.max(o, T);
      }
    }
    let h;
    a >= -128 && o <= 127 ? h = Int8Array : a >= -32768 && o <= 32767 ? h = Int16Array : h = Int32Array;
    const c = t.length, u = eu + vh * c, f = new Uint32Array(u);
    let m = 0;
    f[m++] = u * Uint32Array.BYTES_PER_ELEMENT + (l - 2 * c) * h.BYTES_PER_ELEMENT, f[m++] = 0, f[m++] = i, f[m++] = r, f[m++] = e ? 0 : 1, f[m++] = Math.max(0, Math.floor(s ?? 0)), f[m++] = c, f[m++] = h.BYTES_PER_ELEMENT;
    for (const E of t)
      f[m++] = E.length - 2, f[m++] = E[0], f[m++] = E[1];
    const A = new CompressionStream("deflate-raw"), y = A.writable.getWriter();
    await y.ready, y.write(f);
    const v = h.prototype.constructor;
    for (const E of t) {
      const _ = new v(E.length - 2);
      for (let C = 2, T = E.length; C < T; C++)
        _[C - 2] = E[C] - E[C - 2];
      y.write(_);
    }
    y.close();
    const w = await new Response(A.readable).arrayBuffer(), S = new Uint8Array(w);
    return Cm(S);
  }
  static async decompressSignature(t) {
    try {
      const e = py(t), {
        readable: s,
        writable: i
      } = new DecompressionStream("deflate-raw"), r = i.getWriter();
      await r.ready, r.write(e).then(async () => {
        await r.ready, await r.close();
      }).catch(() => {
      });
      let a = null, o = 0;
      for await (const E of s)
        a || (a = new Uint8Array(new Uint32Array(E.buffer, 0, 4)[0])), a.set(E, o), o += E.length;
      const l = new Uint32Array(a.buffer, 0, a.length >> 2), h = l[1];
      if (h !== 0)
        throw new Error(`Invalid version: ${h}`);
      const c = l[2], u = l[3], f = l[4] === 0, m = l[5], A = l[6], y = l[7], v = [], w = (eu + vh * A) * Uint32Array.BYTES_PER_ELEMENT;
      let S;
      switch (y) {
        case Int8Array.BYTES_PER_ELEMENT:
          S = new Int8Array(a.buffer, w);
          break;
        case Int16Array.BYTES_PER_ELEMENT:
          S = new Int16Array(a.buffer, w);
          break;
        case Int32Array.BYTES_PER_ELEMENT:
          S = new Int32Array(a.buffer, w);
          break;
      }
      o = 0;
      for (let E = 0; E < A; E++) {
        const _ = l[vh * E + eu], C = new Float32Array(_ + 2);
        v.push(C);
        for (let T = 0; T < vh - 1; T++)
          C[T] = l[vh * E + eu + T + 1];
        for (let T = 0; T < _; T++)
          C[T + 2] = C[T] + S[o++];
      }
      return {
        areContours: f,
        thickness: m,
        outlines: v,
        width: c,
        height: u
      };
    } catch (e) {
      return J(`decompressSignature: ${e}`), null;
    }
  }
}
fo = new WeakMap(), bt = new WeakSet(), Kp = function(t, e, s, i) {
  return s -= t, i -= e, s === 0 ? i > 0 ? 0 : 4 : s === 1 ? i + 6 : 2 - i;
}, Ai = new WeakMap(), S0 = function(t, e, s, i, r, a, o) {
  const l = b(this, bt, Kp).call(this, s, i, r, a);
  for (let h = 0; h < 8; h++) {
    const c = (-h + l - o + 16) % 8, u = n(this, Ai)[2 * c], f = n(this, Ai)[2 * c + 1];
    if (t[(s + u) * e + (i + f)] !== 0)
      return c;
  }
  return -1;
}, _0 = function(t, e, s, i, r, a, o) {
  const l = b(this, bt, Kp).call(this, s, i, r, a);
  for (let h = 0; h < 8; h++) {
    const c = (h + l + o + 16) % 8, u = n(this, Ai)[2 * c], f = n(this, Ai)[2 * c + 1];
    if (t[(s + u) * e + (i + f)] !== 0)
      return c;
  }
  return -1;
}, Zp = function(t, e, s, i) {
  const r = t.length, a = new Int32Array(r);
  for (let c = 0; c < r; c++)
    a[c] = t[c] <= i ? 1 : 0;
  for (let c = 1; c < s - 1; c++)
    a[c * e] = a[c * e + e - 1] = 0;
  for (let c = 0; c < e; c++)
    a[c] = a[e * s - 1 - c] = 0;
  let o = 1, l;
  const h = [];
  for (let c = 1; c < s - 1; c++) {
    l = 1;
    for (let u = 1; u < e - 1; u++) {
      const f = c * e + u, m = a[f];
      if (m === 0)
        continue;
      let A = c, y = u;
      if (m === 1 && a[f - 1] === 0)
        o += 1, y -= 1;
      else if (m >= 1 && a[f + 1] === 0)
        o += 1, y += 1, m > 1 && (l = m);
      else {
        m !== 1 && (l = Math.abs(m));
        continue;
      }
      const v = [u, c], w = y === u + 1, S = {
        isHole: w,
        points: v,
        id: o,
        parent: 0
      };
      h.push(S);
      let E;
      for (const k of h)
        if (k.id === l) {
          E = k;
          break;
        }
      E ? E.isHole ? S.parent = w ? E.parent : l : S.parent = w ? l : E.parent : S.parent = w ? l : 0;
      const _ = b(this, bt, S0).call(this, a, e, c, u, A, y, 0);
      if (_ === -1) {
        a[f] = -o, a[f] !== 1 && (l = Math.abs(a[f]));
        continue;
      }
      let C = n(this, Ai)[2 * _], T = n(this, Ai)[2 * _ + 1];
      const x = c + C, R = u + T;
      A = x, y = R;
      let M = c, D = u;
      for (; ; ) {
        const k = b(this, bt, _0).call(this, a, e, M, D, A, y, 1);
        C = n(this, Ai)[2 * k], T = n(this, Ai)[2 * k + 1];
        const N = M + C, X = D + T;
        v.push(X, N);
        const B = M * e + D;
        if (a[B + 1] === 0 ? a[B] = -o : a[B] === 1 && (a[B] = o), N === c && X === u && M === x && D === R) {
          a[f] !== 1 && (l = Math.abs(a[f]));
          break;
        } else
          A = M, y = D, M = N, D = X;
      }
    }
  }
  return h;
}, Pu = function(t, e, s, i) {
  if (s - e <= 4) {
    for (let x = e; x < s - 2; x += 2)
      i.push(t[x], t[x + 1]);
    return;
  }
  const r = t[e], a = t[e + 1], o = t[s - 4] - r, l = t[s - 3] - a, h = Math.hypot(o, l), c = o / h, u = l / h, f = c * a - u * r, m = l / o, A = 1 / h, y = Math.atan(m), v = Math.cos(y), w = Math.sin(y), S = A * (Math.abs(v) + Math.abs(w)), E = A * (1 - S + S ** 2), _ = Math.max(Math.atan(Math.abs(w + v) * E), Math.atan(Math.abs(w - v) * E));
  let C = 0, T = e;
  for (let x = e + 2; x < s - 2; x += 2) {
    const R = Math.abs(f - c * t[x + 1] + u * t[x]);
    R > C && (T = x, C = R);
  }
  C > (h * _) ** 2 ? (b(this, bt, Pu).call(this, t, e, T + 2, i), b(this, bt, Pu).call(this, t, T, s, i)) : i.push(r, a);
}, C0 = function(t) {
  const e = [], s = t.length;
  return b(this, bt, Pu).call(this, t, 0, s, e), e.push(t[s - 2], t[s - 1]), e.length <= 4 ? null : e;
}, T0 = function(t, e, s, i, r, a) {
  const o = new Float32Array(a ** 2), l = -2 * i ** 2, h = a >> 1;
  for (let y = 0; y < a; y++) {
    const v = (y - h) ** 2;
    for (let w = 0; w < a; w++)
      o[y * a + w] = Math.exp((v + (w - h) ** 2) / l);
  }
  const c = new Float32Array(256), u = -2 * r ** 2;
  for (let y = 0; y < 256; y++)
    c[y] = Math.exp(y ** 2 / u);
  const f = t.length, m = new Uint8Array(f), A = new Uint32Array(256);
  for (let y = 0; y < s; y++)
    for (let v = 0; v < e; v++) {
      const w = y * e + v, S = t[w];
      let E = 0, _ = 0;
      for (let T = 0; T < a; T++) {
        const x = y + T - h;
        if (!(x < 0 || x >= s))
          for (let R = 0; R < a; R++) {
            const M = v + R - h;
            if (M < 0 || M >= e)
              continue;
            const D = t[x * e + M], k = o[T * a + R] * c[Math.abs(D - S)];
            E += D * k, _ += k;
          }
      }
      const C = m[w] = Math.round(E / _);
      A[C]++;
    }
  return [m, A];
}, x0 = function(t) {
  const e = new Uint32Array(256);
  for (const s of t)
    e[s]++;
  return e;
}, Jp = function(t) {
  const e = t.length, s = new Uint8ClampedArray(e >> 2);
  let i = -1 / 0, r = 1 / 0;
  for (let o = 0, l = s.length; o < l; o++) {
    const h = s[o] = t[o << 2];
    i = Math.max(i, h), r = Math.min(r, h);
  }
  const a = 255 / (i - r);
  for (let o = 0, l = s.length; o < l; o++)
    s[o] = (s[o] - r) * a;
  return s;
}, Qp = function(t) {
  let e, s = -1 / 0, i = -1 / 0;
  const r = t.findIndex((l) => l !== 0);
  let a = r, o = r;
  for (e = r; e < 256; e++) {
    const l = t[e];
    l > s && (e - a > i && (i = e - a, o = e - 1), s = l, a = e);
  }
  for (e = o - 1; e >= 0 && !(t[e] > t[e + 1]); e--)
    ;
  return e;
}, P0 = function(t) {
  const e = t, {
    width: s,
    height: i
  } = t, {
    maxDim: r
  } = n(this, fo);
  let a = s, o = i;
  if (s > r || i > r) {
    let f = s, m = i, A = Math.log2(Math.max(s, i) / r);
    const y = Math.floor(A);
    A = A === y ? y - 1 : y;
    for (let w = 0; w < A; w++) {
      a = Math.ceil(f / 2), o = Math.ceil(m / 2);
      const S = new OffscreenCanvas(a, o);
      S.getContext("2d").drawImage(t, 0, 0, f, m, 0, 0, a, o), f = a, m = o, t !== e && t.close(), t = S.transferToImageBitmap();
    }
    const v = Math.min(r / a, r / o);
    a = Math.round(a * v), o = Math.round(o * v);
  }
  const h = new OffscreenCanvas(a, o).getContext("2d", {
    willReadFrequently: !0
  });
  h.fillStyle = "white", h.fillRect(0, 0, a, o), h.filter = "grayscale(1)", h.drawImage(t, 0, 0, t.width, t.height, 0, 0, a, o);
  const c = h.getImageData(0, 0, a, o).data;
  return [b(this, bt, Jp).call(this, c), a, o];
}, g(Ji, bt), g(Ji, fo, {
  maxDim: 512,
  sigmaSFactor: 0.02,
  sigmaR: 25,
  kernelSize: 16
}), g(Ji, Ai, new Int32Array([0, 1, -1, 1, -1, 0, -1, -1, 0, -1, 1, -1, 1, 0, 1, 1]));
class Cg extends b0 {
  constructor() {
    super(), super.updateProperties({
      fill: Ft._defaultLineColor,
      "stroke-width": 0
    });
  }
  clone() {
    const t = new Cg();
    return t.updateAll(this), t;
  }
}
class Tg extends bf {
  constructor(t) {
    super(t), super.updateProperties({
      stroke: Ft._defaultLineColor,
      "stroke-width": 1
    });
  }
  clone() {
    const t = new Tg(this._viewParameters);
    return t.updateAll(this), t;
  }
}
var Nr, Yi, Or, po;
const As = class As extends zu {
  constructor(e) {
    super({
      ...e,
      mustBeCommitted: !0,
      name: "signatureEditor"
    });
    g(this, Nr, !1);
    g(this, Yi, null);
    g(this, Or, null);
    g(this, po, null);
    this._willKeepAspectRatio = !0, p(this, Or, e.signatureData || null), p(this, Yi, null), this.defaultL10nId = "pdfjs-editor-signature-editor1";
  }
  static initialize(e, s) {
    Ft.initialize(e, s), this._defaultDrawingOptions = new Cg(), this._defaultDrawnSignatureOptions = new Tg(s.viewParameters);
  }
  static getDefaultDrawingOptions(e) {
    const s = this._defaultDrawingOptions.clone();
    return s.updateProperties(e), s;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  static get typesMap() {
    return it(this, "typesMap", /* @__PURE__ */ new Map());
  }
  static get isDrawer() {
    return !1;
  }
  get telemetryFinalData() {
    return {
      type: "signature",
      hasDescription: !!n(this, Yi)
    };
  }
  static computeTelemetryFinalData(e) {
    const s = e.get("hasDescription");
    return {
      hasAltText: s.get(!0) ?? 0,
      hasNoAltText: s.get(!1) ?? 0
    };
  }
  get isResizable() {
    return !0;
  }
  onScaleChanging() {
    this._drawId !== null && super.onScaleChanging();
  }
  render() {
    if (this.div)
      return this.div;
    let e, s;
    const {
      _isCopy: i
    } = this;
    if (i && (this._isCopy = !1, e = this.x, s = this.y), super.render(), this._drawId === null)
      if (n(this, Or)) {
        const {
          lines: r,
          mustSmooth: a,
          areContours: o,
          description: l,
          uuid: h,
          heightInPage: c
        } = n(this, Or), {
          rawDims: {
            pageWidth: u,
            pageHeight: f
          },
          rotation: m
        } = this.parent.viewport, A = Ji.processDrawnLines({
          lines: r,
          pageWidth: u,
          pageHeight: f,
          rotation: m,
          innerMargin: As._INNER_MARGIN,
          mustSmooth: a,
          areContours: o
        });
        this.addSignature(A, c, l, h);
      } else
        this.div.setAttribute("data-l10n-args", JSON.stringify({
          description: ""
        })), this.div.hidden = !0, this._uiManager.getSignature(this);
    else
      this.div.setAttribute("data-l10n-args", JSON.stringify({
        description: n(this, Yi) || ""
      }));
    return i && (this._isCopy = !0, this._moveAfterPaste(e, s)), this.div;
  }
  setUuid(e) {
    p(this, po, e), this.addEditToolbar();
  }
  getUuid() {
    return n(this, po);
  }
  get description() {
    return n(this, Yi);
  }
  set description(e) {
    p(this, Yi, e), this.div && (this.div.setAttribute("data-l10n-args", JSON.stringify({
      description: e
    })), super.addEditToolbar().then((s) => {
      s == null || s.updateEditSignatureButton(e);
    }));
  }
  getSignaturePreview() {
    const {
      newCurves: e,
      areContours: s,
      thickness: i,
      width: r,
      height: a
    } = n(this, Or), o = Math.max(r, a), l = Ji.processDrawnLines({
      lines: {
        curves: e.map((h) => ({
          points: h
        })),
        thickness: i,
        width: r,
        height: a
      },
      pageWidth: o,
      pageHeight: o,
      rotation: 0,
      innerMargin: 0,
      mustSmooth: !1,
      areContours: s
    });
    return {
      areContours: s,
      outline: l.outline
    };
  }
  get toolbarButtons() {
    return this._uiManager.signatureManager ? [["editSignature", this._uiManager.signatureManager]] : super.toolbarButtons;
  }
  addSignature(e, s, i, r) {
    const {
      x: a,
      y: o
    } = this, {
      outline: l
    } = p(this, Or, e);
    p(this, Nr, l instanceof Yp), this.description = i;
    let h;
    n(this, Nr) ? h = As.getDefaultDrawingOptions() : (h = As._defaultDrawnSignatureOptions.clone(), h.updateProperties({
      "stroke-width": l.thickness
    })), this._addOutlines({
      drawOutlines: l,
      drawingOptions: h
    });
    const [, c] = this.pageDimensions;
    let u = s / c;
    u = u >= 1 ? 0.5 : u, this.width *= u / this.height, this.width >= 1 && (u *= 0.9 / this.width, this.width = 0.9), this.height = u, this.setDims(), this.x = a, this.y = o, this.center(), this._onResized(), this.onScaleChanging(), this.rotate(), this._uiManager.addToAnnotationStorage(this), this.setUuid(r), this._reportTelemetry({
      action: "pdfjs.signature.inserted",
      data: {
        hasBeenSaved: !!r,
        hasDescription: !!i
      }
    }), this.div.hidden = !1;
  }
  getFromImage(e) {
    const {
      rawDims: {
        pageWidth: s,
        pageHeight: i
      },
      rotation: r
    } = this.parent.viewport;
    return Ji.process(e, s, i, r, As._INNER_MARGIN);
  }
  getFromText(e, s) {
    const {
      rawDims: {
        pageWidth: i,
        pageHeight: r
      },
      rotation: a
    } = this.parent.viewport;
    return Ji.extractContoursFromText(e, s, i, r, a, As._INNER_MARGIN);
  }
  getDrawnSignature(e) {
    const {
      rawDims: {
        pageWidth: s,
        pageHeight: i
      },
      rotation: r
    } = this.parent.viewport;
    return Ji.processDrawnLines({
      lines: e,
      pageWidth: s,
      pageHeight: i,
      rotation: r,
      innerMargin: As._INNER_MARGIN,
      mustSmooth: !1,
      areContours: !1
    });
  }
  createDrawingOptions({
    areContours: e,
    thickness: s
  }) {
    e ? this._drawingOptions = As.getDefaultDrawingOptions() : (this._drawingOptions = As._defaultDrawnSignatureOptions.clone(), this._drawingOptions.updateProperties({
      "stroke-width": s
    }));
  }
  serialize(e = !1) {
    if (this.isEmpty())
      return null;
    const {
      lines: s,
      points: i
    } = this.serializeDraw(e), {
      _drawingOptions: {
        "stroke-width": r
      }
    } = this, a = Object.assign(super.serialize(e), {
      isSignature: !0,
      areContours: n(this, Nr),
      color: [0, 0, 0],
      thickness: n(this, Nr) ? 0 : r
    });
    return this.addComment(a), e ? (a.paths = {
      lines: s,
      points: i
    }, a.uuid = n(this, po), a.isCopy = !0) : a.lines = s, n(this, Yi) && (a.accessibilityData = {
      type: "Figure",
      alt: n(this, Yi)
    }), a;
  }
  static deserializeDraw(e, s, i, r, a, o) {
    return o.areContours ? Yp.deserialize(e, s, i, r, a, o) : Hd.deserialize(e, s, i, r, a, o);
  }
  static async deserialize(e, s, i) {
    var a;
    const r = await super.deserialize(e, s, i);
    return p(r, Nr, e.areContours), r.description = ((a = e.accessibilityData) == null ? void 0 : a.alt) || "", p(r, po, e.uuid), r;
  }
};
Nr = new WeakMap(), Yi = new WeakMap(), Or = new WeakMap(), po = new WeakMap(), L(As, "_type", "signature"), L(As, "_editorType", Z.SIGNATURE), L(As, "_defaultDrawingOptions", null);
let tg = As;
var Ut, ve, Br, On, Hr, rh, Bn, go, Ki, Ns, ah, gt, $h, Vh, Ru, Mu, ku, sg, Lu, R0;
class eg extends Ft {
  constructor(e) {
    super({
      ...e,
      name: "stampEditor"
    });
    g(this, gt);
    g(this, Ut, null);
    g(this, ve, null);
    g(this, Br, null);
    g(this, On, null);
    g(this, Hr, null);
    g(this, rh, "");
    g(this, Bn, null);
    g(this, go, !1);
    g(this, Ki, null);
    g(this, Ns, !1);
    g(this, ah, !1);
    p(this, On, e.bitmapUrl), p(this, Hr, e.bitmapFile), this.defaultL10nId = "pdfjs-editor-stamp-editor";
  }
  static initialize(e, s) {
    Ft.initialize(e, s);
  }
  static isHandlingMimeForPasting(e) {
    return Fu.includes(e);
  }
  static paste(e, s) {
    s.pasteEditor({
      mode: Z.STAMP
    }, {
      bitmapFile: e.getAsFile()
    });
  }
  altTextFinish() {
    this._uiManager.useNewAltTextFlow && (this.div.hidden = !1), super.altTextFinish();
  }
  get telemetryFinalData() {
    var e;
    return {
      type: "stamp",
      hasAltText: !!((e = this.altTextData) != null && e.altText)
    };
  }
  static computeTelemetryFinalData(e) {
    const s = e.get("hasAltText");
    return {
      hasAltText: s.get(!0) ?? 0,
      hasNoAltText: s.get(!1) ?? 0
    };
  }
  async mlGuessAltText(e = null, s = !0) {
    if (this.hasAltTextData())
      return null;
    const {
      mlManager: i
    } = this._uiManager;
    if (!i)
      throw new Error("No ML.");
    if (!await i.isEnabledFor("altText"))
      throw new Error("ML isn't enabled for alt text.");
    const {
      data: r,
      width: a,
      height: o
    } = e || this.copyCanvas(null, null, !0).imageData, l = await i.guess({
      name: "altText",
      request: {
        data: r,
        width: a,
        height: o,
        channels: r.length / (a * o)
      }
    });
    if (!l)
      throw new Error("No response from the AI service.");
    if (l.error)
      throw new Error("Error from the AI service.");
    if (l.cancel)
      return null;
    if (!l.output)
      throw new Error("No valid response from the AI service.");
    const h = l.output;
    return await this.setGuessedAltText(h), s && !this.hasAltTextData() && (this.altTextData = {
      alt: h,
      decorative: !1
    }), h;
  }
  remove() {
    var e;
    n(this, ve) && (p(this, Ut, null), this._uiManager.imageManager.deleteId(n(this, ve)), (e = n(this, Bn)) == null || e.remove(), p(this, Bn, null), n(this, Ki) && (clearTimeout(n(this, Ki)), p(this, Ki, null))), super.remove();
  }
  rebuild() {
    if (!this.parent) {
      n(this, ve) && b(this, gt, Ru).call(this);
      return;
    }
    super.rebuild(), this.div !== null && (n(this, ve) && n(this, Bn) === null && b(this, gt, Ru).call(this), this.isAttachedToDOM || this.parent.add(this));
  }
  onceAdded(e) {
    this._isDraggable = !0, e && this.div.focus();
  }
  isEmpty() {
    return !(n(this, Br) || n(this, Ut) || n(this, On) || n(this, Hr) || n(this, ve) || n(this, go));
  }
  get toolbarButtons() {
    return [["altText", this.createAltText()]];
  }
  get isResizable() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let e, s;
    return this._isCopy && (e = this.x, s = this.y), super.render(), this.div.hidden = !0, this.createAltText(), n(this, go) || (n(this, Ut) ? b(this, gt, Mu).call(this) : b(this, gt, Ru).call(this)), this._isCopy && this._moveAfterPaste(e, s), this._uiManager.addShouldRescale(this), this.div;
  }
  setCanvas(e, s) {
    const {
      id: i,
      bitmap: r
    } = this._uiManager.imageManager.getFromCanvas(e, s);
    s.remove(), i && this._uiManager.imageManager.isValidId(i) && (p(this, ve, i), r && p(this, Ut, r), p(this, go, !1), b(this, gt, Mu).call(this));
  }
  _onResized() {
    this.onScaleChanging();
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    n(this, Ki) !== null && clearTimeout(n(this, Ki)), p(this, Ki, setTimeout(() => {
      p(this, Ki, null), b(this, gt, sg).call(this);
    }, 200));
  }
  copyCanvas(e, s, i = !1) {
    e || (e = 224);
    const {
      width: r,
      height: a
    } = n(this, Ut), o = new Si();
    let l = n(this, Ut), h = r, c = a, u = null;
    if (s) {
      if (r > s || a > s) {
        const x = Math.min(s / r, s / a);
        h = Math.floor(r * x), c = Math.floor(a * x);
      }
      u = document.createElement("canvas");
      const m = u.width = Math.ceil(h * o.sx), A = u.height = Math.ceil(c * o.sy);
      n(this, Ns) || (l = b(this, gt, ku).call(this, m, A));
      const y = u.getContext("2d");
      y.filter = this._uiManager.hcmFilter;
      let v = "white", w = "#cfcfd8";
      this._uiManager.hcmFilter !== "none" ? w = "black" : by.isDarkMode && (v = "#8f8f9d", w = "#42414d");
      const S = 15, E = S * o.sx, _ = S * o.sy, C = new OffscreenCanvas(E * 2, _ * 2), T = C.getContext("2d");
      T.fillStyle = v, T.fillRect(0, 0, E * 2, _ * 2), T.fillStyle = w, T.fillRect(0, 0, E, _), T.fillRect(E, _, E, _), y.fillStyle = y.createPattern(C, "repeat"), y.fillRect(0, 0, m, A), y.drawImage(l, 0, 0, l.width, l.height, 0, 0, m, A);
    }
    let f = null;
    if (i) {
      let m, A;
      if (o.symmetric && l.width < e && l.height < e)
        m = l.width, A = l.height;
      else if (l = n(this, Ut), r > e || a > e) {
        const w = Math.min(e / r, e / a);
        m = Math.floor(r * w), A = Math.floor(a * w), n(this, Ns) || (l = b(this, gt, ku).call(this, m, A));
      }
      const v = new OffscreenCanvas(m, A).getContext("2d", {
        willReadFrequently: !0
      });
      v.drawImage(l, 0, 0, l.width, l.height, 0, 0, m, A), f = {
        width: m,
        height: A,
        data: v.getImageData(0, 0, m, A).data
      };
    }
    return {
      canvas: u,
      width: h,
      height: c,
      imageData: f
    };
  }
  static async deserialize(e, s, i) {
    var v;
    let r = null, a = !1;
    if (e instanceof jb) {
      const {
        data: {
          rect: w,
          rotation: S,
          id: E,
          structParent: _,
          popupRef: C,
          richText: T,
          contentsObj: x,
          creationDate: R,
          modificationDate: M
        },
        container: D,
        parent: {
          page: {
            pageNumber: k
          }
        },
        canvas: N
      } = e;
      let X, B;
      N ? (delete e.canvas, {
        id: X,
        bitmap: B
      } = i.imageManager.getFromCanvas(D.id, N), N.remove()) : (a = !0, e._hasNoCanvas = !0);
      const Y = ((v = await s._structTree.getAriaAttributes(`${pg}${E}`)) == null ? void 0 : v.get("aria-label")) || "";
      r = e = {
        annotationType: Z.STAMP,
        bitmapId: X,
        bitmap: B,
        pageIndex: k - 1,
        rect: w.slice(0),
        rotation: S,
        annotationElementId: E,
        id: E,
        deleted: !1,
        accessibilityData: {
          decorative: !1,
          altText: Y
        },
        isSvg: !1,
        structParent: _,
        popupRef: C,
        richText: T,
        comment: (x == null ? void 0 : x.str) || null,
        creationDate: R,
        modificationDate: M
      };
    }
    const o = await super.deserialize(e, s, i), {
      rect: l,
      bitmap: h,
      bitmapUrl: c,
      bitmapId: u,
      isSvg: f,
      accessibilityData: m
    } = e;
    a ? (i.addMissingCanvas(e.id, o), p(o, go, !0)) : u && i.imageManager.isValidId(u) ? (p(o, ve, u), h && p(o, Ut, h)) : p(o, On, c), p(o, Ns, f);
    const [A, y] = o.pageDimensions;
    return o.width = (l[2] - l[0]) / A, o.height = (l[3] - l[1]) / y, m && (o.altTextData = m), o._initialData = r, e.comment && o.setCommentData(e), p(o, ah, !!r), o;
  }
  serialize(e = !1, s = null) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const i = Object.assign(super.serialize(e), {
      bitmapId: n(this, ve),
      isSvg: n(this, Ns)
    });
    if (this.addComment(i), e)
      return i.bitmapUrl = b(this, gt, Lu).call(this, !0), i.accessibilityData = this.serializeAltText(!0), i.isCopy = !0, i;
    const {
      decorative: r,
      altText: a
    } = this.serializeAltText(!1);
    if (!r && a && (i.accessibilityData = {
      type: "Figure",
      alt: a
    }), this.annotationElementId) {
      const l = b(this, gt, R0).call(this, i);
      return l.isSame ? null : (l.isSameAltText ? delete i.accessibilityData : i.accessibilityData.structParent = this._initialData.structParent ?? -1, i.id = this.annotationElementId, delete i.bitmapId, i);
    }
    if (s === null)
      return i;
    s.stamps || (s.stamps = /* @__PURE__ */ new Map());
    const o = n(this, Ns) ? (i.rect[2] - i.rect[0]) * (i.rect[3] - i.rect[1]) : null;
    if (!s.stamps.has(n(this, ve)))
      s.stamps.set(n(this, ve), {
        area: o,
        serialized: i
      }), i.bitmap = b(this, gt, Lu).call(this, !1);
    else if (n(this, Ns)) {
      const l = s.stamps.get(n(this, ve));
      o > l.area && (l.area = o, l.serialized.bitmap.close(), l.serialized.bitmap = b(this, gt, Lu).call(this, !1));
    }
    return i;
  }
  renderAnnotationElement(e) {
    return this.deleted ? (e.hide(), null) : (e.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
}
Ut = new WeakMap(), ve = new WeakMap(), Br = new WeakMap(), On = new WeakMap(), Hr = new WeakMap(), rh = new WeakMap(), Bn = new WeakMap(), go = new WeakMap(), Ki = new WeakMap(), Ns = new WeakMap(), ah = new WeakMap(), gt = new WeakSet(), $h = function(e, s = !1) {
  if (!e) {
    this.remove();
    return;
  }
  p(this, Ut, e.bitmap), s || (p(this, ve, e.id), p(this, Ns, e.isSvg)), e.file && p(this, rh, e.file.name), b(this, gt, Mu).call(this);
}, Vh = function() {
  if (p(this, Br, null), this._uiManager.enableWaiting(!1), !!n(this, Bn)) {
    if (this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && n(this, Ut)) {
      this.addEditToolbar().then(() => {
        this._editToolbar.hide(), this._uiManager.editAltText(this, !0);
      });
      return;
    }
    if (!this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && n(this, Ut)) {
      this._reportTelemetry({
        action: "pdfjs.image.image_added",
        data: {
          alt_text_modal: !1,
          alt_text_type: "empty"
        }
      });
      try {
        this.mlGuessAltText();
      } catch {
      }
    }
    this.div.focus();
  }
}, Ru = function() {
  if (n(this, ve)) {
    this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(n(this, ve)).then((i) => b(this, gt, $h).call(this, i, !0)).finally(() => b(this, gt, Vh).call(this));
    return;
  }
  if (n(this, On)) {
    const i = n(this, On);
    p(this, On, null), this._uiManager.enableWaiting(!0), p(this, Br, this._uiManager.imageManager.getFromUrl(i).then((r) => b(this, gt, $h).call(this, r)).finally(() => b(this, gt, Vh).call(this)));
    return;
  }
  if (n(this, Hr)) {
    const i = n(this, Hr);
    p(this, Hr, null), this._uiManager.enableWaiting(!0), p(this, Br, this._uiManager.imageManager.getFromFile(i).then((r) => b(this, gt, $h).call(this, r)).finally(() => b(this, gt, Vh).call(this)));
    return;
  }
  const e = document.createElement("input");
  e.type = "file", e.accept = Fu.join(",");
  const s = this._uiManager._signal;
  p(this, Br, new Promise((i) => {
    e.addEventListener("change", async () => {
      if (!e.files || e.files.length === 0)
        this.remove();
      else {
        this._uiManager.enableWaiting(!0);
        const r = await this._uiManager.imageManager.getFromFile(e.files[0]);
        this._reportTelemetry({
          action: "pdfjs.image.image_selected",
          data: {
            alt_text_modal: this._uiManager.useNewAltTextFlow
          }
        }), b(this, gt, $h).call(this, r);
      }
      i();
    }, {
      signal: s
    }), e.addEventListener("cancel", () => {
      this.remove(), i();
    }, {
      signal: s
    });
  }).finally(() => b(this, gt, Vh).call(this))), e.click();
}, Mu = function() {
  var h;
  const {
    div: e
  } = this;
  let {
    width: s,
    height: i
  } = n(this, Ut);
  const [r, a] = this.pageDimensions, o = 0.75;
  if (this.width)
    s = this.width * r, i = this.height * a;
  else if (s > o * r || i > o * a) {
    const c = Math.min(o * r / s, o * a / i);
    s *= c, i *= c;
  }
  this._uiManager.enableWaiting(!1);
  const l = p(this, Bn, document.createElement("canvas"));
  l.setAttribute("role", "img"), this.addContainer(l), this.width = s / r, this.height = i / a, this.setDims(), (h = this._initialOptions) != null && h.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, (!this._uiManager.useNewAltTextWhenAddingImage || !this._uiManager.useNewAltTextFlow || this.annotationElementId) && (e.hidden = !1), b(this, gt, sg).call(this), n(this, ah) || (this.parent.addUndoableEditor(this), p(this, ah, !0)), this._reportTelemetry({
    action: "inserted_image"
  }), n(this, rh) && this.div.setAttribute("aria-description", n(this, rh)), this.annotationElementId || this._uiManager.a11yAlert("pdfjs-editor-stamp-added-alert");
}, ku = function(e, s) {
  const {
    width: i,
    height: r
  } = n(this, Ut);
  let a = i, o = r, l = n(this, Ut);
  for (; a > 2 * e || o > 2 * s; ) {
    const h = a, c = o;
    a > 2 * e && (a = a >= 16384 ? Math.floor(a / 2) - 1 : Math.ceil(a / 2)), o > 2 * s && (o = o >= 16384 ? Math.floor(o / 2) - 1 : Math.ceil(o / 2));
    const u = new OffscreenCanvas(a, o);
    u.getContext("2d").drawImage(l, 0, 0, h, c, 0, 0, a, o), l = u.transferToImageBitmap();
  }
  return l;
}, sg = function() {
  const [e, s] = this.parentDimensions, {
    width: i,
    height: r
  } = this, a = new Si(), o = Math.ceil(i * e * a.sx), l = Math.ceil(r * s * a.sy), h = n(this, Bn);
  if (!h || h.width === o && h.height === l)
    return;
  h.width = o, h.height = l;
  const c = n(this, Ns) ? n(this, Ut) : b(this, gt, ku).call(this, o, l), u = h.getContext("2d");
  u.filter = this._uiManager.hcmFilter, u.drawImage(c, 0, 0, c.width, c.height, 0, 0, o, l);
}, Lu = function(e) {
  if (e) {
    if (n(this, Ns)) {
      const r = this._uiManager.imageManager.getSvgUrl(n(this, ve));
      if (r)
        return r;
    }
    const s = document.createElement("canvas");
    return {
      width: s.width,
      height: s.height
    } = n(this, Ut), s.getContext("2d").drawImage(n(this, Ut), 0, 0), s.toDataURL();
  }
  if (n(this, Ns)) {
    const [s, i] = this.pageDimensions, r = Math.round(this.width * s * jn.PDF_TO_CSS_UNITS), a = Math.round(this.height * i * jn.PDF_TO_CSS_UNITS), o = new OffscreenCanvas(r, a);
    return o.getContext("2d").drawImage(n(this, Ut), 0, 0, n(this, Ut).width, n(this, Ut).height, 0, 0, r, a), o.transferToImageBitmap();
  }
  return structuredClone(n(this, Ut));
}, R0 = function(e) {
  var o;
  const {
    pageIndex: s,
    accessibilityData: {
      altText: i
    }
  } = this._initialData, r = e.pageIndex === s, a = (((o = e.accessibilityData) == null ? void 0 : o.alt) || "") === i;
  return {
    isSame: !this.hasEditedComment && !this._hasBeenMoved && !this._hasBeenResized && r && a,
    isSameAltText: a
  };
}, L(eg, "_type", "stamp"), L(eg, "_editorType", Z.STAMP);
var mo, oh, Ur, $r, Hn, gs, Vr, lh, hh, wi, Un, Ee, $n, zr, ch, W, Gr, Lt, ig, M0, xi, ng, rg, Du;
const hi = class hi {
  constructor({
    uiManager: t,
    pageIndex: e,
    div: s,
    structTreeLayer: i,
    accessibilityManager: r,
    annotationLayer: a,
    drawLayer: o,
    textLayer: l,
    viewport: h,
    l10n: c
  }) {
    g(this, Lt);
    g(this, mo);
    g(this, oh, !1);
    g(this, Ur, null);
    g(this, $r, null);
    g(this, Hn, null);
    g(this, gs, /* @__PURE__ */ new Map());
    g(this, Vr, !1);
    g(this, lh, !1);
    g(this, hh, !1);
    g(this, wi, null);
    g(this, Un, null);
    g(this, Ee, null);
    g(this, $n, null);
    g(this, zr, null);
    g(this, ch, -1);
    g(this, W);
    const u = [...n(hi, Gr).values()];
    if (!hi._initialized) {
      hi._initialized = !0;
      for (const f of u)
        f.initialize(c, t);
    }
    t.registerEditorTypes(u), p(this, W, t), this.pageIndex = e, this.div = s, p(this, mo, r), p(this, Ur, a), this.viewport = h, p(this, Ee, l), this.drawLayer = o, this._structTree = i, n(this, W).addLayer(this);
  }
  get isEmpty() {
    return n(this, gs).size === 0;
  }
  get isInvisible() {
    return this.isEmpty && n(this, W).getMode() === Z.NONE;
  }
  updateToolbar(t) {
    n(this, W).updateToolbar(t);
  }
  updateMode(t = n(this, W).getMode()) {
    switch (b(this, Lt, Du).call(this), t) {
      case Z.NONE:
        this.div.classList.toggle("nonEditing", !0), this.disableTextSelection(), this.togglePointerEvents(!1), this.toggleAnnotationLayerPointerEvents(!0), this.disableClick();
        return;
      case Z.INK:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
        break;
      case Z.HIGHLIGHT:
        this.enableTextSelection(), this.togglePointerEvents(!1), this.disableClick();
        break;
      default:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
    }
    this.toggleAnnotationLayerPointerEvents(!1);
    const {
      classList: e
    } = this.div;
    if (e.toggle("nonEditing", !1), t === Z.POPUP)
      e.toggle("commentEditing", !0);
    else {
      e.toggle("commentEditing", !1);
      for (const s of n(hi, Gr).values())
        e.toggle(`${s._type}Editing`, t === s._editorType);
    }
    this.div.hidden = !1;
  }
  hasTextLayer(t) {
    var e;
    return t === ((e = n(this, Ee)) == null ? void 0 : e.div);
  }
  setEditingState(t) {
    n(this, W).setEditingState(t);
  }
  addCommands(t) {
    n(this, W).addCommands(t);
  }
  cleanUndoStack(t) {
    n(this, W).cleanUndoStack(t);
  }
  toggleDrawing(t = !1) {
    this.div.classList.toggle("drawing", !t);
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  toggleAnnotationLayerPointerEvents(t = !1) {
    var e;
    (e = n(this, Ur)) == null || e.div.classList.toggle("disabled", !t);
  }
  async enable() {
    var s;
    p(this, hh, !0), this.div.tabIndex = 0, this.togglePointerEvents(!0), this.div.classList.toggle("nonEditing", !1), (s = n(this, zr)) == null || s.abort(), p(this, zr, null);
    const t = /* @__PURE__ */ new Set();
    for (const i of n(this, Lt, ig))
      i.enableEditing(), i.show(!0), i.annotationElementId && (n(this, W).removeChangedExistingAnnotation(i), t.add(i.annotationElementId));
    const e = n(this, Ur);
    if (e)
      for (const i of e.getEditableAnnotations()) {
        if (i.hide(), n(this, W).isDeletedAnnotationElement(i.data.id) || t.has(i.data.id))
          continue;
        const r = await this.deserialize(i);
        r && (this.addOrRebuild(r), r.enableEditing());
      }
    p(this, hh, !1), n(this, W)._eventBus.dispatch("editorsrendered", {
      source: this,
      pageNumber: this.pageIndex + 1
    });
  }
  disable() {
    var s;
    if (p(this, lh, !0), this.div.tabIndex = -1, this.togglePointerEvents(!1), this.div.classList.toggle("nonEditing", !0), n(this, Ee) && !n(this, zr)) {
      p(this, zr, new AbortController());
      const i = n(this, W).combinedSignal(n(this, zr));
      n(this, Ee).div.addEventListener("pointerdown", (r) => {
        const {
          clientX: o,
          clientY: l,
          timeStamp: h
        } = r, c = n(this, ch);
        if (h - c > 500) {
          p(this, ch, h);
          return;
        }
        p(this, ch, -1);
        const {
          classList: u
        } = this.div;
        u.toggle("getElements", !0);
        const f = document.elementsFromPoint(o, l);
        if (u.toggle("getElements", !1), !this.div.contains(f[0]))
          return;
        let m;
        const A = new RegExp(`^${Gh}[0-9]+$`);
        for (const v of f)
          if (A.test(v.id)) {
            m = v.id;
            break;
          }
        if (!m)
          return;
        const y = n(this, gs).get(m);
        (y == null ? void 0 : y.annotationElementId) === null && (r.stopPropagation(), r.preventDefault(), y.dblclick(r));
      }, {
        signal: i,
        capture: !0
      });
    }
    const t = n(this, Ur);
    if (t) {
      const i = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
      for (const o of n(this, Lt, ig)) {
        if (o.disableEditing(), !o.annotationElementId) {
          o.updateFakeAnnotationElement(t);
          continue;
        }
        if (o.serialize() !== null) {
          i.set(o.annotationElementId, o);
          continue;
        } else
          r.set(o.annotationElementId, o);
        (s = this.getEditableAnnotation(o.annotationElementId)) == null || s.show(), o.remove();
      }
      const a = t.getEditableAnnotations();
      for (const o of a) {
        const {
          id: l
        } = o.data;
        if (n(this, W).isDeletedAnnotationElement(l)) {
          o.updateEdited({
            deleted: !0
          });
          continue;
        }
        let h = r.get(l);
        if (h) {
          h.resetAnnotationElement(o), h.show(!1), o.show();
          continue;
        }
        h = i.get(l), h && (n(this, W).addChangedExistingAnnotation(h), h.renderAnnotationElement(o) && h.show(!1)), o.show();
      }
    }
    b(this, Lt, Du).call(this), this.isEmpty && (this.div.hidden = !0);
    const {
      classList: e
    } = this.div;
    for (const i of n(hi, Gr).values())
      e.remove(`${i._type}Editing`);
    this.disableTextSelection(), this.toggleAnnotationLayerPointerEvents(!0), p(this, lh, !1);
  }
  getEditableAnnotation(t) {
    var e;
    return ((e = n(this, Ur)) == null ? void 0 : e.getEditableAnnotation(t)) || null;
  }
  setActiveEditor(t) {
    n(this, W).getActive() !== t && n(this, W).setActiveEditor(t);
  }
  enableTextSelection() {
    var t;
    if (this.div.tabIndex = -1, (t = n(this, Ee)) != null && t.div && !n(this, $n)) {
      p(this, $n, new AbortController());
      const e = n(this, W).combinedSignal(n(this, $n));
      n(this, Ee).div.addEventListener("pointerdown", b(this, Lt, M0).bind(this), {
        signal: e
      }), n(this, Ee).div.classList.add("highlighting");
    }
  }
  disableTextSelection() {
    var t;
    this.div.tabIndex = 0, (t = n(this, Ee)) != null && t.div && n(this, $n) && (n(this, $n).abort(), p(this, $n, null), n(this, Ee).div.classList.remove("highlighting"));
  }
  enableClick() {
    if (n(this, $r))
      return;
    p(this, $r, new AbortController());
    const t = n(this, W).combinedSignal(n(this, $r));
    this.div.addEventListener("pointerdown", this.pointerdown.bind(this), {
      signal: t
    });
    const e = this.pointerup.bind(this);
    this.div.addEventListener("pointerup", e, {
      signal: t
    }), this.div.addEventListener("pointercancel", e, {
      signal: t
    });
  }
  disableClick() {
    var t;
    (t = n(this, $r)) == null || t.abort(), p(this, $r, null);
  }
  attach(t) {
    n(this, gs).set(t.id, t);
    const {
      annotationElementId: e
    } = t;
    e && n(this, W).isDeletedAnnotationElement(e) && n(this, W).removeDeletedAnnotationElement(t);
  }
  detach(t) {
    var e;
    n(this, gs).delete(t.id), (e = n(this, mo)) == null || e.removePointerInTextLayer(t.contentDiv), !n(this, lh) && t.annotationElementId && n(this, W).addDeletedAnnotationElement(t);
  }
  remove(t) {
    this.detach(t), n(this, W).removeEditor(t), t.div.remove(), t.isAttachedToDOM = !1;
  }
  changeParent(t) {
    var e;
    t.parent !== this && (t.parent && t.annotationElementId && (n(this, W).addDeletedAnnotationElement(t.annotationElementId), Ft.deleteAnnotationElement(t), t.annotationElementId = null), this.attach(t), (e = t.parent) == null || e.detach(t), t.setParent(this), t.div && t.isAttachedToDOM && (t.div.remove(), this.div.append(t.div)));
  }
  add(t) {
    if (!(t.parent === this && t.isAttachedToDOM)) {
      if (this.changeParent(t), n(this, W).addEditor(t), this.attach(t), !t.isAttachedToDOM) {
        const e = t.render();
        this.div.append(e), t.isAttachedToDOM = !0;
      }
      t.fixAndSetPosition(), t.onceAdded(!n(this, hh)), n(this, W).addToAnnotationStorage(t), t._reportTelemetry(t.telemetryInitialData);
    }
  }
  moveEditorInDOM(t) {
    var s;
    if (!t.isAttachedToDOM)
      return;
    const {
      activeElement: e
    } = document;
    t.div.contains(e) && !n(this, Hn) && (t._focusEventsAllowed = !1, p(this, Hn, setTimeout(() => {
      p(this, Hn, null), t.div.contains(document.activeElement) ? t._focusEventsAllowed = !0 : (t.div.addEventListener("focusin", () => {
        t._focusEventsAllowed = !0;
      }, {
        once: !0,
        signal: n(this, W)._signal
      }), e.focus());
    }, 0))), t._structTreeParentId = (s = n(this, mo)) == null ? void 0 : s.moveElementInDOM(this.div, t.div, t.contentDiv, !0);
  }
  addOrRebuild(t) {
    t.needsToBeRebuilt() ? (t.parent || (t.parent = this), t.rebuild(), t.show()) : this.add(t);
  }
  addUndoableEditor(t) {
    const e = () => t._uiManager.rebuild(t), s = () => {
      t.remove();
    };
    this.addCommands({
      cmd: e,
      undo: s,
      mustExec: !1
    });
  }
  getEditorByUID(t) {
    for (const e of n(this, gs).values())
      if (e.uid === t)
        return e;
    return null;
  }
  getNextId() {
    return n(this, W).getId();
  }
  combinedSignal(t) {
    return n(this, W).combinedSignal(t);
  }
  canCreateNewEmptyEditor() {
    var t;
    return (t = n(this, Lt, xi)) == null ? void 0 : t.canCreateNewEmptyEditor();
  }
  async pasteEditor(t, e) {
    this.updateToolbar(t), await n(this, W).updateMode(t.mode);
    const {
      offsetX: s,
      offsetY: i
    } = b(this, Lt, rg).call(this), r = this.getNextId(), a = b(this, Lt, ng).call(this, {
      parent: this,
      id: r,
      x: s,
      y: i,
      uiManager: n(this, W),
      isCentered: !0,
      ...e
    });
    a && this.add(a);
  }
  async deserialize(t) {
    var e;
    return await ((e = n(hi, Gr).get(t.annotationType ?? t.annotationEditorType)) == null ? void 0 : e.deserialize(t, this, n(this, W))) || null;
  }
  createAndAddNewEditor(t, e, s = {}) {
    const i = this.getNextId(), r = b(this, Lt, ng).call(this, {
      parent: this,
      id: i,
      x: t.offsetX,
      y: t.offsetY,
      uiManager: n(this, W),
      isCentered: e,
      ...s
    });
    return r && this.add(r), r;
  }
  get boundingClientRect() {
    return this.div.getBoundingClientRect();
  }
  addNewEditor(t = {}) {
    this.createAndAddNewEditor(b(this, Lt, rg).call(this), !0, t);
  }
  setSelected(t) {
    n(this, W).setSelected(t);
  }
  toggleSelected(t) {
    n(this, W).toggleSelected(t);
  }
  unselect(t) {
    n(this, W).unselect(t);
  }
  pointerup(t) {
    var i;
    const {
      isMac: e
    } = _e.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div || !n(this, Vr) || (p(this, Vr, !1), (i = n(this, Lt, xi)) != null && i.isDrawer && n(this, Lt, xi).supportMultipleDrawings))
      return;
    if (!n(this, oh)) {
      p(this, oh, !0);
      return;
    }
    const s = n(this, W).getMode();
    if (s === Z.STAMP || s === Z.SIGNATURE) {
      n(this, W).unselectAll();
      return;
    }
    this.createAndAddNewEditor(t, !1);
  }
  pointerdown(t) {
    var i;
    if (n(this, W).getMode() === Z.HIGHLIGHT && this.enableTextSelection(), n(this, Vr)) {
      p(this, Vr, !1);
      return;
    }
    const {
      isMac: e
    } = _e.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div)
      return;
    if (p(this, Vr, !0), (i = n(this, Lt, xi)) != null && i.isDrawer) {
      this.startDrawingSession(t);
      return;
    }
    const s = n(this, W).getActive();
    p(this, oh, !s || s.isEmpty());
  }
  startDrawingSession(t) {
    if (this.div.focus({
      preventScroll: !0
    }), n(this, wi)) {
      n(this, Lt, xi).startDrawing(this, n(this, W), !1, t);
      return;
    }
    n(this, W).setCurrentDrawingSession(this), p(this, wi, new AbortController());
    const e = n(this, W).combinedSignal(n(this, wi));
    this.div.addEventListener("blur", ({
      relatedTarget: s
    }) => {
      s && !this.div.contains(s) && (p(this, Un, null), this.commitOrRemove());
    }, {
      signal: e
    }), n(this, Lt, xi).startDrawing(this, n(this, W), !1, t);
  }
  pause(t) {
    if (t) {
      const {
        activeElement: e
      } = document;
      this.div.contains(e) && p(this, Un, e);
      return;
    }
    n(this, Un) && setTimeout(() => {
      var e;
      (e = n(this, Un)) == null || e.focus(), p(this, Un, null);
    }, 0);
  }
  endDrawingSession(t = !1) {
    return n(this, wi) ? (n(this, W).setCurrentDrawingSession(null), n(this, wi).abort(), p(this, wi, null), p(this, Un, null), n(this, Lt, xi).endDrawing(t)) : null;
  }
  findNewParent(t, e, s) {
    const i = n(this, W).findParent(e, s);
    return i === null || i === this ? !1 : (i.changeParent(t), !0);
  }
  commitOrRemove() {
    return n(this, wi) ? (this.endDrawingSession(), !0) : !1;
  }
  onScaleChanging() {
    n(this, wi) && n(this, Lt, xi).onScaleChangingWhenDrawing(this);
  }
  destroy() {
    var t, e;
    this.commitOrRemove(), ((t = n(this, W).getActive()) == null ? void 0 : t.parent) === this && (n(this, W).commitOrRemove(), n(this, W).setActiveEditor(null)), n(this, Hn) && (clearTimeout(n(this, Hn)), p(this, Hn, null));
    for (const s of n(this, gs).values())
      (e = n(this, mo)) == null || e.removePointerInTextLayer(s.contentDiv), s.setParent(null), s.isAttachedToDOM = !1, s.div.remove();
    this.div = null, n(this, gs).clear(), n(this, W).removeLayer(this);
  }
  render({
    viewport: t
  }) {
    this.viewport = t, jr(this.div, t);
    for (const e of n(this, W).getEditors(this.pageIndex))
      this.add(e), e.rebuild();
    this.updateMode();
  }
  update({
    viewport: t
  }) {
    n(this, W).commitOrRemove(), b(this, Lt, Du).call(this);
    const e = this.viewport.rotation, s = t.rotation;
    if (this.viewport = t, jr(this.div, {
      rotation: s
    }), e !== s)
      for (const i of n(this, gs).values())
        i.rotate(s);
  }
  get pageDimensions() {
    const {
      pageWidth: t,
      pageHeight: e
    } = this.viewport.rawDims;
    return [t, e];
  }
  get scale() {
    return n(this, W).viewParameters.realScale;
  }
};
mo = new WeakMap(), oh = new WeakMap(), Ur = new WeakMap(), $r = new WeakMap(), Hn = new WeakMap(), gs = new WeakMap(), Vr = new WeakMap(), lh = new WeakMap(), hh = new WeakMap(), wi = new WeakMap(), Un = new WeakMap(), Ee = new WeakMap(), $n = new WeakMap(), zr = new WeakMap(), ch = new WeakMap(), W = new WeakMap(), Gr = new WeakMap(), Lt = new WeakSet(), ig = function() {
  return n(this, gs).size !== 0 ? n(this, gs).values() : n(this, W).getEditors(this.pageIndex);
}, M0 = function(t) {
  n(this, W).unselectAll();
  const {
    target: e
  } = t;
  if (e === n(this, Ee).div || (e.getAttribute("role") === "img" || e.classList.contains("endOfContent")) && n(this, Ee).div.contains(e)) {
    const {
      isMac: s
    } = _e.platform;
    if (t.button !== 0 || t.ctrlKey && s)
      return;
    n(this, W).showAllEditors("highlight", !0, !0), n(this, Ee).div.classList.add("free"), this.toggleDrawing(), Vu.startHighlighting(this, n(this, W).direction === "ltr", {
      target: n(this, Ee).div,
      x: t.x,
      y: t.y
    }), n(this, Ee).div.addEventListener("pointerup", () => {
      n(this, Ee).div.classList.remove("free"), this.toggleDrawing(!0);
    }, {
      once: !0,
      signal: n(this, W)._signal
    }), t.preventDefault();
  }
}, xi = function() {
  return n(hi, Gr).get(n(this, W).getMode());
}, ng = function(t) {
  const e = n(this, Lt, xi);
  return e ? new e.prototype.constructor(t) : null;
}, rg = function() {
  const {
    x: t,
    y: e,
    width: s,
    height: i
  } = this.boundingClientRect, r = Math.max(0, t), a = Math.max(0, e), o = Math.min(window.innerWidth, t + s), l = Math.min(window.innerHeight, e + i), h = (r + o) / 2 - t, c = (a + l) / 2 - e, [u, f] = this.viewport.rotation % 180 === 0 ? [h, c] : [c, h];
  return {
    offsetX: u,
    offsetY: f
  };
}, Du = function() {
  for (const t of n(this, gs).values())
    t.isEmpty() && t.remove();
}, L(hi, "_initialized", !1), g(hi, Gr, new Map([Bp, qp, eg, Vu, tg].map((t) => [t._editorType, t])));
let Gu = hi;
var vi, es, bo, Ld, df, k0, Qi, ag, L0, og;
const he = class he {
  constructor({
    pageIndex: t
  }) {
    g(this, Qi);
    g(this, vi, null);
    g(this, es, /* @__PURE__ */ new Map());
    g(this, bo, /* @__PURE__ */ new Map());
    this.pageIndex = t;
  }
  setParent(t) {
    if (!n(this, vi)) {
      p(this, vi, t);
      return;
    }
    if (n(this, vi) !== t) {
      if (n(this, es).size > 0)
        for (const e of n(this, es).values())
          e.remove(), t.append(e);
      p(this, vi, t);
    }
  }
  static get _svgFactory() {
    return it(this, "_svgFactory", new Jh());
  }
  draw(t, e = !1, s = !1) {
    const i = oe(he, Ld)._++, r = b(this, Qi, ag).call(this), a = he._svgFactory.createElement("defs");
    r.append(a);
    const o = he._svgFactory.createElement("path");
    a.append(o);
    const l = `path_p${this.pageIndex}_${i}`;
    o.setAttribute("id", l), o.setAttribute("vector-effect", "non-scaling-stroke"), e && n(this, bo).set(i, o);
    const h = s ? b(this, Qi, L0).call(this, a, l) : null, c = he._svgFactory.createElement("use");
    return r.append(c), c.setAttribute("href", `#${l}`), this.updateProperties(r, t), n(this, es).set(i, r), {
      id: i,
      clipPathId: `url(#${h})`
    };
  }
  drawOutline(t, e) {
    const s = oe(he, Ld)._++, i = b(this, Qi, ag).call(this), r = he._svgFactory.createElement("defs");
    i.append(r);
    const a = he._svgFactory.createElement("path");
    r.append(a);
    const o = `path_p${this.pageIndex}_${s}`;
    a.setAttribute("id", o), a.setAttribute("vector-effect", "non-scaling-stroke");
    let l;
    if (e) {
      const u = he._svgFactory.createElement("mask");
      r.append(u), l = `mask_p${this.pageIndex}_${s}`, u.setAttribute("id", l), u.setAttribute("maskUnits", "objectBoundingBox");
      const f = he._svgFactory.createElement("rect");
      u.append(f), f.setAttribute("width", "1"), f.setAttribute("height", "1"), f.setAttribute("fill", "white");
      const m = he._svgFactory.createElement("use");
      u.append(m), m.setAttribute("href", `#${o}`), m.setAttribute("stroke", "none"), m.setAttribute("fill", "black"), m.setAttribute("fill-rule", "nonzero"), m.classList.add("mask");
    }
    const h = he._svgFactory.createElement("use");
    i.append(h), h.setAttribute("href", `#${o}`), l && h.setAttribute("mask", `url(#${l})`);
    const c = h.cloneNode();
    return i.append(c), h.classList.add("mainOutline"), c.classList.add("secondaryOutline"), this.updateProperties(i, t), n(this, es).set(s, i), s;
  }
  finalizeDraw(t, e) {
    n(this, bo).delete(t), this.updateProperties(t, e);
  }
  updateProperties(t, e) {
    var l;
    if (!e)
      return;
    const {
      root: s,
      bbox: i,
      rootClass: r,
      path: a
    } = e, o = typeof t == "number" ? n(this, es).get(t) : t;
    if (o) {
      if (s && b(this, Qi, og).call(this, o, s), i && b(l = he, df, k0).call(l, o, i), r) {
        const {
          classList: h
        } = o;
        for (const [c, u] of Object.entries(r))
          h.toggle(c, u);
      }
      if (a) {
        const c = o.firstChild.firstChild;
        b(this, Qi, og).call(this, c, a);
      }
    }
  }
  updateParent(t, e) {
    if (e === this)
      return;
    const s = n(this, es).get(t);
    s && (n(e, vi).append(s), n(this, es).delete(t), n(e, es).set(t, s));
  }
  remove(t) {
    n(this, bo).delete(t), n(this, vi) !== null && (n(this, es).get(t).remove(), n(this, es).delete(t));
  }
  destroy() {
    p(this, vi, null);
    for (const t of n(this, es).values())
      t.remove();
    n(this, es).clear(), n(this, bo).clear();
  }
};
vi = new WeakMap(), es = new WeakMap(), bo = new WeakMap(), Ld = new WeakMap(), df = new WeakSet(), k0 = function(t, [e, s, i, r]) {
  const {
    style: a
  } = t;
  a.top = `${100 * s}%`, a.left = `${100 * e}%`, a.width = `${100 * i}%`, a.height = `${100 * r}%`;
}, Qi = new WeakSet(), ag = function() {
  const t = he._svgFactory.create(1, 1, !0);
  return n(this, vi).append(t), t.setAttribute("aria-hidden", !0), t;
}, L0 = function(t, e) {
  const s = he._svgFactory.createElement("clipPath");
  t.append(s);
  const i = `clip_${e}`;
  s.setAttribute("id", i), s.setAttribute("clipPathUnits", "objectBoundingBox");
  const r = he._svgFactory.createElement("use");
  return s.append(r), r.setAttribute("href", `#${e}`), r.classList.add("clip"), i;
}, og = function(t, e) {
  for (const [s, i] of Object.entries(e))
    i === null ? t.removeAttribute(s) : t.setAttribute(s, i);
}, g(he, df), g(he, Ld, 0);
let ju = he;
globalThis._pdfjsTestingUtils = {
  HighlightOutliner: Up
};
globalThis.pdfjsLib = {
  AbortException: Gn,
  AnnotationEditorLayer: Gu,
  AnnotationEditorParamsType: ht,
  AnnotationEditorType: Z,
  AnnotationEditorUIManager: Wr,
  AnnotationLayer: _g,
  AnnotationMode: Zi,
  AnnotationType: te,
  applyOpacity: Mm,
  build: Db,
  ColorPicker: Zh,
  createValidAbsoluteUrl: dg,
  CSSConstants: Rm,
  DOMSVGFactory: Jh,
  DrawLayer: ju,
  FeatureTest: _e,
  fetchData: ph,
  findContrastColor: km,
  getDocument: wg,
  getFilenameFromUrl: Tm,
  getPdfFilenameFromUrl: xm,
  getRGB: gh,
  getUuid: fg,
  getXfaPageViewport: Pm,
  GlobalWorkerOptions: ni,
  ImageKind: zh,
  InvalidPDFException: Iu,
  isDataScheme: Nd,
  isPdfFile: gf,
  isValidExplicitDest: cb,
  MathClamp: je,
  noContextMenu: $s,
  normalizeUnicode: _m,
  OPS: dh,
  OutputScale: Si,
  PasswordResponses: Em,
  PDFDataRangeTransport: vg,
  PDFDateString: Xh,
  PDFWorker: uh,
  PermissionFlag: vm,
  PixelsPerInch: jn,
  RenderingCancelledException: pf,
  renderRichText: mg,
  ResponseException: jh,
  setLayerDimensions: jr,
  shadow: it,
  SignatureExtractor: Ji,
  stopEvent: zt,
  SupportedImageMimeTypes: Fu,
  TextLayer: Yh,
  TouchManager: qh,
  updateUrlHash: ug,
  Util: V,
  VerbosityLevel: Dd,
  version: Kh,
  XfaLayer: gg
};
const GA = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AbortException: Gn,
  AnnotationEditorLayer: Gu,
  AnnotationEditorParamsType: ht,
  AnnotationEditorType: Z,
  AnnotationEditorUIManager: Wr,
  AnnotationLayer: _g,
  AnnotationMode: Zi,
  AnnotationType: te,
  CSSConstants: Rm,
  ColorPicker: Zh,
  DOMSVGFactory: Jh,
  DrawLayer: ju,
  FeatureTest: _e,
  GlobalWorkerOptions: ni,
  ImageKind: zh,
  InvalidPDFException: Iu,
  MathClamp: je,
  OPS: dh,
  OutputScale: Si,
  PDFDataRangeTransport: vg,
  PDFDateString: Xh,
  PDFWorker: uh,
  PasswordResponses: Em,
  PermissionFlag: vm,
  PixelsPerInch: jn,
  RenderingCancelledException: pf,
  ResponseException: jh,
  SignatureExtractor: Ji,
  SupportedImageMimeTypes: Fu,
  TextLayer: Yh,
  TouchManager: qh,
  Util: V,
  VerbosityLevel: Dd,
  XfaLayer: gg,
  applyOpacity: Mm,
  build: Db,
  createValidAbsoluteUrl: dg,
  fetchData: ph,
  findContrastColor: km,
  getDocument: wg,
  getFilenameFromUrl: Tm,
  getPdfFilenameFromUrl: xm,
  getRGB: gh,
  getUuid: fg,
  getXfaPageViewport: Pm,
  isDataScheme: Nd,
  isPdfFile: gf,
  isValidExplicitDest: cb,
  noContextMenu: $s,
  normalizeUnicode: _m,
  renderRichText: mg,
  setLayerDimensions: jr,
  shadow: it,
  stopEvent: zt,
  updateUrlHash: ug,
  version: Kh
}, Symbol.toStringTag, { value: "Module" }));
function D0(d) {
  var t, e, s = "";
  if (typeof d == "string" || typeof d == "number") s += d;
  else if (typeof d == "object") if (Array.isArray(d)) {
    var i = d.length;
    for (t = 0; t < i; t++) d[t] && (e = D0(d[t])) && (s && (s += " "), s += e);
  } else for (e in d) d[e] && (s && (s += " "), s += e);
  return s;
}
function yf() {
  for (var d, t, e = 0, s = "", i = arguments.length; e < i; e++) (d = arguments[e]) && (t = D0(d)) && (s && (s += " "), s += t);
  return s;
}
var om = Object.prototype.hasOwnProperty;
function lm(d, t, e) {
  for (e of d.keys())
    if (Oo(e, t)) return e;
}
function Oo(d, t) {
  var e, s, i;
  if (d === t) return !0;
  if (d && t && (e = d.constructor) === t.constructor) {
    if (e === Date) return d.getTime() === t.getTime();
    if (e === RegExp) return d.toString() === t.toString();
    if (e === Array) {
      if ((s = d.length) === t.length)
        for (; s-- && Oo(d[s], t[s]); ) ;
      return s === -1;
    }
    if (e === Set) {
      if (d.size !== t.size)
        return !1;
      for (s of d)
        if (i = s, i && typeof i == "object" && (i = lm(t, i), !i) || !t.has(i)) return !1;
      return !0;
    }
    if (e === Map) {
      if (d.size !== t.size)
        return !1;
      for (s of d)
        if (i = s[0], i && typeof i == "object" && (i = lm(t, i), !i) || !Oo(s[1], t.get(i)))
          return !1;
      return !0;
    }
    if (e === ArrayBuffer)
      d = new Uint8Array(d), t = new Uint8Array(t);
    else if (e === DataView) {
      if ((s = d.byteLength) === t.byteLength)
        for (; s-- && d.getInt8(s) === t.getInt8(s); ) ;
      return s === -1;
    }
    if (ArrayBuffer.isView(d)) {
      if ((s = d.byteLength) === t.byteLength)
        for (; s-- && d[s] === t[s]; ) ;
      return s === -1;
    }
    if (!e || typeof d == "object") {
      s = 0;
      for (e in d)
        if (om.call(d, e) && ++s && !om.call(t, e) || !(e in t) || !Oo(d[e], t[e])) return !1;
      return Object.keys(t).length === s;
    }
  }
  return d !== d && t !== t;
}
function Ud(d) {
  let t = !1;
  return {
    promise: new Promise((s, i) => {
      d.then((r) => !t && s(r)).catch((r) => !t && i(r));
    }),
    cancel() {
      t = !0;
    }
  };
}
const jA = ["onCopy", "onCut", "onPaste"], WA = [
  "onCompositionEnd",
  "onCompositionStart",
  "onCompositionUpdate"
], XA = ["onFocus", "onBlur"], qA = ["onInput", "onInvalid", "onReset", "onSubmit"], YA = ["onLoad", "onError"], KA = ["onKeyDown", "onKeyPress", "onKeyUp"], ZA = [
  "onAbort",
  "onCanPlay",
  "onCanPlayThrough",
  "onDurationChange",
  "onEmptied",
  "onEncrypted",
  "onEnded",
  "onError",
  "onLoadedData",
  "onLoadedMetadata",
  "onLoadStart",
  "onPause",
  "onPlay",
  "onPlaying",
  "onProgress",
  "onRateChange",
  "onSeeked",
  "onSeeking",
  "onStalled",
  "onSuspend",
  "onTimeUpdate",
  "onVolumeChange",
  "onWaiting"
], JA = [
  "onClick",
  "onContextMenu",
  "onDoubleClick",
  "onMouseDown",
  "onMouseEnter",
  "onMouseLeave",
  "onMouseMove",
  "onMouseOut",
  "onMouseOver",
  "onMouseUp"
], QA = [
  "onDrag",
  "onDragEnd",
  "onDragEnter",
  "onDragExit",
  "onDragLeave",
  "onDragOver",
  "onDragStart",
  "onDrop"
], tw = ["onSelect"], ew = ["onTouchCancel", "onTouchEnd", "onTouchMove", "onTouchStart"], sw = [
  "onPointerDown",
  "onPointerMove",
  "onPointerUp",
  "onPointerCancel",
  "onGotPointerCapture",
  "onLostPointerCapture",
  "onPointerEnter",
  "onPointerLeave",
  "onPointerOver",
  "onPointerOut"
], iw = ["onScroll"], nw = ["onWheel"], rw = [
  "onAnimationStart",
  "onAnimationEnd",
  "onAnimationIteration"
], aw = ["onTransitionEnd"], ow = ["onToggle"], lw = ["onChange"], hw = [
  ...jA,
  ...WA,
  ...XA,
  ...qA,
  ...YA,
  ...KA,
  ...ZA,
  ...JA,
  ...QA,
  ...tw,
  ...ew,
  ...sw,
  ...iw,
  ...nw,
  ...rw,
  ...aw,
  ...lw,
  ...ow
];
function I0(d, t) {
  const e = {};
  for (const s of hw) {
    const i = d[s];
    i && (t ? e[s] = ((r) => i(r, t(s))) : e[s] = i);
  }
  return e;
}
var cw = "Invariant failed";
function kt(d, t) {
  if (!d)
    throw new Error(cw);
}
function dw(d) {
  return d && d.__esModule && Object.prototype.hasOwnProperty.call(d, "default") ? d.default : d;
}
var Ff, hm;
function uw() {
  if (hm) return Ff;
  hm = 1;
  var d = function() {
  };
  return Ff = d, Ff;
}
var fw = uw();
const Xe = /* @__PURE__ */ dw(fw), F0 = cg(null), pw = "noopener noreferrer nofollow";
class gw {
  constructor() {
    this.externalLinkEnabled = !0, this.externalLinkRel = void 0, this.externalLinkTarget = void 0, this.isInPresentationMode = !1, this.pdfDocument = void 0, this.pdfViewer = void 0;
  }
  setDocument(t) {
    this.pdfDocument = t;
  }
  setViewer(t) {
    this.pdfViewer = t;
  }
  setExternalLinkRel(t) {
    this.externalLinkRel = t;
  }
  setExternalLinkTarget(t) {
    this.externalLinkTarget = t;
  }
  setHash() {
  }
  setHistory() {
  }
  get pagesCount() {
    return this.pdfDocument ? this.pdfDocument.numPages : 0;
  }
  get page() {
    return kt(this.pdfViewer), this.pdfViewer.currentPageNumber || 0;
  }
  set page(t) {
    kt(this.pdfViewer), this.pdfViewer.currentPageNumber = t;
  }
  get rotation() {
    return 0;
  }
  set rotation(t) {
  }
  addLinkAttributes(t, e, s) {
    t.href = e, t.rel = this.externalLinkRel || pw, t.target = s ? "_blank" : this.externalLinkTarget || "";
  }
  goToDestination(t) {
    return new Promise((e) => {
      kt(this.pdfDocument), kt(t), typeof t == "string" ? this.pdfDocument.getDestination(t).then(e) : Array.isArray(t) ? e(t) : t.then(e);
    }).then((e) => {
      kt(Array.isArray(e));
      const s = e[0];
      new Promise((i) => {
        kt(this.pdfDocument), s instanceof Object ? this.pdfDocument.getPageIndex(s).then((r) => {
          i(r);
        }).catch(() => {
          kt(!1);
        }) : typeof s == "number" ? i(s) : kt(!1);
      }).then((i) => {
        const r = i + 1;
        kt(this.pdfViewer), kt(r >= 1 && r <= this.pagesCount), this.pdfViewer.scrollPageIntoView({
          dest: e,
          pageIndex: i,
          pageNumber: r
        });
      });
    });
  }
  goToPage(t) {
    const e = t - 1;
    kt(this.pdfViewer), kt(t >= 1 && t <= this.pagesCount), this.pdfViewer.scrollPageIntoView({
      pageIndex: e,
      pageNumber: t
    });
  }
  goToXY() {
  }
  cachePageRef() {
  }
  getDestinationHash() {
    return "#";
  }
  getAnchorUrl() {
    return "#";
  }
  executeNamedAction() {
  }
  executeSetOCGState() {
  }
  isPageVisible() {
    return !0;
  }
  isPageCached() {
    return !0;
  }
  navigateTo(t) {
    this.goToDestination(t);
  }
}
function Bo({ children: d, type: t }) {
  return K("div", { className: `react-pdf__message react-pdf__message--${t}`, children: d });
}
const cm = {
  NEED_PASSWORD: 1,
  INCORRECT_PASSWORD: 2
};
function mw(d, t) {
  switch (t.type) {
    case "RESOLVE":
      return { value: t.value, error: void 0 };
    case "REJECT":
      return { value: !1, error: t.error };
    case "RESET":
      return { value: void 0, error: void 0 };
    default:
      return d;
  }
}
function fh() {
  return ey(mw, { value: void 0, error: void 0 });
}
const Af = typeof window < "u", N0 = Af && window.location.protocol === "file:";
function bw(d) {
  return typeof d < "u";
}
function Jr(d) {
  return bw(d) && d !== null;
}
function yw(d) {
  return typeof d == "string";
}
function Aw(d) {
  return d instanceof ArrayBuffer;
}
function ww(d) {
  return kt(Af), d instanceof Blob;
}
function lg(d) {
  return yw(d) && /^data:/.test(d);
}
function dm(d) {
  kt(lg(d));
  const [t = "", e = ""] = d.split(",");
  return t.split(";").indexOf("base64") !== -1 ? atob(e) : unescape(e);
}
function vw() {
  return Af && window.devicePixelRatio || 1;
}
const O0 = "On Chromium based browsers, you can use --allow-file-access-from-files flag for debugging purposes.";
function um() {
  Xe(!N0, `Loading PDF as base64 strings/URLs may not work on protocols other than HTTP/HTTPS. ${O0}`);
}
function Ew() {
  Xe(!N0, `Loading PDF.js worker may not work on protocols other than HTTP/HTTPS. ${O0}`);
}
function Ao(d) {
  d != null && d.cancel && d.cancel();
}
function hg(d, t) {
  return Object.defineProperty(d, "width", {
    get() {
      return this.getViewport({ scale: t }).width;
    },
    configurable: !0
  }), Object.defineProperty(d, "height", {
    get() {
      return this.getViewport({ scale: t }).height;
    },
    configurable: !0
  }), Object.defineProperty(d, "originalWidth", {
    get() {
      return this.getViewport({ scale: 1 }).width;
    },
    configurable: !0
  }), Object.defineProperty(d, "originalHeight", {
    get() {
      return this.getViewport({ scale: 1 }).height;
    },
    configurable: !0
  }), d;
}
function B0(d) {
  return d.name === "AbortException" || d.name === "RenderingCancelledException";
}
function Sw(d) {
  return new Promise((t, e) => {
    const s = new FileReader();
    s.onload = () => {
      if (!s.result)
        return e(new Error("Error while reading a file."));
      t(s.result);
    }, s.onerror = (i) => {
      if (!i.target)
        return e(new Error("Error while reading a file."));
      const { error: r } = i.target;
      if (!r)
        return e(new Error("Error while reading a file."));
      switch (r.code) {
        case r.NOT_FOUND_ERR:
          return e(new Error("Error while reading a file: File not found."));
        case r.SECURITY_ERR:
          return e(new Error("Error while reading a file: Security error."));
        case r.ABORT_ERR:
          return e(new Error("Error while reading a file: Aborted."));
        default:
          return e(new Error("Error while reading a file."));
      }
    }, s.readAsArrayBuffer(d);
  });
}
const { PDFDataRangeTransport: _w } = GA, Cw = (d, t) => {
  switch (t) {
    case cm.NEED_PASSWORD: {
      const e = prompt("Enter the password to open this PDF file.");
      d(e);
      break;
    }
    case cm.INCORRECT_PASSWORD: {
      const e = prompt("Invalid password. Please try again.");
      d(e);
      break;
    }
  }
};
function fm(d) {
  return typeof d == "object" && d !== null && ("data" in d || "range" in d || "url" in d);
}
const Tw = sy(function({ children: t, className: e, error: s = "Failed to load PDF file.", externalLinkRel: i, externalLinkTarget: r, file: a, inputRef: o, imageResourcesPath: l, loading: h = "Loading PDF…", noData: c = "No PDF file specified.", onItemClick: u, onLoadError: f, onLoadProgress: m, onLoadSuccess: A, onPassword: y = Cw, onSourceError: v, onSourceSuccess: w, options: S, renderMode: E, rotate: _, scale: C, ...T }, x) {
  const [R, M] = fh(), { value: D, error: k } = R, [N, X] = fh(), { value: B, error: Y } = N, O = ii(new gw()), H = ii([]), st = ii(void 0), at = ii(void 0);
  a && a !== st.current && fm(a) && (Xe(!Oo(a, st.current), `File prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to "file" prop.`), st.current = a), S && S !== at.current && (Xe(!Oo(S, at.current), `Options prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to "options" prop.`), at.current = S);
  const Jt = ii({
    // Handling jumping to internal links target
    scrollPageIntoView: (Pt) => {
      const { dest: jt, pageNumber: Nt, pageIndex: pe = Nt - 1 } = Pt;
      if (u) {
        u({ dest: jt, pageIndex: pe, pageNumber: Nt });
        return;
      }
      const Ne = H.current[pe];
      if (Ne) {
        Ne.scrollIntoView();
        return;
      }
      Xe(!1, `An internal link leading to page ${Nt} was clicked, but neither <Document> was provided with onItemClick nor it was able to find the page within itself. Either provide onItemClick to <Document> and handle navigating by yourself or ensure that all pages are rendered within <Document>.`);
    }
  });
  iy(x, () => ({
    linkService: O,
    pages: H,
    viewer: Jt
  }), []);
  function qe() {
    w && w();
  }
  function lt() {
    k && (Xe(!1, k.toString()), v && v(k));
  }
  function tt() {
    M({ type: "RESET" });
  }
  wt(tt, [a, M]);
  const vt = Se(async () => {
    if (!a)
      return null;
    if (typeof a == "string")
      return lg(a) ? { data: dm(a) } : (um(), { url: a });
    if (a instanceof _w)
      return { range: a };
    if (Aw(a))
      return { data: a };
    if (Af && ww(a))
      return { data: await Sw(a) };
    if (kt(typeof a == "object"), kt(fm(a)), "url" in a && typeof a.url == "string") {
      if (lg(a.url)) {
        const { url: Pt, ...jt } = a;
        return { data: dm(Pt), ...jt };
      }
      um();
    }
    return a;
  }, [a]);
  wt(() => {
    const Pt = Ud(vt());
    return Pt.promise.then((jt) => {
      M({ type: "RESOLVE", value: jt });
    }).catch((jt) => {
      M({ type: "REJECT", error: jt });
    }), () => {
      Ao(Pt);
    };
  }, [vt, M]), wt(() => {
    if (!(typeof D > "u")) {
      if (D === !1) {
        lt();
        return;
      }
      qe();
    }
  }, [D]);
  function ie() {
    B && (A && A(B), H.current = new Array(B.numPages), O.current.setDocument(B));
  }
  function fe() {
    Y && (Xe(!1, Y.toString()), f && f(Y));
  }
  wt(function() {
    X({ type: "RESET" });
  }, [X, D]), wt(function() {
    if (!D)
      return;
    const jt = S ? { ...D, ...S } : D, Nt = wg(jt);
    m && (Nt.onProgress = m), y && (Nt.onPassword = y);
    const pe = Nt;
    return pe.promise.then((Ne) => {
      pe.destroyed || X({ type: "RESOLVE", value: Ne });
    }).catch((Ne) => {
      pe.destroyed || X({ type: "REJECT", error: Ne });
    }), () => {
      pe.destroy();
    };
  }, [S, X, D]), wt(() => {
    if (!(typeof B > "u")) {
      if (B === !1) {
        fe();
        return;
      }
      ie();
    }
  }, [B]), wt(function() {
    O.current.setViewer(Jt.current), O.current.setExternalLinkRel(i), O.current.setExternalLinkTarget(r);
  }, [i, r]);
  const ct = Se((Pt, jt) => {
    H.current[Pt] = jt;
  }, []), bs = Se((Pt) => {
    delete H.current[Pt];
  }, []), Ye = We(() => ({
    imageResourcesPath: l,
    linkService: O.current,
    onItemClick: u,
    pdf: B,
    registerPage: ct,
    renderMode: E,
    rotate: _,
    scale: C,
    unregisterPage: bs
  }), [l, u, B, ct, E, _, C, bs]), Vs = We(
    () => I0(T, () => B),
    // biome-ignore lint/correctness/useExhaustiveDependencies: FIXME
    [T, B]
  );
  function Ce() {
    function Pt(Nt) {
      return !!(Nt != null && Nt.pdf);
    }
    if (!Pt(Ye))
      throw new Error("pdf is undefined");
    const jt = typeof t == "function" ? t(Ye) : t;
    return K(F0.Provider, { value: Ye, children: jt });
  }
  function xt() {
    return a ? B == null ? K(Bo, { type: "loading", children: typeof h == "function" ? h() : h }) : B === !1 ? K(Bo, { type: "error", children: typeof s == "function" ? s() : s }) : Ce() : K(Bo, { type: "no-data", children: typeof c == "function" ? c() : c });
  }
  return K("div", {
    className: yf("react-pdf__Document", e),
    // Assertion is needed for React 18 compatibility
    ref: o,
    ...Vs,
    children: xt()
  });
});
function H0() {
  return wm(F0);
}
function U0() {
  for (var d = [], t = 0; t < arguments.length; t++)
    d[t] = arguments[t];
  var e = d.filter(Boolean);
  if (e.length <= 1) {
    var s = e[0];
    return s || null;
  }
  return function(r) {
    for (var a = 0, o = e; a < o.length; a++) {
      var l = o[a];
      typeof l == "function" ? l(r) : l && (l.current = r);
    }
  };
}
const $0 = cg(null);
function wf() {
  return wm($0);
}
function xw() {
  const d = H0(), t = wf();
  kt(t);
  const e = { ...d, ...t }, { filterAnnotations: s, imageResourcesPath: i, linkService: r, onGetAnnotationsError: a, onGetAnnotationsSuccess: o, onRenderAnnotationLayerError: l, onRenderAnnotationLayerSuccess: h, page: c, pdf: u, renderForms: f, rotate: m, scale: A = 1 } = e;
  kt(u), kt(c), kt(r);
  const [y, v] = fh(), { value: w, error: S } = y, E = ii(null);
  Xe(Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--react-pdf-annotation-layer"), 10) === 1, "AnnotationLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-annotations");
  function _() {
    w && o && o(w);
  }
  function C() {
    S && (Xe(!1, S.toString()), a && a(S));
  }
  wt(function() {
    v({ type: "RESET" });
  }, [v, c]), wt(function() {
    if (!c)
      return;
    const D = Ud(c.getAnnotations()), k = D;
    return D.promise.then((N) => {
      v({ type: "RESOLVE", value: N });
    }).catch((N) => {
      v({ type: "REJECT", error: N });
    }), () => {
      Ao(k);
    };
  }, [v, c]), wt(() => {
    if (w !== void 0) {
      if (w === !1) {
        C();
        return;
      }
      _();
    }
  }, [w]);
  function T() {
    h && h();
  }
  function x(M) {
    Xe(!1, `${M}`), l && l(M);
  }
  const R = We(() => c.getViewport({ scale: A, rotation: m }), [c, m, A]);
  return wt(function() {
    if (!u || !c || !r || !w)
      return;
    const { current: D } = E;
    if (!D)
      return;
    const k = R.clone({ dontFlip: !0 }), N = {
      accessibilityManager: null,
      // TODO: Implement this
      annotationCanvasMap: null,
      // TODO: Implement this
      annotationEditorUIManager: null,
      // TODO: Implement this
      annotationStorage: u.annotationStorage,
      commentManager: null,
      // TODO: Implement this
      div: D,
      l10n: null,
      // TODO: Implement this
      linkService: r,
      page: c,
      structTreeLayer: null,
      // TODO: Implement this
      viewport: k
    }, X = {
      annotations: s ? s({ annotations: w }) : w,
      annotationStorage: u.annotationStorage,
      div: D,
      imageResourcesPath: i,
      linkService: r,
      page: c,
      renderForms: f,
      viewport: k
    };
    D.innerHTML = "";
    try {
      new _g(N).render(X), T();
    } catch (B) {
      x(B);
    }
    return () => {
    };
  }, [
    w,
    s,
    i,
    r,
    c,
    u,
    f,
    R
  ]), K("div", { className: yf("react-pdf__Page__annotations", "annotationLayer"), ref: E });
}
const V0 = {
  // Document level structure types
  Document: null,
  // There's a "document" role, but it doesn't make sense here.
  DocumentFragment: null,
  // Grouping level structure types
  Part: "group",
  Sect: "group",
  // XXX: There's a "section" role, but it's abstract.
  Div: "group",
  Aside: "note",
  NonStruct: "none",
  // Block level structure types
  P: null,
  // H<n>,
  H: "heading",
  Title: null,
  FENote: "note",
  // Sub-block level structure type
  Sub: "group",
  // General inline level structure types
  Lbl: null,
  Span: null,
  Em: null,
  Strong: null,
  Link: "link",
  Annot: "note",
  Form: "form",
  // Ruby and Warichu structure types
  Ruby: null,
  RB: null,
  RT: null,
  RP: null,
  Warichu: null,
  WT: null,
  WP: null,
  // List standard structure types
  L: "list",
  LI: "listitem",
  LBody: null,
  // Table standard structure types
  Table: "table",
  TR: "row",
  TH: "columnheader",
  TD: "cell",
  THead: "columnheader",
  TBody: null,
  TFoot: null,
  // Standard structure type Caption
  Caption: null,
  // Standard structure type Figure
  Figure: "figure",
  // Standard structure type Formula
  Formula: null,
  // standard structure type Artifact
  Artifact: null
}, Pw = /^H(\d+)$/;
function Rw(d) {
  return d in V0;
}
function vf(d) {
  return "children" in d;
}
function z0(d) {
  return vf(d) ? d.children.length === 1 && 0 in d.children && "id" in d.children[0] : !1;
}
function Mw(d) {
  const t = {};
  if (vf(d)) {
    const { role: e } = d, s = e.match(Pw);
    if (s)
      t.role = "heading", t["aria-level"] = Number(s[1]);
    else if (Rw(e)) {
      const i = V0[e];
      i && (t.role = i);
    }
  }
  return t;
}
function G0(d) {
  const t = {};
  if (vf(d)) {
    if (d.alt !== void 0 && (t["aria-label"] = d.alt), d.lang !== void 0 && (t.lang = d.lang), z0(d)) {
      const [e] = d.children;
      if (e) {
        const s = G0(e);
        return {
          ...t,
          ...s
        };
      }
    }
  } else "id" in d && (t["aria-owns"] = d.id);
  return t;
}
function kw(d) {
  return d ? {
    ...Mw(d),
    ...G0(d)
  } : null;
}
function j0({ className: d, node: t }) {
  const e = We(() => kw(t), [t]), s = We(() => !vf(t) || z0(t) ? null : t.children.map((i, r) => (
    // biome-ignore lint/suspicious/noArrayIndexKey: index is stable here
    K(j0, { node: i }, r)
  )), [t]);
  return K("span", { className: d, ...e, children: s });
}
function Lw() {
  const d = wf();
  kt(d);
  const { onGetStructTreeError: t, onGetStructTreeSuccess: e } = d, [s, i] = fh(), { value: r, error: a } = s, { customTextRenderer: o, page: l } = d;
  function h() {
    r && e && e(r);
  }
  function c() {
    a && (Xe(!1, a.toString()), t && t(a));
  }
  return wt(function() {
    i({ type: "RESET" });
  }, [i, l]), wt(function() {
    if (o || !l)
      return;
    const f = Ud(l.getStructTree()), m = f;
    return f.promise.then((A) => {
      i({ type: "RESOLVE", value: A });
    }).catch((A) => {
      i({ type: "REJECT", error: A });
    }), () => Ao(m);
  }, [o, l, i]), wt(() => {
    if (r !== void 0) {
      if (r === !1) {
        c();
        return;
      }
      h();
    }
  }, [r]), r ? K(j0, { className: "react-pdf__Page__structTree structTree", node: r }) : null;
}
const pm = Zi;
function Dw(d) {
  const t = wf();
  kt(t);
  const e = { ...t, ...d }, { _className: s, canvasBackground: i, devicePixelRatio: r = vw(), onRenderError: a, onRenderSuccess: o, page: l, renderForms: h, renderTextLayer: c, pageColors: u, rotate: f, scale: m } = e, { canvasRef: A } = d;
  kt(l);
  const y = ii(null);
  function v() {
    l && o && o(hg(l, m));
  }
  function w(C) {
    B0(C) || (Xe(!1, C.toString()), a && a(C));
  }
  const S = We(() => l.getViewport({ scale: m * r, rotation: f }), [r, l, f, m]), E = We(() => l.getViewport({ scale: m, rotation: f }), [l, f, m]);
  wt(function() {
    if (!l)
      return;
    l.cleanup();
    const { current: T } = y;
    if (!T)
      return;
    T.width = S.width, T.height = S.height, T.style.width = `${Math.floor(E.width)}px`, T.style.height = `${Math.floor(E.height)}px`, T.style.visibility = "hidden";
    const x = {
      annotationMode: h ? pm.ENABLE_FORMS : pm.ENABLE,
      canvas: T,
      canvasContext: T.getContext("2d", { alpha: !1 }),
      pageColors: u,
      viewport: S
    };
    i && (x.background = i);
    const R = l.render(x), M = R;
    return R.promise.then(() => {
      T.style.visibility = "", v();
    }).catch(w), () => Ao(M);
  }, [i, l, u, h, S, E]);
  const _ = Se(() => {
    const { current: C } = y;
    C && (C.width = 0, C.height = 0);
  }, []);
  return wt(() => _, [_]), K("canvas", { className: `${s}__canvas`, dir: "ltr", ref: U0(A, y), style: {
    display: "block",
    userSelect: "none"
  }, children: c ? K(Lw, {}) : null });
}
function Iw(d) {
  return "str" in d;
}
const Fw = /* @__PURE__ */ new Set([
  "base",
  "embed",
  "iframe",
  "link",
  "meta",
  "object",
  "script",
  "style",
  "template"
]), Nw = /* @__PURE__ */ new Set(["action", "formaction", "href", "poster", "src", "xlink:href"]);
function Ow(d) {
  let t = "";
  for (const e of d) {
    const s = e.charCodeAt(0);
    s <= 32 || s === 127 || (t += e.toLowerCase());
  }
  return t.startsWith("javascript:") || t.startsWith("vbscript:");
}
function Bw(d) {
  return d.nodeType === Node.ELEMENT_NODE;
}
function W0(d) {
  return Bw(d) && d instanceof HTMLElement;
}
function Hw(d) {
  return W0(d) && Fw.has(d.tagName.toLowerCase());
}
function Uw(d) {
  const t = document.createElement(d.tagName.toLowerCase());
  return Array.from(d.attributes).forEach((e) => {
    const s = e.name.toLowerCase();
    s.startsWith("on") || s === "srcdoc" || Nw.has(s) && Ow(e.value) || t.setAttribute(e.name, e.value);
  }), Array.from(d.childNodes).forEach((e) => {
    t.append(X0(e));
  }), t;
}
function X0(d) {
  var t;
  return W0(d) && !Hw(d) ? Uw(d) : document.createTextNode((t = d.textContent) !== null && t !== void 0 ? t : "");
}
function $w(d, t) {
  const e = document.createElement("template");
  e.innerHTML = t;
  const s = document.createDocumentFragment();
  Array.from(e.content.childNodes).forEach((i) => {
    s.append(X0(i));
  }), d.replaceChildren(s);
}
function Vw() {
  const d = wf();
  kt(d);
  const { customTextRenderer: t, onGetTextError: e, onGetTextSuccess: s, onRenderTextLayerError: i, onRenderTextLayerSuccess: r, page: a, pageIndex: o, pageNumber: l, rotate: h, scale: c } = d;
  kt(a);
  const [u, f] = fh(), { value: m, error: A } = u, y = ii(null);
  Xe(Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--react-pdf-text-layer"), 10) === 1, "TextLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-text-layer");
  function v() {
    m && s && s(m);
  }
  function w() {
    A && (Xe(!1, A.toString()), e && e(A));
  }
  wt(function() {
    f({ type: "RESET" });
  }, [a, f]), wt(function() {
    if (!a)
      return;
    const R = Ud(a.getTextContent()), M = R;
    return R.promise.then((D) => {
      f({ type: "RESOLVE", value: D });
    }).catch((D) => {
      f({ type: "REJECT", error: D });
    }), () => Ao(M);
  }, [a, f]), wt(() => {
    if (m !== void 0) {
      if (m === !1) {
        w();
        return;
      }
      v();
    }
  }, [m]);
  const S = Se(() => {
    r && r();
  }, [r]), E = Se((x) => {
    B0(x) || (Xe(!1, x.toString()), i && i(x));
  }, [i]);
  function _() {
    const x = y.current;
    x && x.classList.add("selecting");
  }
  function C() {
    const x = y.current;
    x && x.classList.remove("selecting");
  }
  const T = We(() => a.getViewport({ scale: c, rotation: h }), [a, h, c]);
  return ny(function() {
    if (!a || !m)
      return;
    const { current: R } = y;
    if (!R)
      return;
    R.innerHTML = "";
    const M = a.streamTextContent({ includeMarkedContent: !0 }), D = {
      container: R,
      textContentSource: M,
      viewport: T
    }, k = new Yh(D), N = k;
    return k.render().then(() => {
      const X = document.createElement("div");
      X.className = "endOfContent", R.append(X);
      const B = R.querySelectorAll('[role="presentation"]');
      if (t) {
        let Y = 0;
        m.items.forEach((O, H) => {
          if (!Iw(O))
            return;
          const st = B[Y];
          if (!st)
            return;
          const at = t({
            pageIndex: o,
            pageNumber: l,
            itemIndex: H,
            ...O
          });
          $w(st, at), Y += O.str && O.hasEOL ? 2 : 1;
        });
      }
      S();
    }).catch(E), () => Ao(N);
  }, [
    t,
    E,
    S,
    a,
    o,
    l,
    m,
    T
  ]), // biome-ignore lint/a11y/noStaticElementInteractions: False positive caused by non interactive wrapper listening for bubbling events
  K("div", { className: yf("react-pdf__Page__textContent", "textLayer"), onMouseUp: C, onMouseDown: _, ref: y });
}
const gm = 1;
function zw(d) {
  const e = { ...H0(), ...d }, { _className: s = "react-pdf__Page", _enableRegisterUnregisterPage: i = !0, canvasBackground: r, canvasRef: a, children: o, className: l, customRenderer: h, customTextRenderer: c, devicePixelRatio: u, error: f = "Failed to load the page.", filterAnnotations: m, height: A, inputRef: y, loading: v = "Loading page…", noData: w = "No page specified.", onGetAnnotationsError: S, onGetAnnotationsSuccess: E, onGetStructTreeError: _, onGetStructTreeSuccess: C, onGetTextError: T, onGetTextSuccess: x, onLoadError: R, onLoadSuccess: M, onRenderAnnotationLayerError: D, onRenderAnnotationLayerSuccess: k, onRenderError: N, onRenderSuccess: X, onRenderTextLayerError: B, onRenderTextLayerSuccess: Y, pageColors: O, pageIndex: H, pageNumber: st, pdf: at, registerPage: Jt, renderAnnotationLayer: qe = !0, renderForms: lt = !1, renderMode: tt = "canvas", renderTextLayer: vt = !0, rotate: ie, scale: fe = gm, unregisterPage: ct, width: bs, ...Ye } = e, [Vs, Ce] = fh(), { value: xt, error: Pt } = Vs, jt = ii(null);
  kt(at);
  const Nt = Jr(st) ? st - 1 : H ?? null, pe = st ?? (Jr(H) ? H + 1 : null), Ne = ie ?? (xt ? xt.rotate : null), rs = We(() => {
    if (!xt)
      return null;
    let Wt = 1;
    const ge = fe ?? gm;
    if (bs || A) {
      const as = xt.getViewport({ scale: 1, rotation: Ne });
      bs ? Wt = bs / as.width : A && (Wt = A / as.height);
    }
    return ge * Wt;
  }, [A, xt, Ne, fe, bs]);
  wt(function() {
    return () => {
      Jr(Nt) && i && ct && ct(Nt);
    };
  }, [i, at, Nt, ct]);
  function Ef() {
    if (M) {
      if (!xt || !rs)
        return;
      M(hg(xt, rs));
    }
    if (i && Jt) {
      if (!Jr(Nt) || !jt.current)
        return;
      Jt(Nt, jt.current);
    }
  }
  function Sf() {
    Pt && (Xe(!1, Pt.toString()), R && R(Pt));
  }
  wt(function() {
    Ce({ type: "RESET" });
  }, [Ce, at, Nt]), wt(function() {
    if (!at || !pe)
      return;
    const ge = Ud(at.getPage(pe)), as = ge;
    return ge.promise.then((zs) => {
      Ce({ type: "RESOLVE", value: zs });
    }).catch((zs) => {
      Ce({ type: "REJECT", error: zs });
    }), () => Ao(as);
  }, [Ce, at, pe]), wt(() => {
    if (xt !== void 0) {
      if (xt === !1) {
        Sf();
        return;
      }
      Ef();
    }
  }, [xt, rs]);
  const mh = We(() => (
    // Technically there cannot be page without pageIndex, pageNumber, rotate and scale, but TypeScript doesn't know that
    Jr(Nt) && pe && Jr(Ne) && Jr(rs) ? {
      _className: s,
      canvasBackground: r,
      customTextRenderer: c,
      devicePixelRatio: u,
      filterAnnotations: m,
      onGetAnnotationsError: S,
      onGetAnnotationsSuccess: E,
      onGetStructTreeError: _,
      onGetStructTreeSuccess: C,
      onGetTextError: T,
      onGetTextSuccess: x,
      onRenderAnnotationLayerError: D,
      onRenderAnnotationLayerSuccess: k,
      onRenderError: N,
      onRenderSuccess: X,
      onRenderTextLayerError: B,
      onRenderTextLayerSuccess: Y,
      page: xt,
      pageColors: O,
      pageIndex: Nt,
      pageNumber: pe,
      renderForms: lt,
      renderTextLayer: vt,
      rotate: Ne,
      scale: rs
    } : null
  ), [
    s,
    r,
    c,
    u,
    m,
    S,
    E,
    _,
    C,
    T,
    x,
    D,
    k,
    N,
    X,
    B,
    Y,
    xt,
    O,
    Nt,
    pe,
    lt,
    vt,
    Ne,
    rs
  ]), P = We(
    () => I0(Ye, () => xt && (rs ? hg(xt, rs) : void 0)),
    // biome-ignore lint/correctness/useExhaustiveDependencies: FIXME
    [Ye, xt, rs]
  ), j = `${Nt}@${rs}/${Ne}`;
  function G() {
    switch (tt) {
      case "custom":
        return kt(h), K(h, {}, `${j}_custom`);
      case "none":
        return null;
      case "canvas":
      default:
        return K(Dw, { canvasRef: a }, `${j}_canvas`);
    }
  }
  function ut() {
    return vt ? K(Vw, {}, `${j}_text`) : null;
  }
  function ft() {
    return qe ? K(xw, {}, `${j}_annotations`) : null;
  }
  function Qt() {
    function Wt(as) {
      return !!(as != null && as.page);
    }
    if (!Wt(mh))
      throw new Error("page is undefined");
    const ge = typeof o == "function" ? o(mh) : o;
    return le($0.Provider, { value: mh, children: [G(), ut(), ft(), ge] });
  }
  function Ke() {
    return pe ? at === null || xt === void 0 || xt === null ? K(Bo, { type: "loading", children: typeof v == "function" ? v() : v }) : at === !1 || xt === !1 ? K(Bo, { type: "error", children: typeof f == "function" ? f() : f }) : Qt() : K(Bo, { type: "no-data", children: typeof w == "function" ? w() : w });
  }
  return K("div", {
    className: yf(s, l),
    "data-page-number": pe,
    // Assertion is needed for React 18 compatibility
    ref: U0(y, jt),
    style: {
      "--scale-round-x": "1px",
      "--scale-round-y": "1px",
      "--scale-factor": "1",
      "--user-unit": `${rs}`,
      "--total-scale-factor": "calc(var(--scale-factor) * var(--user-unit))",
      backgroundColor: r || "white",
      position: "relative",
      minWidth: "min-content",
      minHeight: "min-content"
    },
    ...P,
    children: Ke()
  });
}
Ew();
ni.workerSrc = "pdf.worker.mjs";
const Gw = /* @__PURE__ */ new Map([
  [
    "bold",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,44H40A20,20,0,0,0,20,64V224A19.82,19.82,0,0,0,31.56,242.1a20.14,20.14,0,0,0,8.49,1.9,19.91,19.91,0,0,0,12.82-4.72l.12-.11L84.47,212H216a20,20,0,0,0,20-20V64A20,20,0,0,0,216,44Zm-4,144H80a11.93,11.93,0,0,0-7.84,2.92L44,215.23V68H212ZM84,108A12,12,0,0,1,96,96h64a12,12,0,1,1,0,24H96A12,12,0,0,1,84,108Zm0,40a12,12,0,0,1,12-12h64a12,12,0,0,1,0,24H96A12,12,0,0,1,84,148Z" }))
  ],
  [
    "duotone",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement(
      "path",
      {
        d: "M224,64V192a8,8,0,0,1-8,8H80L45.15,230.11A8,8,0,0,1,32,224V64a8,8,0,0,1,8-8H216A8,8,0,0,1,224,64Z",
        opacity: "0.2"
      }
    ), /* @__PURE__ */ I.createElement("path", { d: "M216,48H40A16,16,0,0,0,24,64V224a15.85,15.85,0,0,0,9.24,14.5A16.13,16.13,0,0,0,40,240a15.89,15.89,0,0,0,10.25-3.78l.09-.07L83,208H216a16,16,0,0,0,16-16V64A16,16,0,0,0,216,48ZM40,224h0ZM216,192H80a8,8,0,0,0-5.23,1.95L40,224V64H216ZM88,112a8,8,0,0,1,8-8h64a8,8,0,0,1,0,16H96A8,8,0,0,1,88,112Zm0,32a8,8,0,0,1,8-8h64a8,8,0,1,1,0,16H96A8,8,0,0,1,88,144Z" }))
  ],
  [
    "fill",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,48H40A16,16,0,0,0,24,64V224a15.84,15.84,0,0,0,9.25,14.5A16.05,16.05,0,0,0,40,240a15.89,15.89,0,0,0,10.25-3.78l.09-.07L83,208H216a16,16,0,0,0,16-16V64A16,16,0,0,0,216,48ZM160,152H96a8,8,0,0,1,0-16h64a8,8,0,0,1,0,16Zm0-32H96a8,8,0,0,1,0-16h64a8,8,0,0,1,0,16Z" }))
  ],
  [
    "light",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,50H40A14,14,0,0,0,26,64V224a13.88,13.88,0,0,0,8.09,12.69A14.11,14.11,0,0,0,40,238a13.87,13.87,0,0,0,9-3.31l.06-.05L82.23,206H216a14,14,0,0,0,14-14V64A14,14,0,0,0,216,50Zm2,142a2,2,0,0,1-2,2H80a6,6,0,0,0-3.92,1.46L41.26,225.53A2,2,0,0,1,38,224V64a2,2,0,0,1,2-2H216a2,2,0,0,1,2,2Zm-52-80a6,6,0,0,1-6,6H96a6,6,0,0,1,0-12h64A6,6,0,0,1,166,112Zm0,32a6,6,0,0,1-6,6H96a6,6,0,0,1,0-12h64A6,6,0,0,1,166,144Z" }))
  ],
  [
    "regular",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,48H40A16,16,0,0,0,24,64V224a15.85,15.85,0,0,0,9.24,14.5A16.13,16.13,0,0,0,40,240a15.89,15.89,0,0,0,10.25-3.78l.09-.07L83,208H216a16,16,0,0,0,16-16V64A16,16,0,0,0,216,48ZM40,224h0ZM216,192H80a8,8,0,0,0-5.23,1.95L40,224V64H216ZM88,112a8,8,0,0,1,8-8h64a8,8,0,0,1,0,16H96A8,8,0,0,1,88,112Zm0,32a8,8,0,0,1,8-8h64a8,8,0,1,1,0,16H96A8,8,0,0,1,88,144Z" }))
  ],
  [
    "thin",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,52H40A12,12,0,0,0,28,64V224a11.89,11.89,0,0,0,6.93,10.88A12.17,12.17,0,0,0,40,236a11.89,11.89,0,0,0,7.69-2.83l0,0L81.49,204H216a12,12,0,0,0,12-12V64A12,12,0,0,0,216,52Zm4,140a4,4,0,0,1-4,4H80a4,4,0,0,0-2.62,1L42.56,227.06A4,4,0,0,1,36,224V64a4,4,0,0,1,4-4H216a4,4,0,0,1,4,4Zm-56-80a4,4,0,0,1-4,4H96a4,4,0,0,1,0-8h64A4,4,0,0,1,164,112Zm0,32a4,4,0,0,1-4,4H96a4,4,0,0,1,0-8h64A4,4,0,0,1,164,144Z" }))
  ]
]), jw = /* @__PURE__ */ new Map([
  [
    "bold",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M156,112a12,12,0,0,1-12,12H80a12,12,0,0,1,0-24h64A12,12,0,0,1,156,112Zm76.49,120.49a12,12,0,0,1-17,0L168,185a92.12,92.12,0,1,1,17-17l47.54,47.53A12,12,0,0,1,232.49,232.49ZM112,180a68,68,0,1,0-68-68A68.08,68.08,0,0,0,112,180Z" }))
  ],
  [
    "duotone",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M192,112a80,80,0,1,1-80-80A80,80,0,0,1,192,112Z", opacity: "0.2" }), /* @__PURE__ */ I.createElement("path", { d: "M229.66,218.34,179.6,168.28a88.21,88.21,0,1,0-11.32,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Zm112,0a8,8,0,0,1-8,8H80a8,8,0,0,1,0-16h64A8,8,0,0,1,152,112Z" }))
  ],
  [
    "fill",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M229.66,218.34,179.6,168.28a88.21,88.21,0,1,0-11.32,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM144,120H80a8,8,0,0,1,0-16h64a8,8,0,0,1,0,16Z" }))
  ],
  [
    "light",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M150,112a6,6,0,0,1-6,6H80a6,6,0,0,1,0-12h64A6,6,0,0,1,150,112Zm78.24,116.24a6,6,0,0,1-8.48,0l-51.38-51.38a86.15,86.15,0,1,1,8.48-8.48l51.38,51.38A6,6,0,0,1,228.24,228.24ZM112,186a74,74,0,1,0-74-74A74.09,74.09,0,0,0,112,186Z" }))
  ],
  [
    "regular",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M152,112a8,8,0,0,1-8,8H80a8,8,0,0,1,0-16h64A8,8,0,0,1,152,112Zm77.66,117.66a8,8,0,0,1-11.32,0l-50.06-50.07a88.11,88.11,0,1,1,11.31-11.31l50.07,50.06A8,8,0,0,1,229.66,229.66ZM112,184a72,72,0,1,0-72-72A72.08,72.08,0,0,0,112,184Z" }))
  ],
  [
    "thin",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M148,112a4,4,0,0,1-4,4H80a4,4,0,0,1,0-8h64A4,4,0,0,1,148,112Zm78.83,114.83a4,4,0,0,1-5.66,0l-52.7-52.7a84.1,84.1,0,1,1,5.66-5.66l52.7,52.7A4,4,0,0,1,226.83,226.83ZM112,188a76,76,0,1,0-76-76A76.08,76.08,0,0,0,112,188Z" }))
  ]
]), Ww = /* @__PURE__ */ new Map([
  [
    "bold",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M156,112a12,12,0,0,1-12,12H124v20a12,12,0,0,1-24,0V124H80a12,12,0,0,1,0-24h20V80a12,12,0,0,1,24,0v20h20A12,12,0,0,1,156,112Zm76.49,120.49a12,12,0,0,1-17,0L168,185a92.12,92.12,0,1,1,17-17l47.54,47.53A12,12,0,0,1,232.49,232.49ZM112,180a68,68,0,1,0-68-68A68.08,68.08,0,0,0,112,180Z" }))
  ],
  [
    "duotone",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M192,112a80,80,0,1,1-80-80A80,80,0,0,1,192,112Z", opacity: "0.2" }), /* @__PURE__ */ I.createElement("path", { d: "M229.66,218.34,179.6,168.28a88.21,88.21,0,1,0-11.32,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Zm112,0a8,8,0,0,1-8,8H120v24a8,8,0,0,1-16,0V120H80a8,8,0,0,1,0-16h24V80a8,8,0,0,1,16,0v24h24A8,8,0,0,1,152,112Z" }))
  ],
  [
    "fill",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M229.66,218.34,179.6,168.28a88.21,88.21,0,1,0-11.32,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM144,120H120v24a8,8,0,0,1-16,0V120H80a8,8,0,0,1,0-16h24V80a8,8,0,0,1,16,0v24h24a8,8,0,0,1,0,16Z" }))
  ],
  [
    "light",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M150,112a6,6,0,0,1-6,6H118v26a6,6,0,0,1-12,0V118H80a6,6,0,0,1,0-12h26V80a6,6,0,0,1,12,0v26h26A6,6,0,0,1,150,112Zm78.24,116.24a6,6,0,0,1-8.48,0l-51.38-51.38a86.15,86.15,0,1,1,8.48-8.48l51.38,51.38A6,6,0,0,1,228.24,228.24ZM112,186a74,74,0,1,0-74-74A74.09,74.09,0,0,0,112,186Z" }))
  ],
  [
    "regular",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M152,112a8,8,0,0,1-8,8H120v24a8,8,0,0,1-16,0V120H80a8,8,0,0,1,0-16h24V80a8,8,0,0,1,16,0v24h24A8,8,0,0,1,152,112Zm77.66,117.66a8,8,0,0,1-11.32,0l-50.06-50.07a88.11,88.11,0,1,1,11.31-11.31l50.07,50.06A8,8,0,0,1,229.66,229.66ZM112,184a72,72,0,1,0-72-72A72.08,72.08,0,0,0,112,184Z" }))
  ],
  [
    "thin",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M148,112a4,4,0,0,1-4,4H116v28a4,4,0,0,1-8,0V116H80a4,4,0,0,1,0-8h28V80a4,4,0,0,1,8,0v28h28A4,4,0,0,1,148,112Zm78.83,114.83a4,4,0,0,1-5.66,0l-52.7-52.7a84.1,84.1,0,1,1,5.66-5.66l52.7,52.7A4,4,0,0,1,226.83,226.83ZM112,188a76,76,0,1,0-76-76A76.08,76.08,0,0,0,112,188Z" }))
  ]
]), Xw = /* @__PURE__ */ new Map([
  [
    "bold",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M208.49,191.51a12,12,0,0,1-17,17L128,145,64.49,208.49a12,12,0,0,1-17-17L111,128,47.51,64.49a12,12,0,0,1,17-17L128,111l63.51-63.52a12,12,0,0,1,17,17L145,128Z" }))
  ],
  [
    "duotone",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement(
      "path",
      {
        d: "M216,56V200a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V56A16,16,0,0,1,56,40H200A16,16,0,0,1,216,56Z",
        opacity: "0.2"
      }
    ), /* @__PURE__ */ I.createElement("path", { d: "M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z" }))
  ],
  [
    "fill",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM181.66,170.34a8,8,0,0,1-11.32,11.32L128,139.31,85.66,181.66a8,8,0,0,1-11.32-11.32L116.69,128,74.34,85.66A8,8,0,0,1,85.66,74.34L128,116.69l42.34-42.35a8,8,0,0,1,11.32,11.32L139.31,128Z" }))
  ],
  [
    "light",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M204.24,195.76a6,6,0,1,1-8.48,8.48L128,136.49,60.24,204.24a6,6,0,0,1-8.48-8.48L119.51,128,51.76,60.24a6,6,0,0,1,8.48-8.48L128,119.51l67.76-67.75a6,6,0,0,1,8.48,8.48L136.49,128Z" }))
  ],
  [
    "regular",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z" }))
  ],
  [
    "thin",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M202.83,197.17a4,4,0,0,1-5.66,5.66L128,133.66,58.83,202.83a4,4,0,0,1-5.66-5.66L122.34,128,53.17,58.83a4,4,0,0,1,5.66-5.66L128,122.34l69.17-69.17a4,4,0,1,1,5.66,5.66L133.66,128Z" }))
  ]
]), qw = cg({
  color: "currentColor",
  size: "1em",
  weight: "regular",
  mirrored: !1
}), $d = I.forwardRef(
  (d, t) => {
    const {
      alt: e,
      color: s,
      size: i,
      weight: r,
      mirrored: a,
      children: o,
      weights: l,
      ...h
    } = d, {
      color: c = "currentColor",
      size: u,
      weight: f = "regular",
      mirrored: m = !1,
      ...A
    } = I.useContext(qw);
    return /* @__PURE__ */ I.createElement(
      "svg",
      {
        ref: t,
        xmlns: "http://www.w3.org/2000/svg",
        width: i ?? u,
        height: i ?? u,
        fill: s ?? c,
        viewBox: "0 0 256 256",
        transform: a || m ? "scale(-1, 1)" : void 0,
        ...A,
        ...h
      },
      !!e && /* @__PURE__ */ I.createElement("title", null, e),
      o,
      l.get(r ?? f)
    );
  }
);
$d.displayName = "IconBase";
const q0 = I.forwardRef((d, t) => /* @__PURE__ */ I.createElement($d, { ref: t, ...d, weights: Gw }));
q0.displayName = "ChatTextIcon";
const Y0 = I.forwardRef((d, t) => /* @__PURE__ */ I.createElement($d, { ref: t, ...d, weights: jw }));
Y0.displayName = "MagnifyingGlassMinusIcon";
const K0 = I.forwardRef((d, t) => /* @__PURE__ */ I.createElement($d, { ref: t, ...d, weights: Ww }));
K0.displayName = "MagnifyingGlassPlusIcon";
const Z0 = I.forwardRef((d, t) => /* @__PURE__ */ I.createElement($d, { ref: t, ...d, weights: Xw }));
Z0.displayName = "XIcon";
ni.workerSrc = `https://unpkg.com/pdfjs-dist@${Kh}/build/pdf.worker.min.mjs`;
function Yw(d) {
  function t(l, h) {
    const c = h.startsWith(l + "/") ? h.slice(l.length + 1) : h;
    return `${l}/.quipu/meta/${c}.frame.json`;
  }
  function e(l, h) {
    const c = h.startsWith(l + "/") ? h.slice(l.length + 1) : h;
    return {
      version: 1,
      type: "frame",
      id: crypto.randomUUID(),
      filePath: c,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      annotations: [],
      instructions: "",
      history: []
    };
  }
  async function s(l, h) {
    try {
      const c = await d.readFile(t(l, h));
      return c ? JSON.parse(c) : null;
    } catch {
      return null;
    }
  }
  async function i(l, h, c) {
    const u = t(l, h);
    try {
      await d.createFolder(u.substring(0, u.lastIndexOf("/")));
    } catch {
    }
    c.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), await d.writeFile(u, JSON.stringify(c, null, 2));
  }
  async function r(l, h, c) {
    let u = await s(l, h);
    u || (u = e(l, h)), u.annotations.push({ ...c, timestamp: (/* @__PURE__ */ new Date()).toISOString() }), await i(l, h, u);
  }
  async function a(l, h, c, u) {
    const f = await s(l, h);
    if (!f) return;
    const m = f.annotations.find((A) => A.id === c);
    m && (m.type = u, await i(l, h, f));
  }
  async function o(l, h, c) {
    const u = await s(l, h);
    u && (u.annotations = u.annotations.filter((f) => f.id !== c), await i(l, h, u));
  }
  return { readFrame: s, addAnnotation: r, updateAnnotationType: a, removeAnnotation: o };
}
const mm = ["comment", "review", "todo", "bug", "question", "instruction"], bm = {
  comment: "bg-text-tertiary/20 text-text-secondary",
  review: "bg-accent/20 text-accent",
  todo: "bg-info/20 text-info",
  bug: "bg-error/20 text-error",
  question: "bg-warning/20 text-warning",
  instruction: "bg-success/20 text-success"
}, Nf = 5, Of = 1056, Kw = 24, Zw = {
  cMapUrl: `https://unpkg.com/pdfjs-dist@${Kh}/cmaps/`,
  cMapPacked: !0,
  standardFontDataUrl: `https://unpkg.com/pdfjs-dist@${Kh}/standard_fonts/`
}, Jw = ({ tab: d, workspacePath: t, fileSystem: e }) => {
  const s = d.path, i = We(() => Yw(e), [e]), [r, a] = Te(null), [o, l] = Te(1), [h, c] = Te(100), [u, f] = Te(0), [m, A] = Te("1"), [y, v] = Te(/* @__PURE__ */ new Set([1])), [w, S] = Te({}), [E, _] = Te([]), [C, T] = Te(!1), [x, R] = Te(""), [M, D] = Te(0), [k, N] = Te(null), [X, B] = Te("comment"), [Y, O] = Te(!1), [H, st] = Te({ top: 0, left: 0 }), [at, Jt] = Te({}), [qe, lt] = Te({}), tt = ii(null), vt = ii({}), ie = ii({}), fe = We(() => e.getFileUrl(s), [e, s]);
  wt(() => {
    const P = tt.current;
    if (!P) return;
    const j = () => f(P.clientWidth);
    j();
    const G = new ResizeObserver(j);
    return G.observe(P), () => G.disconnect();
  }, []);
  const ct = We(() => {
    if (!u) return 612;
    const P = u > 900 ? 340 : 0;
    return Math.max(300, (u - 48 - P) * h / 100);
  }, [u, h]), bs = We(() => {
    const P = /* @__PURE__ */ new Set();
    for (const j of y)
      for (let G = Math.max(1, j - Nf); G <= Math.min(r || 1, j + Nf); G++) P.add(G);
    return P;
  }, [y, r]), Ye = We(() => E.filter((P) => y.has(P.page)), [E, y]), Vs = Se(async () => {
    var P;
    if (!(!t || !s))
      try {
        const j = await i.readFrame(t, s);
        _(((P = j == null ? void 0 : j.annotations) == null ? void 0 : P.filter((G) => G.page != null).map((G) => ({
          id: G.id,
          page: G.page,
          selectedText: G.selectedText,
          topRatio: G.topRatio,
          text: G.text,
          type: G.type || "comment",
          author: G.author,
          timestamp: G.timestamp
        }))) ?? []);
      } catch {
        _([]);
      }
  }, [t, s, i]);
  wt(() => {
    Vs();
  }, [Vs]), wt(() => {
    if (!r || !tt.current) return;
    const P = new IntersectionObserver(
      (j) => v((G) => {
        const ut = new Set(G);
        for (const ft of j) {
          const Qt = parseInt(ft.target.dataset.pageNumber || "0", 10);
          ft.isIntersecting ? ut.add(Qt) : ut.delete(Qt);
        }
        return ut;
      }),
      { root: tt.current, rootMargin: "200px 0px", threshold: 0.01 }
    );
    for (let j = 1; j <= r; j++) {
      const G = vt.current[j];
      G && P.observe(G);
    }
    return () => P.disconnect();
  }, [r]), wt(() => {
    const P = tt.current;
    if (!P || !r) return;
    const j = () => {
      const G = P.getBoundingClientRect().top + P.getBoundingClientRect().height / 2;
      let ut = 1, ft = 1 / 0;
      for (let Qt = 1; Qt <= r; Qt++) {
        const Ke = vt.current[Qt];
        if (!Ke) continue;
        const Wt = Ke.getBoundingClientRect(), ge = Math.abs(Wt.top + Wt.height / 2 - G);
        ge < ft && (ft = ge, ut = Qt);
      }
      l(ut), A(String(ut));
    };
    return P.addEventListener("scroll", j, { passive: !0 }), () => P.removeEventListener("scroll", j);
  }, [r]), wt(() => {
    if (!Ye.length) {
      Jt({}), lt({});
      return;
    }
    const P = setTimeout(() => {
      const j = {}, G = {}, ut = {};
      for (const ft of Ye)
        ut[ft.page] || (ut[ft.page] = []), ut[ft.page].push(ft);
      for (const [ft, Qt] of Object.entries(ut)) {
        const Ke = parseInt(ft, 10), Wt = vt.current[Ke];
        if (!Wt) continue;
        const ge = Wt.querySelector(".react-pdf__Page"), as = (ge == null ? void 0 : ge.offsetHeight) || Of, zs = Wt.getBoundingClientRect();
        let qn = 0;
        [...Qt].sort((ys, Oe) => (ys.topRatio || 0) - (Oe.topRatio || 0)).forEach((ys) => {
          var Yn;
          let Oe = Wt.offsetTop + (ys.topRatio || 0) * as;
          const Cf = ((Yn = ie.current[ys.id]) == null ? void 0 : Yn.offsetHeight) || 80;
          Oe < qn + 12 && (Oe = qn + 12), j[ys.id] = Oe, qn = Oe + Cf;
        });
        const Yr = ge == null ? void 0 : ge.querySelector(".react-pdf__Page__textContent");
        if (!Yr) continue;
        const J0 = Array.from(Yr.querySelectorAll("span")), _f = [];
        let Kr = "";
        for (const ys of J0) {
          const Oe = ys.textContent || "";
          Oe && (Kr.length > 0 && !Kr.endsWith(" ") && !Oe.startsWith(" ") && (Kr += " "), _f.push({ span: ys, start: Kr.length, end: Kr.length + Oe.length }), Kr += Oe);
        }
        Qt.forEach((ys) => {
          if (!ys.selectedText) return;
          const Oe = ys.selectedText.replace(/\s+/g, " ").trim();
          if (!Oe) return;
          const Cf = (ys.topRatio || 0) * as, Yn = [];
          let Vd = 0;
          for (; (Vd = Kr.indexOf(Oe, Vd)) !== -1; )
            Yn.push(Vd), Vd += Oe.length;
          if (!Yn.length) return;
          let zd = Yn[0];
          if (Yn.length > 1) {
            let tn = 1 / 0;
            for (const en of Yn) {
              const bh = _f.find((Zr) => Zr.start <= en && en < Zr.end);
              if (!bh) continue;
              const jd = bh.span.getBoundingClientRect().top - zs.top, oi = Math.abs(jd - Cf);
              oi < tn && (tn = oi, zd = en);
            }
          }
          const Lg = zd + Oe.length, Gd = [];
          for (const tn of _f) {
            if (tn.end <= zd || tn.start >= Lg) continue;
            const en = tn.span.firstChild;
            if (!en || en.nodeType !== Node.TEXT_NODE) continue;
            const bh = Math.max(0, zd - tn.start), jd = Math.min(en.length, Lg - tn.start);
            if (!(bh >= jd))
              try {
                const oi = document.createRange();
                oi.setStart(en, bh), oi.setEnd(en, jd);
                for (const Zr of oi.getClientRects())
                  Gd.push({ top: Zr.top - zs.top, left: Zr.left - zs.left, width: Zr.width, height: Zr.height });
              } catch {
                const oi = tn.span.getBoundingClientRect();
                Gd.push({ top: oi.top - zs.top, left: oi.left - zs.left, width: oi.width, height: oi.height });
              }
          }
          Gd.length && (G[ys.id] = { rects: Gd, pageNum: Ke });
        });
      }
      Jt(j), lt(G);
    }, 350);
    return () => clearTimeout(P);
  }, [Ye, ct, y]);
  const Ce = Se(({ numPages: P }) => {
    a(P), l(1), A("1");
    const j = /* @__PURE__ */ new Set();
    for (let G = 1; G <= Math.min(P, 1 + Nf); G++) j.add(G);
    v(j);
  }, []), xt = Se(
    (P) => (j) => S((G) => ({ ...G, [P]: { width: j.width, height: j.height } })),
    []
  ), Pt = Se((P) => {
    var j;
    (j = vt.current[P]) == null || j.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []), jt = Se(() => {
    const P = parseInt(m, 10);
    P >= 1 && P <= (r || 1) ? Pt(P) : A(String(o));
  }, [m, r, o, Pt]);
  wt(() => {
    const P = tt.current;
    if (!P) return;
    const j = (G) => {
      if (!G.ctrlKey) return;
      G.preventDefault();
      const ut = P.scrollHeight > 0 ? P.scrollTop / P.scrollHeight : 0;
      c((ft) => {
        const Qt = Math.min(300, Math.max(30, ft + (G.deltaY > 0 ? -10 : 10)));
        return requestAnimationFrame(() => {
          P.scrollTop = ut * P.scrollHeight;
        }), Qt;
      });
    };
    return P.addEventListener("wheel", j, { passive: !1 }), () => P.removeEventListener("wheel", j);
  }, []);
  const Nt = Se(() => {
    const P = window.getSelection(), j = P == null ? void 0 : P.toString().replace(/\s+/g, " ").trim();
    if (!j || !tt.current) {
      O(!1);
      return;
    }
    let G = null, ut = null;
    for (let qn = 1; qn <= (r || 0); qn++) {
      const Yr = vt.current[qn];
      if (Yr != null && Yr.contains(P.anchorNode)) {
        G = qn, ut = Yr;
        break;
      }
    }
    if (!G || !ut) {
      O(!1);
      return;
    }
    const ft = P.getRangeAt(0), Qt = ft.getBoundingClientRect(), Ke = ut.getBoundingClientRect(), Wt = ut.querySelector(".react-pdf__Page"), ge = (Wt == null ? void 0 : Wt.offsetHeight) || Ke.height || Of, as = Qt.top - Ke.top, zs = tt.current.getBoundingClientRect();
    st({ top: Qt.top - zs.top + tt.current.scrollTop - 36, left: Qt.left - zs.left + Qt.width / 2 - 16 }), N({ text: j, topRatio: as / ge, relativeTop: as, page: G }), O(!0);
  }, [r]), pe = Se(() => {
    if (!k) return;
    const P = vt.current[k.page];
    P && (D(P.offsetTop + k.relativeTop), T(!0), O(!1));
  }, [k]), Ne = Se(async () => {
    var G;
    if (!x.trim() || !k || !t || !s) return;
    const P = crypto.randomUUID(), j = {
      id: P,
      page: k.page,
      selectedText: k.text,
      topRatio: k.topRatio,
      text: x.trim(),
      type: X,
      author: "user",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    _((ut) => [...ut, j]), i.addAnnotation(t, s, {
      id: P,
      page: j.page,
      selectedText: j.selectedText,
      topRatio: j.topRatio,
      text: j.text,
      type: j.type,
      author: "user"
    }).catch((ut) => console.warn("PDF comment sync failed:", ut)), R(""), B("comment"), T(!1), N(null), (G = window.getSelection()) == null || G.removeAllRanges();
  }, [x, X, k, t, s, i]), rs = Se(() => {
    R(""), B("comment"), T(!1), N(null);
  }, []), Ef = Se(async (P, j) => {
    _((G) => G.map((ut) => ut.id === P ? { ...ut, type: j } : ut)), t && s && i.updateAnnotationType(t, s, P, j).catch(console.warn);
  }, [t, s, i]), Sf = Se(async (P) => {
    _((j) => j.filter((G) => G.id !== P)), t && s && i.removeAnnotation(t, s, P).catch(console.warn);
  }, [t, s, i]), mh = Se((P) => {
    const j = w[P];
    return j ? ct * (j.height / j.width) : ct * (11 / 8.5);
  }, [w, ct]);
  return /* @__PURE__ */ le("div", { className: "flex-1 flex flex-col overflow-hidden bg-bg-surface", children: [
    /* @__PURE__ */ le("div", { className: "flex items-center justify-center gap-4 px-4 py-2 bg-bg-elevated border-b border-border", children: [
      /* @__PURE__ */ le("div", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ K(
          "input",
          {
            type: "text",
            value: m,
            onChange: (P) => A(P.target.value),
            onBlur: jt,
            onKeyDown: (P) => {
              P.key === "Enter" && jt();
            },
            className: "w-10 text-center text-sm text-text-primary bg-bg-surface border border-border rounded px-1 py-0.5 outline-none focus:border-accent"
          }
        ),
        /* @__PURE__ */ le("span", { className: "text-sm text-text-secondary", children: [
          "/ ",
          r || "..."
        ] })
      ] }),
      /* @__PURE__ */ K("div", { className: "w-px h-4 bg-border" }),
      /* @__PURE__ */ K("button", { onClick: () => c((P) => Math.max(30, P - 10)), className: "p-1 rounded hover:bg-white/[0.06] text-text-secondary", children: /* @__PURE__ */ K(Y0, { size: 18 }) }),
      /* @__PURE__ */ le("span", { className: "text-xs text-text-tertiary w-12 text-center", children: [
        h,
        "%"
      ] }),
      /* @__PURE__ */ K("button", { onClick: () => c((P) => Math.min(300, P + 10)), className: "p-1 rounded hover:bg-white/[0.06] text-text-secondary", children: /* @__PURE__ */ K(K0, { size: 18 }) })
    ] }),
    /* @__PURE__ */ K(
      "div",
      {
        className: "flex-1 overflow-auto py-6 [&::-webkit-scrollbar]:w-2.5 [&::-webkit-scrollbar-thumb]:bg-white/15",
        ref: tt,
        onMouseUp: Nt,
        children: /* @__PURE__ */ le("div", { className: "relative flex flex-col items-center min-w-fit", children: [
          /* @__PURE__ */ K(
            Tw,
            {
              file: fe,
              onLoadSuccess: Ce,
              options: Zw,
              loading: /* @__PURE__ */ K("div", { className: "text-text-tertiary text-sm p-8", children: "Loading PDF..." }),
              error: /* @__PURE__ */ K("div", { className: "text-error text-sm p-8", children: "Failed to load PDF." }),
              children: r && Array.from({ length: r }, (P, j) => {
                const G = j + 1, ut = bs.has(G);
                return /* @__PURE__ */ le(
                  "div",
                  {
                    ref: (ft) => {
                      vt.current[G] = ft;
                    },
                    "data-page-number": G,
                    className: "relative",
                    style: { marginBottom: Kw },
                    children: [
                      ut ? /* @__PURE__ */ K(
                        zw,
                        {
                          pageNumber: G,
                          width: ct,
                          devicePixelRatio: Math.max(window.devicePixelRatio * 1.5 || 2, 100 / h * (window.devicePixelRatio * 1.5 || 2)),
                          className: "shadow-lg",
                          onLoadSuccess: xt(G),
                          error: /* @__PURE__ */ le("div", { className: "p-4 text-error text-sm", children: [
                            "Failed to render page ",
                            G
                          ] })
                        }
                      ) : /* @__PURE__ */ le(
                        "div",
                        {
                          className: "bg-bg-elevated shadow-lg flex items-center justify-center text-text-tertiary text-sm",
                          style: { width: ct, height: mh(G) },
                          children: [
                            "Page ",
                            G
                          ]
                        }
                      ),
                      Object.entries(qe).filter(([, ft]) => ft.pageNum === G).map(([ft, Qt]) => Qt.rects.map((Ke, Wt) => /* @__PURE__ */ K(
                        "div",
                        {
                          className: "absolute bg-accent/20 pointer-events-none rounded-sm",
                          style: { top: Ke.top, left: Ke.left, width: Ke.width, height: Ke.height }
                        },
                        `hl-${ft}-${Wt}`
                      )))
                    ]
                  },
                  G
                );
              })
            }
          ),
          Y && /* @__PURE__ */ K(
            "button",
            {
              className: "absolute z-50 p-1.5 rounded-lg bg-accent text-white shadow-lg hover:bg-accent-hover transition-colors",
              style: { top: H.top, left: H.left },
              onMouseDown: (P) => P.preventDefault(),
              onClick: pe,
              title: "Add comment",
              children: /* @__PURE__ */ K(q0, { size: 18 })
            }
          ),
          /* @__PURE__ */ le(
            "div",
            {
              className: "absolute top-0 bottom-0 w-[300px] pointer-events-none",
              style: { left: `calc(50% + ${ct / 2}px + 16px)` },
              children: [
                C && /* @__PURE__ */ le(
                  "div",
                  {
                    className: "absolute w-[280px] bg-bg-surface rounded-lg shadow-lg p-3 pointer-events-auto border border-accent z-[100]",
                    style: { top: M },
                    children: [
                      /* @__PURE__ */ K(
                        "textarea",
                        {
                          value: x,
                          onChange: (P) => R(P.target.value),
                          onKeyDown: (P) => {
                            (P.ctrlKey || P.metaKey || P.shiftKey) && P.key === "Enter" && (P.preventDefault(), Ne()), P.key === "Escape" && rs();
                          },
                          placeholder: "Type your comment...",
                          autoFocus: !0,
                          className: "w-full border border-border rounded py-2 px-2 font-[inherit] text-sm resize-y min-h-[60px] outline-none mb-2 text-page-text focus:border-accent"
                        }
                      ),
                      /* @__PURE__ */ le("div", { className: "flex items-center justify-between gap-2", children: [
                        /* @__PURE__ */ K(
                          "select",
                          {
                            value: X,
                            onChange: (P) => B(P.target.value),
                            className: "text-[11px] bg-bg-elevated border border-border rounded px-1.5 py-1 text-text-secondary outline-none cursor-pointer",
                            children: mm.map((P) => /* @__PURE__ */ K("option", { value: P, children: P }, P))
                          }
                        ),
                        /* @__PURE__ */ le("div", { className: "flex gap-2", children: [
                          /* @__PURE__ */ K("button", { onClick: rs, onMouseDown: (P) => P.preventDefault(), className: "py-1.5 px-3 rounded text-[13px] font-medium bg-transparent text-text-tertiary hover:bg-bg-elevated", children: "Cancel" }),
                          /* @__PURE__ */ K("button", { onClick: Ne, onMouseDown: (P) => P.preventDefault(), className: "py-1.5 px-3 rounded text-[13px] font-medium bg-accent text-white hover:bg-accent-hover", children: "Comment" })
                        ] })
                      ] })
                    ]
                  }
                ),
                Ye.map((P) => {
                  var j, G, ut;
                  return /* @__PURE__ */ le(
                    "div",
                    {
                      ref: (ft) => {
                        ie.current[P.id] = ft;
                      },
                      className: "absolute w-[280px] bg-bg-surface rounded-lg shadow-md p-3 pointer-events-auto border border-transparent hover:shadow-lg",
                      style: {
                        top: at[P.id] !== void 0 ? at[P.id] : (((j = vt.current[P.page]) == null ? void 0 : j.offsetTop) || 0) + (P.topRatio || 0) * (((ut = (G = vt.current[P.page]) == null ? void 0 : G.querySelector(".react-pdf__Page")) == null ? void 0 : ut.offsetHeight) || Of),
                        transition: "top 0.3s ease-out"
                      },
                      children: [
                        /* @__PURE__ */ le("div", { className: "flex justify-between mb-1 text-xs", children: [
                          /* @__PURE__ */ K(
                            "select",
                            {
                              value: P.type || "comment",
                              onChange: (ft) => Ef(P.id, ft.target.value),
                              className: `px-1 py-0.5 rounded text-[10px] font-medium border-none outline-none cursor-pointer ${bm[P.type] || bm.comment}`,
                              children: mm.map((ft) => /* @__PURE__ */ K("option", { value: ft, children: ft }, ft))
                            }
                          ),
                          /* @__PURE__ */ le("div", { className: "flex gap-2 items-center", children: [
                            /* @__PURE__ */ le("span", { className: "text-text-secondary", children: [
                              "p.",
                              P.page
                            ] }),
                            /* @__PURE__ */ K(
                              "button",
                              {
                                className: "border-none bg-transparent text-text-secondary cursor-pointer py-0.5 px-1.5 rounded hover:bg-bg-elevated hover:text-page-text",
                                onClick: () => Sf(P.id),
                                onMouseDown: (ft) => ft.preventDefault(),
                                title: "Resolve comment",
                                children: /* @__PURE__ */ K(Z0, { size: 14 })
                              }
                            )
                          ] })
                        ] }),
                        /* @__PURE__ */ K("div", { className: "text-sm text-page-text mb-2 whitespace-pre-wrap", children: P.text }),
                        /* @__PURE__ */ le("div", { className: "text-xs text-text-secondary border-l-2 border-warning pl-2 italic whitespace-nowrap overflow-hidden text-ellipsis", children: [
                          '"',
                          P.selectedText,
                          '"'
                        ] })
                      ]
                    },
                    P.id
                  );
                })
              ]
            }
          )
        ] })
      }
    )
  ] });
};
function i1(d) {
  const t = d.services.fileSystem;
  function e(s) {
    return Jw({ ...s, fileSystem: t });
  }
  e.displayName = "PdfViewer", d.register({
    id: "pdf-plugin",
    canHandle: (s) => !!s.isPdf || s.name.toLowerCase().endsWith(".pdf"),
    priority: 10,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    component: e
  });
}
export {
  i1 as init
};
