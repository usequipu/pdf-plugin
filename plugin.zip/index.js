var Q0 = Object.defineProperty;
var Dg = (d) => {
  throw TypeError(d);
};
var ty = (d, t, e) => t in d ? Q0(d, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : d[t] = e;
var M = (d, t, e) => ty(d, typeof t != "symbol" ? t + "" : t, e), Cf = (d, t, e) => t.has(d) || Dg("Cannot " + e);
var n = (d, t, e) => (Cf(d, t, "read from private field"), e ? e.call(d) : t.get(d)), g = (d, t, e) => t.has(d) ? Dg("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(d) : t.set(d, e), p = (d, t, e, i) => (Cf(d, t, "write to private field"), i ? i.call(d, e) : t.set(d, e), e), b = (d, t, e) => (Cf(d, t, "access private method"), e);
var oe = (d, t, e, i) => ({
  set _(s) {
    p(d, t, s, e);
  },
  get _() {
    return n(d, t, i);
  }
});
import { jsx as K, jsxs as le } from "react/jsx-runtime";
import * as I from "react";
import { createContext as cg, useReducer as ey, forwardRef as iy, useRef as ss, useImperativeHandle as sy, useEffect as bt, useCallback as Se, useMemo as je, useContext as wm, useLayoutEffect as ny, useState as Ce } from "react";
const ii = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser"), Bf = [1e-3, 0, 0, 1e-3, 0, 0], Tf = 1.35, Oi = {
  ANY: 1,
  DISPLAY: 2,
  PRINT: 4,
  ANNOTATIONS_FORMS: 16,
  ANNOTATIONS_STORAGE: 32,
  ANNOTATIONS_DISABLE: 64,
  IS_EDITING: 128,
  OPLIST: 256
}, Zs = {
  DISABLE: 0,
  ENABLE: 1,
  ENABLE_FORMS: 2,
  ENABLE_STORAGE: 3
}, Gh = "pdfjs_internal_editor_", Z = {
  DISABLE: -1,
  NONE: 0,
  FREETEXT: 3,
  HIGHLIGHT: 9,
  STAMP: 13,
  INK: 15,
  POPUP: 16,
  SIGNATURE: 101,
  COMMENT: 102
}, ht = {
  RESIZE: 1,
  CREATE: 2,
  FREETEXT_SIZE: 11,
  FREETEXT_COLOR: 12,
  FREETEXT_OPACITY: 13,
  INK_COLOR: 21,
  INK_THICKNESS: 22,
  INK_OPACITY: 23,
  HIGHLIGHT_COLOR: 31,
  HIGHLIGHT_THICKNESS: 32,
  HIGHLIGHT_FREE: 33,
  HIGHLIGHT_SHOW_ALL: 34,
  DRAW_STEP: 41
}, vm = {
  PRINT: 4,
  MODIFY_CONTENTS: 8,
  COPY: 16,
  MODIFY_ANNOTATIONS: 32,
  FILL_INTERACTIVE_FORMS: 256,
  COPY_FOR_ACCESSIBILITY: 512,
  ASSEMBLE: 1024,
  PRINT_HIGH_QUALITY: 2048
}, Te = {
  FILL: 0,
  STROKE: 1,
  FILL_STROKE: 2,
  INVISIBLE: 3,
  FILL_STROKE_MASK: 3,
  ADD_TO_PATH_FLAG: 4
}, zh = {
  GRAYSCALE_1BPP: 1,
  RGB_24BPP: 2,
  RGBA_32BPP: 3
}, te = {
  TEXT: 1,
  LINK: 2,
  FREETEXT: 3,
  LINE: 4,
  SQUARE: 5,
  CIRCLE: 6,
  POLYGON: 7,
  POLYLINE: 8,
  HIGHLIGHT: 9,
  UNDERLINE: 10,
  SQUIGGLY: 11,
  STRIKEOUT: 12,
  STAMP: 13,
  CARET: 14,
  INK: 15,
  POPUP: 16,
  FILEATTACHMENT: 17,
  SOUND: 18,
  MOVIE: 19,
  WIDGET: 20,
  SCREEN: 21,
  PRINTERMARK: 22,
  TRAPNET: 23,
  WATERMARK: 24,
  THREED: 25,
  REDACT: 26
}, So = {
  SOLID: 1,
  DASHED: 2,
  BEVELED: 3,
  INSET: 4,
  UNDERLINE: 5
}, Dd = {
  ERRORS: 0,
  WARNINGS: 1,
  INFOS: 5
}, dh = {
  dependency: 1,
  setLineWidth: 2,
  setLineCap: 3,
  setLineJoin: 4,
  setMiterLimit: 5,
  setDash: 6,
  setRenderingIntent: 7,
  setFlatness: 8,
  setGState: 9,
  save: 10,
  restore: 11,
  transform: 12,
  moveTo: 13,
  lineTo: 14,
  curveTo: 15,
  curveTo2: 16,
  curveTo3: 17,
  closePath: 18,
  rectangle: 19,
  stroke: 20,
  closeStroke: 21,
  fill: 22,
  eoFill: 23,
  fillStroke: 24,
  eoFillStroke: 25,
  closeFillStroke: 26,
  closeEOFillStroke: 27,
  endPath: 28,
  clip: 29,
  eoClip: 30,
  beginText: 31,
  endText: 32,
  setCharSpacing: 33,
  setWordSpacing: 34,
  setHScale: 35,
  setLeading: 36,
  setFont: 37,
  setTextRenderingMode: 38,
  setTextRise: 39,
  moveText: 40,
  setLeadingMoveText: 41,
  setTextMatrix: 42,
  nextLine: 43,
  showText: 44,
  showSpacedText: 45,
  nextLineShowText: 46,
  nextLineSetSpacingShowText: 47,
  setCharWidth: 48,
  setCharWidthAndBounds: 49,
  setStrokeColorSpace: 50,
  setFillColorSpace: 51,
  setStrokeColor: 52,
  setStrokeColorN: 53,
  setFillColor: 54,
  setFillColorN: 55,
  setStrokeGray: 56,
  setFillGray: 57,
  setStrokeRGBColor: 58,
  setFillRGBColor: 59,
  setStrokeCMYKColor: 60,
  setFillCMYKColor: 61,
  shadingFill: 62,
  beginInlineImage: 63,
  beginImageData: 64,
  endInlineImage: 65,
  paintXObject: 66,
  markPoint: 67,
  markPointProps: 68,
  beginMarkedContent: 69,
  beginMarkedContentProps: 70,
  endMarkedContent: 71,
  beginCompat: 72,
  endCompat: 73,
  paintFormXObjectBegin: 74,
  paintFormXObjectEnd: 75,
  beginGroup: 76,
  endGroup: 77,
  beginAnnotation: 80,
  endAnnotation: 81,
  paintImageMaskXObject: 83,
  paintImageMaskXObjectGroup: 84,
  paintImageXObject: 85,
  paintInlineImageXObject: 86,
  paintInlineImageXObjectGroup: 87,
  paintImageXObjectRepeat: 88,
  paintImageMaskXObjectRepeat: 89,
  paintSolidColorImageMask: 90,
  constructPath: 91,
  setStrokeTransparent: 92,
  setFillTransparent: 93,
  rawFillPath: 94
}, jd = {
  moveTo: 0,
  lineTo: 1,
  curveTo: 2,
  closePath: 3
}, Em = {
  NEED_PASSWORD: 1,
  INCORRECT_PASSWORD: 2
};
let uf = Dd.WARNINGS;
function ry(d) {
  Number.isInteger(d) && (uf = d);
}
function ay() {
  return uf;
}
function ff(d) {
  uf >= Dd.INFOS && console.info(`Info: ${d}`);
}
function J(d) {
  uf >= Dd.WARNINGS && console.warn(`Warning: ${d}`);
}
function Dt(d) {
  throw new Error(d);
}
function dt(d, t) {
  d || Dt(t);
}
function oy(d) {
  switch (d == null ? void 0 : d.protocol) {
    case "http:":
    case "https:":
    case "ftp:":
    case "mailto:":
    case "tel:":
      return !0;
    default:
      return !1;
  }
}
function dg(d, t = null, e = null) {
  if (!d)
    return null;
  if (e && typeof d == "string") {
    if (e.addDefaultProtocol && d.startsWith("www.")) {
      const s = d.match(/\./g);
      (s == null ? void 0 : s.length) >= 2 && (d = `http://${d}`);
    }
    if (e.tryConvertEncoding)
      try {
        d = uy(d);
      } catch {
      }
  }
  const i = t ? URL.parse(d, t) : URL.parse(d);
  return oy(i) ? i : null;
}
function ug(d, t, e = !1) {
  const i = URL.parse(d);
  return i ? (i.hash = t, i.href) : e && dg(d, "http://example.com") ? d.split("#", 1)[0] + `${t ? `#${t}` : ""}` : "";
}
function st(d, t, e, i = !1) {
  return Object.defineProperty(d, t, {
    value: e,
    enumerable: !i,
    configurable: !0,
    writable: !1
  }), e;
}
const wo = (function() {
  function t(e, i) {
    this.message = e, this.name = i;
  }
  return t.prototype = new Error(), t.constructor = t, t;
})();
class Ig extends wo {
  constructor(t, e) {
    super(t, "PasswordException"), this.code = e;
  }
}
class Pf extends wo {
  constructor(t, e) {
    super(t, "UnknownErrorException"), this.details = e;
  }
}
class Iu extends wo {
  constructor(t) {
    super(t, "InvalidPDFException");
  }
}
class Wh extends wo {
  constructor(t, e, i) {
    super(t, "ResponseException"), this.status = e, this.missing = i;
  }
}
class ly extends wo {
  constructor(t) {
    super(t, "FormatError");
  }
}
class Gn extends wo {
  constructor(t) {
    super(t, "AbortException");
  }
}
function Sm(d) {
  (typeof d != "object" || (d == null ? void 0 : d.length) === void 0) && Dt("Invalid argument for bytesToString");
  const t = d.length, e = 8192;
  if (t < e)
    return String.fromCharCode.apply(null, d);
  const i = [];
  for (let s = 0; s < t; s += e) {
    const r = Math.min(s + e, t), a = d.subarray(s, r);
    i.push(String.fromCharCode.apply(null, a));
  }
  return i.join("");
}
function Id(d) {
  typeof d != "string" && Dt("Invalid argument for stringToBytes");
  const t = d.length, e = new Uint8Array(t);
  for (let i = 0; i < t; ++i)
    e[i] = d.charCodeAt(i) & 255;
  return e;
}
function hy(d) {
  return String.fromCharCode(d >> 24 & 255, d >> 16 & 255, d >> 8 & 255, d & 255);
}
function cy() {
  const d = new Uint8Array(4);
  return d[0] = 1, new Uint32Array(d.buffer, 0, 1)[0] === 1;
}
function dy() {
  try {
    return new Function(""), !0;
  } catch {
    return !1;
  }
}
class _e {
  static get isLittleEndian() {
    return st(this, "isLittleEndian", cy());
  }
  static get isEvalSupported() {
    return st(this, "isEvalSupported", dy());
  }
  static get isOffscreenCanvasSupported() {
    return st(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
  }
  static get isImageDecoderSupported() {
    return st(this, "isImageDecoderSupported", typeof ImageDecoder < "u");
  }
  static get platform() {
    const {
      platform: t,
      userAgent: e
    } = navigator;
    return st(this, "platform", {
      isAndroid: e.includes("Android"),
      isLinux: t.includes("Linux"),
      isMac: t.includes("Mac"),
      isWindows: t.includes("Win"),
      isFirefox: e.includes("Firefox")
    });
  }
  static get isCSSRoundSupported() {
    var t, e;
    return st(this, "isCSSRoundSupported", (e = (t = globalThis.CSS) == null ? void 0 : t.supports) == null ? void 0 : e.call(t, "width: round(1.5px, 1px)"));
  }
}
const Lf = Array.from(Array(256).keys(), (d) => d.toString(16).padStart(2, "0"));
var Vn, iu, Hf;
class z {
  static makeHexColor(t, e, i) {
    return `#${Lf[t]}${Lf[e]}${Lf[i]}`;
  }
  static domMatrixToTransform(t) {
    return [t.a, t.b, t.c, t.d, t.e, t.f];
  }
  static scaleMinMax(t, e) {
    let i;
    t[0] ? (t[0] < 0 && (i = e[0], e[0] = e[2], e[2] = i), e[0] *= t[0], e[2] *= t[0], t[3] < 0 && (i = e[1], e[1] = e[3], e[3] = i), e[1] *= t[3], e[3] *= t[3]) : (i = e[0], e[0] = e[1], e[1] = i, i = e[2], e[2] = e[3], e[3] = i, t[1] < 0 && (i = e[1], e[1] = e[3], e[3] = i), e[1] *= t[1], e[3] *= t[1], t[2] < 0 && (i = e[0], e[0] = e[2], e[2] = i), e[0] *= t[2], e[2] *= t[2]), e[0] += t[4], e[1] += t[5], e[2] += t[4], e[3] += t[5];
  }
  static transform(t, e) {
    return [t[0] * e[0] + t[2] * e[1], t[1] * e[0] + t[3] * e[1], t[0] * e[2] + t[2] * e[3], t[1] * e[2] + t[3] * e[3], t[0] * e[4] + t[2] * e[5] + t[4], t[1] * e[4] + t[3] * e[5] + t[5]];
  }
  static multiplyByDOMMatrix(t, e) {
    return [t[0] * e.a + t[2] * e.b, t[1] * e.a + t[3] * e.b, t[0] * e.c + t[2] * e.d, t[1] * e.c + t[3] * e.d, t[0] * e.e + t[2] * e.f + t[4], t[1] * e.e + t[3] * e.f + t[5]];
  }
  static applyTransform(t, e, i = 0) {
    const s = t[i], r = t[i + 1];
    t[i] = s * e[0] + r * e[2] + e[4], t[i + 1] = s * e[1] + r * e[3] + e[5];
  }
  static applyTransformToBezier(t, e, i = 0) {
    const s = e[0], r = e[1], a = e[2], o = e[3], l = e[4], h = e[5];
    for (let c = 0; c < 6; c += 2) {
      const u = t[i + c], f = t[i + c + 1];
      t[i + c] = u * s + f * a + l, t[i + c + 1] = u * r + f * o + h;
    }
  }
  static applyInverseTransform(t, e) {
    const i = t[0], s = t[1], r = e[0] * e[3] - e[1] * e[2];
    t[0] = (i * e[3] - s * e[2] + e[2] * e[5] - e[4] * e[3]) / r, t[1] = (-i * e[1] + s * e[0] + e[4] * e[1] - e[5] * e[0]) / r;
  }
  static axialAlignedBoundingBox(t, e, i) {
    const s = e[0], r = e[1], a = e[2], o = e[3], l = e[4], h = e[5], c = t[0], u = t[1], f = t[2], m = t[3];
    let A = s * c + l, y = A, v = s * f + l, w = v, S = o * u + h, E = S, _ = o * m + h, x = _;
    if (r !== 0 || a !== 0) {
      const C = r * c, T = r * f, L = a * u, k = a * m;
      A += L, w += L, v += k, y += k, S += C, x += C, _ += T, E += T;
    }
    i[0] = Math.min(i[0], A, v, y, w), i[1] = Math.min(i[1], S, _, E, x), i[2] = Math.max(i[2], A, v, y, w), i[3] = Math.max(i[3], S, _, E, x);
  }
  static inverseTransform(t) {
    const e = t[0] * t[3] - t[1] * t[2];
    return [t[3] / e, -t[1] / e, -t[2] / e, t[0] / e, (t[2] * t[5] - t[4] * t[3]) / e, (t[4] * t[1] - t[5] * t[0]) / e];
  }
  static singularValueDecompose2dScale(t, e) {
    const i = t[0], s = t[1], r = t[2], a = t[3], o = i ** 2 + s ** 2, l = i * r + s * a, h = r ** 2 + a ** 2, c = (o + h) / 2, u = Math.sqrt(c ** 2 - (o * h - l ** 2));
    e[0] = Math.sqrt(c + u || 1), e[1] = Math.sqrt(c - u || 1);
  }
  static normalizeRect(t) {
    const e = t.slice(0);
    return t[0] > t[2] && (e[0] = t[2], e[2] = t[0]), t[1] > t[3] && (e[1] = t[3], e[3] = t[1]), e;
  }
  static intersect(t, e) {
    const i = Math.max(Math.min(t[0], t[2]), Math.min(e[0], e[2])), s = Math.min(Math.max(t[0], t[2]), Math.max(e[0], e[2]));
    if (i > s)
      return null;
    const r = Math.max(Math.min(t[1], t[3]), Math.min(e[1], e[3])), a = Math.min(Math.max(t[1], t[3]), Math.max(e[1], e[3]));
    return r > a ? null : [i, r, s, a];
  }
  static pointBoundingBox(t, e, i) {
    i[0] = Math.min(i[0], t), i[1] = Math.min(i[1], e), i[2] = Math.max(i[2], t), i[3] = Math.max(i[3], e);
  }
  static rectBoundingBox(t, e, i, s, r) {
    r[0] = Math.min(r[0], t, i), r[1] = Math.min(r[1], e, s), r[2] = Math.max(r[2], t, i), r[3] = Math.max(r[3], e, s);
  }
  static bezierBoundingBox(t, e, i, s, r, a, o, l, h) {
    h[0] = Math.min(h[0], t, o), h[1] = Math.min(h[1], e, l), h[2] = Math.max(h[2], t, o), h[3] = Math.max(h[3], e, l), b(this, Vn, Hf).call(this, t, i, r, o, e, s, a, l, 3 * (-t + 3 * (i - r) + o), 6 * (t - 2 * i + r), 3 * (i - t), h), b(this, Vn, Hf).call(this, t, i, r, o, e, s, a, l, 3 * (-e + 3 * (s - a) + l), 6 * (e - 2 * s + a), 3 * (s - e), h);
  }
}
Vn = new WeakSet(), iu = function(t, e, i, s, r, a, o, l, h, c) {
  if (h <= 0 || h >= 1)
    return;
  const u = 1 - h, f = h * h, m = f * h, A = u * (u * (u * t + 3 * h * e) + 3 * f * i) + m * s, y = u * (u * (u * r + 3 * h * a) + 3 * f * o) + m * l;
  c[0] = Math.min(c[0], A), c[1] = Math.min(c[1], y), c[2] = Math.max(c[2], A), c[3] = Math.max(c[3], y);
}, Hf = function(t, e, i, s, r, a, o, l, h, c, u, f) {
  if (Math.abs(h) < 1e-12) {
    Math.abs(c) >= 1e-12 && b(this, Vn, iu).call(this, t, e, i, s, r, a, o, l, -u / c, f);
    return;
  }
  const m = c ** 2 - 4 * u * h;
  if (m < 0)
    return;
  const A = Math.sqrt(m), y = 2 * h;
  b(this, Vn, iu).call(this, t, e, i, s, r, a, o, l, (-c + A) / y, f), b(this, Vn, iu).call(this, t, e, i, s, r, a, o, l, (-c - A) / y, f);
}, g(z, Vn);
function uy(d) {
  return decodeURIComponent(escape(d));
}
let kf = null, Fg = null;
function _m(d) {
  return kf || (kf = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc-\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa-\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, Fg = /* @__PURE__ */ new Map([["ﬅ", "ſt"]])), d.replaceAll(kf, (t, e, i) => e ? e.normalize("NFKC") : Fg.get(i));
}
function fg() {
  if (typeof crypto.randomUUID == "function")
    return crypto.randomUUID();
  const d = new Uint8Array(32);
  return crypto.getRandomValues(d), Sm(d);
}
const pg = "pdfjs_internal_id_";
function fy(d, t, e) {
  if (!Array.isArray(e) || e.length < 2)
    return !1;
  const [i, s, ...r] = e;
  if (!d(i) && !Number.isInteger(i) || !t(s))
    return !1;
  const a = r.length;
  let o = !0;
  switch (s.name) {
    case "XYZ":
      if (a < 2 || a > 3)
        return !1;
      break;
    case "Fit":
    case "FitB":
      return a === 0;
    case "FitH":
    case "FitBH":
    case "FitV":
    case "FitBV":
      if (a > 1)
        return !1;
      break;
    case "FitR":
      if (a !== 4)
        return !1;
      o = !1;
      break;
    default:
      return !1;
  }
  for (const l of r)
    if (!(typeof l == "number" || o && l === null))
      return !1;
  return !0;
}
function We(d, t, e) {
  return Math.min(Math.max(d, t), e);
}
function xm(d) {
  return Uint8Array.prototype.toBase64 ? d.toBase64() : btoa(Sm(d));
}
function py(d) {
  return Uint8Array.fromBase64 ? Uint8Array.fromBase64(d) : Id(atob(d));
}
typeof Promise.try != "function" && (Promise.try = function(d, ...t) {
  return new Promise((e) => {
    e(d(...t));
  });
});
typeof Math.sumPrecise != "function" && (Math.sumPrecise = function(d) {
  return d.reduce((t, e) => t + e, 0);
});
class jh {
  static textContent(t) {
    const e = [], i = {
      items: e,
      styles: /* @__PURE__ */ Object.create(null)
    };
    function s(r) {
      var l;
      if (!r)
        return;
      let a = null;
      const o = r.name;
      if (o === "#text")
        a = r.value;
      else if (jh.shouldBuildText(o))
        (l = r == null ? void 0 : r.attributes) != null && l.textContent ? a = r.attributes.textContent : r.value && (a = r.value);
      else return;
      if (a !== null && e.push({
        str: a
      }), !!r.children)
        for (const h of r.children)
          s(h);
    }
    return s(t), i;
  }
  static shouldBuildText(t) {
    return !(t === "textarea" || t === "input" || t === "option" || t === "select");
  }
}
class gg {
  static setupStorage(t, e, i, s, r) {
    const a = s.getValue(e, {
      value: null
    });
    switch (i.name) {
      case "textarea":
        if (a.value !== null && (t.textContent = a.value), r === "print")
          break;
        t.addEventListener("input", (o) => {
          s.setValue(e, {
            value: o.target.value
          });
        });
        break;
      case "input":
        if (i.attributes.type === "radio" || i.attributes.type === "checkbox") {
          if (a.value === i.attributes.xfaOn ? t.setAttribute("checked", !0) : a.value === i.attributes.xfaOff && t.removeAttribute("checked"), r === "print")
            break;
          t.addEventListener("change", (o) => {
            s.setValue(e, {
              value: o.target.checked ? o.target.getAttribute("xfaOn") : o.target.getAttribute("xfaOff")
            });
          });
        } else {
          if (a.value !== null && t.setAttribute("value", a.value), r === "print")
            break;
          t.addEventListener("input", (o) => {
            s.setValue(e, {
              value: o.target.value
            });
          });
        }
        break;
      case "select":
        if (a.value !== null) {
          t.setAttribute("value", a.value);
          for (const o of i.children)
            o.attributes.value === a.value ? o.attributes.selected = !0 : o.attributes.hasOwnProperty("selected") && delete o.attributes.selected;
        }
        t.addEventListener("input", (o) => {
          const l = o.target.options, h = l.selectedIndex === -1 ? "" : l[l.selectedIndex].value;
          s.setValue(e, {
            value: h
          });
        });
        break;
    }
  }
  static setAttributes({
    html: t,
    element: e,
    storage: i = null,
    intent: s,
    linkService: r
  }) {
    const {
      attributes: a
    } = e, o = t instanceof HTMLAnchorElement;
    a.type === "radio" && (a.name = `${a.name}-${s}`);
    for (const [l, h] of Object.entries(a))
      if (h != null)
        switch (l) {
          case "class":
            h.length && t.setAttribute(l, h.join(" "));
            break;
          case "dataId":
            break;
          case "id":
            t.setAttribute("data-element-id", h);
            break;
          case "style":
            Object.assign(t.style, h);
            break;
          case "textContent":
            t.textContent = h;
            break;
          default:
            (!o || l !== "href" && l !== "newWindow") && t.setAttribute(l, h);
        }
    o && r.addLinkAttributes(t, a.href, a.newWindow), i && a.dataId && this.setupStorage(t, a.dataId, e, i);
  }
  static render(t) {
    var u, f;
    const e = t.annotationStorage, i = t.linkService, s = t.xfaHtml, r = t.intent || "display", a = document.createElement(s.name);
    s.attributes && this.setAttributes({
      html: a,
      element: s,
      intent: r,
      linkService: i
    });
    const o = r !== "richText", l = t.div;
    if (l.append(a), t.viewport) {
      const m = `matrix(${t.viewport.transform.join(",")})`;
      l.style.transform = m;
    }
    o && l.setAttribute("class", "xfaLayer xfaFont");
    const h = [];
    if (s.children.length === 0) {
      if (s.value) {
        const m = document.createTextNode(s.value);
        a.append(m), o && jh.shouldBuildText(s.name) && h.push(m);
      }
      return {
        textDivs: h
      };
    }
    const c = [[s, -1, a]];
    for (; c.length > 0; ) {
      const [m, A, y] = c.at(-1);
      if (A + 1 === m.children.length) {
        c.pop();
        continue;
      }
      const v = m.children[++c.at(-1)[1]];
      if (v === null)
        continue;
      const {
        name: w
      } = v;
      if (w === "#text") {
        const E = document.createTextNode(v.value);
        h.push(E), y.append(E);
        continue;
      }
      const S = (u = v == null ? void 0 : v.attributes) != null && u.xmlns ? document.createElementNS(v.attributes.xmlns, w) : document.createElement(w);
      if (y.append(S), v.attributes && this.setAttributes({
        html: S,
        element: v,
        storage: e,
        intent: r,
        linkService: i
      }), ((f = v.children) == null ? void 0 : f.length) > 0)
        c.push([v, -1, S]);
      else if (v.value) {
        const E = document.createTextNode(v.value);
        o && jh.shouldBuildText(w) && h.push(E), S.append(E);
      }
    }
    for (const m of l.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
      m.setAttribute("readOnly", !0);
    return {
      textDivs: h
    };
  }
  static update(t) {
    const e = `matrix(${t.viewport.transform.join(",")})`;
    t.div.style.transform = e, t.div.hidden = !1;
  }
}
const sn = "http://www.w3.org/2000/svg", ia = class ia {
};
M(ia, "CSS", 96), M(ia, "PDF", 72), M(ia, "PDF_TO_CSS_UNITS", ia.CSS / ia.PDF);
let Wn = ia;
async function ph(d, t = "text") {
  if (Eh(d, document.baseURI)) {
    const e = await fetch(d);
    if (!e.ok)
      throw new Error(e.statusText);
    switch (t) {
      case "arraybuffer":
        return e.arrayBuffer();
      case "blob":
        return e.blob();
      case "json":
        return e.json();
    }
    return e.text();
  }
  return new Promise((e, i) => {
    const s = new XMLHttpRequest();
    s.open("GET", d, !0), s.responseType = t, s.onreadystatechange = () => {
      if (s.readyState === XMLHttpRequest.DONE) {
        if (s.status === 200 || s.status === 0) {
          switch (t) {
            case "arraybuffer":
            case "blob":
            case "json":
              e(s.response);
              return;
          }
          e(s.responseText);
          return;
        }
        i(new Error(s.statusText));
      }
    }, s.send(null);
  });
}
class Fd {
  constructor({
    viewBox: t,
    userUnit: e,
    scale: i,
    rotation: s,
    offsetX: r = 0,
    offsetY: a = 0,
    dontFlip: o = !1
  }) {
    this.viewBox = t, this.userUnit = e, this.scale = i, this.rotation = s, this.offsetX = r, this.offsetY = a, i *= e;
    const l = (t[2] + t[0]) / 2, h = (t[3] + t[1]) / 2;
    let c, u, f, m;
    switch (s %= 360, s < 0 && (s += 360), s) {
      case 180:
        c = -1, u = 0, f = 0, m = 1;
        break;
      case 90:
        c = 0, u = 1, f = 1, m = 0;
        break;
      case 270:
        c = 0, u = -1, f = -1, m = 0;
        break;
      case 0:
        c = 1, u = 0, f = 0, m = -1;
        break;
      default:
        throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
    }
    o && (f = -f, m = -m);
    let A, y, v, w;
    c === 0 ? (A = Math.abs(h - t[1]) * i + r, y = Math.abs(l - t[0]) * i + a, v = (t[3] - t[1]) * i, w = (t[2] - t[0]) * i) : (A = Math.abs(l - t[0]) * i + r, y = Math.abs(h - t[1]) * i + a, v = (t[2] - t[0]) * i, w = (t[3] - t[1]) * i), this.transform = [c * i, u * i, f * i, m * i, A - c * i * l - f * i * h, y - u * i * l - m * i * h], this.width = v, this.height = w;
  }
  get rawDims() {
    const t = this.viewBox;
    return st(this, "rawDims", {
      pageWidth: t[2] - t[0],
      pageHeight: t[3] - t[1],
      pageX: t[0],
      pageY: t[1]
    });
  }
  clone({
    scale: t = this.scale,
    rotation: e = this.rotation,
    offsetX: i = this.offsetX,
    offsetY: s = this.offsetY,
    dontFlip: r = !1
  } = {}) {
    return new Fd({
      viewBox: this.viewBox.slice(),
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: i,
      offsetY: s,
      dontFlip: r
    });
  }
  convertToViewportPoint(t, e) {
    const i = [t, e];
    return z.applyTransform(i, this.transform), i;
  }
  convertToViewportRectangle(t) {
    const e = [t[0], t[1]];
    z.applyTransform(e, this.transform);
    const i = [t[2], t[3]];
    return z.applyTransform(i, this.transform), [e[0], e[1], i[0], i[1]];
  }
  convertToPdfPoint(t, e) {
    const i = [t, e];
    return z.applyInverseTransform(i, this.transform), i;
  }
}
class pf extends wo {
  constructor(t, e = 0) {
    super(t, "RenderingCancelledException"), this.extraDelay = e;
  }
}
function Nd(d) {
  const t = d.length;
  let e = 0;
  for (; e < t && d[e].trim() === ""; )
    e++;
  return d.substring(e, e + 5).toLowerCase() === "data:";
}
function gf(d) {
  return typeof d == "string" && /\.pdf$/i.test(d);
}
function Cm(d) {
  return [d] = d.split(/[#?]/, 1), d.substring(d.lastIndexOf("/") + 1);
}
function Tm(d, t = "document.pdf") {
  if (typeof d != "string")
    return t;
  if (Nd(d))
    return J('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), t;
  const i = ((o) => {
    try {
      return new URL(o);
    } catch {
      try {
        return new URL(decodeURIComponent(o));
      } catch {
        try {
          return new URL(o, "https://foo.bar");
        } catch {
          try {
            return new URL(decodeURIComponent(o), "https://foo.bar");
          } catch {
            return null;
          }
        }
      }
    }
  })(d);
  if (!i)
    return t;
  const s = (o) => {
    try {
      let l = decodeURIComponent(o);
      return l.includes("/") ? (l = l.split("/").at(-1), l.test(/^\.pdf$/i) ? l : o) : l;
    } catch {
      return o;
    }
  }, r = /\.pdf$/i, a = i.pathname.split("/").at(-1);
  if (r.test(a))
    return s(a);
  if (i.searchParams.size > 0) {
    const o = Array.from(i.searchParams.values()).reverse();
    for (const h of o)
      if (r.test(h))
        return s(h);
    const l = Array.from(i.searchParams.keys()).reverse();
    for (const h of l)
      if (r.test(h))
        return s(h);
  }
  if (i.hash) {
    const l = /[^/?#=]+\.pdf\b(?!.*\.pdf\b)/i.exec(i.hash);
    if (l)
      return s(l[0]);
  }
  return t;
}
class Ng {
  constructor() {
    M(this, "started", /* @__PURE__ */ Object.create(null));
    M(this, "times", []);
  }
  time(t) {
    t in this.started && J(`Timer is already running for ${t}`), this.started[t] = Date.now();
  }
  timeEnd(t) {
    t in this.started || J(`Timer has not been started for ${t}`), this.times.push({
      name: t,
      start: this.started[t],
      end: Date.now()
    }), delete this.started[t];
  }
  toString() {
    const t = [];
    let e = 0;
    for (const {
      name: i
    } of this.times)
      e = Math.max(i.length, e);
    for (const {
      name: i,
      start: s,
      end: r
    } of this.times)
      t.push(`${i.padEnd(e)} ${r - s}ms
`);
    return t.join("");
  }
}
function Eh(d, t) {
  const e = t ? URL.parse(d, t) : URL.parse(d);
  return (e == null ? void 0 : e.protocol) === "http:" || (e == null ? void 0 : e.protocol) === "https:";
}
function $i(d) {
  d.preventDefault();
}
function zt(d) {
  d.preventDefault(), d.stopPropagation();
}
function gy(d) {
  console.log("Deprecated API usage: " + d);
}
var Qh;
class qh {
  static toDateObject(t) {
    if (t instanceof Date)
      return t;
    if (!t || typeof t != "string")
      return null;
    n(this, Qh) || p(this, Qh, new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+|-])?(\\d{2})?'?(\\d{2})?'?"));
    const e = n(this, Qh).exec(t);
    if (!e)
      return null;
    const i = parseInt(e[1], 10);
    let s = parseInt(e[2], 10);
    s = s >= 1 && s <= 12 ? s - 1 : 0;
    let r = parseInt(e[3], 10);
    r = r >= 1 && r <= 31 ? r : 1;
    let a = parseInt(e[4], 10);
    a = a >= 0 && a <= 23 ? a : 0;
    let o = parseInt(e[5], 10);
    o = o >= 0 && o <= 59 ? o : 0;
    let l = parseInt(e[6], 10);
    l = l >= 0 && l <= 59 ? l : 0;
    const h = e[7] || "Z";
    let c = parseInt(e[8], 10);
    c = c >= 0 && c <= 23 ? c : 0;
    let u = parseInt(e[9], 10) || 0;
    return u = u >= 0 && u <= 59 ? u : 0, h === "-" ? (a += c, o += u) : h === "+" && (a -= c, o -= u), new Date(Date.UTC(i, s, r, a, o, l));
  }
}
Qh = new WeakMap(), g(qh, Qh);
function Pm(d, {
  scale: t = 1,
  rotation: e = 0
}) {
  const {
    width: i,
    height: s
  } = d.attributes.style, r = [0, 0, parseInt(i), parseInt(s)];
  return new Fd({
    viewBox: r,
    userUnit: 1,
    scale: t,
    rotation: e
  });
}
function gh(d) {
  if (d.startsWith("#")) {
    const t = parseInt(d.slice(1), 16);
    return [(t & 16711680) >> 16, (t & 65280) >> 8, t & 255];
  }
  return d.startsWith("rgb(") ? d.slice(4, -1).split(",").map((t) => parseInt(t)) : d.startsWith("rgba(") ? d.slice(5, -1).split(",").map((t) => parseInt(t)).slice(0, 3) : (J(`Not a valid color format: "${d}"`), [0, 0, 0]);
}
function my(d) {
  const t = document.createElement("span");
  t.style.visibility = "hidden", t.style.colorScheme = "only light", document.body.append(t);
  for (const e of d.keys()) {
    t.style.color = e;
    const i = window.getComputedStyle(t).color;
    d.set(e, gh(i));
  }
  t.remove();
}
function Vt(d) {
  const {
    a: t,
    b: e,
    c: i,
    d: s,
    e: r,
    f: a
  } = d.getTransform();
  return [t, e, i, s, r, a];
}
function xs(d) {
  const {
    a: t,
    b: e,
    c: i,
    d: s,
    e: r,
    f: a
  } = d.getTransform().invertSelf();
  return [t, e, i, s, r, a];
}
function Wr(d, t, e = !1, i = !0) {
  if (t instanceof Fd) {
    const {
      pageWidth: s,
      pageHeight: r
    } = t.rawDims, {
      style: a
    } = d, o = _e.isCSSRoundSupported, l = `var(--total-scale-factor) * ${s}px`, h = `var(--total-scale-factor) * ${r}px`, c = o ? `round(down, ${l}, var(--scale-round-x))` : `calc(${l})`, u = o ? `round(down, ${h}, var(--scale-round-y))` : `calc(${h})`;
    !e || t.rotation % 180 === 0 ? (a.width = c, a.height = u) : (a.width = u, a.height = c);
  }
  i && d.setAttribute("data-main-rotation", t.rotation);
}
class Ss {
  constructor() {
    const {
      pixelRatio: t
    } = Ss;
    this.sx = t, this.sy = t;
  }
  get scaled() {
    return this.sx !== 1 || this.sy !== 1;
  }
  get symmetric() {
    return this.sx === this.sy;
  }
  limitCanvas(t, e, i, s, r = -1) {
    let a = 1 / 0, o = 1 / 0, l = 1 / 0;
    i = Ss.capPixels(i, r), i > 0 && (a = Math.sqrt(i / (t * e))), s !== -1 && (o = s / t, l = s / e);
    const h = Math.min(a, o, l);
    return this.sx > h || this.sy > h ? (this.sx = h, this.sy = h, !0) : !1;
  }
  static get pixelRatio() {
    return globalThis.devicePixelRatio || 1;
  }
  static capPixels(t, e) {
    if (e >= 0) {
      const i = Math.ceil(window.screen.availWidth * window.screen.availHeight * this.pixelRatio ** 2 * (1 + e / 100));
      return t > 0 ? Math.min(t, i) : i;
    }
    return t;
  }
}
const Fu = ["image/apng", "image/avif", "image/bmp", "image/gif", "image/jpeg", "image/png", "image/svg+xml", "image/webp", "image/x-icon"];
class by {
  static get isDarkMode() {
    var t;
    return st(this, "isDarkMode", !!((t = window == null ? void 0 : window.matchMedia) != null && t.call(window, "(prefers-color-scheme: dark)").matches));
  }
}
class Lm {
  static get commentForegroundColor() {
    const t = document.createElement("span");
    t.classList.add("comment", "sidebar");
    const {
      style: e
    } = t;
    e.width = e.height = "0", e.display = "none", e.color = "var(--comment-fg-color)", document.body.append(t);
    const {
      color: i
    } = window.getComputedStyle(t);
    return t.remove(), st(this, "commentForegroundColor", gh(i));
  }
}
function km(d, t, e, i) {
  i = Math.min(Math.max(i ?? 1, 0), 1);
  const s = 255 * (1 - i);
  return d = Math.round(d * i + s), t = Math.round(t * i + s), e = Math.round(e * i + s), [d, t, e];
}
function Og(d, t) {
  const e = d[0] / 255, i = d[1] / 255, s = d[2] / 255, r = Math.max(e, i, s), a = Math.min(e, i, s), o = (r + a) / 2;
  if (r === a)
    t[0] = t[1] = 0;
  else {
    const l = r - a;
    switch (t[1] = o < 0.5 ? l / (r + a) : l / (2 - r - a), r) {
      case e:
        t[0] = ((i - s) / l + (i < s ? 6 : 0)) * 60;
        break;
      case i:
        t[0] = ((s - e) / l + 2) * 60;
        break;
      case s:
        t[0] = ((e - i) / l + 4) * 60;
        break;
    }
  }
  t[2] = o;
}
function Uf(d, t) {
  const e = d[0], i = d[1], s = d[2], r = (1 - Math.abs(2 * s - 1)) * i, a = r * (1 - Math.abs(e / 60 % 2 - 1)), o = s - r / 2;
  switch (Math.floor(e / 60)) {
    case 0:
      t[0] = r + o, t[1] = a + o, t[2] = o;
      break;
    case 1:
      t[0] = a + o, t[1] = r + o, t[2] = o;
      break;
    case 2:
      t[0] = o, t[1] = r + o, t[2] = a + o;
      break;
    case 3:
      t[0] = o, t[1] = a + o, t[2] = r + o;
      break;
    case 4:
      t[0] = a + o, t[1] = o, t[2] = r + o;
      break;
    case 5:
    case 6:
      t[0] = r + o, t[1] = o, t[2] = a + o;
      break;
  }
}
function Bg(d) {
  return d <= 0.03928 ? d / 12.92 : ((d + 0.055) / 1.055) ** 2.4;
}
function Hg(d, t, e) {
  Uf(d, e), e.map(Bg);
  const i = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  Uf(t, e), e.map(Bg);
  const s = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  return i > s ? (i + 0.05) / (s + 0.05) : (s + 0.05) / (i + 0.05);
}
const Ug = /* @__PURE__ */ new Map();
function Rm(d, t) {
  const e = d[0] + d[1] * 256 + d[2] * 65536 + t[0] * 16777216 + t[1] * 4294967296 + t[2] * 1099511627776;
  let i = Ug.get(e);
  if (i)
    return i;
  const s = new Float32Array(9), r = s.subarray(0, 3), a = s.subarray(3, 6);
  Og(d, a);
  const o = s.subarray(6, 9);
  Og(t, o);
  const l = o[2] < 0.5, h = l ? 12 : 4.5;
  if (a[2] = l ? Math.sqrt(a[2]) : 1 - Math.sqrt(1 - a[2]), Hg(a, o, r) < h) {
    let c, u;
    l ? (c = a[2], u = 1) : (c = 0, u = a[2]);
    const f = 5e-3;
    for (; u - c > f; ) {
      const m = a[2] = (c + u) / 2;
      l === Hg(a, o, r) < h ? c = m : u = m;
    }
    a[2] = l ? u : c;
  }
  return Uf(a, r), i = z.makeHexColor(Math.round(r[0] * 255), Math.round(r[1] * 255), Math.round(r[2] * 255)), Ug.set(e, i), i;
}
function mg({
  html: d,
  dir: t,
  className: e
}, i) {
  const s = document.createDocumentFragment();
  if (typeof d == "string") {
    const r = document.createElement("p");
    r.dir = t || "auto";
    const a = d.split(/(?:\r\n?|\n)/);
    for (let o = 0, l = a.length; o < l; ++o) {
      const h = a[o];
      r.append(document.createTextNode(h)), o < l - 1 && r.append(document.createElement("br"));
    }
    s.append(r);
  } else
    gg.render({
      xfaHtml: d,
      div: s,
      intent: "richText"
    });
  s.firstChild.classList.add("richText", e), i.append(s);
}
var Zn, Jn, ji, qi, tc, Qn, Ho, Uo, ec, ju, Mm, Fe, Dm, Im, _o, Sh;
const an = class an {
  constructor(t) {
    g(this, Fe);
    g(this, Zn, null);
    g(this, Jn, null);
    g(this, ji);
    g(this, qi, null);
    g(this, tc, null);
    g(this, Qn, null);
    g(this, Ho, null);
    g(this, Uo, null);
    p(this, ji, t), n(an, ec) || p(an, ec, Object.freeze({
      freetext: "pdfjs-editor-remove-freetext-button",
      highlight: "pdfjs-editor-remove-highlight-button",
      ink: "pdfjs-editor-remove-ink-button",
      stamp: "pdfjs-editor-remove-stamp-button",
      signature: "pdfjs-editor-remove-signature-button"
    }));
  }
  render() {
    const t = p(this, Zn, document.createElement("div"));
    t.classList.add("editToolbar", "hidden"), t.setAttribute("role", "toolbar");
    const e = n(this, ji)._uiManager._signal;
    e instanceof AbortSignal && !e.aborted && (t.addEventListener("contextmenu", $i, {
      signal: e
    }), t.addEventListener("pointerdown", b(an, ju, Mm), {
      signal: e
    }));
    const i = p(this, qi, document.createElement("div"));
    i.className = "buttons", t.append(i);
    const s = n(this, ji).toolbarPosition;
    if (s) {
      const {
        style: r
      } = t, a = n(this, ji)._uiManager.direction === "ltr" ? 1 - s[0] : s[0];
      r.insetInlineEnd = `${100 * a}%`, r.top = `calc(${100 * s[1]}% + var(--editor-toolbar-vert-offset))`;
    }
    return t;
  }
  get div() {
    return n(this, Zn);
  }
  hide() {
    var t;
    n(this, Zn).classList.add("hidden"), (t = n(this, Jn)) == null || t.hideDropdown();
  }
  show() {
    var t, e;
    n(this, Zn).classList.remove("hidden"), (t = n(this, tc)) == null || t.shown(), (e = n(this, Qn)) == null || e.shown();
  }
  addDeleteButton() {
    const {
      editorType: t,
      _uiManager: e
    } = n(this, ji), i = document.createElement("button");
    i.classList.add("basic", "deleteButton"), i.tabIndex = 0, i.setAttribute("data-l10n-id", n(an, ec)[t]), b(this, Fe, _o).call(this, i) && i.addEventListener("click", (s) => {
      e.delete();
    }, {
      signal: e._signal
    }), n(this, qi).append(i);
  }
  async addAltText(t) {
    const e = await t.render();
    b(this, Fe, _o).call(this, e), n(this, qi).append(e, n(this, Fe, Sh)), p(this, tc, t);
  }
  addComment(t, e = null) {
    if (n(this, Qn))
      return;
    const i = t.renderForToolbar();
    if (!i)
      return;
    b(this, Fe, _o).call(this, i);
    const s = p(this, Ho, n(this, Fe, Sh));
    e ? (n(this, qi).insertBefore(i, e), n(this, qi).insertBefore(s, e)) : n(this, qi).append(i, s), p(this, Qn, t), t.toolbar = this;
  }
  addColorPicker(t) {
    if (n(this, Jn))
      return;
    p(this, Jn, t);
    const e = t.renderButton();
    b(this, Fe, _o).call(this, e), n(this, qi).append(e, n(this, Fe, Sh));
  }
  async addEditSignatureButton(t) {
    const e = p(this, Uo, await t.renderEditButton(n(this, ji)));
    b(this, Fe, _o).call(this, e), n(this, qi).append(e, n(this, Fe, Sh));
  }
  removeButton(t) {
    var e, i;
    switch (t) {
      case "comment":
        (e = n(this, Qn)) == null || e.removeToolbarCommentButton(), p(this, Qn, null), (i = n(this, Ho)) == null || i.remove(), p(this, Ho, null);
        break;
    }
  }
  async addButton(t, e) {
    switch (t) {
      case "colorPicker":
        this.addColorPicker(e);
        break;
      case "altText":
        await this.addAltText(e);
        break;
      case "editSignature":
        await this.addEditSignatureButton(e);
        break;
      case "delete":
        this.addDeleteButton();
        break;
      case "comment":
        this.addComment(e);
        break;
    }
  }
  async addButtonBefore(t, e, i) {
    const s = n(this, qi).querySelector(i);
    s && t === "comment" && this.addComment(e, s);
  }
  updateEditSignatureButton(t) {
    n(this, Uo) && (n(this, Uo).title = t);
  }
  remove() {
    var t;
    n(this, Zn).remove(), (t = n(this, Jn)) == null || t.destroy(), p(this, Jn, null);
  }
};
Zn = new WeakMap(), Jn = new WeakMap(), ji = new WeakMap(), qi = new WeakMap(), tc = new WeakMap(), Qn = new WeakMap(), Ho = new WeakMap(), Uo = new WeakMap(), ec = new WeakMap(), ju = new WeakSet(), Mm = function(t) {
  t.stopPropagation();
}, Fe = new WeakSet(), Dm = function(t) {
  n(this, ji)._focusEventsAllowed = !1, zt(t);
}, Im = function(t) {
  n(this, ji)._focusEventsAllowed = !0, zt(t);
}, _o = function(t) {
  const e = n(this, ji)._uiManager._signal;
  return !(e instanceof AbortSignal) || e.aborted ? !1 : (t.addEventListener("focusin", b(this, Fe, Dm).bind(this), {
    capture: !0,
    signal: e
  }), t.addEventListener("focusout", b(this, Fe, Im).bind(this), {
    capture: !0,
    signal: e
  }), t.addEventListener("contextmenu", $i, {
    signal: e
  }), !0);
}, Sh = function() {
  const t = document.createElement("div");
  return t.className = "divider", t;
}, g(an, ju), g(an, ec, null);
let $f = an;
var ic, ra, ln, jn, Fm, Nm, Vf;
class yy {
  constructor(t) {
    g(this, jn);
    g(this, ic, null);
    g(this, ra, null);
    g(this, ln);
    p(this, ln, t);
  }
  show(t, e, i) {
    const [s, r] = b(this, jn, Nm).call(this, e, i), {
      style: a
    } = n(this, ra) || p(this, ra, b(this, jn, Fm).call(this));
    t.append(n(this, ra)), a.insetInlineEnd = `${100 * s}%`, a.top = `calc(${100 * r}% + var(--editor-toolbar-vert-offset))`;
  }
  hide() {
    n(this, ra).remove();
  }
}
ic = new WeakMap(), ra = new WeakMap(), ln = new WeakMap(), jn = new WeakSet(), Fm = function() {
  const t = p(this, ra, document.createElement("div"));
  t.className = "editToolbar", t.setAttribute("role", "toolbar");
  const e = n(this, ln)._signal;
  e instanceof AbortSignal && !e.aborted && t.addEventListener("contextmenu", $i, {
    signal: e
  });
  const i = p(this, ic, document.createElement("div"));
  return i.className = "buttons", t.append(i), n(this, ln).hasCommentManager() && b(this, jn, Vf).call(this, "commentButton", "pdfjs-comment-floating-button", "pdfjs-comment-floating-button-label", () => {
    n(this, ln).commentSelection("floating_button");
  }), b(this, jn, Vf).call(this, "highlightButton", "pdfjs-highlight-floating-button1", "pdfjs-highlight-floating-button-label", () => {
    n(this, ln).highlightSelection("floating_button");
  }), t;
}, Nm = function(t, e) {
  let i = 0, s = 0;
  for (const r of t) {
    const a = r.y + r.height;
    if (a < i)
      continue;
    const o = r.x + (e ? r.width : 0);
    if (a > i) {
      s = o, i = a;
      continue;
    }
    e ? o > s && (s = o) : o < s && (s = o);
  }
  return [e ? 1 - s : s, i];
}, Vf = function(t, e, i, s) {
  const r = document.createElement("button");
  r.classList.add("basic", t), r.tabIndex = 0, r.setAttribute("data-l10n-id", e);
  const a = document.createElement("span");
  r.append(a), a.className = "visuallyHidden", a.setAttribute("data-l10n-id", i);
  const o = n(this, ln)._signal;
  o instanceof AbortSignal && !o.aborted && (r.addEventListener("contextmenu", $i, {
    signal: o
  }), r.addEventListener("click", s, {
    signal: o
  })), n(this, ic).append(r);
};
function Om(d, t, e) {
  for (const i of e)
    t.addEventListener(i, d[i].bind(d));
}
var qu;
class Ay {
  constructor() {
    g(this, qu, 0);
  }
  get id() {
    return `${Gh}${oe(this, qu)._++}`;
  }
}
qu = new WeakMap();
var $o, sc, He, Vo, su;
const Tg = class Tg {
  constructor() {
    g(this, Vo);
    g(this, $o, fg());
    g(this, sc, 0);
    g(this, He, null);
  }
  static get _isSVGFittingCanvas() {
    const t = 'data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" style="fill:red;"/></svg>', i = new OffscreenCanvas(1, 3).getContext("2d", {
      willReadFrequently: !0
    }), s = new Image();
    s.src = t;
    const r = s.decode().then(() => (i.drawImage(s, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(i.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
    return st(this, "_isSVGFittingCanvas", r);
  }
  async getFromFile(t) {
    const {
      lastModified: e,
      name: i,
      size: s,
      type: r
    } = t;
    return b(this, Vo, su).call(this, `${e}_${i}_${s}_${r}`, t);
  }
  async getFromUrl(t) {
    return b(this, Vo, su).call(this, t, t);
  }
  async getFromBlob(t, e) {
    const i = await e;
    return b(this, Vo, su).call(this, t, i);
  }
  async getFromId(t) {
    n(this, He) || p(this, He, /* @__PURE__ */ new Map());
    const e = n(this, He).get(t);
    if (!e)
      return null;
    if (e.bitmap)
      return e.refCounter += 1, e;
    if (e.file)
      return this.getFromFile(e.file);
    if (e.blobPromise) {
      const {
        blobPromise: i
      } = e;
      return delete e.blobPromise, this.getFromBlob(e.id, i);
    }
    return this.getFromUrl(e.url);
  }
  getFromCanvas(t, e) {
    n(this, He) || p(this, He, /* @__PURE__ */ new Map());
    let i = n(this, He).get(t);
    if (i != null && i.bitmap)
      return i.refCounter += 1, i;
    const s = new OffscreenCanvas(e.width, e.height);
    return s.getContext("2d").drawImage(e, 0, 0), i = {
      bitmap: s.transferToImageBitmap(),
      id: `image_${n(this, $o)}_${oe(this, sc)._++}`,
      refCounter: 1,
      isSvg: !1
    }, n(this, He).set(t, i), n(this, He).set(i.id, i), i;
  }
  getSvgUrl(t) {
    const e = n(this, He).get(t);
    return e != null && e.isSvg ? e.svgUrl : null;
  }
  deleteId(t) {
    var s;
    n(this, He) || p(this, He, /* @__PURE__ */ new Map());
    const e = n(this, He).get(t);
    if (!e || (e.refCounter -= 1, e.refCounter !== 0))
      return;
    const {
      bitmap: i
    } = e;
    if (!e.url && !e.file) {
      const r = new OffscreenCanvas(i.width, i.height);
      r.getContext("bitmaprenderer").transferFromImageBitmap(i), e.blobPromise = r.convertToBlob();
    }
    (s = i.close) == null || s.call(i), e.bitmap = null;
  }
  isValidId(t) {
    return t.startsWith(`image_${n(this, $o)}_`);
  }
};
$o = new WeakMap(), sc = new WeakMap(), He = new WeakMap(), Vo = new WeakSet(), su = async function(t, e) {
  n(this, He) || p(this, He, /* @__PURE__ */ new Map());
  let i = n(this, He).get(t);
  if (i === null)
    return null;
  if (i != null && i.bitmap)
    return i.refCounter += 1, i;
  try {
    i || (i = {
      bitmap: null,
      id: `image_${n(this, $o)}_${oe(this, sc)._++}`,
      refCounter: 0,
      isSvg: !1
    });
    let s;
    if (typeof e == "string" ? (i.url = e, s = await ph(e, "blob")) : e instanceof File ? s = i.file = e : e instanceof Blob && (s = e), s.type === "image/svg+xml") {
      const r = Tg._isSVGFittingCanvas, a = new FileReader(), o = new Image(), l = new Promise((h, c) => {
        o.onload = () => {
          i.bitmap = o, i.isSvg = !0, h();
        }, a.onload = async () => {
          const u = i.svgUrl = a.result;
          o.src = await r ? `${u}#svgView(preserveAspectRatio(none))` : u;
        }, o.onerror = a.onerror = c;
      });
      a.readAsDataURL(s), await l;
    } else
      i.bitmap = await createImageBitmap(s);
    i.refCounter = 1;
  } catch (s) {
    J(s), i = null;
  }
  return n(this, He).set(t, i), i && n(this, He).set(i.id, i), i;
};
let zf = Tg;
var ee, tr, nc, $t;
class wy {
  constructor(t = 128) {
    g(this, ee, []);
    g(this, tr, !1);
    g(this, nc);
    g(this, $t, -1);
    p(this, nc, t);
  }
  add({
    cmd: t,
    undo: e,
    post: i,
    mustExec: s,
    type: r = NaN,
    overwriteIfSameType: a = !1,
    keepUndo: o = !1
  }) {
    if (s && t(), n(this, tr))
      return;
    const l = {
      cmd: t,
      undo: e,
      post: i,
      type: r
    };
    if (n(this, $t) === -1) {
      n(this, ee).length > 0 && (n(this, ee).length = 0), p(this, $t, 0), n(this, ee).push(l);
      return;
    }
    if (a && n(this, ee)[n(this, $t)].type === r) {
      o && (l.undo = n(this, ee)[n(this, $t)].undo), n(this, ee)[n(this, $t)] = l;
      return;
    }
    const h = n(this, $t) + 1;
    h === n(this, nc) ? n(this, ee).splice(0, 1) : (p(this, $t, h), h < n(this, ee).length && n(this, ee).splice(h)), n(this, ee).push(l);
  }
  undo() {
    if (n(this, $t) === -1)
      return;
    p(this, tr, !0);
    const {
      undo: t,
      post: e
    } = n(this, ee)[n(this, $t)];
    t(), e == null || e(), p(this, tr, !1), p(this, $t, n(this, $t) - 1);
  }
  redo() {
    if (n(this, $t) < n(this, ee).length - 1) {
      p(this, $t, n(this, $t) + 1), p(this, tr, !0);
      const {
        cmd: t,
        post: e
      } = n(this, ee)[n(this, $t)];
      t(), e == null || e(), p(this, tr, !1);
    }
  }
  hasSomethingToUndo() {
    return n(this, $t) !== -1;
  }
  hasSomethingToRedo() {
    return n(this, $t) < n(this, ee).length - 1;
  }
  cleanType(t) {
    if (n(this, $t) !== -1) {
      for (let e = n(this, $t); e >= 0; e--)
        if (n(this, ee)[e].type !== t) {
          n(this, ee).splice(e + 1, n(this, $t) - e), p(this, $t, e);
          return;
        }
      n(this, ee).length = 0, p(this, $t, -1);
    }
  }
  destroy() {
    p(this, ee, null);
  }
}
ee = new WeakMap(), tr = new WeakMap(), nc = new WeakMap(), $t = new WeakMap();
var Xu, Bm;
class Od {
  constructor(t) {
    g(this, Xu);
    this.buffer = [], this.callbacks = /* @__PURE__ */ new Map(), this.allKeys = /* @__PURE__ */ new Set();
    const {
      isMac: e
    } = _e.platform;
    for (const [i, s, r = {}] of t)
      for (const a of i) {
        const o = a.startsWith("mac+");
        e && o ? (this.callbacks.set(a.slice(4), {
          callback: s,
          options: r
        }), this.allKeys.add(a.split("+").at(-1))) : !e && !o && (this.callbacks.set(a, {
          callback: s,
          options: r
        }), this.allKeys.add(a.split("+").at(-1)));
      }
  }
  exec(t, e) {
    if (!this.allKeys.has(e.key))
      return;
    const i = this.callbacks.get(b(this, Xu, Bm).call(this, e));
    if (!i)
      return;
    const {
      callback: s,
      options: {
        bubbles: r = !1,
        args: a = [],
        checker: o = null
      }
    } = i;
    o && !o(t, e) || (s.bind(t, ...a, e)(), r || zt(e));
  }
}
Xu = new WeakSet(), Bm = function(t) {
  t.altKey && this.buffer.push("alt"), t.ctrlKey && this.buffer.push("ctrl"), t.metaKey && this.buffer.push("meta"), t.shiftKey && this.buffer.push("shift"), this.buffer.push(t.key);
  const e = this.buffer.join("+");
  return this.buffer.length = 0, e;
};
const Yu = class Yu {
  get _colors() {
    const t = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
    return my(t), st(this, "_colors", t);
  }
  convert(t) {
    const e = gh(t);
    if (!window.matchMedia("(forced-colors: active)").matches)
      return e;
    for (const [i, s] of this._colors)
      if (s.every((r, a) => r === e[a]))
        return Yu._colorsMapping.get(i);
    return e;
  }
  getHexCode(t) {
    const e = this._colors.get(t);
    return e ? z.makeHexColor(...e) : t;
  }
};
M(Yu, "_colorsMapping", /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]));
let Gf = Yu;
var zo, wi, Go, qt, ce, Wo, Xi, jo, Yi, Ue, er, ir, qo, sr, Ps, Ki, aa, rc, ac, Xo, oc, Ls, nr, Yo, rr, ks, Ku, ar, Ko, lc, or, oa, Zo, lr, hc, re, At, hn, hr, cr, cc, Jo, dc, dr, Rs, cn, uc, fc, Zi, F, nu, Wf, Hm, Um, _h, $m, Vm, zm, jf, Gm, qf, Xf, Wm, Ze, nn, jm, qm, Yf, Xm, xh, Kf;
const Mo = class Mo {
  constructor(t, e, i, s, r, a, o, l, h, c, u, f, m, A, y, v) {
    g(this, F);
    g(this, zo, new AbortController());
    g(this, wi, null);
    g(this, Go, null);
    g(this, qt, /* @__PURE__ */ new Map());
    g(this, ce, /* @__PURE__ */ new Map());
    g(this, Wo, null);
    g(this, Xi, null);
    g(this, jo, null);
    g(this, Yi, new wy());
    g(this, Ue, null);
    g(this, er, null);
    g(this, ir, null);
    g(this, qo, 0);
    g(this, sr, /* @__PURE__ */ new Set());
    g(this, Ps, null);
    g(this, Ki, null);
    g(this, aa, /* @__PURE__ */ new Set());
    M(this, "_editorUndoBar", null);
    g(this, rc, !1);
    g(this, ac, !1);
    g(this, Xo, !1);
    g(this, oc, null);
    g(this, Ls, null);
    g(this, nr, null);
    g(this, Yo, null);
    g(this, rr, !1);
    g(this, ks, null);
    g(this, Ku, new Ay());
    g(this, ar, !1);
    g(this, Ko, !1);
    g(this, lc, !1);
    g(this, or, null);
    g(this, oa, null);
    g(this, Zo, null);
    g(this, lr, null);
    g(this, hc, null);
    g(this, re, Z.NONE);
    g(this, At, /* @__PURE__ */ new Set());
    g(this, hn, null);
    g(this, hr, null);
    g(this, cr, null);
    g(this, cc, null);
    g(this, Jo, null);
    g(this, dc, {
      isEditing: !1,
      isEmpty: !0,
      hasSomethingToUndo: !1,
      hasSomethingToRedo: !1,
      hasSelectedEditor: !1,
      hasSelectedText: !1
    });
    g(this, dr, [0, 0]);
    g(this, Rs, null);
    g(this, cn, null);
    g(this, uc, null);
    g(this, fc, null);
    g(this, Zi, null);
    const w = this._signal = n(this, zo).signal;
    p(this, cn, t), p(this, uc, e), p(this, fc, i), p(this, Wo, s), p(this, Ue, r), p(this, hr, a), p(this, Jo, l), this._eventBus = o, o._on("editingaction", this.onEditingAction.bind(this), {
      signal: w
    }), o._on("pagechanging", this.onPageChanging.bind(this), {
      signal: w
    }), o._on("scalechanging", this.onScaleChanging.bind(this), {
      signal: w
    }), o._on("rotationchanging", this.onRotationChanging.bind(this), {
      signal: w
    }), o._on("setpreference", this.onSetPreference.bind(this), {
      signal: w
    }), o._on("switchannotationeditorparams", (S) => this.updateParams(S.type, S.value), {
      signal: w
    }), window.addEventListener("pointerdown", () => {
      p(this, Ko, !0);
    }, {
      capture: !0,
      signal: w
    }), window.addEventListener("pointerup", () => {
      p(this, Ko, !1);
    }, {
      capture: !0,
      signal: w
    }), b(this, F, $m).call(this), b(this, F, Wm).call(this), b(this, F, jf).call(this), p(this, Xi, l.annotationStorage), p(this, oc, l.filterFactory), p(this, cr, h), p(this, Yo, c || null), p(this, rc, u), p(this, ac, f), p(this, Xo, m), p(this, hc, A || null), this.viewParameters = {
      realScale: Wn.PDF_TO_CSS_UNITS,
      rotation: 0
    }, this.isShiftKeyDown = !1, this._editorUndoBar = y || null, this._supportsPinchToZoom = v !== !1, r == null || r.setSidebarUiManager(this);
  }
  static get _keyboardManager() {
    const t = Mo.prototype, e = (a) => n(a, cn).contains(document.activeElement) && document.activeElement.tagName !== "BUTTON" && a.hasSomethingToControl(), i = (a, {
      target: o
    }) => {
      if (o instanceof HTMLInputElement) {
        const {
          type: l
        } = o;
        return l !== "text" && l !== "number";
      }
      return !0;
    }, s = this.TRANSLATE_SMALL, r = this.TRANSLATE_BIG;
    return st(this, "_keyboardManager", new Od([[["ctrl+a", "mac+meta+a"], t.selectAll, {
      checker: i
    }], [["ctrl+z", "mac+meta+z"], t.undo, {
      checker: i
    }], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], t.redo, {
      checker: i
    }], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], t.delete, {
      checker: i
    }], [["Enter", "mac+Enter"], t.addNewEditorFromKeyboard, {
      checker: (a, {
        target: o
      }) => !(o instanceof HTMLButtonElement) && n(a, cn).contains(o) && !a.isEnterHandled
    }], [[" ", "mac+ "], t.addNewEditorFromKeyboard, {
      checker: (a, {
        target: o
      }) => !(o instanceof HTMLButtonElement) && n(a, cn).contains(document.activeElement)
    }], [["Escape", "mac+Escape"], t.unselectAll], [["ArrowLeft", "mac+ArrowLeft"], t.translateSelectedEditors, {
      args: [-s, 0],
      checker: e
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t.translateSelectedEditors, {
      args: [-r, 0],
      checker: e
    }], [["ArrowRight", "mac+ArrowRight"], t.translateSelectedEditors, {
      args: [s, 0],
      checker: e
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t.translateSelectedEditors, {
      args: [r, 0],
      checker: e
    }], [["ArrowUp", "mac+ArrowUp"], t.translateSelectedEditors, {
      args: [0, -s],
      checker: e
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t.translateSelectedEditors, {
      args: [0, -r],
      checker: e
    }], [["ArrowDown", "mac+ArrowDown"], t.translateSelectedEditors, {
      args: [0, s],
      checker: e
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t.translateSelectedEditors, {
      args: [0, r],
      checker: e
    }]]));
  }
  destroy() {
    var t, e, i, s, r, a, o, l, h;
    (t = n(this, Zi)) == null || t.resolve(), p(this, Zi, null), (e = n(this, zo)) == null || e.abort(), p(this, zo, null), this._signal = null;
    for (const c of n(this, ce).values())
      c.destroy();
    n(this, ce).clear(), n(this, qt).clear(), n(this, aa).clear(), (i = n(this, lr)) == null || i.clear(), p(this, wi, null), n(this, At).clear(), n(this, Yi).destroy(), (s = n(this, Wo)) == null || s.destroy(), (r = n(this, Ue)) == null || r.destroy(), (a = n(this, hr)) == null || a.destroy(), (o = n(this, ks)) == null || o.hide(), p(this, ks, null), (l = n(this, Zo)) == null || l.destroy(), p(this, Zo, null), p(this, Go, null), n(this, Ls) && (clearTimeout(n(this, Ls)), p(this, Ls, null)), n(this, Rs) && (clearTimeout(n(this, Rs)), p(this, Rs, null)), (h = this._editorUndoBar) == null || h.destroy(), p(this, Jo, null);
  }
  combinedSignal(t) {
    return AbortSignal.any([this._signal, t.signal]);
  }
  get mlManager() {
    return n(this, hc);
  }
  get useNewAltTextFlow() {
    return n(this, ac);
  }
  get useNewAltTextWhenAddingImage() {
    return n(this, Xo);
  }
  get hcmFilter() {
    return st(this, "hcmFilter", n(this, cr) ? n(this, oc).addHCMFilter(n(this, cr).foreground, n(this, cr).background) : "none");
  }
  get direction() {
    return st(this, "direction", getComputedStyle(n(this, cn)).direction);
  }
  get _highlightColors() {
    return st(this, "_highlightColors", n(this, Yo) ? new Map(n(this, Yo).split(",").map((t) => (t = t.split("=").map((e) => e.trim()), t[1] = t[1].toUpperCase(), t))) : null);
  }
  get highlightColors() {
    const {
      _highlightColors: t
    } = this;
    if (!t)
      return st(this, "highlightColors", null);
    const e = /* @__PURE__ */ new Map(), i = !!n(this, cr);
    for (const [s, r] of t) {
      const a = s.endsWith("_HCM");
      if (i && a) {
        e.set(s.replace("_HCM", ""), r);
        continue;
      }
      !i && !a && e.set(s, r);
    }
    return st(this, "highlightColors", e);
  }
  get highlightColorNames() {
    return st(this, "highlightColorNames", this.highlightColors ? new Map(Array.from(this.highlightColors, (t) => t.reverse())) : null);
  }
  getNonHCMColor(t) {
    if (!this._highlightColors)
      return t;
    const e = this.highlightColorNames.get(t);
    return this._highlightColors.get(e) || t;
  }
  getNonHCMColorName(t) {
    return this.highlightColorNames.get(t) || t;
  }
  setCurrentDrawingSession(t) {
    t ? (this.unselectAll(), this.disableUserSelect(!0)) : this.disableUserSelect(!1), p(this, ir, t);
  }
  setMainHighlightColorPicker(t) {
    p(this, Zo, t);
  }
  editAltText(t, e = !1) {
    var i;
    (i = n(this, Wo)) == null || i.editAltText(this, t, e);
  }
  hasCommentManager() {
    return !!n(this, Ue);
  }
  editComment(t, e, i, s) {
    var r;
    (r = n(this, Ue)) == null || r.showDialog(this, t, e, i, s);
  }
  selectComment(t, e) {
    const i = n(this, ce).get(t), s = i == null ? void 0 : i.getEditorByUID(e);
    s == null || s.toggleComment(!0, !0);
  }
  updateComment(t) {
    var e;
    (e = n(this, Ue)) == null || e.updateComment(t.getData());
  }
  updatePopupColor(t) {
    var e;
    (e = n(this, Ue)) == null || e.updatePopupColor(t);
  }
  removeComment(t) {
    var e;
    (e = n(this, Ue)) == null || e.removeComments([t.uid]);
  }
  toggleComment(t, e, i = void 0) {
    var s;
    (s = n(this, Ue)) == null || s.toggleCommentPopup(t, e, i);
  }
  makeCommentColor(t, e) {
    var i;
    return t && ((i = n(this, Ue)) == null ? void 0 : i.makeCommentColor(t, e)) || null;
  }
  getCommentDialogElement() {
    var t;
    return ((t = n(this, Ue)) == null ? void 0 : t.dialogElement) || null;
  }
  async waitForEditorsRendered(t) {
    if (n(this, ce).has(t - 1))
      return;
    const {
      resolve: e,
      promise: i
    } = Promise.withResolvers(), s = (r) => {
      r.pageNumber === t && (this._eventBus._off("editorsrendered", s), e());
    };
    this._eventBus.on("editorsrendered", s), await i;
  }
  getSignature(t) {
    var e;
    (e = n(this, hr)) == null || e.getSignature({
      uiManager: this,
      editor: t
    });
  }
  get signatureManager() {
    return n(this, hr);
  }
  switchToMode(t, e) {
    this._eventBus.on("annotationeditormodechanged", e, {
      once: !0,
      signal: this._signal
    }), this._eventBus.dispatch("showannotationeditorui", {
      source: this,
      mode: t
    });
  }
  setPreference(t, e) {
    this._eventBus.dispatch("setpreference", {
      source: this,
      name: t,
      value: e
    });
  }
  onSetPreference({
    name: t,
    value: e
  }) {
    switch (t) {
      case "enableNewAltTextWhenAddingImage":
        p(this, Xo, e);
        break;
    }
  }
  onPageChanging({
    pageNumber: t
  }) {
    p(this, qo, t - 1);
  }
  focusMainContainer() {
    n(this, cn).focus();
  }
  findParent(t, e) {
    for (const i of n(this, ce).values()) {
      const {
        x: s,
        y: r,
        width: a,
        height: o
      } = i.div.getBoundingClientRect();
      if (t >= s && t <= s + a && e >= r && e <= r + o)
        return i;
    }
    return null;
  }
  disableUserSelect(t = !1) {
    n(this, uc).classList.toggle("noUserSelect", t);
  }
  addShouldRescale(t) {
    n(this, aa).add(t);
  }
  removeShouldRescale(t) {
    n(this, aa).delete(t);
  }
  onScaleChanging({
    scale: t
  }) {
    var e;
    this.commitOrRemove(), this.viewParameters.realScale = t * Wn.PDF_TO_CSS_UNITS;
    for (const i of n(this, aa))
      i.onScaleChanging();
    (e = n(this, ir)) == null || e.onScaleChanging();
  }
  onRotationChanging({
    pagesRotation: t
  }) {
    this.commitOrRemove(), this.viewParameters.rotation = t;
  }
  highlightSelection(t = "", e = !1) {
    const i = document.getSelection();
    if (!i || i.isCollapsed)
      return;
    const {
      anchorNode: s,
      anchorOffset: r,
      focusNode: a,
      focusOffset: o
    } = i, l = i.toString(), c = b(this, F, nu).call(this, i).closest(".textLayer"), u = this.getSelectionBoxes(c);
    if (!u)
      return;
    i.empty();
    const f = b(this, F, Wf).call(this, c), m = n(this, re) === Z.NONE, A = () => {
      const y = f == null ? void 0 : f.createAndAddNewEditor({
        x: 0,
        y: 0
      }, !1, {
        methodOfCreation: t,
        boxes: u,
        anchorNode: s,
        anchorOffset: r,
        focusNode: a,
        focusOffset: o,
        text: l
      });
      m && this.showAllEditors("highlight", !0, !0), e && (y == null || y.editComment());
    };
    if (m) {
      this.switchToMode(Z.HIGHLIGHT, A);
      return;
    }
    A();
  }
  commentSelection(t = "") {
    this.highlightSelection(t, !0);
  }
  getAndRemoveDataFromAnnotationStorage(t) {
    if (!n(this, Xi))
      return null;
    const e = `${Gh}${t}`, i = n(this, Xi).getRawValue(e);
    return i && n(this, Xi).remove(e), i;
  }
  addToAnnotationStorage(t) {
    !t.isEmpty() && n(this, Xi) && !n(this, Xi).has(t.id) && n(this, Xi).setValue(t.id, t);
  }
  a11yAlert(t, e = null) {
    const i = n(this, fc);
    i && (i.setAttribute("data-l10n-id", t), e ? i.setAttribute("data-l10n-args", JSON.stringify(e)) : i.removeAttribute("data-l10n-args"));
  }
  blur() {
    if (this.isShiftKeyDown = !1, n(this, rr) && (p(this, rr, !1), b(this, F, _h).call(this, "main_toolbar")), !this.hasSelection)
      return;
    const {
      activeElement: t
    } = document;
    for (const e of n(this, At))
      if (e.div.contains(t)) {
        p(this, oa, [e, t]), e._focusEventsAllowed = !1;
        break;
      }
  }
  focus() {
    if (!n(this, oa))
      return;
    const [t, e] = n(this, oa);
    p(this, oa, null), e.addEventListener("focusin", () => {
      t._focusEventsAllowed = !0;
    }, {
      once: !0,
      signal: this._signal
    }), e.focus();
  }
  addEditListeners() {
    b(this, F, jf).call(this), b(this, F, qf).call(this);
  }
  removeEditListeners() {
    b(this, F, Gm).call(this), b(this, F, Xf).call(this);
  }
  dragOver(t) {
    for (const {
      type: e
    } of t.dataTransfer.items)
      for (const i of n(this, Ki))
        if (i.isHandlingMimeForPasting(e)) {
          t.dataTransfer.dropEffect = "copy", t.preventDefault();
          return;
        }
  }
  drop(t) {
    for (const e of t.dataTransfer.items)
      for (const i of n(this, Ki))
        if (i.isHandlingMimeForPasting(e.type)) {
          i.paste(e, this.currentLayer), t.preventDefault();
          return;
        }
  }
  copy(t) {
    var i;
    if (t.preventDefault(), (i = n(this, wi)) == null || i.commitOrRemove(), !this.hasSelection)
      return;
    const e = [];
    for (const s of n(this, At)) {
      const r = s.serialize(!0);
      r && e.push(r);
    }
    e.length !== 0 && t.clipboardData.setData("application/pdfjs", JSON.stringify(e));
  }
  cut(t) {
    this.copy(t), this.delete();
  }
  async paste(t) {
    t.preventDefault();
    const {
      clipboardData: e
    } = t;
    for (const r of e.items)
      for (const a of n(this, Ki))
        if (a.isHandlingMimeForPasting(r.type)) {
          a.paste(r, this.currentLayer);
          return;
        }
    let i = e.getData("application/pdfjs");
    if (!i)
      return;
    try {
      i = JSON.parse(i);
    } catch (r) {
      J(`paste: "${r.message}".`);
      return;
    }
    if (!Array.isArray(i))
      return;
    this.unselectAll();
    const s = this.currentLayer;
    try {
      const r = [];
      for (const l of i) {
        const h = await s.deserialize(l);
        if (!h)
          return;
        r.push(h);
      }
      const a = () => {
        for (const l of r)
          b(this, F, Yf).call(this, l);
        b(this, F, Kf).call(this, r);
      }, o = () => {
        for (const l of r)
          l.remove();
      };
      this.addCommands({
        cmd: a,
        undo: o,
        mustExec: !0
      });
    } catch (r) {
      J(`paste: "${r.message}".`);
    }
  }
  keydown(t) {
    !this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !0), n(this, re) !== Z.NONE && !this.isEditorHandlingKeyboard && Mo._keyboardManager.exec(this, t);
  }
  keyup(t) {
    this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !1, n(this, rr) && (p(this, rr, !1), b(this, F, _h).call(this, "main_toolbar")));
  }
  onEditingAction({
    name: t
  }) {
    switch (t) {
      case "undo":
      case "redo":
      case "delete":
      case "selectAll":
        this[t]();
        break;
      case "highlightSelection":
        this.highlightSelection("context_menu");
        break;
      case "commentSelection":
        this.commentSelection("context_menu");
        break;
    }
  }
  setEditingState(t) {
    t ? (b(this, F, Vm).call(this), b(this, F, qf).call(this), b(this, F, Ze).call(this, {
      isEditing: n(this, re) !== Z.NONE,
      isEmpty: b(this, F, xh).call(this),
      hasSomethingToUndo: n(this, Yi).hasSomethingToUndo(),
      hasSomethingToRedo: n(this, Yi).hasSomethingToRedo(),
      hasSelectedEditor: !1
    })) : (b(this, F, zm).call(this), b(this, F, Xf).call(this), b(this, F, Ze).call(this, {
      isEditing: !1
    }), this.disableUserSelect(!1));
  }
  registerEditorTypes(t) {
    if (!n(this, Ki)) {
      p(this, Ki, t);
      for (const e of n(this, Ki))
        b(this, F, nn).call(this, e.defaultPropertiesToUpdate);
    }
  }
  getId() {
    return n(this, Ku).id;
  }
  get currentLayer() {
    return n(this, ce).get(n(this, qo));
  }
  getLayer(t) {
    return n(this, ce).get(t);
  }
  get currentPageIndex() {
    return n(this, qo);
  }
  addLayer(t) {
    n(this, ce).set(t.pageIndex, t), n(this, ar) ? t.enable() : t.disable();
  }
  removeLayer(t) {
    n(this, ce).delete(t.pageIndex);
  }
  async updateMode(t, e = null, i = !1, s = !1, r = !1) {
    var a, o, l, h, c, u;
    if (n(this, re) !== t && !(n(this, Zi) && (await n(this, Zi).promise, !n(this, Zi)))) {
      if (p(this, Zi, Promise.withResolvers()), (a = n(this, ir)) == null || a.commitOrRemove(), n(this, re) === Z.POPUP && ((o = n(this, Ue)) == null || o.hideSidebar()), (l = n(this, Ue)) == null || l.destroyPopup(), p(this, re, t), t === Z.NONE) {
        this.setEditingState(!1), b(this, F, qm).call(this);
        for (const f of n(this, qt).values())
          f.hideStandaloneCommentButton();
        (h = this._editorUndoBar) == null || h.hide(), this.toggleComment(null), n(this, Zi).resolve();
        return;
      }
      for (const f of n(this, qt).values())
        f.addStandaloneCommentButton();
      t === Z.SIGNATURE && await ((c = n(this, hr)) == null ? void 0 : c.loadSignatures()), this.setEditingState(!0), await b(this, F, jm).call(this), this.unselectAll();
      for (const f of n(this, ce).values())
        f.updateMode(t);
      if (t === Z.POPUP) {
        n(this, Go) || p(this, Go, await n(this, Jo).getAnnotationsByType(new Set(n(this, Ki).map((A) => A._editorType))));
        const f = /* @__PURE__ */ new Set(), m = [];
        for (const A of n(this, qt).values()) {
          const {
            annotationElementId: y,
            hasComment: v,
            deleted: w
          } = A;
          y && f.add(y), v && !w && m.push(A.getData());
        }
        for (const A of n(this, Go)) {
          const {
            id: y,
            popupRef: v,
            contentsObj: w
          } = A;
          v && (w != null && w.str) && !f.has(y) && !n(this, sr).has(y) && m.push(A);
        }
        (u = n(this, Ue)) == null || u.showSidebar(m);
      }
      if (!e) {
        i && this.addNewEditorFromKeyboard(), n(this, Zi).resolve();
        return;
      }
      for (const f of n(this, qt).values())
        f.uid === e ? (this.setSelected(f), r ? f.editComment() : s ? f.enterInEditMode() : f.focus()) : f.unselect();
      n(this, Zi).resolve();
    }
  }
  addNewEditorFromKeyboard() {
    this.currentLayer.canCreateNewEmptyEditor() && this.currentLayer.addNewEditor();
  }
  updateToolbar(t) {
    t.mode !== n(this, re) && this._eventBus.dispatch("switchannotationeditormode", {
      source: this,
      ...t
    });
  }
  updateParams(t, e) {
    if (n(this, Ki)) {
      switch (t) {
        case ht.CREATE:
          this.currentLayer.addNewEditor(e);
          return;
        case ht.HIGHLIGHT_SHOW_ALL:
          this._eventBus.dispatch("reporttelemetry", {
            source: this,
            details: {
              type: "editing",
              data: {
                type: "highlight",
                action: "toggle_visibility"
              }
            }
          }), (n(this, cc) || p(this, cc, /* @__PURE__ */ new Map())).set(t, e), this.showAllEditors("highlight", e);
          break;
      }
      if (this.hasSelection)
        for (const i of n(this, At))
          i.updateParams(t, e);
      else
        for (const i of n(this, Ki))
          i.updateDefaultParams(t, e);
    }
  }
  showAllEditors(t, e, i = !1) {
    var r;
    for (const a of n(this, qt).values())
      a.editorType === t && a.show(e);
    (((r = n(this, cc)) == null ? void 0 : r.get(ht.HIGHLIGHT_SHOW_ALL)) ?? !0) !== e && b(this, F, nn).call(this, [[ht.HIGHLIGHT_SHOW_ALL, e]]);
  }
  enableWaiting(t = !1) {
    if (n(this, lc) !== t) {
      p(this, lc, t);
      for (const e of n(this, ce).values())
        t ? e.disableClick() : e.enableClick(), e.div.classList.toggle("waiting", t);
    }
  }
  *getEditors(t) {
    for (const e of n(this, qt).values())
      e.pageIndex === t && (yield e);
  }
  getEditor(t) {
    return n(this, qt).get(t);
  }
  addEditor(t) {
    n(this, qt).set(t.id, t);
  }
  removeEditor(t) {
    var e, i;
    t.div.contains(document.activeElement) && (n(this, Ls) && clearTimeout(n(this, Ls)), p(this, Ls, setTimeout(() => {
      this.focusMainContainer(), p(this, Ls, null);
    }, 0))), n(this, qt).delete(t.id), t.annotationElementId && ((e = n(this, lr)) == null || e.delete(t.annotationElementId)), this.unselect(t), (!t.annotationElementId || !n(this, sr).has(t.annotationElementId)) && ((i = n(this, Xi)) == null || i.remove(t.id));
  }
  addDeletedAnnotationElement(t) {
    n(this, sr).add(t.annotationElementId), this.addChangedExistingAnnotation(t), t.deleted = !0;
  }
  isDeletedAnnotationElement(t) {
    return n(this, sr).has(t);
  }
  removeDeletedAnnotationElement(t) {
    n(this, sr).delete(t.annotationElementId), this.removeChangedExistingAnnotation(t), t.deleted = !1;
  }
  setActiveEditor(t) {
    n(this, wi) !== t && (p(this, wi, t), t && b(this, F, nn).call(this, t.propertiesToUpdate));
  }
  updateUI(t) {
    n(this, F, Xm) === t && b(this, F, nn).call(this, t.propertiesToUpdate);
  }
  updateUIForDefaultProperties(t) {
    b(this, F, nn).call(this, t.defaultPropertiesToUpdate);
  }
  toggleSelected(t) {
    if (n(this, At).has(t)) {
      n(this, At).delete(t), t.unselect(), b(this, F, Ze).call(this, {
        hasSelectedEditor: this.hasSelection
      });
      return;
    }
    n(this, At).add(t), t.select(), b(this, F, nn).call(this, t.propertiesToUpdate), b(this, F, Ze).call(this, {
      hasSelectedEditor: !0
    });
  }
  setSelected(t) {
    var e;
    this.updateToolbar({
      mode: t.mode,
      editId: t.id
    }), (e = n(this, ir)) == null || e.commitOrRemove();
    for (const i of n(this, At))
      i !== t && i.unselect();
    n(this, At).clear(), n(this, At).add(t), t.select(), b(this, F, nn).call(this, t.propertiesToUpdate), b(this, F, Ze).call(this, {
      hasSelectedEditor: !0
    });
  }
  isSelected(t) {
    return n(this, At).has(t);
  }
  get firstSelectedEditor() {
    return n(this, At).values().next().value;
  }
  unselect(t) {
    t.unselect(), n(this, At).delete(t), b(this, F, Ze).call(this, {
      hasSelectedEditor: this.hasSelection
    });
  }
  get hasSelection() {
    return n(this, At).size !== 0;
  }
  get isEnterHandled() {
    return n(this, At).size === 1 && this.firstSelectedEditor.isEnterHandled;
  }
  undo() {
    var t;
    n(this, Yi).undo(), b(this, F, Ze).call(this, {
      hasSomethingToUndo: n(this, Yi).hasSomethingToUndo(),
      hasSomethingToRedo: !0,
      isEmpty: b(this, F, xh).call(this)
    }), (t = this._editorUndoBar) == null || t.hide();
  }
  redo() {
    n(this, Yi).redo(), b(this, F, Ze).call(this, {
      hasSomethingToUndo: !0,
      hasSomethingToRedo: n(this, Yi).hasSomethingToRedo(),
      isEmpty: b(this, F, xh).call(this)
    });
  }
  addCommands(t) {
    n(this, Yi).add(t), b(this, F, Ze).call(this, {
      hasSomethingToUndo: !0,
      hasSomethingToRedo: !1,
      isEmpty: b(this, F, xh).call(this)
    });
  }
  cleanUndoStack(t) {
    n(this, Yi).cleanType(t);
  }
  delete() {
    var r;
    this.commitOrRemove();
    const t = (r = this.currentLayer) == null ? void 0 : r.endDrawingSession(!0);
    if (!this.hasSelection && !t)
      return;
    const e = t ? [t] : [...n(this, At)], i = () => {
      var a;
      (a = this._editorUndoBar) == null || a.show(s, e.length === 1 ? e[0].editorType : e.length);
      for (const o of e)
        o.remove();
    }, s = () => {
      for (const a of e)
        b(this, F, Yf).call(this, a);
    };
    this.addCommands({
      cmd: i,
      undo: s,
      mustExec: !0
    });
  }
  commitOrRemove() {
    var t;
    (t = n(this, wi)) == null || t.commitOrRemove();
  }
  hasSomethingToControl() {
    return n(this, wi) || this.hasSelection;
  }
  selectAll() {
    for (const t of n(this, At))
      t.commit();
    b(this, F, Kf).call(this, n(this, qt).values());
  }
  unselectAll() {
    var t;
    if (!(n(this, wi) && (n(this, wi).commitOrRemove(), n(this, re) !== Z.NONE)) && !((t = n(this, ir)) != null && t.commitOrRemove()) && this.hasSelection) {
      for (const e of n(this, At))
        e.unselect();
      n(this, At).clear(), b(this, F, Ze).call(this, {
        hasSelectedEditor: !1
      });
    }
  }
  translateSelectedEditors(t, e, i = !1) {
    if (i || this.commitOrRemove(), !this.hasSelection)
      return;
    n(this, dr)[0] += t, n(this, dr)[1] += e;
    const [s, r] = n(this, dr), a = [...n(this, At)], o = 1e3;
    n(this, Rs) && clearTimeout(n(this, Rs)), p(this, Rs, setTimeout(() => {
      p(this, Rs, null), n(this, dr)[0] = n(this, dr)[1] = 0, this.addCommands({
        cmd: () => {
          for (const l of a)
            n(this, qt).has(l.id) && (l.translateInPage(s, r), l.translationDone());
        },
        undo: () => {
          for (const l of a)
            n(this, qt).has(l.id) && (l.translateInPage(-s, -r), l.translationDone());
        },
        mustExec: !1
      });
    }, o));
    for (const l of a)
      l.translateInPage(t, e), l.translationDone();
  }
  setUpDragSession() {
    if (this.hasSelection) {
      this.disableUserSelect(!0), p(this, Ps, /* @__PURE__ */ new Map());
      for (const t of n(this, At))
        n(this, Ps).set(t, {
          savedX: t.x,
          savedY: t.y,
          savedPageIndex: t.pageIndex,
          newX: 0,
          newY: 0,
          newPageIndex: -1
        });
    }
  }
  endDragSession() {
    if (!n(this, Ps))
      return !1;
    this.disableUserSelect(!1);
    const t = n(this, Ps);
    p(this, Ps, null);
    let e = !1;
    for (const [{
      x: s,
      y: r,
      pageIndex: a
    }, o] of t)
      o.newX = s, o.newY = r, o.newPageIndex = a, e || (e = s !== o.savedX || r !== o.savedY || a !== o.savedPageIndex);
    if (!e)
      return !1;
    const i = (s, r, a, o) => {
      if (n(this, qt).has(s.id)) {
        const l = n(this, ce).get(o);
        l ? s._setParentAndPosition(l, r, a) : (s.pageIndex = o, s.x = r, s.y = a);
      }
    };
    return this.addCommands({
      cmd: () => {
        for (const [s, {
          newX: r,
          newY: a,
          newPageIndex: o
        }] of t)
          i(s, r, a, o);
      },
      undo: () => {
        for (const [s, {
          savedX: r,
          savedY: a,
          savedPageIndex: o
        }] of t)
          i(s, r, a, o);
      },
      mustExec: !0
    }), !0;
  }
  dragSelectedEditors(t, e) {
    if (n(this, Ps))
      for (const i of n(this, Ps).keys())
        i.drag(t, e);
  }
  rebuild(t) {
    if (t.parent === null) {
      const e = this.getLayer(t.pageIndex);
      e ? (e.changeParent(t), e.addOrRebuild(t)) : (this.addEditor(t), this.addToAnnotationStorage(t), t.rebuild());
    } else
      t.parent.addOrRebuild(t);
  }
  get isEditorHandlingKeyboard() {
    var t;
    return ((t = this.getActive()) == null ? void 0 : t.shouldGetKeyboardEvents()) || n(this, At).size === 1 && this.firstSelectedEditor.shouldGetKeyboardEvents();
  }
  isActive(t) {
    return n(this, wi) === t;
  }
  getActive() {
    return n(this, wi);
  }
  getMode() {
    return n(this, re);
  }
  isEditingMode() {
    return n(this, re) !== Z.NONE;
  }
  get imageManager() {
    return st(this, "imageManager", new zf());
  }
  getSelectionBoxes(t) {
    if (!t)
      return null;
    const e = document.getSelection();
    for (let h = 0, c = e.rangeCount; h < c; h++)
      if (!t.contains(e.getRangeAt(h).commonAncestorContainer))
        return null;
    const {
      x: i,
      y: s,
      width: r,
      height: a
    } = t.getBoundingClientRect();
    let o;
    switch (t.getAttribute("data-main-rotation")) {
      case "90":
        o = (h, c, u, f) => ({
          x: (c - s) / a,
          y: 1 - (h + u - i) / r,
          width: f / a,
          height: u / r
        });
        break;
      case "180":
        o = (h, c, u, f) => ({
          x: 1 - (h + u - i) / r,
          y: 1 - (c + f - s) / a,
          width: u / r,
          height: f / a
        });
        break;
      case "270":
        o = (h, c, u, f) => ({
          x: 1 - (c + f - s) / a,
          y: (h - i) / r,
          width: f / a,
          height: u / r
        });
        break;
      default:
        o = (h, c, u, f) => ({
          x: (h - i) / r,
          y: (c - s) / a,
          width: u / r,
          height: f / a
        });
        break;
    }
    const l = [];
    for (let h = 0, c = e.rangeCount; h < c; h++) {
      const u = e.getRangeAt(h);
      if (!u.collapsed)
        for (const {
          x: f,
          y: m,
          width: A,
          height: y
        } of u.getClientRects())
          A === 0 || y === 0 || l.push(o(f, m, A, y));
    }
    return l.length === 0 ? null : l;
  }
  addChangedExistingAnnotation({
    annotationElementId: t,
    id: e
  }) {
    (n(this, jo) || p(this, jo, /* @__PURE__ */ new Map())).set(t, e);
  }
  removeChangedExistingAnnotation({
    annotationElementId: t
  }) {
    var e;
    (e = n(this, jo)) == null || e.delete(t);
  }
  renderAnnotationElement(t) {
    var s;
    const e = (s = n(this, jo)) == null ? void 0 : s.get(t.data.id);
    if (!e)
      return;
    const i = n(this, Xi).getRawValue(e);
    i && (n(this, re) === Z.NONE && !i.hasBeenModified || i.renderAnnotationElement(t));
  }
  setMissingCanvas(t, e, i) {
    var r;
    const s = (r = n(this, lr)) == null ? void 0 : r.get(t);
    s && (s.setCanvas(e, i), n(this, lr).delete(t));
  }
  addMissingCanvas(t, e) {
    (n(this, lr) || p(this, lr, /* @__PURE__ */ new Map())).set(t, e);
  }
};
zo = new WeakMap(), wi = new WeakMap(), Go = new WeakMap(), qt = new WeakMap(), ce = new WeakMap(), Wo = new WeakMap(), Xi = new WeakMap(), jo = new WeakMap(), Yi = new WeakMap(), Ue = new WeakMap(), er = new WeakMap(), ir = new WeakMap(), qo = new WeakMap(), sr = new WeakMap(), Ps = new WeakMap(), Ki = new WeakMap(), aa = new WeakMap(), rc = new WeakMap(), ac = new WeakMap(), Xo = new WeakMap(), oc = new WeakMap(), Ls = new WeakMap(), nr = new WeakMap(), Yo = new WeakMap(), rr = new WeakMap(), ks = new WeakMap(), Ku = new WeakMap(), ar = new WeakMap(), Ko = new WeakMap(), lc = new WeakMap(), or = new WeakMap(), oa = new WeakMap(), Zo = new WeakMap(), lr = new WeakMap(), hc = new WeakMap(), re = new WeakMap(), At = new WeakMap(), hn = new WeakMap(), hr = new WeakMap(), cr = new WeakMap(), cc = new WeakMap(), Jo = new WeakMap(), dc = new WeakMap(), dr = new WeakMap(), Rs = new WeakMap(), cn = new WeakMap(), uc = new WeakMap(), fc = new WeakMap(), Zi = new WeakMap(), F = new WeakSet(), nu = function({
  anchorNode: t
}) {
  return t.nodeType === Node.TEXT_NODE ? t.parentElement : t;
}, Wf = function(t) {
  const {
    currentLayer: e
  } = this;
  if (e.hasTextLayer(t))
    return e;
  for (const i of n(this, ce).values())
    if (i.hasTextLayer(t))
      return i;
  return null;
}, Hm = function() {
  const t = document.getSelection();
  if (!t || t.isCollapsed)
    return;
  const i = b(this, F, nu).call(this, t).closest(".textLayer"), s = this.getSelectionBoxes(i);
  s && (n(this, ks) || p(this, ks, new yy(this)), n(this, ks).show(i, s, this.direction === "ltr"));
}, Um = function() {
  var r, a, o;
  const t = document.getSelection();
  if (!t || t.isCollapsed) {
    n(this, hn) && ((r = n(this, ks)) == null || r.hide(), p(this, hn, null), b(this, F, Ze).call(this, {
      hasSelectedText: !1
    }));
    return;
  }
  const {
    anchorNode: e
  } = t;
  if (e === n(this, hn))
    return;
  const s = b(this, F, nu).call(this, t).closest(".textLayer");
  if (!s) {
    n(this, hn) && ((a = n(this, ks)) == null || a.hide(), p(this, hn, null), b(this, F, Ze).call(this, {
      hasSelectedText: !1
    }));
    return;
  }
  if ((o = n(this, ks)) == null || o.hide(), p(this, hn, e), b(this, F, Ze).call(this, {
    hasSelectedText: !0
  }), !(n(this, re) !== Z.HIGHLIGHT && n(this, re) !== Z.NONE) && (n(this, re) === Z.HIGHLIGHT && this.showAllEditors("highlight", !0, !0), p(this, rr, this.isShiftKeyDown), !this.isShiftKeyDown)) {
    const l = n(this, re) === Z.HIGHLIGHT ? b(this, F, Wf).call(this, s) : null;
    if (l == null || l.toggleDrawing(), n(this, Ko)) {
      const h = new AbortController(), c = this.combinedSignal(h), u = (f) => {
        f.type === "pointerup" && f.button !== 0 || (h.abort(), l == null || l.toggleDrawing(!0), f.type === "pointerup" && b(this, F, _h).call(this, "main_toolbar"));
      };
      window.addEventListener("pointerup", u, {
        signal: c
      }), window.addEventListener("blur", u, {
        signal: c
      });
    } else
      l == null || l.toggleDrawing(!0), b(this, F, _h).call(this, "main_toolbar");
  }
}, _h = function(t = "") {
  n(this, re) === Z.HIGHLIGHT ? this.highlightSelection(t) : n(this, rc) && b(this, F, Hm).call(this);
}, $m = function() {
  document.addEventListener("selectionchange", b(this, F, Um).bind(this), {
    signal: this._signal
  });
}, Vm = function() {
  if (n(this, nr))
    return;
  p(this, nr, new AbortController());
  const t = this.combinedSignal(n(this, nr));
  window.addEventListener("focus", this.focus.bind(this), {
    signal: t
  }), window.addEventListener("blur", this.blur.bind(this), {
    signal: t
  });
}, zm = function() {
  var t;
  (t = n(this, nr)) == null || t.abort(), p(this, nr, null);
}, jf = function() {
  if (n(this, or))
    return;
  p(this, or, new AbortController());
  const t = this.combinedSignal(n(this, or));
  window.addEventListener("keydown", this.keydown.bind(this), {
    signal: t
  }), window.addEventListener("keyup", this.keyup.bind(this), {
    signal: t
  });
}, Gm = function() {
  var t;
  (t = n(this, or)) == null || t.abort(), p(this, or, null);
}, qf = function() {
  if (n(this, er))
    return;
  p(this, er, new AbortController());
  const t = this.combinedSignal(n(this, er));
  document.addEventListener("copy", this.copy.bind(this), {
    signal: t
  }), document.addEventListener("cut", this.cut.bind(this), {
    signal: t
  }), document.addEventListener("paste", this.paste.bind(this), {
    signal: t
  });
}, Xf = function() {
  var t;
  (t = n(this, er)) == null || t.abort(), p(this, er, null);
}, Wm = function() {
  const t = this._signal;
  document.addEventListener("dragover", this.dragOver.bind(this), {
    signal: t
  }), document.addEventListener("drop", this.drop.bind(this), {
    signal: t
  });
}, Ze = function(t) {
  Object.entries(t).some(([i, s]) => n(this, dc)[i] !== s) && (this._eventBus.dispatch("annotationeditorstateschanged", {
    source: this,
    details: Object.assign(n(this, dc), t)
  }), n(this, re) === Z.HIGHLIGHT && t.hasSelectedEditor === !1 && b(this, F, nn).call(this, [[ht.HIGHLIGHT_FREE, !0]]));
}, nn = function(t) {
  this._eventBus.dispatch("annotationeditorparamschanged", {
    source: this,
    details: t
  });
}, jm = async function() {
  if (!n(this, ar)) {
    p(this, ar, !0);
    const t = [];
    for (const e of n(this, ce).values())
      t.push(e.enable());
    await Promise.all(t);
    for (const e of n(this, qt).values())
      e.enable();
  }
}, qm = function() {
  if (this.unselectAll(), n(this, ar)) {
    p(this, ar, !1);
    for (const t of n(this, ce).values())
      t.disable();
    for (const t of n(this, qt).values())
      t.disable();
  }
}, Yf = function(t) {
  const e = n(this, ce).get(t.pageIndex);
  e ? e.addOrRebuild(t) : (this.addEditor(t), this.addToAnnotationStorage(t));
}, Xm = function() {
  let t = null;
  for (t of n(this, At))
    ;
  return t;
}, xh = function() {
  if (n(this, qt).size === 0)
    return !0;
  if (n(this, qt).size === 1)
    for (const t of n(this, qt).values())
      return t.isEmpty();
  return !1;
}, Kf = function(t) {
  for (const e of n(this, At))
    e.unselect();
  n(this, At).clear();
  for (const e of t)
    e.isEmpty() || (n(this, At).add(e), e.select());
  b(this, F, Ze).call(this, {
    hasSelectedEditor: this.hasSelection
  });
}, M(Mo, "TRANSLATE_SMALL", 1), M(Mo, "TRANSLATE_BIG", 10);
let jr = Mo;
var me, Ms, cs, Qo, Ds, vi, tl, Is, hi, dn, la, Fs, ur, Es, Ch, ru;
const Je = class Je {
  constructor(t) {
    g(this, Es);
    g(this, me, null);
    g(this, Ms, !1);
    g(this, cs, null);
    g(this, Qo, null);
    g(this, Ds, null);
    g(this, vi, null);
    g(this, tl, !1);
    g(this, Is, null);
    g(this, hi, null);
    g(this, dn, null);
    g(this, la, null);
    g(this, Fs, !1);
    p(this, hi, t), p(this, Fs, t._uiManager.useNewAltTextFlow), n(Je, ur) || p(Je, ur, Object.freeze({
      added: "pdfjs-editor-new-alt-text-added-button",
      "added-label": "pdfjs-editor-new-alt-text-added-button-label",
      missing: "pdfjs-editor-new-alt-text-missing-button",
      "missing-label": "pdfjs-editor-new-alt-text-missing-button-label",
      review: "pdfjs-editor-new-alt-text-to-review-button",
      "review-label": "pdfjs-editor-new-alt-text-to-review-button-label"
    }));
  }
  static initialize(t) {
    Je._l10n ?? (Je._l10n = t);
  }
  async render() {
    const t = p(this, cs, document.createElement("button"));
    t.className = "altText", t.tabIndex = "0";
    const e = p(this, Qo, document.createElement("span"));
    t.append(e), n(this, Fs) ? (t.classList.add("new"), t.setAttribute("data-l10n-id", n(Je, ur).missing), e.setAttribute("data-l10n-id", n(Je, ur)["missing-label"])) : (t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button"), e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button-label"));
    const i = n(this, hi)._uiManager._signal;
    t.addEventListener("contextmenu", $i, {
      signal: i
    }), t.addEventListener("pointerdown", (r) => r.stopPropagation(), {
      signal: i
    });
    const s = (r) => {
      r.preventDefault(), n(this, hi)._uiManager.editAltText(n(this, hi)), n(this, Fs) && n(this, hi)._reportTelemetry({
        action: "pdfjs.image.alt_text.image_status_label_clicked",
        data: {
          label: n(this, Es, Ch)
        }
      });
    };
    return t.addEventListener("click", s, {
      capture: !0,
      signal: i
    }), t.addEventListener("keydown", (r) => {
      r.target === t && r.key === "Enter" && (p(this, tl, !0), s(r));
    }, {
      signal: i
    }), await b(this, Es, ru).call(this), t;
  }
  finish() {
    n(this, cs) && (n(this, cs).focus({
      focusVisible: n(this, tl)
    }), p(this, tl, !1));
  }
  isEmpty() {
    return n(this, Fs) ? n(this, me) === null : !n(this, me) && !n(this, Ms);
  }
  hasData() {
    return n(this, Fs) ? n(this, me) !== null || !!n(this, dn) : this.isEmpty();
  }
  get guessedText() {
    return n(this, dn);
  }
  async setGuessedText(t) {
    n(this, me) === null && (p(this, dn, t), p(this, la, await Je._l10n.get("pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer", {
      generatedAltText: t
    })), b(this, Es, ru).call(this));
  }
  toggleAltTextBadge(t = !1) {
    var e;
    if (!n(this, Fs) || n(this, me)) {
      (e = n(this, Is)) == null || e.remove(), p(this, Is, null);
      return;
    }
    if (!n(this, Is)) {
      const i = p(this, Is, document.createElement("div"));
      i.className = "noAltTextBadge", n(this, hi).div.append(i);
    }
    n(this, Is).classList.toggle("hidden", !t);
  }
  serialize(t) {
    let e = n(this, me);
    return !t && n(this, dn) === e && (e = n(this, la)), {
      altText: e,
      decorative: n(this, Ms),
      guessedText: n(this, dn),
      textWithDisclaimer: n(this, la)
    };
  }
  get data() {
    return {
      altText: n(this, me),
      decorative: n(this, Ms)
    };
  }
  set data({
    altText: t,
    decorative: e,
    guessedText: i,
    textWithDisclaimer: s,
    cancel: r = !1
  }) {
    i && (p(this, dn, i), p(this, la, s)), !(n(this, me) === t && n(this, Ms) === e) && (r || (p(this, me, t), p(this, Ms, e)), b(this, Es, ru).call(this));
  }
  toggle(t = !1) {
    n(this, cs) && (!t && n(this, vi) && (clearTimeout(n(this, vi)), p(this, vi, null)), n(this, cs).disabled = !t);
  }
  shown() {
    n(this, hi)._reportTelemetry({
      action: "pdfjs.image.alt_text.image_status_label_displayed",
      data: {
        label: n(this, Es, Ch)
      }
    });
  }
  destroy() {
    var t, e;
    (t = n(this, cs)) == null || t.remove(), p(this, cs, null), p(this, Qo, null), p(this, Ds, null), (e = n(this, Is)) == null || e.remove(), p(this, Is, null);
  }
};
me = new WeakMap(), Ms = new WeakMap(), cs = new WeakMap(), Qo = new WeakMap(), Ds = new WeakMap(), vi = new WeakMap(), tl = new WeakMap(), Is = new WeakMap(), hi = new WeakMap(), dn = new WeakMap(), la = new WeakMap(), Fs = new WeakMap(), ur = new WeakMap(), Es = new WeakSet(), Ch = function() {
  return n(this, me) && "added" || n(this, me) === null && this.guessedText && "review" || "missing";
}, ru = async function() {
  var s, r, a;
  const t = n(this, cs);
  if (!t)
    return;
  if (n(this, Fs)) {
    if (t.classList.toggle("done", !!n(this, me)), t.setAttribute("data-l10n-id", n(Je, ur)[n(this, Es, Ch)]), (s = n(this, Qo)) == null || s.setAttribute("data-l10n-id", n(Je, ur)[`${n(this, Es, Ch)}-label`]), !n(this, me)) {
      (r = n(this, Ds)) == null || r.remove();
      return;
    }
  } else {
    if (!n(this, me) && !n(this, Ms)) {
      t.classList.remove("done"), (a = n(this, Ds)) == null || a.remove();
      return;
    }
    t.classList.add("done"), t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-edit-button");
  }
  let e = n(this, Ds);
  if (!e) {
    p(this, Ds, e = document.createElement("span")), e.className = "tooltip", e.setAttribute("role", "tooltip"), e.id = `alt-text-tooltip-${n(this, hi).id}`;
    const o = 100, l = n(this, hi)._uiManager._signal;
    l.addEventListener("abort", () => {
      clearTimeout(n(this, vi)), p(this, vi, null);
    }, {
      once: !0
    }), t.addEventListener("mouseenter", () => {
      p(this, vi, setTimeout(() => {
        p(this, vi, null), n(this, Ds).classList.add("show"), n(this, hi)._reportTelemetry({
          action: "alt_text_tooltip"
        });
      }, o));
    }, {
      signal: l
    }), t.addEventListener("mouseleave", () => {
      var h;
      n(this, vi) && (clearTimeout(n(this, vi)), p(this, vi, null)), (h = n(this, Ds)) == null || h.classList.remove("show");
    }, {
      signal: l
    });
  }
  n(this, Ms) ? e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-decorative-tooltip") : (e.removeAttribute("data-l10n-id"), e.textContent = n(this, me)), e.parentNode || t.append(e);
  const i = n(this, hi).getElementForAltText();
  i == null || i.setAttribute("aria-describedby", e.id);
}, g(Je, ur, null), M(Je, "_l10n", null);
let Nu = Je;
var Pe, Ji, ha, It, pc, ca, ds, da, ua, fa, gc, Zf;
class qd {
  constructor(t) {
    g(this, gc);
    g(this, Pe, null);
    g(this, Ji, null);
    g(this, ha, !1);
    g(this, It, null);
    g(this, pc, null);
    g(this, ca, null);
    g(this, ds, null);
    g(this, da, null);
    g(this, ua, !1);
    g(this, fa, null);
    p(this, It, t);
  }
  renderForToolbar() {
    const t = p(this, Ji, document.createElement("button"));
    return t.className = "comment", b(this, gc, Zf).call(this, t, !1);
  }
  renderForStandalone() {
    const t = p(this, Pe, document.createElement("button"));
    t.className = "annotationCommentButton";
    const e = n(this, It).commentButtonPosition;
    if (e) {
      const {
        style: i
      } = t;
      i.insetInlineEnd = `calc(${100 * (n(this, It)._uiManager.direction === "ltr" ? 1 - e[0] : e[0])}% - var(--comment-button-dim))`, i.top = `calc(${100 * e[1]}% - var(--comment-button-dim))`;
      const s = n(this, It).commentButtonColor;
      s && (i.backgroundColor = s);
    }
    return b(this, gc, Zf).call(this, t, !0);
  }
  focusButton() {
    setTimeout(() => {
      var t;
      (t = n(this, Pe) ?? n(this, Ji)) == null || t.focus();
    }, 0);
  }
  onUpdatedColor() {
    if (!n(this, Pe))
      return;
    const t = n(this, It).commentButtonColor;
    t && (n(this, Pe).style.backgroundColor = t), n(this, It)._uiManager.updatePopupColor(n(this, It));
  }
  get commentButtonWidth() {
    var t;
    return (((t = n(this, Pe)) == null ? void 0 : t.getBoundingClientRect().width) ?? 0) / n(this, It).parent.boundingClientRect.width;
  }
  get commentPopupPositionInLayer() {
    if (n(this, fa))
      return n(this, fa);
    if (!n(this, Pe))
      return null;
    const {
      x: t,
      y: e,
      height: i
    } = n(this, Pe).getBoundingClientRect(), {
      x: s,
      y: r,
      width: a,
      height: o
    } = n(this, It).parent.boundingClientRect;
    return [(t - s) / a, (e + i - r) / o];
  }
  set commentPopupPositionInLayer(t) {
    p(this, fa, t);
  }
  hasDefaultPopupPosition() {
    return n(this, fa) === null;
  }
  removeStandaloneCommentButton() {
    var t;
    (t = n(this, Pe)) == null || t.remove(), p(this, Pe, null);
  }
  removeToolbarCommentButton() {
    var t;
    (t = n(this, Ji)) == null || t.remove(), p(this, Ji, null);
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    n(this, Pe) && (n(this, Pe).classList.toggle("selected", t), n(this, Pe).ariaExpanded = e);
  }
  edit(t) {
    const e = this.commentPopupPositionInLayer;
    let i, s;
    if (e)
      [i, s] = e;
    else {
      [i, s] = n(this, It).commentButtonPosition;
      const {
        width: c,
        height: u,
        x: f,
        y: m
      } = n(this, It);
      i = f + i * c, s = m + s * u;
    }
    const r = n(this, It).parent.boundingClientRect, {
      x: a,
      y: o,
      width: l,
      height: h
    } = r;
    n(this, It)._uiManager.editComment(n(this, It), a + i * l, o + s * h, {
      ...t,
      parentDimensions: r
    });
  }
  finish() {
    n(this, Ji) && (n(this, Ji).focus({
      focusVisible: n(this, ha)
    }), p(this, ha, !1));
  }
  isDeleted() {
    return n(this, ua) || n(this, ds) === "";
  }
  isEmpty() {
    return n(this, ds) === null;
  }
  hasBeenEdited() {
    return this.isDeleted() || n(this, ds) !== n(this, pc);
  }
  serialize() {
    return this.data;
  }
  get data() {
    return {
      text: n(this, ds),
      richText: n(this, ca),
      date: n(this, da),
      deleted: this.isDeleted()
    };
  }
  set data(t) {
    if (t !== n(this, ds) && p(this, ca, null), t === null) {
      p(this, ds, ""), p(this, ua, !0);
      return;
    }
    p(this, ds, t), p(this, da, /* @__PURE__ */ new Date()), p(this, ua, !1);
  }
  setInitialText(t, e = null) {
    p(this, pc, t), this.data = t, p(this, da, null), p(this, ca, e);
  }
  shown() {
  }
  destroy() {
    var t, e;
    (t = n(this, Ji)) == null || t.remove(), p(this, Ji, null), (e = n(this, Pe)) == null || e.remove(), p(this, Pe, null), p(this, ds, ""), p(this, ca, null), p(this, da, null), p(this, It, null), p(this, ha, !1), p(this, ua, !1);
  }
}
Pe = new WeakMap(), Ji = new WeakMap(), ha = new WeakMap(), It = new WeakMap(), pc = new WeakMap(), ca = new WeakMap(), ds = new WeakMap(), da = new WeakMap(), ua = new WeakMap(), fa = new WeakMap(), gc = new WeakSet(), Zf = function(t, e) {
  if (!n(this, It)._uiManager.hasCommentManager())
    return null;
  t.tabIndex = "0", t.ariaHasPopup = "dialog", e ? (t.ariaControls = "commentPopup", t.setAttribute("data-l10n-id", "pdfjs-show-comment-button")) : (t.ariaControlsElements = [n(this, It)._uiManager.getCommentDialogElement()], t.setAttribute("data-l10n-id", "pdfjs-editor-edit-comment-button"));
  const i = n(this, It)._uiManager._signal;
  if (!(i instanceof AbortSignal) || i.aborted)
    return t;
  t.addEventListener("contextmenu", $i, {
    signal: i
  }), e && (t.addEventListener("focusin", (r) => {
    n(this, It)._focusEventsAllowed = !1, zt(r);
  }, {
    capture: !0,
    signal: i
  }), t.addEventListener("focusout", (r) => {
    n(this, It)._focusEventsAllowed = !0, zt(r);
  }, {
    capture: !0,
    signal: i
  })), t.addEventListener("pointerdown", (r) => r.stopPropagation(), {
    signal: i
  });
  const s = (r) => {
    r.preventDefault(), t === n(this, Ji) ? this.edit() : n(this, It).toggleComment(!0);
  };
  return t.addEventListener("click", s, {
    capture: !0,
    signal: i
  }), t.addEventListener("keydown", (r) => {
    r.target === t && r.key === "Enter" && (p(this, ha, !0), s(r));
  }, {
    signal: i
  }), t.addEventListener("pointerenter", () => {
    n(this, It).toggleComment(!1, !0);
  }, {
    signal: i
  }), t.addEventListener("pointerleave", () => {
    n(this, It).toggleComment(!1, !1);
  }, {
    signal: i
  }), t;
};
var el, pa, mc, bc, yc, Ac, wc, un, ga, fn, ma, pn, qr, Ym, Km, Zm;
const Pg = class Pg {
  constructor({
    container: t,
    isPinchingDisabled: e = null,
    isPinchingStopped: i = null,
    onPinchStart: s = null,
    onPinching: r = null,
    onPinchEnd: a = null,
    signal: o
  }) {
    g(this, qr);
    g(this, el);
    g(this, pa, !1);
    g(this, mc, null);
    g(this, bc);
    g(this, yc);
    g(this, Ac);
    g(this, wc);
    g(this, un, null);
    g(this, ga);
    g(this, fn, null);
    g(this, ma);
    g(this, pn, null);
    p(this, el, t), p(this, mc, i), p(this, bc, e), p(this, yc, s), p(this, Ac, r), p(this, wc, a), p(this, ma, new AbortController()), p(this, ga, AbortSignal.any([o, n(this, ma).signal])), t.addEventListener("touchstart", b(this, qr, Ym).bind(this), {
      passive: !1,
      signal: n(this, ga)
    });
  }
  get MIN_TOUCH_DISTANCE_TO_PINCH() {
    return 35 / Ss.pixelRatio;
  }
  destroy() {
    var t, e;
    (t = n(this, ma)) == null || t.abort(), p(this, ma, null), (e = n(this, un)) == null || e.abort(), p(this, un, null);
  }
};
el = new WeakMap(), pa = new WeakMap(), mc = new WeakMap(), bc = new WeakMap(), yc = new WeakMap(), Ac = new WeakMap(), wc = new WeakMap(), un = new WeakMap(), ga = new WeakMap(), fn = new WeakMap(), ma = new WeakMap(), pn = new WeakMap(), qr = new WeakSet(), Ym = function(t) {
  var s, r, a;
  if ((s = n(this, bc)) != null && s.call(this))
    return;
  if (t.touches.length === 1) {
    if (n(this, un))
      return;
    const o = p(this, un, new AbortController()), l = AbortSignal.any([n(this, ga), o.signal]), h = n(this, el), c = {
      capture: !0,
      signal: l,
      passive: !1
    }, u = (f) => {
      var m;
      f.pointerType === "touch" && ((m = n(this, un)) == null || m.abort(), p(this, un, null));
    };
    h.addEventListener("pointerdown", (f) => {
      f.pointerType === "touch" && (zt(f), u(f));
    }, c), h.addEventListener("pointerup", u, c), h.addEventListener("pointercancel", u, c);
    return;
  }
  if (!n(this, pn)) {
    p(this, pn, new AbortController());
    const o = AbortSignal.any([n(this, ga), n(this, pn).signal]), l = n(this, el), h = {
      signal: o,
      capture: !1,
      passive: !1
    };
    l.addEventListener("touchmove", b(this, qr, Km).bind(this), h);
    const c = b(this, qr, Zm).bind(this);
    l.addEventListener("touchend", c, h), l.addEventListener("touchcancel", c, h), h.capture = !0, l.addEventListener("pointerdown", zt, h), l.addEventListener("pointermove", zt, h), l.addEventListener("pointercancel", zt, h), l.addEventListener("pointerup", zt, h), (r = n(this, yc)) == null || r.call(this);
  }
  if (zt(t), t.touches.length !== 2 || (a = n(this, mc)) != null && a.call(this)) {
    p(this, fn, null);
    return;
  }
  let [e, i] = t.touches;
  e.identifier > i.identifier && ([e, i] = [i, e]), p(this, fn, {
    touch0X: e.screenX,
    touch0Y: e.screenY,
    touch1X: i.screenX,
    touch1Y: i.screenY
  });
}, Km = function(t) {
  var _;
  if (!n(this, fn) || t.touches.length !== 2)
    return;
  zt(t);
  let [e, i] = t.touches;
  e.identifier > i.identifier && ([e, i] = [i, e]);
  const {
    screenX: s,
    screenY: r
  } = e, {
    screenX: a,
    screenY: o
  } = i, l = n(this, fn), {
    touch0X: h,
    touch0Y: c,
    touch1X: u,
    touch1Y: f
  } = l, m = u - h, A = f - c, y = a - s, v = o - r, w = Math.hypot(y, v) || 1, S = Math.hypot(m, A) || 1;
  if (!n(this, pa) && Math.abs(S - w) <= Pg.MIN_TOUCH_DISTANCE_TO_PINCH)
    return;
  if (l.touch0X = s, l.touch0Y = r, l.touch1X = a, l.touch1Y = o, !n(this, pa)) {
    p(this, pa, !0);
    return;
  }
  const E = [(s + a) / 2, (r + o) / 2];
  (_ = n(this, Ac)) == null || _.call(this, E, S, w);
}, Zm = function(t) {
  var e;
  t.touches.length >= 2 || (n(this, pn) && (n(this, pn).abort(), p(this, pn, null), (e = n(this, wc)) == null || e.call(this)), n(this, fn) && (zt(t), p(this, fn, null), p(this, pa, !1)));
};
let Xh = Pg;
var ba, us, Ht, Lt, gn, il, fr, vc, Le, ya, mn, Ns, pr, Ec, Aa, Ei, Sc, wa, bn, Os, sl, nl, Qi, va, _c, Zu, X, Jf, xc, Qf, au, Jm, Qm, tp, ou, ep, tb, eb, ib, ip, sb, sp, nb, rb, ab, np, Th;
const Q = class Q {
  constructor(t) {
    g(this, X);
    g(this, ba, null);
    g(this, us, null);
    g(this, Ht, null);
    g(this, Lt, null);
    g(this, gn, null);
    g(this, il, !1);
    g(this, fr, null);
    g(this, vc, "");
    g(this, Le, null);
    g(this, ya, null);
    g(this, mn, null);
    g(this, Ns, null);
    g(this, pr, null);
    g(this, Ec, "");
    g(this, Aa, !1);
    g(this, Ei, null);
    g(this, Sc, !1);
    g(this, wa, !1);
    g(this, bn, !1);
    g(this, Os, null);
    g(this, sl, 0);
    g(this, nl, 0);
    g(this, Qi, null);
    g(this, va, null);
    M(this, "isSelected", !1);
    M(this, "_isCopy", !1);
    M(this, "_editToolbar", null);
    M(this, "_initialOptions", /* @__PURE__ */ Object.create(null));
    M(this, "_initialData", null);
    M(this, "_isVisible", !0);
    M(this, "_uiManager", null);
    M(this, "_focusEventsAllowed", !0);
    g(this, _c, !1);
    g(this, Zu, Q._zIndex++);
    this.parent = t.parent, this.id = t.id, this.width = this.height = null, this.pageIndex = t.parent.pageIndex, this.name = t.name, this.div = null, this._uiManager = t.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = t.isCentered, this._structTreeParentId = null, this.annotationElementId = t.annotationElementId || null, this.creationDate = t.creationDate || /* @__PURE__ */ new Date(), this.modificationDate = t.modificationDate || null;
    const {
      rotation: e,
      rawDims: {
        pageWidth: i,
        pageHeight: s,
        pageX: r,
        pageY: a
      }
    } = this.parent.viewport;
    this.rotation = e, this.pageRotation = (360 + e - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [i, s], this.pageTranslation = [r, a];
    const [o, l] = this.parentDimensions;
    this.x = t.x / o, this.y = t.y / l, this.isAttachedToDOM = !1, this.deleted = !1;
  }
  static get _resizerKeyboardManager() {
    const t = Q.prototype._resizeWithKeyboard, e = jr.TRANSLATE_SMALL, i = jr.TRANSLATE_BIG;
    return st(this, "_resizerKeyboardManager", new Od([[["ArrowLeft", "mac+ArrowLeft"], t, {
      args: [-e, 0]
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t, {
      args: [-i, 0]
    }], [["ArrowRight", "mac+ArrowRight"], t, {
      args: [e, 0]
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t, {
      args: [i, 0]
    }], [["ArrowUp", "mac+ArrowUp"], t, {
      args: [0, -e]
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t, {
      args: [0, -i]
    }], [["ArrowDown", "mac+ArrowDown"], t, {
      args: [0, e]
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t, {
      args: [0, i]
    }], [["Escape", "mac+Escape"], Q.prototype._stopResizingWithKeyboard]]));
  }
  get editorType() {
    return Object.getPrototypeOf(this).constructor._type;
  }
  get mode() {
    return Object.getPrototypeOf(this).constructor._editorType;
  }
  static get isDrawer() {
    return !1;
  }
  static get _defaultLineColor() {
    return st(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
  }
  static deleteAnnotationElement(t) {
    const e = new vy({
      id: t.parent.getNextId(),
      parent: t.parent,
      uiManager: t._uiManager
    });
    e.annotationElementId = t.annotationElementId, e.deleted = !0, e._uiManager.addToAnnotationStorage(e);
  }
  static initialize(t, e) {
    if (Q._l10n ?? (Q._l10n = t), Q._l10nResizer || (Q._l10nResizer = Object.freeze({
      topLeft: "pdfjs-editor-resizer-top-left",
      topMiddle: "pdfjs-editor-resizer-top-middle",
      topRight: "pdfjs-editor-resizer-top-right",
      middleRight: "pdfjs-editor-resizer-middle-right",
      bottomRight: "pdfjs-editor-resizer-bottom-right",
      bottomMiddle: "pdfjs-editor-resizer-bottom-middle",
      bottomLeft: "pdfjs-editor-resizer-bottom-left",
      middleLeft: "pdfjs-editor-resizer-middle-left"
    })), Q._borderLineWidth !== -1)
      return;
    const i = getComputedStyle(document.documentElement);
    Q._borderLineWidth = parseFloat(i.getPropertyValue("--outline-width")) || 0;
  }
  static updateDefaultParams(t, e) {
  }
  static get defaultPropertiesToUpdate() {
    return [];
  }
  static isHandlingMimeForPasting(t) {
    return !1;
  }
  static paste(t, e) {
    Dt("Not implemented");
  }
  get propertiesToUpdate() {
    return [];
  }
  get _isDraggable() {
    return n(this, _c);
  }
  set _isDraggable(t) {
    var e;
    p(this, _c, t), (e = this.div) == null || e.classList.toggle("draggable", t);
  }
  get uid() {
    return this.annotationElementId || this.id;
  }
  get isEnterHandled() {
    return !0;
  }
  center() {
    const [t, e] = this.pageDimensions;
    switch (this.parentRotation) {
      case 90:
        this.x -= this.height * e / (t * 2), this.y += this.width * t / (e * 2);
        break;
      case 180:
        this.x += this.width / 2, this.y += this.height / 2;
        break;
      case 270:
        this.x += this.height * e / (t * 2), this.y -= this.width * t / (e * 2);
        break;
      default:
        this.x -= this.width / 2, this.y -= this.height / 2;
        break;
    }
    this.fixAndSetPosition();
  }
  addCommands(t) {
    this._uiManager.addCommands(t);
  }
  get currentLayer() {
    return this._uiManager.currentLayer;
  }
  setInBackground() {
    this.div.style.zIndex = 0;
  }
  setInForeground() {
    this.div.style.zIndex = n(this, Zu);
  }
  setParent(t) {
    var e;
    t !== null ? (this.pageIndex = t.pageIndex, this.pageDimensions = t.pageDimensions) : (b(this, X, Th).call(this), (e = n(this, Ns)) == null || e.remove(), p(this, Ns, null)), this.parent = t;
  }
  focusin(t) {
    this._focusEventsAllowed && (n(this, Aa) ? p(this, Aa, !1) : this.parent.setSelected(this));
  }
  focusout(t) {
    var i;
    if (!this._focusEventsAllowed || !this.isAttachedToDOM)
      return;
    const e = t.relatedTarget;
    e != null && e.closest(`#${this.id}`) || (t.preventDefault(), (i = this.parent) != null && i.isMultipleSelection || this.commitOrRemove());
  }
  commitOrRemove() {
    this.isEmpty() ? this.remove() : this.commit();
  }
  commit() {
    this.isInEditMode() && this.addToAnnotationStorage();
  }
  addToAnnotationStorage() {
    this._uiManager.addToAnnotationStorage(this);
  }
  setAt(t, e, i, s) {
    const [r, a] = this.parentDimensions;
    [i, s] = this.screenToPageTranslation(i, s), this.x = (t + i) / r, this.y = (e + s) / a, this.fixAndSetPosition();
  }
  _moveAfterPaste(t, e) {
    const [i, s] = this.parentDimensions;
    this.setAt(t * i, e * s, this.width * i, this.height * s), this._onTranslated();
  }
  translate(t, e) {
    b(this, X, Jf).call(this, this.parentDimensions, t, e);
  }
  translateInPage(t, e) {
    n(this, Ei) || p(this, Ei, [this.x, this.y, this.width, this.height]), b(this, X, Jf).call(this, this.pageDimensions, t, e), this.div.scrollIntoView({
      block: "nearest"
    });
  }
  translationDone() {
    this._onTranslated(this.x, this.y);
  }
  drag(t, e) {
    n(this, Ei) || p(this, Ei, [this.x, this.y, this.width, this.height]);
    const {
      div: i,
      parentDimensions: [s, r]
    } = this;
    if (this.x += t / s, this.y += e / r, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
      const {
        x: u,
        y: f
      } = this.div.getBoundingClientRect();
      this.parent.findNewParent(this, u, f) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
    }
    let {
      x: a,
      y: o
    } = this;
    const [l, h] = this.getBaseTranslation();
    a += l, o += h;
    const {
      style: c
    } = i;
    c.left = `${(100 * a).toFixed(2)}%`, c.top = `${(100 * o).toFixed(2)}%`, this._onTranslating(a, o), i.scrollIntoView({
      block: "nearest"
    });
  }
  _onTranslating(t, e) {
  }
  _onTranslated(t, e) {
  }
  get _hasBeenMoved() {
    return !!n(this, Ei) && (n(this, Ei)[0] !== this.x || n(this, Ei)[1] !== this.y);
  }
  get _hasBeenResized() {
    return !!n(this, Ei) && (n(this, Ei)[2] !== this.width || n(this, Ei)[3] !== this.height);
  }
  getBaseTranslation() {
    const [t, e] = this.parentDimensions, {
      _borderLineWidth: i
    } = Q, s = i / t, r = i / e;
    switch (this.rotation) {
      case 90:
        return [-s, r];
      case 180:
        return [s, r];
      case 270:
        return [s, -r];
      default:
        return [-s, -r];
    }
  }
  get _mustFixPosition() {
    return !0;
  }
  fixAndSetPosition(t = this.rotation) {
    const {
      div: {
        style: e
      },
      pageDimensions: [i, s]
    } = this;
    let {
      x: r,
      y: a,
      width: o,
      height: l
    } = this;
    if (o *= i, l *= s, r *= i, a *= s, this._mustFixPosition)
      switch (t) {
        case 0:
          r = We(r, 0, i - o), a = We(a, 0, s - l);
          break;
        case 90:
          r = We(r, 0, i - l), a = We(a, o, s);
          break;
        case 180:
          r = We(r, o, i), a = We(a, l, s);
          break;
        case 270:
          r = We(r, l, i), a = We(a, 0, s - o);
          break;
      }
    this.x = r /= i, this.y = a /= s;
    const [h, c] = this.getBaseTranslation();
    r += h, a += c, e.left = `${(100 * r).toFixed(2)}%`, e.top = `${(100 * a).toFixed(2)}%`, this.moveInDOM();
  }
  screenToPageTranslation(t, e) {
    var i;
    return b(i = Q, xc, Qf).call(i, t, e, this.parentRotation);
  }
  pageTranslationToScreen(t, e) {
    var i;
    return b(i = Q, xc, Qf).call(i, t, e, 360 - this.parentRotation);
  }
  get parentScale() {
    return this._uiManager.viewParameters.realScale;
  }
  get parentRotation() {
    return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
  }
  get parentDimensions() {
    const {
      parentScale: t,
      pageDimensions: [e, i]
    } = this;
    return [e * t, i * t];
  }
  setDims() {
    const {
      div: {
        style: t
      },
      width: e,
      height: i
    } = this;
    t.width = `${(100 * e).toFixed(2)}%`, t.height = `${(100 * i).toFixed(2)}%`;
  }
  getInitialTranslation() {
    return [0, 0];
  }
  _onResized() {
  }
  static _round(t) {
    return Math.round(t * 1e4) / 1e4;
  }
  _onResizing() {
  }
  altTextFinish() {
    var t;
    (t = n(this, Ht)) == null || t.finish();
  }
  get toolbarButtons() {
    return null;
  }
  async addEditToolbar() {
    if (this._editToolbar || n(this, wa))
      return this._editToolbar;
    this._editToolbar = new $f(this), this.div.append(this._editToolbar.render());
    const {
      toolbarButtons: t
    } = this;
    if (t)
      for (const [e, i] of t)
        await this._editToolbar.addButton(e, i);
    return this.hasComment || this._editToolbar.addButton("comment", this.addCommentButton()), this._editToolbar.addButton("delete"), this._editToolbar;
  }
  addCommentButtonInToolbar() {
    var t;
    (t = this._editToolbar) == null || t.addButtonBefore("comment", this.addCommentButton(), ".deleteButton");
  }
  removeCommentButtonFromToolbar() {
    var t;
    (t = this._editToolbar) == null || t.removeButton("comment");
  }
  removeEditToolbar() {
    var t, e;
    (t = this._editToolbar) == null || t.remove(), this._editToolbar = null, (e = n(this, Ht)) == null || e.destroy();
  }
  addContainer(t) {
    var i;
    const e = (i = this._editToolbar) == null ? void 0 : i.div;
    e ? e.before(t) : this.div.append(t);
  }
  getClientDimensions() {
    return this.div.getBoundingClientRect();
  }
  createAltText() {
    return n(this, Ht) || (Nu.initialize(Q._l10n), p(this, Ht, new Nu(this)), n(this, ba) && (n(this, Ht).data = n(this, ba), p(this, ba, null))), n(this, Ht);
  }
  get altTextData() {
    var t;
    return (t = n(this, Ht)) == null ? void 0 : t.data;
  }
  set altTextData(t) {
    n(this, Ht) && (n(this, Ht).data = t);
  }
  get guessedAltText() {
    var t;
    return (t = n(this, Ht)) == null ? void 0 : t.guessedText;
  }
  async setGuessedAltText(t) {
    var e;
    await ((e = n(this, Ht)) == null ? void 0 : e.setGuessedText(t));
  }
  serializeAltText(t) {
    var e;
    return (e = n(this, Ht)) == null ? void 0 : e.serialize(t);
  }
  hasAltText() {
    return !!n(this, Ht) && !n(this, Ht).isEmpty();
  }
  hasAltTextData() {
    var t;
    return ((t = n(this, Ht)) == null ? void 0 : t.hasData()) ?? !1;
  }
  focusCommentButton() {
    var t;
    (t = n(this, Lt)) == null || t.focusButton();
  }
  addCommentButton() {
    return n(this, Lt) || p(this, Lt, new qd(this));
  }
  addStandaloneCommentButton() {
    if (n(this, gn)) {
      this._uiManager.isEditingMode() && n(this, gn).classList.remove("hidden");
      return;
    }
    this.hasComment && (p(this, gn, n(this, Lt).renderForStandalone()), this.div.append(n(this, gn)));
  }
  removeStandaloneCommentButton() {
    n(this, Lt).removeStandaloneCommentButton(), p(this, gn, null);
  }
  hideStandaloneCommentButton() {
    var t;
    (t = n(this, gn)) == null || t.classList.add("hidden");
  }
  get comment() {
    const {
      data: {
        richText: t,
        text: e,
        date: i,
        deleted: s
      }
    } = n(this, Lt);
    return {
      text: e,
      richText: t,
      date: i,
      deleted: s,
      color: this.getNonHCMColor(),
      opacity: this.opacity ?? 1
    };
  }
  set comment(t) {
    n(this, Lt) || p(this, Lt, new qd(this)), n(this, Lt).data = t, this.hasComment ? (this.removeCommentButtonFromToolbar(), this.addStandaloneCommentButton(), this._uiManager.updateComment(this)) : (this.addCommentButtonInToolbar(), this.removeStandaloneCommentButton(), this._uiManager.removeComment(this));
  }
  setCommentData({
    comment: t,
    popupRef: e,
    richText: i
  }) {
    if (!e || (n(this, Lt) || p(this, Lt, new qd(this)), n(this, Lt).setInitialText(t, i), !this.annotationElementId))
      return;
    const s = this._uiManager.getAndRemoveDataFromAnnotationStorage(this.annotationElementId);
    s && this.updateFromAnnotationLayer(s);
  }
  get hasEditedComment() {
    var t;
    return (t = n(this, Lt)) == null ? void 0 : t.hasBeenEdited();
  }
  get hasDeletedComment() {
    var t;
    return (t = n(this, Lt)) == null ? void 0 : t.isDeleted();
  }
  get hasComment() {
    return !!n(this, Lt) && !n(this, Lt).isEmpty() && !n(this, Lt).isDeleted();
  }
  async editComment(t) {
    n(this, Lt) || p(this, Lt, new qd(this)), n(this, Lt).edit(t);
  }
  toggleComment(t, e = void 0) {
    this.hasComment && this._uiManager.toggleComment(this, t, e);
  }
  setSelectedCommentButton(t) {
    n(this, Lt).setSelectedButton(t);
  }
  addComment(t) {
    if (this.hasEditedComment) {
      const [, , , s] = t.rect, [r] = this.pageDimensions, [a] = this.pageTranslation, o = a + r + 1, l = s - 100, h = o + 180;
      t.popup = {
        contents: this.comment.text,
        deleted: this.comment.deleted,
        rect: [o, l, h, s]
      };
    }
  }
  updateFromAnnotationLayer({
    popup: {
      contents: t,
      deleted: e
    }
  }) {
    n(this, Lt).data = e ? null : t;
  }
  get parentBoundingClientRect() {
    return this.parent.boundingClientRect;
  }
  render() {
    var a;
    const t = this.div = document.createElement("div");
    t.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), t.className = this.name, t.setAttribute("id", this.id), t.tabIndex = n(this, il) ? -1 : 0, t.setAttribute("role", "application"), this.defaultL10nId && t.setAttribute("data-l10n-id", this.defaultL10nId), this._isVisible || t.classList.add("hidden"), this.setInForeground(), b(this, X, sp).call(this);
    const [e, i] = this.parentDimensions;
    this.parentRotation % 180 !== 0 && (t.style.maxWidth = `${(100 * i / e).toFixed(2)}%`, t.style.maxHeight = `${(100 * e / i).toFixed(2)}%`);
    const [s, r] = this.getInitialTranslation();
    return this.translate(s, r), Om(this, t, ["keydown", "pointerdown", "dblclick"]), this.isResizable && this._uiManager._supportsPinchToZoom && (n(this, va) || p(this, va, new Xh({
      container: t,
      isPinchingDisabled: () => !this.isSelected,
      onPinchStart: b(this, X, tb).bind(this),
      onPinching: b(this, X, eb).bind(this),
      onPinchEnd: b(this, X, ib).bind(this),
      signal: this._uiManager._signal
    }))), this.addStandaloneCommentButton(), (a = this._uiManager._editorUndoBar) == null || a.hide(), t;
  }
  pointerdown(t) {
    const {
      isMac: e
    } = _e.platform;
    if (t.button !== 0 || t.ctrlKey && e) {
      t.preventDefault();
      return;
    }
    if (p(this, Aa, !0), this._isDraggable) {
      b(this, X, sb).call(this, t);
      return;
    }
    b(this, X, ip).call(this, t);
  }
  _onStartDragging() {
  }
  _onStopDragging() {
  }
  moveInDOM() {
    n(this, Os) && clearTimeout(n(this, Os)), p(this, Os, setTimeout(() => {
      var t;
      p(this, Os, null), (t = this.parent) == null || t.moveEditorInDOM(this);
    }, 0));
  }
  _setParentAndPosition(t, e, i) {
    t.changeParent(this), this.x = e, this.y = i, this.fixAndSetPosition(), this._onTranslated();
  }
  getRect(t, e, i = this.rotation) {
    const s = this.parentScale, [r, a] = this.pageDimensions, [o, l] = this.pageTranslation, h = t / s, c = e / s, u = this.x * r, f = this.y * a, m = this.width * r, A = this.height * a;
    switch (i) {
      case 0:
        return [u + h + o, a - f - c - A + l, u + h + m + o, a - f - c + l];
      case 90:
        return [u + c + o, a - f + h + l, u + c + A + o, a - f + h + m + l];
      case 180:
        return [u - h - m + o, a - f + c + l, u - h + o, a - f + c + A + l];
      case 270:
        return [u - c - A + o, a - f - h - m + l, u - c + o, a - f - h + l];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getRectInCurrentCoords(t, e) {
    const [i, s, r, a] = t, o = r - i, l = a - s;
    switch (this.rotation) {
      case 0:
        return [i, e - a, o, l];
      case 90:
        return [i, e - s, l, o];
      case 180:
        return [r, e - s, o, l];
      case 270:
        return [r, e - a, l, o];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getPDFRect() {
    return this.getRect(0, 0);
  }
  getNonHCMColor() {
    return this.color && Q._colorManager.convert(this._uiManager.getNonHCMColor(this.color));
  }
  onUpdatedColor() {
    var t;
    (t = n(this, Lt)) == null || t.onUpdatedColor();
  }
  getData() {
    const {
      comment: {
        text: t,
        color: e,
        date: i,
        opacity: s,
        deleted: r,
        richText: a
      },
      uid: o,
      pageIndex: l,
      creationDate: h,
      modificationDate: c
    } = this;
    return {
      id: o,
      pageIndex: l,
      rect: this.getPDFRect(),
      richText: a,
      contentsObj: {
        str: t
      },
      creationDate: h,
      modificationDate: i || c,
      popupRef: !r,
      color: e,
      opacity: s
    };
  }
  onceAdded(t) {
  }
  isEmpty() {
    return !1;
  }
  enableEditMode() {
    return this.isInEditMode() ? !1 : (this.parent.setEditingState(!1), p(this, wa, !0), !0);
  }
  disableEditMode() {
    return this.isInEditMode() ? (this.parent.setEditingState(!0), p(this, wa, !1), !0) : !1;
  }
  isInEditMode() {
    return n(this, wa);
  }
  shouldGetKeyboardEvents() {
    return n(this, bn);
  }
  needsToBeRebuilt() {
    return this.div && !this.isAttachedToDOM;
  }
  get isOnScreen() {
    const {
      top: t,
      left: e,
      bottom: i,
      right: s
    } = this.getClientDimensions(), {
      innerHeight: r,
      innerWidth: a
    } = window;
    return e < a && s > 0 && t < r && i > 0;
  }
  rebuild() {
    b(this, X, sp).call(this);
  }
  rotate(t) {
  }
  resize() {
  }
  serializeDeleted() {
    var t;
    return {
      id: this.annotationElementId,
      deleted: !0,
      pageIndex: this.pageIndex,
      popupRef: ((t = this._initialData) == null ? void 0 : t.popupRef) || ""
    };
  }
  serialize(t = !1, e = null) {
    var i;
    return {
      annotationType: this.mode,
      pageIndex: this.pageIndex,
      rect: this.getPDFRect(),
      rotation: this.rotation,
      structTreeParentId: this._structTreeParentId,
      popupRef: ((i = this._initialData) == null ? void 0 : i.popupRef) || ""
    };
  }
  static async deserialize(t, e, i) {
    const s = new this.prototype.constructor({
      parent: e,
      id: e.getNextId(),
      uiManager: i,
      annotationElementId: t.annotationElementId,
      creationDate: t.creationDate,
      modificationDate: t.modificationDate
    });
    s.rotation = t.rotation, p(s, ba, t.accessibilityData), s._isCopy = t.isCopy || !1;
    const [r, a] = s.pageDimensions, [o, l, h, c] = s.getRectInCurrentCoords(t.rect, a);
    return s.x = o / r, s.y = l / a, s.width = h / r, s.height = c / a, s;
  }
  get hasBeenModified() {
    return !!this.annotationElementId && (this.deleted || this.serialize() !== null);
  }
  remove() {
    var t, e;
    if ((t = n(this, pr)) == null || t.abort(), p(this, pr, null), this.isEmpty() || this.commit(), this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), n(this, Os) && (clearTimeout(n(this, Os)), p(this, Os, null)), b(this, X, Th).call(this), this.removeEditToolbar(), n(this, Qi)) {
      for (const i of n(this, Qi).values())
        clearTimeout(i);
      p(this, Qi, null);
    }
    this.parent = null, (e = n(this, va)) == null || e.destroy(), p(this, va, null);
  }
  get isResizable() {
    return !1;
  }
  makeResizable() {
    this.isResizable && (b(this, X, Jm).call(this), n(this, Le).classList.remove("hidden"));
  }
  get toolbarPosition() {
    return null;
  }
  get commentButtonPosition() {
    return this._uiManager.direction === "ltr" ? [1, 0] : [0, 0];
  }
  get commentButtonPositionInPage() {
    const {
      commentButtonPosition: [t, e]
    } = this, [i, s, r, a] = this.getPDFRect();
    return [Q._round(i + (r - i) * t), Q._round(s + (a - s) * (1 - e))];
  }
  get commentButtonColor() {
    return this._uiManager.makeCommentColor(this.getNonHCMColor(), this.opacity);
  }
  get commentPopupPosition() {
    return n(this, Lt).commentPopupPositionInLayer;
  }
  set commentPopupPosition(t) {
    n(this, Lt).commentPopupPositionInLayer = t;
  }
  hasDefaultPopupPosition() {
    return n(this, Lt).hasDefaultPopupPosition();
  }
  get commentButtonWidth() {
    return n(this, Lt).commentButtonWidth;
  }
  get elementBeforePopup() {
    return this.div;
  }
  setCommentButtonStates(t) {
    n(this, Lt).setCommentButtonStates(t);
  }
  keydown(t) {
    if (!this.isResizable || t.target !== this.div || t.key !== "Enter")
      return;
    this._uiManager.setSelected(this), p(this, mn, {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    });
    const e = n(this, Le).children;
    if (!n(this, us)) {
      p(this, us, Array.from(e));
      const a = b(this, X, nb).bind(this), o = b(this, X, rb).bind(this), l = this._uiManager._signal;
      for (const h of n(this, us)) {
        const c = h.getAttribute("data-resizer-name");
        h.setAttribute("role", "spinbutton"), h.addEventListener("keydown", a, {
          signal: l
        }), h.addEventListener("blur", o, {
          signal: l
        }), h.addEventListener("focus", b(this, X, ab).bind(this, c), {
          signal: l
        }), h.setAttribute("data-l10n-id", Q._l10nResizer[c]);
      }
    }
    const i = n(this, us)[0];
    let s = 0;
    for (const a of e) {
      if (a === i)
        break;
      s++;
    }
    const r = (360 - this.rotation + this.parentRotation) % 360 / 90 * (n(this, us).length / 4);
    if (r !== s) {
      if (r < s)
        for (let o = 0; o < s - r; o++)
          n(this, Le).append(n(this, Le).firstChild);
      else if (r > s)
        for (let o = 0; o < r - s; o++)
          n(this, Le).firstChild.before(n(this, Le).lastChild);
      let a = 0;
      for (const o of e) {
        const h = n(this, us)[a++].getAttribute("data-resizer-name");
        o.setAttribute("data-l10n-id", Q._l10nResizer[h]);
      }
    }
    b(this, X, np).call(this, 0), p(this, bn, !0), n(this, Le).firstChild.focus({
      focusVisible: !0
    }), t.preventDefault(), t.stopImmediatePropagation();
  }
  _resizeWithKeyboard(t, e) {
    n(this, bn) && b(this, X, ep).call(this, n(this, Ec), {
      deltaX: t,
      deltaY: e,
      fromKeyboard: !0
    });
  }
  _stopResizingWithKeyboard() {
    b(this, X, Th).call(this), this.div.focus();
  }
  select() {
    var t, e, i;
    if (this.isSelected && this._editToolbar) {
      this._editToolbar.show();
      return;
    }
    if (this.isSelected = !0, this.makeResizable(), (t = this.div) == null || t.classList.add("selectedEditor"), !this._editToolbar) {
      this.addEditToolbar().then(() => {
        var s, r;
        (s = this.div) != null && s.classList.contains("selectedEditor") && ((r = this._editToolbar) == null || r.show());
      });
      return;
    }
    (e = this._editToolbar) == null || e.show(), (i = n(this, Ht)) == null || i.toggleAltTextBadge(!1);
  }
  focus() {
    this.div && !this.div.contains(document.activeElement) && setTimeout(() => {
      var t;
      return (t = this.div) == null ? void 0 : t.focus({
        preventScroll: !0
      });
    }, 0);
  }
  unselect() {
    var t, e, i, s, r;
    this.isSelected && (this.isSelected = !1, (t = n(this, Le)) == null || t.classList.add("hidden"), (e = this.div) == null || e.classList.remove("selectedEditor"), (i = this.div) != null && i.contains(document.activeElement) && this._uiManager.currentLayer.div.focus({
      preventScroll: !0
    }), (s = this._editToolbar) == null || s.hide(), (r = n(this, Ht)) == null || r.toggleAltTextBadge(!0), this.hasComment && this._uiManager.toggleComment(this, !1, !1));
  }
  updateParams(t, e) {
  }
  disableEditing() {
  }
  enableEditing() {
  }
  get canChangeContent() {
    return !1;
  }
  enterInEditMode() {
    this.canChangeContent && (this.enableEditMode(), this.div.focus());
  }
  dblclick(t) {
    t.target.nodeName !== "BUTTON" && (this.enterInEditMode(), this.parent.updateToolbar({
      mode: this.constructor._editorType,
      editId: this.id
    }));
  }
  getElementForAltText() {
    return this.div;
  }
  get contentDiv() {
    return this.div;
  }
  get isEditing() {
    return n(this, Sc);
  }
  set isEditing(t) {
    p(this, Sc, t), this.parent && (t ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
  }
  static get MIN_SIZE() {
    return 16;
  }
  static canCreateNewEmptyEditor() {
    return !0;
  }
  get telemetryInitialData() {
    return {
      action: "added"
    };
  }
  get telemetryFinalData() {
    return null;
  }
  _reportTelemetry(t, e = !1) {
    if (e) {
      n(this, Qi) || p(this, Qi, /* @__PURE__ */ new Map());
      const {
        action: i
      } = t;
      let s = n(this, Qi).get(i);
      s && clearTimeout(s), s = setTimeout(() => {
        this._reportTelemetry(t), n(this, Qi).delete(i), n(this, Qi).size === 0 && p(this, Qi, null);
      }, Q._telemetryTimeout), n(this, Qi).set(i, s);
      return;
    }
    t.type || (t.type = this.editorType), this._uiManager._eventBus.dispatch("reporttelemetry", {
      source: this,
      details: {
        type: "editing",
        data: t
      }
    });
  }
  show(t = this._isVisible) {
    this.div.classList.toggle("hidden", !t), this._isVisible = t;
  }
  enable() {
    this.div && (this.div.tabIndex = 0), p(this, il, !1);
  }
  disable() {
    this.div && (this.div.tabIndex = -1), p(this, il, !0);
  }
  updateFakeAnnotationElement(t) {
    if (!n(this, Ns) && !this.deleted) {
      p(this, Ns, t.addFakeAnnotation(this));
      return;
    }
    if (this.deleted) {
      n(this, Ns).remove(), p(this, Ns, null);
      return;
    }
    (this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized) && n(this, Ns).updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    });
  }
  renderAnnotationElement(t) {
    if (this.deleted)
      return t.hide(), null;
    let e = t.container.querySelector(".annotationContent");
    if (!e)
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), t.container.prepend(e);
    else if (e.nodeName === "CANVAS") {
      const i = e;
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), i.before(e);
    }
    return e;
  }
  resetAnnotationElement(t) {
    const {
      firstChild: e
    } = t.container;
    (e == null ? void 0 : e.nodeName) === "DIV" && e.classList.contains("annotationContent") && e.remove();
  }
};
ba = new WeakMap(), us = new WeakMap(), Ht = new WeakMap(), Lt = new WeakMap(), gn = new WeakMap(), il = new WeakMap(), fr = new WeakMap(), vc = new WeakMap(), Le = new WeakMap(), ya = new WeakMap(), mn = new WeakMap(), Ns = new WeakMap(), pr = new WeakMap(), Ec = new WeakMap(), Aa = new WeakMap(), Ei = new WeakMap(), Sc = new WeakMap(), wa = new WeakMap(), bn = new WeakMap(), Os = new WeakMap(), sl = new WeakMap(), nl = new WeakMap(), Qi = new WeakMap(), va = new WeakMap(), _c = new WeakMap(), Zu = new WeakMap(), X = new WeakSet(), Jf = function([t, e], i, s) {
  [i, s] = this.screenToPageTranslation(i, s), this.x += i / t, this.y += s / e, this._onTranslating(this.x, this.y), this.fixAndSetPosition();
}, xc = new WeakSet(), Qf = function(t, e, i) {
  switch (i) {
    case 90:
      return [e, -t];
    case 180:
      return [-t, -e];
    case 270:
      return [-e, t];
    default:
      return [t, e];
  }
}, au = function(t) {
  switch (t) {
    case 90: {
      const [e, i] = this.pageDimensions;
      return [0, -e / i, i / e, 0];
    }
    case 180:
      return [-1, 0, 0, -1];
    case 270: {
      const [e, i] = this.pageDimensions;
      return [0, e / i, -i / e, 0];
    }
    default:
      return [1, 0, 0, 1];
  }
}, Jm = function() {
  if (n(this, Le))
    return;
  p(this, Le, document.createElement("div")), n(this, Le).classList.add("resizers");
  const t = this._willKeepAspectRatio ? ["topLeft", "topRight", "bottomRight", "bottomLeft"] : ["topLeft", "topMiddle", "topRight", "middleRight", "bottomRight", "bottomMiddle", "bottomLeft", "middleLeft"], e = this._uiManager._signal;
  for (const i of t) {
    const s = document.createElement("div");
    n(this, Le).append(s), s.classList.add("resizer", i), s.setAttribute("data-resizer-name", i), s.addEventListener("pointerdown", b(this, X, Qm).bind(this, i), {
      signal: e
    }), s.addEventListener("contextmenu", $i, {
      signal: e
    }), s.tabIndex = -1;
  }
  this.div.prepend(n(this, Le));
}, Qm = function(t, e) {
  var c;
  e.preventDefault();
  const {
    isMac: i
  } = _e.platform;
  if (e.button !== 0 || e.ctrlKey && i)
    return;
  (c = n(this, Ht)) == null || c.toggle(!1);
  const s = this._isDraggable;
  this._isDraggable = !1, p(this, ya, [e.screenX, e.screenY]);
  const r = new AbortController(), a = this._uiManager.combinedSignal(r);
  this.parent.togglePointerEvents(!1), window.addEventListener("pointermove", b(this, X, ep).bind(this, t), {
    passive: !0,
    capture: !0,
    signal: a
  }), window.addEventListener("touchmove", zt, {
    passive: !1,
    signal: a
  }), window.addEventListener("contextmenu", $i, {
    signal: a
  }), p(this, mn, {
    savedX: this.x,
    savedY: this.y,
    savedWidth: this.width,
    savedHeight: this.height
  });
  const o = this.parent.div.style.cursor, l = this.div.style.cursor;
  this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(e.target).cursor;
  const h = () => {
    var u;
    r.abort(), this.parent.togglePointerEvents(!0), (u = n(this, Ht)) == null || u.toggle(!0), this._isDraggable = s, this.parent.div.style.cursor = o, this.div.style.cursor = l, b(this, X, ou).call(this);
  };
  window.addEventListener("pointerup", h, {
    signal: a
  }), window.addEventListener("blur", h, {
    signal: a
  });
}, tp = function(t, e, i, s) {
  this.width = i, this.height = s, this.x = t, this.y = e, this.setDims(), this.fixAndSetPosition(), this._onResized();
}, ou = function() {
  if (!n(this, mn))
    return;
  const {
    savedX: t,
    savedY: e,
    savedWidth: i,
    savedHeight: s
  } = n(this, mn);
  p(this, mn, null);
  const r = this.x, a = this.y, o = this.width, l = this.height;
  r === t && a === e && o === i && l === s || this.addCommands({
    cmd: b(this, X, tp).bind(this, r, a, o, l),
    undo: b(this, X, tp).bind(this, t, e, i, s),
    mustExec: !0
  });
}, ep = function(t, e) {
  const [i, s] = this.parentDimensions, r = this.x, a = this.y, o = this.width, l = this.height, h = Q.MIN_SIZE / i, c = Q.MIN_SIZE / s, u = b(this, X, au).call(this, this.rotation), f = (O, H) => [u[0] * O + u[2] * H, u[1] * O + u[3] * H], m = b(this, X, au).call(this, 360 - this.rotation), A = (O, H) => [m[0] * O + m[2] * H, m[1] * O + m[3] * H];
  let y, v, w = !1, S = !1;
  switch (t) {
    case "topLeft":
      w = !0, y = (O, H) => [0, 0], v = (O, H) => [O, H];
      break;
    case "topMiddle":
      y = (O, H) => [O / 2, 0], v = (O, H) => [O / 2, H];
      break;
    case "topRight":
      w = !0, y = (O, H) => [O, 0], v = (O, H) => [0, H];
      break;
    case "middleRight":
      S = !0, y = (O, H) => [O, H / 2], v = (O, H) => [0, H / 2];
      break;
    case "bottomRight":
      w = !0, y = (O, H) => [O, H], v = (O, H) => [0, 0];
      break;
    case "bottomMiddle":
      y = (O, H) => [O / 2, H], v = (O, H) => [O / 2, 0];
      break;
    case "bottomLeft":
      w = !0, y = (O, H) => [0, H], v = (O, H) => [O, 0];
      break;
    case "middleLeft":
      S = !0, y = (O, H) => [0, H / 2], v = (O, H) => [O, H / 2];
      break;
  }
  const E = y(o, l), _ = v(o, l);
  let x = f(..._);
  const C = Q._round(r + x[0]), T = Q._round(a + x[1]);
  let L = 1, k = 1, D, R;
  if (e.fromKeyboard)
    ({
      deltaX: D,
      deltaY: R
    } = e);
  else {
    const {
      screenX: O,
      screenY: H
    } = e, [it, at] = n(this, ya);
    [D, R] = this.screenToPageTranslation(O - it, H - at), n(this, ya)[0] = O, n(this, ya)[1] = H;
  }
  if ([D, R] = A(D / i, R / s), w) {
    const O = Math.hypot(o, l);
    L = k = Math.max(Math.min(Math.hypot(_[0] - E[0] - D, _[1] - E[1] - R) / O, 1 / o, 1 / l), h / o, c / l);
  } else S ? L = We(Math.abs(_[0] - E[0] - D), h, 1) / o : k = We(Math.abs(_[1] - E[1] - R), c, 1) / l;
  const N = Q._round(o * L), q = Q._round(l * k);
  x = f(...v(N, q));
  const B = C - x[0], Y = T - x[1];
  n(this, Ei) || p(this, Ei, [this.x, this.y, this.width, this.height]), this.width = N, this.height = q, this.x = B, this.y = Y, this.setDims(), this.fixAndSetPosition(), this._onResizing();
}, tb = function() {
  var t;
  p(this, mn, {
    savedX: this.x,
    savedY: this.y,
    savedWidth: this.width,
    savedHeight: this.height
  }), (t = n(this, Ht)) == null || t.toggle(!1), this.parent.togglePointerEvents(!1);
}, eb = function(t, e, i) {
  let r = 0.7 * (i / e) + 1 - 0.7;
  if (r === 1)
    return;
  const a = b(this, X, au).call(this, this.rotation), o = (C, T) => [a[0] * C + a[2] * T, a[1] * C + a[3] * T], [l, h] = this.parentDimensions, c = this.x, u = this.y, f = this.width, m = this.height, A = Q.MIN_SIZE / l, y = Q.MIN_SIZE / h;
  r = Math.max(Math.min(r, 1 / f, 1 / m), A / f, y / m);
  const v = Q._round(f * r), w = Q._round(m * r);
  if (v === f && w === m)
    return;
  n(this, Ei) || p(this, Ei, [c, u, f, m]);
  const S = o(f / 2, m / 2), E = Q._round(c + S[0]), _ = Q._round(u + S[1]), x = o(v / 2, w / 2);
  this.x = E - x[0], this.y = _ - x[1], this.width = v, this.height = w, this.setDims(), this.fixAndSetPosition(), this._onResizing();
}, ib = function() {
  var t;
  (t = n(this, Ht)) == null || t.toggle(!0), this.parent.togglePointerEvents(!0), b(this, X, ou).call(this);
}, ip = function(t) {
  const {
    isMac: e
  } = _e.platform;
  t.ctrlKey && !e || t.shiftKey || t.metaKey && e ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
}, sb = function(t) {
  const {
    isSelected: e
  } = this;
  this._uiManager.setUpDragSession();
  let i = !1;
  const s = new AbortController(), r = this._uiManager.combinedSignal(s), a = {
    capture: !0,
    passive: !1,
    signal: r
  }, o = (h) => {
    s.abort(), p(this, fr, null), p(this, Aa, !1), this._uiManager.endDragSession() || b(this, X, ip).call(this, h), i && this._onStopDragging();
  };
  e && (p(this, sl, t.clientX), p(this, nl, t.clientY), p(this, fr, t.pointerId), p(this, vc, t.pointerType), window.addEventListener("pointermove", (h) => {
    i || (i = !0, this._uiManager.toggleComment(this, !0, !1), this._onStartDragging());
    const {
      clientX: c,
      clientY: u,
      pointerId: f
    } = h;
    if (f !== n(this, fr)) {
      zt(h);
      return;
    }
    const [m, A] = this.screenToPageTranslation(c - n(this, sl), u - n(this, nl));
    p(this, sl, c), p(this, nl, u), this._uiManager.dragSelectedEditors(m, A);
  }, a), window.addEventListener("touchmove", zt, a), window.addEventListener("pointerdown", (h) => {
    h.pointerType === n(this, vc) && (n(this, va) || h.isPrimary) && o(h), zt(h);
  }, a));
  const l = (h) => {
    if (!n(this, fr) || n(this, fr) === h.pointerId) {
      o(h);
      return;
    }
    zt(h);
  };
  window.addEventListener("pointerup", l, {
    signal: r
  }), window.addEventListener("blur", l, {
    signal: r
  });
}, sp = function() {
  if (n(this, pr) || !this.div)
    return;
  p(this, pr, new AbortController());
  const t = this._uiManager.combinedSignal(n(this, pr));
  this.div.addEventListener("focusin", this.focusin.bind(this), {
    signal: t
  }), this.div.addEventListener("focusout", this.focusout.bind(this), {
    signal: t
  });
}, nb = function(t) {
  Q._resizerKeyboardManager.exec(this, t);
}, rb = function(t) {
  var e;
  n(this, bn) && ((e = t.relatedTarget) == null ? void 0 : e.parentNode) !== n(this, Le) && b(this, X, Th).call(this);
}, ab = function(t) {
  p(this, Ec, n(this, bn) ? t : "");
}, np = function(t) {
  if (n(this, us))
    for (const e of n(this, us))
      e.tabIndex = t;
}, Th = function() {
  p(this, bn, !1), b(this, X, np).call(this, -1), b(this, X, ou).call(this);
}, g(Q, xc), M(Q, "_l10n", null), M(Q, "_l10nResizer", null), M(Q, "_borderLineWidth", -1), M(Q, "_colorManager", new Gf()), M(Q, "_zIndex", 1), M(Q, "_telemetryTimeout", 1e3);
let Ft = Q;
class vy extends Ft {
  constructor(t) {
    super(t), this.annotationElementId = t.annotationElementId, this.deleted = !0;
  }
  serialize() {
    return this.serializeDeleted();
  }
}
const $g = 3285377520, Gi = 4294901760, Cs = 65535;
class ob {
  constructor(t) {
    this.h1 = t ? t & 4294967295 : $g, this.h2 = t ? t & 4294967295 : $g;
  }
  update(t) {
    let e, i;
    if (typeof t == "string") {
      e = new Uint8Array(t.length * 2), i = 0;
      for (let y = 0, v = t.length; y < v; y++) {
        const w = t.charCodeAt(y);
        w <= 255 ? e[i++] = w : (e[i++] = w >>> 8, e[i++] = w & 255);
      }
    } else if (ArrayBuffer.isView(t))
      e = t.slice(), i = e.byteLength;
    else
      throw new Error("Invalid data format, must be a string or TypedArray.");
    const s = i >> 2, r = i - s * 4, a = new Uint32Array(e.buffer, 0, s);
    let o = 0, l = 0, h = this.h1, c = this.h2;
    const u = 3432918353, f = 461845907, m = u & Cs, A = f & Cs;
    for (let y = 0; y < s; y++)
      y & 1 ? (o = a[y], o = o * u & Gi | o * m & Cs, o = o << 15 | o >>> 17, o = o * f & Gi | o * A & Cs, h ^= o, h = h << 13 | h >>> 19, h = h * 5 + 3864292196) : (l = a[y], l = l * u & Gi | l * m & Cs, l = l << 15 | l >>> 17, l = l * f & Gi | l * A & Cs, c ^= l, c = c << 13 | c >>> 19, c = c * 5 + 3864292196);
    switch (o = 0, r) {
      case 3:
        o ^= e[s * 4 + 2] << 16;
      case 2:
        o ^= e[s * 4 + 1] << 8;
      case 1:
        o ^= e[s * 4], o = o * u & Gi | o * m & Cs, o = o << 15 | o >>> 17, o = o * f & Gi | o * A & Cs, s & 1 ? h ^= o : c ^= o;
    }
    this.h1 = h, this.h2 = c;
  }
  hexdigest() {
    let t = this.h1, e = this.h2;
    return t ^= e >>> 1, t = t * 3981806797 & Gi | t * 36045 & Cs, e = e * 4283543511 & Gi | ((e << 16 | t >>> 16) * 2950163797 & Gi) >>> 16, t ^= e >>> 1, t = t * 444984403 & Gi | t * 60499 & Cs, e = e * 3301882366 & Gi | ((e << 16 | t >>> 16) * 3120437893 & Gi) >>> 16, t ^= e >>> 1, (t >>> 0).toString(16).padStart(8, "0") + (e >>> 0).toString(16).padStart(8, "0");
  }
}
const rp = Object.freeze({
  map: null,
  hash: "",
  transfer: void 0
});
var Ea, Sa, yn, ke, Ju, lb;
class bg {
  constructor() {
    g(this, Ju);
    g(this, Ea, !1);
    g(this, Sa, null);
    g(this, yn, null);
    g(this, ke, /* @__PURE__ */ new Map());
    this.onSetModified = null, this.onResetModified = null, this.onAnnotationEditor = null;
  }
  getValue(t, e) {
    const i = n(this, ke).get(t);
    return i === void 0 ? e : Object.assign(e, i);
  }
  getRawValue(t) {
    return n(this, ke).get(t);
  }
  remove(t) {
    const e = n(this, ke).get(t);
    if (e !== void 0 && (e instanceof Ft && n(this, yn).delete(e.annotationElementId), n(this, ke).delete(t), n(this, ke).size === 0 && this.resetModified(), typeof this.onAnnotationEditor == "function")) {
      for (const i of n(this, ke).values())
        if (i instanceof Ft)
          return;
      this.onAnnotationEditor(null);
    }
  }
  setValue(t, e) {
    const i = n(this, ke).get(t);
    let s = !1;
    if (i !== void 0)
      for (const [r, a] of Object.entries(e))
        i[r] !== a && (s = !0, i[r] = a);
    else
      s = !0, n(this, ke).set(t, e);
    s && b(this, Ju, lb).call(this), e instanceof Ft && ((n(this, yn) || p(this, yn, /* @__PURE__ */ new Map())).set(e.annotationElementId, e), typeof this.onAnnotationEditor == "function" && this.onAnnotationEditor(e.constructor._type));
  }
  has(t) {
    return n(this, ke).has(t);
  }
  get size() {
    return n(this, ke).size;
  }
  resetModified() {
    n(this, Ea) && (p(this, Ea, !1), typeof this.onResetModified == "function" && this.onResetModified());
  }
  get print() {
    return new hb(this);
  }
  get serializable() {
    if (n(this, ke).size === 0)
      return rp;
    const t = /* @__PURE__ */ new Map(), e = new ob(), i = [], s = /* @__PURE__ */ Object.create(null);
    let r = !1;
    for (const [a, o] of n(this, ke)) {
      const l = o instanceof Ft ? o.serialize(!1, s) : o;
      l && (t.set(a, l), e.update(`${a}:${JSON.stringify(l)}`), r || (r = !!l.bitmap));
    }
    if (r)
      for (const a of t.values())
        a.bitmap && i.push(a.bitmap);
    return t.size > 0 ? {
      map: t,
      hash: e.hexdigest(),
      transfer: i
    } : rp;
  }
  get editorStats() {
    let t = null;
    const e = /* @__PURE__ */ new Map();
    let i = 0, s = 0;
    for (const r of n(this, ke).values()) {
      if (!(r instanceof Ft)) {
        r.popup && (r.popup.deleted ? s += 1 : i += 1);
        continue;
      }
      r.isCommentDeleted ? s += 1 : r.hasEditedComment && (i += 1);
      const a = r.telemetryFinalData;
      if (!a)
        continue;
      const {
        type: o
      } = a;
      e.has(o) || e.set(o, Object.getPrototypeOf(r).constructor), t || (t = /* @__PURE__ */ Object.create(null));
      const l = t[o] || (t[o] = /* @__PURE__ */ new Map());
      for (const [h, c] of Object.entries(a)) {
        if (h === "type")
          continue;
        let u = l.get(h);
        u || (u = /* @__PURE__ */ new Map(), l.set(h, u));
        const f = u.get(c) ?? 0;
        u.set(c, f + 1);
      }
    }
    if ((s > 0 || i > 0) && (t || (t = /* @__PURE__ */ Object.create(null)), t.comments = {
      deleted: s,
      edited: i
    }), !t)
      return null;
    for (const [r, a] of e)
      t[r] = a.computeTelemetryFinalData(t[r]);
    return t;
  }
  resetModifiedIds() {
    p(this, Sa, null);
  }
  updateEditor(t, e) {
    var s;
    const i = (s = n(this, yn)) == null ? void 0 : s.get(t);
    return i ? (i.updateFromAnnotationLayer(e), !0) : !1;
  }
  getEditor(t) {
    var e;
    return ((e = n(this, yn)) == null ? void 0 : e.get(t)) || null;
  }
  get modifiedIds() {
    if (n(this, Sa))
      return n(this, Sa);
    const t = [];
    if (n(this, yn))
      for (const e of n(this, yn).values())
        e.serialize() && t.push(e.annotationElementId);
    return p(this, Sa, {
      ids: new Set(t),
      hash: t.join(",")
    });
  }
  [Symbol.iterator]() {
    return n(this, ke).entries();
  }
}
Ea = new WeakMap(), Sa = new WeakMap(), yn = new WeakMap(), ke = new WeakMap(), Ju = new WeakSet(), lb = function() {
  n(this, Ea) || (p(this, Ea, !0), typeof this.onSetModified == "function" && this.onSetModified());
};
var Cc;
class hb extends bg {
  constructor(e) {
    super();
    g(this, Cc);
    const {
      map: i,
      hash: s,
      transfer: r
    } = e.serializable, a = structuredClone(i, r ? {
      transfer: r
    } : null);
    p(this, Cc, {
      map: a,
      hash: s,
      transfer: r
    });
  }
  get print() {
    Dt("Should not call PrintAnnotationStorage.print");
  }
  get serializable() {
    return n(this, Cc);
  }
  get modifiedIds() {
    return st(this, "modifiedIds", {
      ids: /* @__PURE__ */ new Set(),
      hash: ""
    });
  }
}
Cc = new WeakMap();
var rl;
class Ey {
  constructor({
    ownerDocument: t = globalThis.document,
    styleElement: e = null
  }) {
    g(this, rl, /* @__PURE__ */ new Set());
    this._document = t, this.nativeFontFaces = /* @__PURE__ */ new Set(), this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
  }
  addNativeFontFace(t) {
    this.nativeFontFaces.add(t), this._document.fonts.add(t);
  }
  removeNativeFontFace(t) {
    this.nativeFontFaces.delete(t), this._document.fonts.delete(t);
  }
  insertRule(t) {
    this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement));
    const e = this.styleElement.sheet;
    e.insertRule(t, e.cssRules.length);
  }
  clear() {
    for (const t of this.nativeFontFaces)
      this._document.fonts.delete(t);
    this.nativeFontFaces.clear(), n(this, rl).clear(), this.styleElement && (this.styleElement.remove(), this.styleElement = null);
  }
  async loadSystemFont({
    systemFontInfo: t,
    disableFontFace: e,
    _inspectFont: i
  }) {
    if (!(!t || n(this, rl).has(t.loadedName))) {
      if (dt(!e, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
        const {
          loadedName: s,
          src: r,
          style: a
        } = t, o = new FontFace(s, r, a);
        this.addNativeFontFace(o);
        try {
          await o.load(), n(this, rl).add(s), i == null || i(t);
        } catch {
          J(`Cannot load system font: ${t.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(o);
        }
        return;
      }
      Dt("Not implemented: loadSystemFont without the Font Loading API.");
    }
  }
  async bind(t) {
    if (t.attached || t.missingFile && !t.systemFontInfo)
      return;
    if (t.attached = !0, t.systemFontInfo) {
      await this.loadSystemFont(t);
      return;
    }
    if (this.isFontLoadingAPISupported) {
      const i = t.createNativeFontFace();
      if (i) {
        this.addNativeFontFace(i);
        try {
          await i.loaded;
        } catch (s) {
          throw J(`Failed to load font '${i.family}': '${s}'.`), t.disableFontFace = !0, s;
        }
      }
      return;
    }
    const e = t.createFontFaceRule();
    if (e) {
      if (this.insertRule(e), this.isSyncFontLoadingSupported)
        return;
      await new Promise((i) => {
        const s = this._queueLoadingCallback(i);
        this._prepareFontLoadEvent(t, s);
      });
    }
  }
  get isFontLoadingAPISupported() {
    var e;
    const t = !!((e = this._document) != null && e.fonts);
    return st(this, "isFontLoadingAPISupported", t);
  }
  get isSyncFontLoadingSupported() {
    return st(this, "isSyncFontLoadingSupported", ii || _e.platform.isFirefox);
  }
  _queueLoadingCallback(t) {
    function e() {
      for (dt(!s.done, "completeRequest() cannot be called twice."), s.done = !0; i.length > 0 && i[0].done; ) {
        const r = i.shift();
        setTimeout(r.callback, 0);
      }
    }
    const {
      loadingRequests: i
    } = this, s = {
      done: !1,
      complete: e,
      callback: t
    };
    return i.push(s), s;
  }
  get _loadTestFont() {
    const t = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
    return st(this, "_loadTestFont", t);
  }
  _prepareFontLoadEvent(t, e) {
    function i(_, x) {
      return _.charCodeAt(x) << 24 | _.charCodeAt(x + 1) << 16 | _.charCodeAt(x + 2) << 8 | _.charCodeAt(x + 3) & 255;
    }
    function s(_, x, C, T) {
      const L = _.substring(0, x), k = _.substring(x + C);
      return L + T + k;
    }
    let r, a;
    const o = this._document.createElement("canvas");
    o.width = 1, o.height = 1;
    const l = o.getContext("2d");
    let h = 0;
    function c(_, x) {
      if (++h > 30) {
        J("Load test font never loaded."), x();
        return;
      }
      if (l.font = "30px " + _, l.fillText(".", 0, 20), l.getImageData(0, 0, 1, 1).data[3] > 0) {
        x();
        return;
      }
      setTimeout(c.bind(null, _, x));
    }
    const u = `lt${Date.now()}${this.loadTestFontId++}`;
    let f = this._loadTestFont;
    f = s(f, 976, u.length, u);
    const A = 16, y = 1482184792;
    let v = i(f, A);
    for (r = 0, a = u.length - 3; r < a; r += 4)
      v = v - y + i(u, r) | 0;
    r < u.length && (v = v - y + i(u + "XXX", r) | 0), f = s(f, A, 4, hy(v));
    const w = `url(data:font/opentype;base64,${btoa(f)});`, S = `@font-face {font-family:"${u}";src:${w}}`;
    this.insertRule(S);
    const E = this._document.createElement("div");
    E.style.visibility = "hidden", E.style.width = E.style.height = "10px", E.style.position = "absolute", E.style.top = E.style.left = "0px";
    for (const _ of [t.loadedName, u]) {
      const x = this._document.createElement("span");
      x.textContent = "Hi", x.style.fontFamily = _, E.append(x);
    }
    this._document.body.append(E), c(u, () => {
      E.remove(), e.complete();
    });
  }
}
rl = new WeakMap();
var Et;
class Sy {
  constructor(t, e = null, i, s) {
    g(this, Et);
    this.compiledGlyphs = /* @__PURE__ */ Object.create(null), p(this, Et, t), this._inspectFont = e, i && Object.assign(this, i), s && (this.charProcOperatorList = s);
  }
  createNativeFontFace() {
    var e;
    if (!this.data || this.disableFontFace)
      return null;
    let t;
    if (!this.cssFontInfo)
      t = new FontFace(this.loadedName, this.data, {});
    else {
      const i = {
        weight: this.cssFontInfo.fontWeight
      };
      this.cssFontInfo.italicAngle && (i.style = `oblique ${this.cssFontInfo.italicAngle}deg`), t = new FontFace(this.cssFontInfo.fontFamily, this.data, i);
    }
    return (e = this._inspectFont) == null || e.call(this, this), t;
  }
  createFontFaceRule() {
    var i;
    if (!this.data || this.disableFontFace)
      return null;
    const t = `url(data:${this.mimetype};base64,${xm(this.data)});`;
    let e;
    if (!this.cssFontInfo)
      e = `@font-face {font-family:"${this.loadedName}";src:${t}}`;
    else {
      let s = `font-weight: ${this.cssFontInfo.fontWeight};`;
      this.cssFontInfo.italicAngle && (s += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), e = `@font-face {font-family:"${this.cssFontInfo.fontFamily}";${s}src:${t}}`;
    }
    return (i = this._inspectFont) == null || i.call(this, this, t), e;
  }
  getPathGenerator(t, e) {
    if (this.compiledGlyphs[e] !== void 0)
      return this.compiledGlyphs[e];
    const i = this.loadedName + "_path_" + e;
    let s;
    try {
      s = t.get(i);
    } catch (a) {
      J(`getPathGenerator - ignoring character: "${a}".`);
    }
    const r = new Path2D(s || "");
    return this.fontExtraProperties || t.delete(i), this.compiledGlyphs[e] = r;
  }
  get black() {
    return n(this, Et).black;
  }
  get bold() {
    return n(this, Et).bold;
  }
  get disableFontFace() {
    return n(this, Et).disableFontFace ?? !1;
  }
  get fontExtraProperties() {
    return n(this, Et).fontExtraProperties ?? !1;
  }
  get isInvalidPDFjsFont() {
    return n(this, Et).isInvalidPDFjsFont;
  }
  get isType3Font() {
    return n(this, Et).isType3Font;
  }
  get italic() {
    return n(this, Et).italic;
  }
  get missingFile() {
    return n(this, Et).missingFile;
  }
  get remeasure() {
    return n(this, Et).remeasure;
  }
  get vertical() {
    return n(this, Et).vertical;
  }
  get ascent() {
    return n(this, Et).ascent;
  }
  get defaultWidth() {
    return n(this, Et).defaultWidth;
  }
  get descent() {
    return n(this, Et).descent;
  }
  get bbox() {
    return n(this, Et).bbox;
  }
  get fontMatrix() {
    return n(this, Et).fontMatrix;
  }
  get fallbackName() {
    return n(this, Et).fallbackName;
  }
  get loadedName() {
    return n(this, Et).loadedName;
  }
  get mimetype() {
    return n(this, Et).mimetype;
  }
  get name() {
    return n(this, Et).name;
  }
  get data() {
    return n(this, Et).data;
  }
  clearData() {
    n(this, Et).clearData();
  }
  get cssFontInfo() {
    return n(this, Et).cssFontInfo;
  }
  get systemFontInfo() {
    return n(this, Et).systemFontInfo;
  }
  get defaultVMetrics() {
    return n(this, Et).defaultVMetrics;
  }
}
Et = new WeakMap();
function _y(d) {
  if (d instanceof URL)
    return d.href;
  if (typeof d == "string") {
    if (ii)
      return d;
    const t = URL.parse(d, window.location);
    if (t)
      return t.href;
  }
  throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
}
function xy(d) {
  if (ii && typeof Buffer < "u" && d instanceof Buffer)
    throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
  if (d instanceof Uint8Array && d.byteLength === d.buffer.byteLength)
    return d;
  if (typeof d == "string")
    return Id(d);
  if (d instanceof ArrayBuffer || ArrayBuffer.isView(d) || typeof d == "object" && !isNaN(d == null ? void 0 : d.length))
    return new Uint8Array(d);
  throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
}
function Xd(d) {
  if (typeof d != "string")
    return null;
  if (d.endsWith("/"))
    return d;
  throw new Error(`Invalid factory url: "${d}" must include trailing slash.`);
}
const ap = (d) => typeof d == "object" && Number.isInteger(d == null ? void 0 : d.num) && d.num >= 0 && Number.isInteger(d == null ? void 0 : d.gen) && d.gen >= 0, Cy = (d) => typeof d == "object" && typeof (d == null ? void 0 : d.name) == "string", cb = fy.bind(null, ap, Cy);
var An, Qu;
class Ty {
  constructor() {
    g(this, An, /* @__PURE__ */ new Map());
    g(this, Qu, Promise.resolve());
  }
  postMessage(t, e) {
    const i = {
      data: structuredClone(t, e ? {
        transfer: e
      } : null)
    };
    n(this, Qu).then(() => {
      for (const [s] of n(this, An))
        s.call(this, i);
    });
  }
  addEventListener(t, e, i = null) {
    let s = null;
    if ((i == null ? void 0 : i.signal) instanceof AbortSignal) {
      const {
        signal: r
      } = i;
      if (r.aborted) {
        J("LoopbackPort - cannot use an `aborted` signal.");
        return;
      }
      const a = () => this.removeEventListener(t, e);
      s = () => r.removeEventListener("abort", a), r.addEventListener("abort", a);
    }
    n(this, An).set(e, s);
  }
  removeEventListener(t, e) {
    const i = n(this, An).get(e);
    i == null || i(), n(this, An).delete(e);
  }
  terminate() {
    for (const [, t] of n(this, An))
      t == null || t();
    n(this, An).clear();
  }
}
An = new WeakMap(), Qu = new WeakMap();
const Yd = {
  DATA: 1,
  ERROR: 2
}, ne = {
  CANCEL: 1,
  CANCEL_COMPLETE: 2,
  CLOSE: 3,
  ENQUEUE: 4,
  ERROR: 5,
  PULL: 6,
  PULL_COMPLETE: 7,
  START_COMPLETE: 8
};
function Vg() {
}
function oi(d) {
  if (d instanceof Gn || d instanceof Iu || d instanceof Ig || d instanceof Wh || d instanceof Pf)
    return d;
  switch (d instanceof Error || typeof d == "object" && d !== null || Dt('wrapReason: Expected "reason" to be a (possibly cloned) Error.'), d.name) {
    case "AbortException":
      return new Gn(d.message);
    case "InvalidPDFException":
      return new Iu(d.message);
    case "PasswordException":
      return new Ig(d.message, d.code);
    case "ResponseException":
      return new Wh(d.message, d.status, d.missing);
    case "UnknownErrorException":
      return new Pf(d.message, d.details);
  }
  return new Pf(d.message, d.toString());
}
var al, as, db, ub, fb, lu;
class Ph {
  constructor(t, e, i) {
    g(this, as);
    g(this, al, new AbortController());
    this.sourceName = t, this.targetName = e, this.comObj = i, this.callbackId = 1, this.streamId = 1, this.streamSinks = /* @__PURE__ */ Object.create(null), this.streamControllers = /* @__PURE__ */ Object.create(null), this.callbackCapabilities = /* @__PURE__ */ Object.create(null), this.actionHandler = /* @__PURE__ */ Object.create(null), i.addEventListener("message", b(this, as, db).bind(this), {
      signal: n(this, al).signal
    });
  }
  on(t, e) {
    const i = this.actionHandler;
    if (i[t])
      throw new Error(`There is already an actionName called "${t}"`);
    i[t] = e;
  }
  send(t, e, i) {
    this.comObj.postMessage({
      sourceName: this.sourceName,
      targetName: this.targetName,
      action: t,
      data: e
    }, i);
  }
  sendWithPromise(t, e, i) {
    const s = this.callbackId++, r = Promise.withResolvers();
    this.callbackCapabilities[s] = r;
    try {
      this.comObj.postMessage({
        sourceName: this.sourceName,
        targetName: this.targetName,
        action: t,
        callbackId: s,
        data: e
      }, i);
    } catch (a) {
      r.reject(a);
    }
    return r.promise;
  }
  sendWithStream(t, e, i, s) {
    const r = this.streamId++, a = this.sourceName, o = this.targetName, l = this.comObj;
    return new ReadableStream({
      start: (h) => {
        const c = Promise.withResolvers();
        return this.streamControllers[r] = {
          controller: h,
          startCall: c,
          pullCall: null,
          cancelCall: null,
          isClosed: !1
        }, l.postMessage({
          sourceName: a,
          targetName: o,
          action: t,
          streamId: r,
          data: e,
          desiredSize: h.desiredSize
        }, s), c.promise;
      },
      pull: (h) => {
        const c = Promise.withResolvers();
        return this.streamControllers[r].pullCall = c, l.postMessage({
          sourceName: a,
          targetName: o,
          stream: ne.PULL,
          streamId: r,
          desiredSize: h.desiredSize
        }), c.promise;
      },
      cancel: (h) => {
        dt(h instanceof Error, "cancel must have a valid reason");
        const c = Promise.withResolvers();
        return this.streamControllers[r].cancelCall = c, this.streamControllers[r].isClosed = !0, l.postMessage({
          sourceName: a,
          targetName: o,
          stream: ne.CANCEL,
          streamId: r,
          reason: oi(h)
        }), c.promise;
      }
    }, i);
  }
  destroy() {
    var t;
    (t = n(this, al)) == null || t.abort(), p(this, al, null);
  }
}
al = new WeakMap(), as = new WeakSet(), db = function({
  data: t
}) {
  if (t.targetName !== this.sourceName)
    return;
  if (t.stream) {
    b(this, as, fb).call(this, t);
    return;
  }
  if (t.callback) {
    const i = t.callbackId, s = this.callbackCapabilities[i];
    if (!s)
      throw new Error(`Cannot resolve callback ${i}`);
    if (delete this.callbackCapabilities[i], t.callback === Yd.DATA)
      s.resolve(t.data);
    else if (t.callback === Yd.ERROR)
      s.reject(oi(t.reason));
    else
      throw new Error("Unexpected callback case");
    return;
  }
  const e = this.actionHandler[t.action];
  if (!e)
    throw new Error(`Unknown action from worker: ${t.action}`);
  if (t.callbackId) {
    const i = this.sourceName, s = t.sourceName, r = this.comObj;
    Promise.try(e, t.data).then(function(a) {
      r.postMessage({
        sourceName: i,
        targetName: s,
        callback: Yd.DATA,
        callbackId: t.callbackId,
        data: a
      });
    }, function(a) {
      r.postMessage({
        sourceName: i,
        targetName: s,
        callback: Yd.ERROR,
        callbackId: t.callbackId,
        reason: oi(a)
      });
    });
    return;
  }
  if (t.streamId) {
    b(this, as, ub).call(this, t);
    return;
  }
  e(t.data);
}, ub = function(t) {
  const e = t.streamId, i = this.sourceName, s = t.sourceName, r = this.comObj, a = this, o = this.actionHandler[t.action], l = {
    enqueue(h, c = 1, u) {
      if (this.isCancelled)
        return;
      const f = this.desiredSize;
      this.desiredSize -= c, f > 0 && this.desiredSize <= 0 && (this.sinkCapability = Promise.withResolvers(), this.ready = this.sinkCapability.promise), r.postMessage({
        sourceName: i,
        targetName: s,
        stream: ne.ENQUEUE,
        streamId: e,
        chunk: h
      }, u);
    },
    close() {
      this.isCancelled || (this.isCancelled = !0, r.postMessage({
        sourceName: i,
        targetName: s,
        stream: ne.CLOSE,
        streamId: e
      }), delete a.streamSinks[e]);
    },
    error(h) {
      dt(h instanceof Error, "error must have a valid reason"), !this.isCancelled && (this.isCancelled = !0, r.postMessage({
        sourceName: i,
        targetName: s,
        stream: ne.ERROR,
        streamId: e,
        reason: oi(h)
      }));
    },
    sinkCapability: Promise.withResolvers(),
    onPull: null,
    onCancel: null,
    isCancelled: !1,
    desiredSize: t.desiredSize,
    ready: null
  };
  l.sinkCapability.resolve(), l.ready = l.sinkCapability.promise, this.streamSinks[e] = l, Promise.try(o, t.data, l).then(function() {
    r.postMessage({
      sourceName: i,
      targetName: s,
      stream: ne.START_COMPLETE,
      streamId: e,
      success: !0
    });
  }, function(h) {
    r.postMessage({
      sourceName: i,
      targetName: s,
      stream: ne.START_COMPLETE,
      streamId: e,
      reason: oi(h)
    });
  });
}, fb = function(t) {
  const e = t.streamId, i = this.sourceName, s = t.sourceName, r = this.comObj, a = this.streamControllers[e], o = this.streamSinks[e];
  switch (t.stream) {
    case ne.START_COMPLETE:
      t.success ? a.startCall.resolve() : a.startCall.reject(oi(t.reason));
      break;
    case ne.PULL_COMPLETE:
      t.success ? a.pullCall.resolve() : a.pullCall.reject(oi(t.reason));
      break;
    case ne.PULL:
      if (!o) {
        r.postMessage({
          sourceName: i,
          targetName: s,
          stream: ne.PULL_COMPLETE,
          streamId: e,
          success: !0
        });
        break;
      }
      o.desiredSize <= 0 && t.desiredSize > 0 && o.sinkCapability.resolve(), o.desiredSize = t.desiredSize, Promise.try(o.onPull || Vg).then(function() {
        r.postMessage({
          sourceName: i,
          targetName: s,
          stream: ne.PULL_COMPLETE,
          streamId: e,
          success: !0
        });
      }, function(h) {
        r.postMessage({
          sourceName: i,
          targetName: s,
          stream: ne.PULL_COMPLETE,
          streamId: e,
          reason: oi(h)
        });
      });
      break;
    case ne.ENQUEUE:
      if (dt(a, "enqueue should have stream controller"), a.isClosed)
        break;
      a.controller.enqueue(t.chunk);
      break;
    case ne.CLOSE:
      if (dt(a, "close should have stream controller"), a.isClosed)
        break;
      a.isClosed = !0, a.controller.close(), b(this, as, lu).call(this, a, e);
      break;
    case ne.ERROR:
      dt(a, "error should have stream controller"), a.controller.error(oi(t.reason)), b(this, as, lu).call(this, a, e);
      break;
    case ne.CANCEL_COMPLETE:
      t.success ? a.cancelCall.resolve() : a.cancelCall.reject(oi(t.reason)), b(this, as, lu).call(this, a, e);
      break;
    case ne.CANCEL:
      if (!o)
        break;
      const l = oi(t.reason);
      Promise.try(o.onCancel || Vg, l).then(function() {
        r.postMessage({
          sourceName: i,
          targetName: s,
          stream: ne.CANCEL_COMPLETE,
          streamId: e,
          success: !0
        });
      }, function(h) {
        r.postMessage({
          sourceName: i,
          targetName: s,
          stream: ne.CANCEL_COMPLETE,
          streamId: e,
          reason: oi(h)
        });
      }), o.sinkCapability.reject(l), o.isCancelled = !0, delete this.streamSinks[e];
      break;
    default:
      throw new Error("Unexpected stream case");
  }
}, lu = async function(t, e) {
  var i, s, r;
  await Promise.allSettled([(i = t.startCall) == null ? void 0 : i.promise, (s = t.pullCall) == null ? void 0 : s.promise, (r = t.cancelCall) == null ? void 0 : r.promise]), delete this.streamControllers[e];
};
var Tc;
class pb {
  constructor({
    enableHWA: t = !1
  }) {
    g(this, Tc, !1);
    p(this, Tc, t);
  }
  create(t, e) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid canvas size");
    const i = this._createCanvas(t, e);
    return {
      canvas: i,
      context: i.getContext("2d", {
        willReadFrequently: !n(this, Tc)
      })
    };
  }
  reset(t, e, i) {
    if (!t.canvas)
      throw new Error("Canvas is not specified");
    if (e <= 0 || i <= 0)
      throw new Error("Invalid canvas size");
    t.canvas.width = e, t.canvas.height = i;
  }
  destroy(t) {
    if (!t.canvas)
      throw new Error("Canvas is not specified");
    t.canvas.width = 0, t.canvas.height = 0, t.canvas = null, t.context = null;
  }
  _createCanvas(t, e) {
    Dt("Abstract method `_createCanvas` called.");
  }
}
Tc = new WeakMap();
class Py extends pb {
  constructor({
    ownerDocument: t = globalThis.document,
    enableHWA: e = !1
  }) {
    super({
      enableHWA: e
    }), this._document = t;
  }
  _createCanvas(t, e) {
    const i = this._document.createElement("canvas");
    return i.width = t, i.height = e, i;
  }
}
class gb {
  constructor({
    baseUrl: t = null,
    isCompressed: e = !0
  }) {
    this.baseUrl = t, this.isCompressed = e;
  }
  async fetch({
    name: t
  }) {
    if (!this.baseUrl)
      throw new Error("Ensure that the `cMapUrl` and `cMapPacked` API parameters are provided.");
    if (!t)
      throw new Error("CMap name must be specified.");
    const e = this.baseUrl + t + (this.isCompressed ? ".bcmap" : "");
    return this._fetch(e).then((i) => ({
      cMapData: i,
      isCompressed: this.isCompressed
    })).catch((i) => {
      throw new Error(`Unable to load ${this.isCompressed ? "binary " : ""}CMap at: ${e}`);
    });
  }
  async _fetch(t) {
    Dt("Abstract method `_fetch` called.");
  }
}
class zg extends gb {
  async _fetch(t) {
    const e = await ph(t, this.isCompressed ? "arraybuffer" : "text");
    return e instanceof ArrayBuffer ? new Uint8Array(e) : Id(e);
  }
}
class mb {
  addFilter(t) {
    return "none";
  }
  addHCMFilter(t, e) {
    return "none";
  }
  addAlphaFilter(t) {
    return "none";
  }
  addLuminosityFilter(t) {
    return "none";
  }
  addHighlightHCMFilter(t, e, i, s, r) {
    return "none";
  }
  destroy(t = !1) {
  }
}
var _a, ol, wn, vn, $e, xa, Ca, $, Be, Lh, xo, hu, Co, bb, op, To, kh, Rh, lp, Mh;
class Ly extends mb {
  constructor({
    docId: e,
    ownerDocument: i = globalThis.document
  }) {
    super();
    g(this, $);
    g(this, _a);
    g(this, ol);
    g(this, wn);
    g(this, vn);
    g(this, $e);
    g(this, xa);
    g(this, Ca, 0);
    p(this, vn, e), p(this, $e, i);
  }
  addFilter(e) {
    if (!e)
      return "none";
    let i = n(this, $, Be).get(e);
    if (i)
      return i;
    const [s, r, a] = b(this, $, hu).call(this, e), o = e.length === 1 ? s : `${s}${r}${a}`;
    if (i = n(this, $, Be).get(o), i)
      return n(this, $, Be).set(e, i), i;
    const l = `g_${n(this, vn)}_transfer_map_${oe(this, Ca)._++}`, h = b(this, $, Co).call(this, l);
    n(this, $, Be).set(e, h), n(this, $, Be).set(o, h);
    const c = b(this, $, To).call(this, l);
    return b(this, $, Rh).call(this, s, r, a, c), h;
  }
  addHCMFilter(e, i) {
    var A;
    const s = `${e}-${i}`, r = "base";
    let a = n(this, $, Lh).get(r);
    if ((a == null ? void 0 : a.key) === s || (a ? ((A = a.filter) == null || A.remove(), a.key = s, a.url = "none", a.filter = null) : (a = {
      key: s,
      url: "none",
      filter: null
    }, n(this, $, Lh).set(r, a)), !e || !i))
      return a.url;
    const o = b(this, $, Mh).call(this, e);
    e = z.makeHexColor(...o);
    const l = b(this, $, Mh).call(this, i);
    if (i = z.makeHexColor(...l), n(this, $, xo).style.color = "", e === "#000000" && i === "#ffffff" || e === i)
      return a.url;
    const h = new Array(256);
    for (let y = 0; y <= 255; y++) {
      const v = y / 255;
      h[y] = v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
    }
    const c = h.join(","), u = `g_${n(this, vn)}_hcm_filter`, f = a.filter = b(this, $, To).call(this, u);
    b(this, $, Rh).call(this, c, c, c, f), b(this, $, op).call(this, f);
    const m = (y, v) => {
      const w = o[y] / 255, S = l[y] / 255, E = new Array(v + 1);
      for (let _ = 0; _ <= v; _++)
        E[_] = w + _ / v * (S - w);
      return E.join(",");
    };
    return b(this, $, Rh).call(this, m(0, 5), m(1, 5), m(2, 5), f), a.url = b(this, $, Co).call(this, u), a.url;
  }
  addAlphaFilter(e) {
    let i = n(this, $, Be).get(e);
    if (i)
      return i;
    const [s] = b(this, $, hu).call(this, [e]), r = `alpha_${s}`;
    if (i = n(this, $, Be).get(r), i)
      return n(this, $, Be).set(e, i), i;
    const a = `g_${n(this, vn)}_alpha_map_${oe(this, Ca)._++}`, o = b(this, $, Co).call(this, a);
    n(this, $, Be).set(e, o), n(this, $, Be).set(r, o);
    const l = b(this, $, To).call(this, a);
    return b(this, $, lp).call(this, s, l), o;
  }
  addLuminosityFilter(e) {
    let i = n(this, $, Be).get(e || "luminosity");
    if (i)
      return i;
    let s, r;
    if (e ? ([s] = b(this, $, hu).call(this, [e]), r = `luminosity_${s}`) : r = "luminosity", i = n(this, $, Be).get(r), i)
      return n(this, $, Be).set(e, i), i;
    const a = `g_${n(this, vn)}_luminosity_map_${oe(this, Ca)._++}`, o = b(this, $, Co).call(this, a);
    n(this, $, Be).set(e, o), n(this, $, Be).set(r, o);
    const l = b(this, $, To).call(this, a);
    return b(this, $, bb).call(this, l), e && b(this, $, lp).call(this, s, l), o;
  }
  addHighlightHCMFilter(e, i, s, r, a) {
    var S;
    const o = `${i}-${s}-${r}-${a}`;
    let l = n(this, $, Lh).get(e);
    if ((l == null ? void 0 : l.key) === o || (l ? ((S = l.filter) == null || S.remove(), l.key = o, l.url = "none", l.filter = null) : (l = {
      key: o,
      url: "none",
      filter: null
    }, n(this, $, Lh).set(e, l)), !i || !s))
      return l.url;
    const [h, c] = [i, s].map(b(this, $, Mh).bind(this));
    let u = Math.round(0.2126 * h[0] + 0.7152 * h[1] + 0.0722 * h[2]), f = Math.round(0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]), [m, A] = [r, a].map(b(this, $, Mh).bind(this));
    f < u && ([u, f, m, A] = [f, u, A, m]), n(this, $, xo).style.color = "";
    const y = (E, _, x) => {
      const C = new Array(256), T = (f - u) / x, L = E / 255, k = (_ - E) / (255 * x);
      let D = 0;
      for (let R = 0; R <= x; R++) {
        const N = Math.round(u + R * T), q = L + R * k;
        for (let B = D; B <= N; B++)
          C[B] = q;
        D = N + 1;
      }
      for (let R = D; R < 256; R++)
        C[R] = C[D - 1];
      return C.join(",");
    }, v = `g_${n(this, vn)}_hcm_${e}_filter`, w = l.filter = b(this, $, To).call(this, v);
    return b(this, $, op).call(this, w), b(this, $, Rh).call(this, y(m[0], A[0], 5), y(m[1], A[1], 5), y(m[2], A[2], 5), w), l.url = b(this, $, Co).call(this, v), l.url;
  }
  destroy(e = !1) {
    var i, s, r, a;
    e && ((i = n(this, xa)) != null && i.size) || ((s = n(this, wn)) == null || s.parentNode.parentNode.remove(), p(this, wn, null), (r = n(this, ol)) == null || r.clear(), p(this, ol, null), (a = n(this, xa)) == null || a.clear(), p(this, xa, null), p(this, Ca, 0));
  }
}
_a = new WeakMap(), ol = new WeakMap(), wn = new WeakMap(), vn = new WeakMap(), $e = new WeakMap(), xa = new WeakMap(), Ca = new WeakMap(), $ = new WeakSet(), Be = function() {
  return n(this, ol) || p(this, ol, /* @__PURE__ */ new Map());
}, Lh = function() {
  return n(this, xa) || p(this, xa, /* @__PURE__ */ new Map());
}, xo = function() {
  if (!n(this, wn)) {
    const e = n(this, $e).createElement("div"), {
      style: i
    } = e;
    i.visibility = "hidden", i.contain = "strict", i.width = i.height = 0, i.position = "absolute", i.top = i.left = 0, i.zIndex = -1;
    const s = n(this, $e).createElementNS(sn, "svg");
    s.setAttribute("width", 0), s.setAttribute("height", 0), p(this, wn, n(this, $e).createElementNS(sn, "defs")), e.append(s), s.append(n(this, wn)), n(this, $e).body.append(e);
  }
  return n(this, wn);
}, hu = function(e) {
  if (e.length === 1) {
    const h = e[0], c = new Array(256);
    for (let f = 0; f < 256; f++)
      c[f] = h[f] / 255;
    const u = c.join(",");
    return [u, u, u];
  }
  const [i, s, r] = e, a = new Array(256), o = new Array(256), l = new Array(256);
  for (let h = 0; h < 256; h++)
    a[h] = i[h] / 255, o[h] = s[h] / 255, l[h] = r[h] / 255;
  return [a.join(","), o.join(","), l.join(",")];
}, Co = function(e) {
  if (n(this, _a) === void 0) {
    p(this, _a, "");
    const i = n(this, $e).URL;
    i !== n(this, $e).baseURI && (Nd(i) ? J('#createUrl: ignore "data:"-URL for performance reasons.') : p(this, _a, ug(i, "")));
  }
  return `url(${n(this, _a)}#${e})`;
}, bb = function(e) {
  const i = n(this, $e).createElementNS(sn, "feColorMatrix");
  i.setAttribute("type", "matrix"), i.setAttribute("values", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.3 0.59 0.11 0 0"), e.append(i);
}, op = function(e) {
  const i = n(this, $e).createElementNS(sn, "feColorMatrix");
  i.setAttribute("type", "matrix"), i.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), e.append(i);
}, To = function(e) {
  const i = n(this, $e).createElementNS(sn, "filter");
  return i.setAttribute("color-interpolation-filters", "sRGB"), i.setAttribute("id", e), n(this, $, xo).append(i), i;
}, kh = function(e, i, s) {
  const r = n(this, $e).createElementNS(sn, i);
  r.setAttribute("type", "discrete"), r.setAttribute("tableValues", s), e.append(r);
}, Rh = function(e, i, s, r) {
  const a = n(this, $e).createElementNS(sn, "feComponentTransfer");
  r.append(a), b(this, $, kh).call(this, a, "feFuncR", e), b(this, $, kh).call(this, a, "feFuncG", i), b(this, $, kh).call(this, a, "feFuncB", s);
}, lp = function(e, i) {
  const s = n(this, $e).createElementNS(sn, "feComponentTransfer");
  i.append(s), b(this, $, kh).call(this, s, "feFuncA", e);
}, Mh = function(e) {
  return n(this, $, xo).style.color = e, gh(getComputedStyle(n(this, $, xo)).getPropertyValue("color"));
};
class yb {
  constructor({
    baseUrl: t = null
  }) {
    this.baseUrl = t;
  }
  async fetch({
    filename: t
  }) {
    if (!this.baseUrl)
      throw new Error("Ensure that the `standardFontDataUrl` API parameter is provided.");
    if (!t)
      throw new Error("Font filename must be specified.");
    const e = `${this.baseUrl}${t}`;
    return this._fetch(e).catch((i) => {
      throw new Error(`Unable to load font data at: ${e}`);
    });
  }
  async _fetch(t) {
    Dt("Abstract method `_fetch` called.");
  }
}
class Gg extends yb {
  async _fetch(t) {
    const e = await ph(t, "arraybuffer");
    return new Uint8Array(e);
  }
}
class Ab {
  constructor({
    baseUrl: t = null
  }) {
    this.baseUrl = t;
  }
  async fetch({
    filename: t
  }) {
    if (!this.baseUrl)
      throw new Error("Ensure that the `wasmUrl` API parameter is provided.");
    if (!t)
      throw new Error("Wasm filename must be specified.");
    const e = `${this.baseUrl}${t}`;
    return this._fetch(e).catch((i) => {
      throw new Error(`Unable to load wasm data at: ${e}`);
    });
  }
  async _fetch(t) {
    Dt("Abstract method `_fetch` called.");
  }
}
class Wg extends Ab {
  async _fetch(t) {
    const e = await ph(t, "arraybuffer");
    return new Uint8Array(e);
  }
}
ii && J("Please use the `legacy` build in Node.js environments.");
async function yg(d) {
  const e = await process.getBuiltinModule("fs").promises.readFile(d);
  return new Uint8Array(e);
}
class ky extends mb {
}
class Ry extends pb {
  _createCanvas(t, e) {
    return process.getBuiltinModule("module").createRequire(import.meta.url)("@napi-rs/canvas").createCanvas(t, e);
  }
}
class My extends gb {
  async _fetch(t) {
    return yg(t);
  }
}
class Dy extends yb {
  async _fetch(t) {
    return yg(t);
  }
}
class Iy extends Ab {
  async _fetch(t) {
    return yg(t);
  }
}
const Eo = "__forcedDependency", {
  floor: jg,
  ceil: qg
} = Math;
function Kd(d, t, e, i, s, r) {
  d[t * 4 + 0] = Math.min(d[t * 4 + 0], e), d[t * 4 + 1] = Math.min(d[t * 4 + 1], i), d[t * 4 + 2] = Math.max(d[t * 4 + 2], s), d[t * 4 + 3] = Math.max(d[t * 4 + 3], r);
}
const hp = new Uint32Array(new Uint8Array([255, 255, 0, 0]).buffer)[0];
var ll, gr;
class Fy {
  constructor(t, e) {
    g(this, ll);
    g(this, gr);
    p(this, ll, t), p(this, gr, e);
  }
  get length() {
    return n(this, ll).length;
  }
  isEmpty(t) {
    return n(this, ll)[t] === hp;
  }
  minX(t) {
    return n(this, gr)[t * 4 + 0] / 256;
  }
  minY(t) {
    return n(this, gr)[t * 4 + 1] / 256;
  }
  maxX(t) {
    return (n(this, gr)[t * 4 + 2] + 1) / 256;
  }
  maxY(t) {
    return (n(this, gr)[t * 4 + 3] + 1) / 256;
  }
}
ll = new WeakMap(), gr = new WeakMap();
const Zd = (d, t) => {
  if (!d)
    return;
  let e = d.get(t);
  return e || (e = {
    dependencies: /* @__PURE__ */ new Set(),
    isRenderingOperation: !1
  }, d.set(t, e)), e;
};
var ci, di, Ta, fs, Pa, En, wt, St, Sn, ui, Pc, hl, La, ka, _n, Ve, Bs, Lc, cp;
class Ny {
  constructor(t, e, i = !1) {
    g(this, Lc);
    g(this, ci, {
      __proto__: null
    });
    g(this, di, {
      __proto__: null,
      transform: [],
      moveText: [],
      sameLineText: [],
      [Eo]: []
    });
    g(this, Ta, /* @__PURE__ */ new Map());
    g(this, fs, []);
    g(this, Pa, []);
    g(this, En, [[1, 0, 0, 1, 0, 0]]);
    g(this, wt, [-1 / 0, -1 / 0, 1 / 0, 1 / 0]);
    g(this, St, new Float64Array([1 / 0, 1 / 0, -1 / 0, -1 / 0]));
    g(this, Sn, -1);
    g(this, ui, /* @__PURE__ */ new Set());
    g(this, Pc, /* @__PURE__ */ new Map());
    g(this, hl, /* @__PURE__ */ new Map());
    g(this, La);
    g(this, ka);
    g(this, _n);
    g(this, Ve);
    g(this, Bs);
    p(this, La, t.width), p(this, ka, t.height), b(this, Lc, cp).call(this, e), i && p(this, Bs, /* @__PURE__ */ new Map());
  }
  growOperationsCount(t) {
    t >= n(this, Ve).length && b(this, Lc, cp).call(this, t, n(this, Ve));
  }
  save(t) {
    return p(this, ci, {
      __proto__: n(this, ci)
    }), p(this, di, {
      __proto__: n(this, di),
      transform: {
        __proto__: n(this, di).transform
      },
      moveText: {
        __proto__: n(this, di).moveText
      },
      sameLineText: {
        __proto__: n(this, di).sameLineText
      },
      [Eo]: {
        __proto__: n(this, di)[Eo]
      }
    }), p(this, wt, {
      __proto__: n(this, wt)
    }), n(this, fs).push(t), this;
  }
  restore(t) {
    var s;
    const e = Object.getPrototypeOf(n(this, ci));
    if (e === null)
      return this;
    p(this, ci, e), p(this, di, Object.getPrototypeOf(n(this, di))), p(this, wt, Object.getPrototypeOf(n(this, wt)));
    const i = n(this, fs).pop();
    return i !== void 0 && ((s = Zd(n(this, Bs), t)) == null || s.dependencies.add(i), n(this, Ve)[t] = n(this, Ve)[i]), this;
  }
  recordOpenMarker(t) {
    return n(this, fs).push(t), this;
  }
  getOpenMarker() {
    return n(this, fs).length === 0 ? null : n(this, fs).at(-1);
  }
  recordCloseMarker(t) {
    var i;
    const e = n(this, fs).pop();
    return e !== void 0 && ((i = Zd(n(this, Bs), t)) == null || i.dependencies.add(e), n(this, Ve)[t] = n(this, Ve)[e]), this;
  }
  beginMarkedContent(t) {
    return n(this, Pa).push(t), this;
  }
  endMarkedContent(t) {
    var i;
    const e = n(this, Pa).pop();
    return e !== void 0 && ((i = Zd(n(this, Bs), t)) == null || i.dependencies.add(e), n(this, Ve)[t] = n(this, Ve)[e]), this;
  }
  pushBaseTransform(t) {
    return n(this, En).push(z.multiplyByDOMMatrix(n(this, En).at(-1), t.getTransform())), this;
  }
  popBaseTransform() {
    return n(this, En).length > 1 && n(this, En).pop(), this;
  }
  recordSimpleData(t, e) {
    return n(this, ci)[t] = e, this;
  }
  recordIncrementalData(t, e) {
    return n(this, di)[t].push(e), this;
  }
  resetIncrementalData(t, e) {
    return n(this, di)[t].length = 0, this;
  }
  recordNamedData(t, e) {
    return n(this, Ta).set(t, e), this;
  }
  recordSimpleDataFromNamed(t, e, i) {
    n(this, ci)[t] = n(this, Ta).get(e) ?? i;
  }
  recordFutureForcedDependency(t, e) {
    return this.recordIncrementalData(Eo, e), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    for (const e of t)
      e in n(this, ci) && this.recordFutureForcedDependency(e, n(this, ci)[e]);
    return this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    for (const t of n(this, ui))
      this.recordFutureForcedDependency(Eo, t);
    return this;
  }
  resetBBox(t) {
    return n(this, Sn) !== t && (p(this, Sn, t), n(this, St)[0] = 1 / 0, n(this, St)[1] = 1 / 0, n(this, St)[2] = -1 / 0, n(this, St)[3] = -1 / 0), this;
  }
  recordClipBox(t, e, i, s, r, a) {
    const o = z.multiplyByDOMMatrix(n(this, En).at(-1), e.getTransform()), l = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
    z.axialAlignedBoundingBox([i, r, s, a], o, l);
    const h = z.intersect(n(this, wt), l);
    return h ? (n(this, wt)[0] = h[0], n(this, wt)[1] = h[1], n(this, wt)[2] = h[2], n(this, wt)[3] = h[3]) : (n(this, wt)[0] = n(this, wt)[1] = 1 / 0, n(this, wt)[2] = n(this, wt)[3] = -1 / 0), this;
  }
  recordBBox(t, e, i, s, r, a) {
    const o = n(this, wt);
    if (o[0] === 1 / 0)
      return this;
    const l = z.multiplyByDOMMatrix(n(this, En).at(-1), e.getTransform());
    if (o[0] === -1 / 0)
      return z.axialAlignedBoundingBox([i, r, s, a], l, n(this, St)), this;
    const h = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
    return z.axialAlignedBoundingBox([i, r, s, a], l, h), n(this, St)[0] = Math.min(n(this, St)[0], Math.max(h[0], o[0])), n(this, St)[1] = Math.min(n(this, St)[1], Math.max(h[1], o[1])), n(this, St)[2] = Math.max(n(this, St)[2], Math.min(h[2], o[2])), n(this, St)[3] = Math.max(n(this, St)[3], Math.min(h[3], o[3])), this;
  }
  recordCharacterBBox(t, e, i, s = 1, r = 0, a = 0, o) {
    const l = i.bbox;
    let h, c;
    if (l && (h = l[2] !== l[0] && l[3] !== l[1] && n(this, hl).get(i), h !== !1 && (c = [0, 0, 0, 0], z.axialAlignedBoundingBox(l, i.fontMatrix, c), (s !== 1 || r !== 0 || a !== 0) && z.scaleMinMax([s, 0, 0, -s, r, a], c), h)))
      return this.recordBBox(t, e, c[0], c[2], c[1], c[3]);
    if (!o)
      return this.recordFullPageBBox(t);
    const u = o();
    return l && c && h === void 0 && (h = c[0] <= r - u.actualBoundingBoxLeft && c[2] >= r + u.actualBoundingBoxRight && c[1] <= a - u.actualBoundingBoxAscent && c[3] >= a + u.actualBoundingBoxDescent, n(this, hl).set(i, h), h) ? this.recordBBox(t, e, c[0], c[2], c[1], c[3]) : this.recordBBox(t, e, r - u.actualBoundingBoxLeft, r + u.actualBoundingBoxRight, a - u.actualBoundingBoxAscent, a + u.actualBoundingBoxDescent);
  }
  recordFullPageBBox(t) {
    return n(this, St)[0] = Math.max(0, n(this, wt)[0]), n(this, St)[1] = Math.max(0, n(this, wt)[1]), n(this, St)[2] = Math.min(n(this, La), n(this, wt)[2]), n(this, St)[3] = Math.min(n(this, ka), n(this, wt)[3]), this;
  }
  getSimpleIndex(t) {
    return n(this, ci)[t];
  }
  recordDependencies(t, e) {
    const i = n(this, ui), s = n(this, ci), r = n(this, di);
    for (const a of e)
      a in n(this, ci) ? i.add(s[a]) : a in r && r[a].forEach(i.add, i);
    return this;
  }
  recordNamedDependency(t, e) {
    return n(this, Ta).has(e) && n(this, ui).add(n(this, Ta).get(e)), this;
  }
  recordOperation(t, e = !1) {
    if (this.recordDependencies(t, [Eo]), n(this, Bs)) {
      const i = Zd(n(this, Bs), t), {
        dependencies: s
      } = i;
      n(this, ui).forEach(s.add, s), n(this, fs).forEach(s.add, s), n(this, Pa).forEach(s.add, s), s.delete(t), i.isRenderingOperation = !0;
    }
    if (n(this, Sn) === t) {
      const i = jg(n(this, St)[0] * 256 / n(this, La)), s = jg(n(this, St)[1] * 256 / n(this, ka)), r = qg(n(this, St)[2] * 256 / n(this, La)), a = qg(n(this, St)[3] * 256 / n(this, ka));
      Kd(n(this, _n), t, i, s, r, a);
      for (const o of n(this, ui))
        o !== t && Kd(n(this, _n), o, i, s, r, a);
      for (const o of n(this, fs))
        o !== t && Kd(n(this, _n), o, i, s, r, a);
      for (const o of n(this, Pa))
        o !== t && Kd(n(this, _n), o, i, s, r, a);
      e || (n(this, ui).clear(), p(this, Sn, -1));
    }
    return this;
  }
  recordShowTextOperation(t, e = !1) {
    const i = Array.from(n(this, ui));
    this.recordOperation(t, e), this.recordIncrementalData("sameLineText", t);
    for (const s of i)
      this.recordIncrementalData("sameLineText", s);
    return this;
  }
  bboxToClipBoxDropOperation(t, e = !1) {
    return n(this, Sn) === t && (p(this, Sn, -1), n(this, wt)[0] = Math.max(n(this, wt)[0], n(this, St)[0]), n(this, wt)[1] = Math.max(n(this, wt)[1], n(this, St)[1]), n(this, wt)[2] = Math.min(n(this, wt)[2], n(this, St)[2]), n(this, wt)[3] = Math.min(n(this, wt)[3], n(this, St)[3]), e || n(this, ui).clear()), this;
  }
  _takePendingDependencies() {
    const t = n(this, ui);
    return p(this, ui, /* @__PURE__ */ new Set()), t;
  }
  _extractOperation(t) {
    const e = n(this, Pc).get(t);
    return n(this, Pc).delete(t), e;
  }
  _pushPendingDependencies(t) {
    for (const e of t)
      n(this, ui).add(e);
  }
  take() {
    return n(this, hl).clear(), new Fy(n(this, Ve), n(this, _n));
  }
  takeDebugMetadata() {
    return n(this, Bs);
  }
}
ci = new WeakMap(), di = new WeakMap(), Ta = new WeakMap(), fs = new WeakMap(), Pa = new WeakMap(), En = new WeakMap(), wt = new WeakMap(), St = new WeakMap(), Sn = new WeakMap(), ui = new WeakMap(), Pc = new WeakMap(), hl = new WeakMap(), La = new WeakMap(), ka = new WeakMap(), _n = new WeakMap(), Ve = new WeakMap(), Bs = new WeakMap(), Lc = new WeakSet(), cp = function(t, e) {
  const i = new ArrayBuffer(t * 4);
  p(this, _n, new Uint8ClampedArray(i)), p(this, Ve, new Uint32Array(i)), e && e.length > 0 ? (n(this, Ve).set(e), n(this, Ve).fill(hp, e.length)) : n(this, Ve).fill(hp);
};
var kt, Xt, ps, cl, dl;
const Lg = class Lg {
  constructor(t, e, i) {
    g(this, kt);
    g(this, Xt);
    g(this, ps);
    g(this, cl, 0);
    g(this, dl, 0);
    if (t instanceof Lg && n(t, ps) === !!i)
      return t;
    p(this, kt, t), p(this, Xt, e), p(this, ps, !!i);
  }
  growOperationsCount() {
    throw new Error("Unreachable");
  }
  save(t) {
    return oe(this, dl)._++, n(this, kt).save(n(this, Xt)), this;
  }
  restore(t) {
    return n(this, dl) > 0 && (n(this, kt).restore(n(this, Xt)), oe(this, dl)._--), this;
  }
  recordOpenMarker(t) {
    return oe(this, cl)._++, this;
  }
  getOpenMarker() {
    return n(this, cl) > 0 ? n(this, Xt) : n(this, kt).getOpenMarker();
  }
  recordCloseMarker(t) {
    return oe(this, cl)._--, this;
  }
  beginMarkedContent(t) {
    return this;
  }
  endMarkedContent(t) {
    return this;
  }
  pushBaseTransform(t) {
    return n(this, kt).pushBaseTransform(t), this;
  }
  popBaseTransform() {
    return n(this, kt).popBaseTransform(), this;
  }
  recordSimpleData(t, e) {
    return n(this, kt).recordSimpleData(t, n(this, Xt)), this;
  }
  recordIncrementalData(t, e) {
    return n(this, kt).recordIncrementalData(t, n(this, Xt)), this;
  }
  resetIncrementalData(t, e) {
    return n(this, kt).resetIncrementalData(t, n(this, Xt)), this;
  }
  recordNamedData(t, e) {
    return this;
  }
  recordSimpleDataFromNamed(t, e, i) {
    return n(this, kt).recordSimpleDataFromNamed(t, e, n(this, Xt)), this;
  }
  recordFutureForcedDependency(t, e) {
    return n(this, kt).recordFutureForcedDependency(t, n(this, Xt)), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    return n(this, kt).inheritSimpleDataAsFutureForcedDependencies(t), this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    return n(this, kt).inheritPendingDependenciesAsFutureForcedDependencies(), this;
  }
  resetBBox(t) {
    return n(this, ps) || n(this, kt).resetBBox(n(this, Xt)), this;
  }
  recordClipBox(t, e, i, s, r, a) {
    return n(this, ps) || n(this, kt).recordClipBox(n(this, Xt), e, i, s, r, a), this;
  }
  recordBBox(t, e, i, s, r, a) {
    return n(this, ps) || n(this, kt).recordBBox(n(this, Xt), e, i, s, r, a), this;
  }
  recordCharacterBBox(t, e, i, s, r, a, o) {
    return n(this, ps) || n(this, kt).recordCharacterBBox(n(this, Xt), e, i, s, r, a, o), this;
  }
  recordFullPageBBox(t) {
    return n(this, ps) || n(this, kt).recordFullPageBBox(n(this, Xt)), this;
  }
  getSimpleIndex(t) {
    return n(this, kt).getSimpleIndex(t);
  }
  recordDependencies(t, e) {
    return n(this, kt).recordDependencies(n(this, Xt), e), this;
  }
  recordNamedDependency(t, e) {
    return n(this, kt).recordNamedDependency(n(this, Xt), e), this;
  }
  recordOperation(t) {
    return n(this, kt).recordOperation(n(this, Xt), !0), this;
  }
  recordShowTextOperation(t) {
    return n(this, kt).recordShowTextOperation(n(this, Xt), !0), this;
  }
  bboxToClipBoxDropOperation(t) {
    return n(this, ps) || n(this, kt).bboxToClipBoxDropOperation(n(this, Xt), !0), this;
  }
  take() {
    throw new Error("Unreachable");
  }
  takeDebugMetadata() {
    throw new Error("Unreachable");
  }
};
kt = new WeakMap(), Xt = new WeakMap(), ps = new WeakMap(), cl = new WeakMap(), dl = new WeakMap();
let Ou = Lg;
const Wi = {
  stroke: ["path", "transform", "filter", "strokeColor", "strokeAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "dash"],
  fill: ["path", "transform", "filter", "fillColor", "fillAlpha", "globalCompositeOperation", "SMask"],
  imageXObject: ["transform", "SMask", "filter", "fillAlpha", "strokeAlpha", "globalCompositeOperation"],
  rawFillPath: ["filter", "fillColor", "fillAlpha"],
  showText: ["transform", "leading", "charSpacing", "wordSpacing", "hScale", "textRise", "moveText", "textMatrix", "font", "fontObj", "filter", "fillColor", "textRenderingMode", "SMask", "fillAlpha", "strokeAlpha", "globalCompositeOperation", "sameLineText"],
  transform: ["transform"],
  transformAndFill: ["transform", "fillColor"]
}, De = {
  FILL: "Fill",
  STROKE: "Stroke",
  SHADING: "Shading"
};
function dp(d, t) {
  if (!t)
    return;
  const e = t[2] - t[0], i = t[3] - t[1], s = new Path2D();
  s.rect(t[0], t[1], e, i), d.clip(s);
}
class Ag {
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern() {
    Dt("Abstract method `getPattern` called.");
  }
}
class Oy extends Ag {
  constructor(t) {
    super(), this._type = t[1], this._bbox = t[2], this._colorStops = t[3], this._p0 = t[4], this._p1 = t[5], this._r0 = t[6], this._r1 = t[7], this.matrix = null;
  }
  _createGradient(t) {
    let e;
    this._type === "axial" ? e = t.createLinearGradient(this._p0[0], this._p0[1], this._p1[0], this._p1[1]) : this._type === "radial" && (e = t.createRadialGradient(this._p0[0], this._p0[1], this._r0, this._p1[0], this._p1[1], this._r1));
    for (const i of this._colorStops)
      e.addColorStop(i[0], i[1]);
    return e;
  }
  getPattern(t, e, i, s) {
    let r;
    if (s === De.STROKE || s === De.FILL) {
      const a = e.current.getClippedPathBoundingBox(s, Vt(t)) || [0, 0, 0, 0], o = Math.ceil(a[2] - a[0]) || 1, l = Math.ceil(a[3] - a[1]) || 1, h = e.cachedCanvases.getCanvas("pattern", o, l), c = h.context;
      c.clearRect(0, 0, c.canvas.width, c.canvas.height), c.beginPath(), c.rect(0, 0, c.canvas.width, c.canvas.height), c.translate(-a[0], -a[1]), i = z.transform(i, [1, 0, 0, 1, a[0], a[1]]), c.transform(...e.baseTransform), this.matrix && c.transform(...this.matrix), dp(c, this._bbox), c.fillStyle = this._createGradient(c), c.fill(), r = t.createPattern(h.canvas, "no-repeat");
      const u = new DOMMatrix(i);
      r.setTransform(u);
    } else
      dp(t, this._bbox), r = this._createGradient(t);
    return r;
  }
}
function Rf(d, t, e, i, s, r, a, o) {
  const l = t.coords, h = t.colors, c = d.data, u = d.width * 4;
  let f;
  l[e + 1] > l[i + 1] && (f = e, e = i, i = f, f = r, r = a, a = f), l[i + 1] > l[s + 1] && (f = i, i = s, s = f, f = a, a = o, o = f), l[e + 1] > l[i + 1] && (f = e, e = i, i = f, f = r, r = a, a = f);
  const m = (l[e] + t.offsetX) * t.scaleX, A = (l[e + 1] + t.offsetY) * t.scaleY, y = (l[i] + t.offsetX) * t.scaleX, v = (l[i + 1] + t.offsetY) * t.scaleY, w = (l[s] + t.offsetX) * t.scaleX, S = (l[s + 1] + t.offsetY) * t.scaleY;
  if (A >= S)
    return;
  const E = h[r], _ = h[r + 1], x = h[r + 2], C = h[a], T = h[a + 1], L = h[a + 2], k = h[o], D = h[o + 1], R = h[o + 2], N = Math.round(A), q = Math.round(S);
  let B, Y, O, H, it, at, Jt, Xe;
  for (let lt = N; lt <= q; lt++) {
    if (lt < v) {
      const ct = lt < A ? 0 : (A - lt) / (A - v);
      B = m - (m - y) * ct, Y = E - (E - C) * ct, O = _ - (_ - T) * ct, H = x - (x - L) * ct;
    } else {
      let ct;
      lt > S ? ct = 1 : v === S ? ct = 0 : ct = (v - lt) / (v - S), B = y - (y - w) * ct, Y = C - (C - k) * ct, O = T - (T - D) * ct, H = L - (L - R) * ct;
    }
    let tt;
    lt < A ? tt = 0 : lt > S ? tt = 1 : tt = (A - lt) / (A - S), it = m - (m - w) * tt, at = E - (E - k) * tt, Jt = _ - (_ - D) * tt, Xe = x - (x - R) * tt;
    const vt = Math.round(Math.min(B, it)), se = Math.round(Math.max(B, it));
    let fe = u * lt + vt * 4;
    for (let ct = vt; ct <= se; ct++)
      tt = (B - ct) / (B - it), tt < 0 ? tt = 0 : tt > 1 && (tt = 1), c[fe++] = Y - (Y - at) * tt | 0, c[fe++] = O - (O - Jt) * tt | 0, c[fe++] = H - (H - Xe) * tt | 0, c[fe++] = 255;
  }
}
function By(d, t, e) {
  const i = t.coords, s = t.colors;
  let r, a;
  switch (t.type) {
    case "lattice":
      const o = t.verticesPerRow, l = Math.floor(i.length / o) - 1, h = o - 1;
      for (r = 0; r < l; r++) {
        let c = r * o;
        for (let u = 0; u < h; u++, c++)
          Rf(d, e, i[c], i[c + 1], i[c + o], s[c], s[c + 1], s[c + o]), Rf(d, e, i[c + o + 1], i[c + 1], i[c + o], s[c + o + 1], s[c + 1], s[c + o]);
      }
      break;
    case "triangles":
      for (r = 0, a = i.length; r < a; r += 3)
        Rf(d, e, i[r], i[r + 1], i[r + 2], s[r], s[r + 1], s[r + 2]);
      break;
    default:
      throw new Error("illegal figure");
  }
}
class Hy extends Ag {
  constructor(t) {
    super(), this._coords = t[2], this._colors = t[3], this._figures = t[4], this._bounds = t[5], this._bbox = t[6], this._background = t[7], this.matrix = null;
  }
  _createMeshCanvas(t, e, i) {
    const o = Math.floor(this._bounds[0]), l = Math.floor(this._bounds[1]), h = Math.ceil(this._bounds[2]) - o, c = Math.ceil(this._bounds[3]) - l, u = Math.min(Math.ceil(Math.abs(h * t[0] * 1.1)), 3e3), f = Math.min(Math.ceil(Math.abs(c * t[1] * 1.1)), 3e3), m = h / u, A = c / f, y = {
      coords: this._coords,
      colors: this._colors,
      offsetX: -o,
      offsetY: -l,
      scaleX: 1 / m,
      scaleY: 1 / A
    }, v = u + 4, w = f + 4, S = i.getCanvas("mesh", v, w), E = S.context, _ = E.createImageData(u, f);
    if (e) {
      const C = _.data;
      for (let T = 0, L = C.length; T < L; T += 4)
        C[T] = e[0], C[T + 1] = e[1], C[T + 2] = e[2], C[T + 3] = 255;
    }
    for (const C of this._figures)
      By(_, C, y);
    return E.putImageData(_, 2, 2), {
      canvas: S.canvas,
      offsetX: o - 2 * m,
      offsetY: l - 2 * A,
      scaleX: m,
      scaleY: A
    };
  }
  isModifyingCurrentTransform() {
    return !0;
  }
  getPattern(t, e, i, s) {
    dp(t, this._bbox);
    const r = new Float32Array(2);
    if (s === De.SHADING)
      z.singularValueDecompose2dScale(Vt(t), r);
    else if (this.matrix) {
      z.singularValueDecompose2dScale(this.matrix, r);
      const [o, l] = r;
      z.singularValueDecompose2dScale(e.baseTransform, r), r[0] *= o, r[1] *= l;
    } else
      z.singularValueDecompose2dScale(e.baseTransform, r);
    const a = this._createMeshCanvas(r, s === De.SHADING ? null : this._background, e.cachedCanvases);
    return s !== De.SHADING && (t.setTransform(...e.baseTransform), this.matrix && t.transform(...this.matrix)), t.translate(a.offsetX, a.offsetY), t.scale(a.scaleX, a.scaleY), t.createPattern(a.canvas, "no-repeat");
  }
}
class Uy extends Ag {
  getPattern() {
    return "hotpink";
  }
}
function $y(d) {
  switch (d[0]) {
    case "RadialAxial":
      return new Oy(d);
    case "Mesh":
      return new Hy(d);
    case "Dummy":
      return new Uy();
  }
  throw new Error(`Unknown IR type: ${d[0]}`);
}
const Xg = {
  COLORED: 1,
  UNCOLORED: 2
}, tf = class tf {
  constructor(t, e, i, s) {
    this.color = t[1], this.operatorList = t[2], this.matrix = t[3], this.bbox = t[4], this.xstep = t[5], this.ystep = t[6], this.paintType = t[7], this.tilingType = t[8], this.ctx = e, this.canvasGraphicsFactory = i, this.baseTransform = s;
  }
  createPatternCanvas(t, e) {
    var at, Jt;
    const {
      bbox: i,
      operatorList: s,
      paintType: r,
      tilingType: a,
      color: o,
      canvasGraphicsFactory: l
    } = this;
    let {
      xstep: h,
      ystep: c
    } = this;
    h = Math.abs(h), c = Math.abs(c), ff("TilingType: " + a);
    const u = i[0], f = i[1], m = i[2], A = i[3], y = m - u, v = A - f, w = new Float32Array(2);
    z.singularValueDecompose2dScale(this.matrix, w);
    const [S, E] = w;
    z.singularValueDecompose2dScale(this.baseTransform, w);
    const _ = S * w[0], x = E * w[1];
    let C = y, T = v, L = !1, k = !1;
    const D = Math.ceil(h * _), R = Math.ceil(c * x), N = Math.ceil(y * _), q = Math.ceil(v * x);
    D >= N ? C = h : L = !0, R >= q ? T = c : k = !0;
    const B = this.getSizeAndScale(C, this.ctx.canvas.width, _), Y = this.getSizeAndScale(T, this.ctx.canvas.height, x), O = t.cachedCanvases.getCanvas("pattern", B.size, Y.size), H = O.context, it = l.createCanvasGraphics(H, e);
    if (it.groupLevel = t.groupLevel, this.setFillAndStrokeStyleToContext(it, r, o), H.translate(-B.scale * u, -Y.scale * f), it.transform(0, B.scale, 0, 0, Y.scale, 0, 0), H.save(), (at = it.dependencyTracker) == null || at.save(), this.clipBbox(it, u, f, m, A), it.baseTransform = Vt(it.ctx), it.executeOperatorList(s), it.endDrawing(), (Jt = it.dependencyTracker) == null || Jt.restore(), H.restore(), L || k) {
      const Xe = O.canvas;
      L && (C = h), k && (T = c);
      const lt = this.getSizeAndScale(C, this.ctx.canvas.width, _), tt = this.getSizeAndScale(T, this.ctx.canvas.height, x), vt = lt.size, se = tt.size, fe = t.cachedCanvases.getCanvas("pattern-workaround", vt, se), ct = fe.context, bi = L ? Math.floor(y / h) : 0, Ye = k ? Math.floor(v / c) : 0;
      for (let Vi = 0; Vi <= bi; Vi++)
        for (let xe = 0; xe <= Ye; xe++)
          ct.drawImage(Xe, vt * Vi, se * xe, vt, se, 0, 0, vt, se);
      return {
        canvas: fe.canvas,
        scaleX: lt.scale,
        scaleY: tt.scale,
        offsetX: u,
        offsetY: f
      };
    }
    return {
      canvas: O.canvas,
      scaleX: B.scale,
      scaleY: Y.scale,
      offsetX: u,
      offsetY: f
    };
  }
  getSizeAndScale(t, e, i) {
    const s = Math.max(tf.MAX_PATTERN_SIZE, e);
    let r = Math.ceil(t * i);
    return r >= s ? r = s : i = r / t, {
      scale: i,
      size: r
    };
  }
  clipBbox(t, e, i, s, r) {
    const a = s - e, o = r - i;
    t.ctx.rect(e, i, a, o), z.axialAlignedBoundingBox([e, i, s, r], Vt(t.ctx), t.current.minMax), t.clip(), t.endPath();
  }
  setFillAndStrokeStyleToContext(t, e, i) {
    const s = t.ctx, r = t.current;
    switch (e) {
      case Xg.COLORED:
        const {
          fillStyle: a,
          strokeStyle: o
        } = this.ctx;
        s.fillStyle = r.fillColor = a, s.strokeStyle = r.strokeColor = o;
        break;
      case Xg.UNCOLORED:
        s.fillStyle = s.strokeStyle = i, r.fillColor = r.strokeColor = i;
        break;
      default:
        throw new ly(`Unsupported paint type: ${e}`);
    }
  }
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern(t, e, i, s, r) {
    let a = i;
    s !== De.SHADING && (a = z.transform(a, e.baseTransform), this.matrix && (a = z.transform(a, this.matrix)));
    const o = this.createPatternCanvas(e, r);
    let l = new DOMMatrix(a);
    l = l.translate(o.offsetX, o.offsetY), l = l.scale(1 / o.scaleX, 1 / o.scaleY);
    const h = t.createPattern(o.canvas, "repeat");
    return h.setTransform(l), h;
  }
};
M(tf, "MAX_PATTERN_SIZE", 3e3);
let up = tf;
function Vy({
  src: d,
  srcPos: t = 0,
  dest: e,
  width: i,
  height: s,
  nonBlackColor: r = 4294967295,
  inverseDecode: a = !1
}) {
  const o = _e.isLittleEndian ? 4278190080 : 255, [l, h] = a ? [r, o] : [o, r], c = i >> 3, u = i & 7, f = d.length;
  e = new Uint32Array(e.buffer);
  let m = 0;
  for (let A = 0; A < s; A++) {
    for (const v = t + c; t < v; t++) {
      const w = t < f ? d[t] : 255;
      e[m++] = w & 128 ? h : l, e[m++] = w & 64 ? h : l, e[m++] = w & 32 ? h : l, e[m++] = w & 16 ? h : l, e[m++] = w & 8 ? h : l, e[m++] = w & 4 ? h : l, e[m++] = w & 2 ? h : l, e[m++] = w & 1 ? h : l;
    }
    if (u === 0)
      continue;
    const y = t < f ? d[t++] : 255;
    for (let v = 0; v < u; v++)
      e[m++] = y & 1 << 7 - v ? h : l;
  }
  return {
    srcPos: t,
    destPos: m
  };
}
const Yg = 16, Kg = 100, zy = 15, Zg = 10, mi = 16, Mf = new DOMMatrix(), Bi = new Float32Array(2), Ro = new Float32Array([1 / 0, 1 / 0, -1 / 0, -1 / 0]);
function Gy(d, t) {
  if (d._removeMirroring)
    throw new Error("Context is already forwarding operations.");
  d.__originalSave = d.save, d.__originalRestore = d.restore, d.__originalRotate = d.rotate, d.__originalScale = d.scale, d.__originalTranslate = d.translate, d.__originalTransform = d.transform, d.__originalSetTransform = d.setTransform, d.__originalResetTransform = d.resetTransform, d.__originalClip = d.clip, d.__originalMoveTo = d.moveTo, d.__originalLineTo = d.lineTo, d.__originalBezierCurveTo = d.bezierCurveTo, d.__originalRect = d.rect, d.__originalClosePath = d.closePath, d.__originalBeginPath = d.beginPath, d._removeMirroring = () => {
    d.save = d.__originalSave, d.restore = d.__originalRestore, d.rotate = d.__originalRotate, d.scale = d.__originalScale, d.translate = d.__originalTranslate, d.transform = d.__originalTransform, d.setTransform = d.__originalSetTransform, d.resetTransform = d.__originalResetTransform, d.clip = d.__originalClip, d.moveTo = d.__originalMoveTo, d.lineTo = d.__originalLineTo, d.bezierCurveTo = d.__originalBezierCurveTo, d.rect = d.__originalRect, d.closePath = d.__originalClosePath, d.beginPath = d.__originalBeginPath, delete d._removeMirroring;
  }, d.save = function() {
    t.save(), this.__originalSave();
  }, d.restore = function() {
    t.restore(), this.__originalRestore();
  }, d.translate = function(e, i) {
    t.translate(e, i), this.__originalTranslate(e, i);
  }, d.scale = function(e, i) {
    t.scale(e, i), this.__originalScale(e, i);
  }, d.transform = function(e, i, s, r, a, o) {
    t.transform(e, i, s, r, a, o), this.__originalTransform(e, i, s, r, a, o);
  }, d.setTransform = function(e, i, s, r, a, o) {
    t.setTransform(e, i, s, r, a, o), this.__originalSetTransform(e, i, s, r, a, o);
  }, d.resetTransform = function() {
    t.resetTransform(), this.__originalResetTransform();
  }, d.rotate = function(e) {
    t.rotate(e), this.__originalRotate(e);
  }, d.clip = function(e) {
    t.clip(e), this.__originalClip(e);
  }, d.moveTo = function(e, i) {
    t.moveTo(e, i), this.__originalMoveTo(e, i);
  }, d.lineTo = function(e, i) {
    t.lineTo(e, i), this.__originalLineTo(e, i);
  }, d.bezierCurveTo = function(e, i, s, r, a, o) {
    t.bezierCurveTo(e, i, s, r, a, o), this.__originalBezierCurveTo(e, i, s, r, a, o);
  }, d.rect = function(e, i, s, r) {
    t.rect(e, i, s, r), this.__originalRect(e, i, s, r);
  }, d.closePath = function() {
    t.closePath(), this.__originalClosePath();
  }, d.beginPath = function() {
    t.beginPath(), this.__originalBeginPath();
  };
}
class Wy {
  constructor(t) {
    this.canvasFactory = t, this.cache = /* @__PURE__ */ Object.create(null);
  }
  getCanvas(t, e, i) {
    let s;
    return this.cache[t] !== void 0 ? (s = this.cache[t], this.canvasFactory.reset(s, e, i)) : (s = this.canvasFactory.create(e, i), this.cache[t] = s), s;
  }
  delete(t) {
    delete this.cache[t];
  }
  clear() {
    for (const t in this.cache) {
      const e = this.cache[t];
      this.canvasFactory.destroy(e), delete this.cache[t];
    }
  }
}
function Jd(d, t, e, i, s, r, a, o, l, h) {
  const [c, u, f, m, A, y] = Vt(d);
  if (u === 0 && f === 0) {
    const S = a * c + A, E = Math.round(S), _ = o * m + y, x = Math.round(_), C = (a + l) * c + A, T = Math.abs(Math.round(C) - E) || 1, L = (o + h) * m + y, k = Math.abs(Math.round(L) - x) || 1;
    return d.setTransform(Math.sign(c), 0, 0, Math.sign(m), E, x), d.drawImage(t, e, i, s, r, 0, 0, T, k), d.setTransform(c, u, f, m, A, y), [T, k];
  }
  if (c === 0 && m === 0) {
    const S = o * f + A, E = Math.round(S), _ = a * u + y, x = Math.round(_), C = (o + h) * f + A, T = Math.abs(Math.round(C) - E) || 1, L = (a + l) * u + y, k = Math.abs(Math.round(L) - x) || 1;
    return d.setTransform(0, Math.sign(u), Math.sign(f), 0, E, x), d.drawImage(t, e, i, s, r, 0, 0, k, T), d.setTransform(c, u, f, m, A, y), [k, T];
  }
  d.drawImage(t, e, i, s, r, a, o, l, h);
  const v = Math.hypot(c, u), w = Math.hypot(f, m);
  return [v * l, w * h];
}
class Jg {
  constructor(t, e, i) {
    M(this, "alphaIsShape", !1);
    M(this, "fontSize", 0);
    M(this, "fontSizeScale", 1);
    M(this, "textMatrix", null);
    M(this, "textMatrixScale", 1);
    M(this, "fontMatrix", Bf);
    M(this, "leading", 0);
    M(this, "x", 0);
    M(this, "y", 0);
    M(this, "lineX", 0);
    M(this, "lineY", 0);
    M(this, "charSpacing", 0);
    M(this, "wordSpacing", 0);
    M(this, "textHScale", 1);
    M(this, "textRenderingMode", Te.FILL);
    M(this, "textRise", 0);
    M(this, "fillColor", "#000000");
    M(this, "strokeColor", "#000000");
    M(this, "patternFill", !1);
    M(this, "patternStroke", !1);
    M(this, "fillAlpha", 1);
    M(this, "strokeAlpha", 1);
    M(this, "lineWidth", 1);
    M(this, "activeSMask", null);
    M(this, "transferMaps", "none");
    i == null || i(this), this.clipBox = new Float32Array([0, 0, t, e]), this.minMax = Ro.slice();
  }
  clone() {
    const t = Object.create(this);
    return t.clipBox = this.clipBox.slice(), t.minMax = this.minMax.slice(), t;
  }
  getPathBoundingBox(t = De.FILL, e = null) {
    const i = this.minMax.slice();
    if (t === De.STROKE) {
      e || Dt("Stroke bounding box must include transform."), z.singularValueDecompose2dScale(e, Bi);
      const s = Bi[0] * this.lineWidth / 2, r = Bi[1] * this.lineWidth / 2;
      i[0] -= s, i[1] -= r, i[2] += s, i[3] += r;
    }
    return i;
  }
  updateClipFromPath() {
    const t = z.intersect(this.clipBox, this.getPathBoundingBox());
    this.startNewPathAndClipBox(t || [0, 0, 0, 0]);
  }
  isEmptyClip() {
    return this.minMax[0] === 1 / 0;
  }
  startNewPathAndClipBox(t) {
    this.clipBox.set(t, 0), this.minMax.set(Ro, 0);
  }
  getClippedPathBoundingBox(t = De.FILL, e = null) {
    return z.intersect(this.clipBox, this.getPathBoundingBox(t, e));
  }
}
function Qg(d, t) {
  if (t instanceof ImageData) {
    d.putImageData(t, 0, 0);
    return;
  }
  const e = t.height, i = t.width, s = e % mi, r = (e - s) / mi, a = s === 0 ? r : r + 1, o = d.createImageData(i, mi);
  let l = 0, h;
  const c = t.data, u = o.data;
  let f, m, A, y;
  if (t.kind === zh.GRAYSCALE_1BPP) {
    const v = c.byteLength, w = new Uint32Array(u.buffer, 0, u.byteLength >> 2), S = w.length, E = i + 7 >> 3, _ = 4294967295, x = _e.isLittleEndian ? 4278190080 : 255;
    for (f = 0; f < a; f++) {
      for (A = f < r ? mi : s, h = 0, m = 0; m < A; m++) {
        const C = v - l;
        let T = 0;
        const L = C > E ? i : C * 8 - 7, k = L & -8;
        let D = 0, R = 0;
        for (; T < k; T += 8)
          R = c[l++], w[h++] = R & 128 ? _ : x, w[h++] = R & 64 ? _ : x, w[h++] = R & 32 ? _ : x, w[h++] = R & 16 ? _ : x, w[h++] = R & 8 ? _ : x, w[h++] = R & 4 ? _ : x, w[h++] = R & 2 ? _ : x, w[h++] = R & 1 ? _ : x;
        for (; T < L; T++)
          D === 0 && (R = c[l++], D = 128), w[h++] = R & D ? _ : x, D >>= 1;
      }
      for (; h < S; )
        w[h++] = 0;
      d.putImageData(o, 0, f * mi);
    }
  } else if (t.kind === zh.RGBA_32BPP) {
    for (m = 0, y = i * mi * 4, f = 0; f < r; f++)
      u.set(c.subarray(l, l + y)), l += y, d.putImageData(o, 0, m), m += mi;
    f < a && (y = i * s * 4, u.set(c.subarray(l, l + y)), d.putImageData(o, 0, m));
  } else if (t.kind === zh.RGB_24BPP)
    for (A = mi, y = i * A, f = 0; f < a; f++) {
      for (f >= r && (A = s, y = i * A), h = 0, m = y; m--; )
        u[h++] = c[l++], u[h++] = c[l++], u[h++] = c[l++], u[h++] = 255;
      d.putImageData(o, 0, f * mi);
    }
  else
    throw new Error(`bad image kind: ${t.kind}`);
}
function tm(d, t) {
  if (t.bitmap) {
    d.drawImage(t.bitmap, 0, 0);
    return;
  }
  const e = t.height, i = t.width, s = e % mi, r = (e - s) / mi, a = s === 0 ? r : r + 1, o = d.createImageData(i, mi);
  let l = 0;
  const h = t.data, c = o.data;
  for (let u = 0; u < a; u++) {
    const f = u < r ? mi : s;
    ({
      srcPos: l
    } = Vy({
      src: h,
      srcPos: l,
      dest: c,
      width: i,
      height: f,
      nonBlackColor: 0
    })), d.putImageData(o, 0, u * mi);
  }
}
function yh(d, t) {
  const e = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
  for (const i of e)
    d[i] !== void 0 && (t[i] = d[i]);
  d.setLineDash !== void 0 && (t.setLineDash(d.getLineDash()), t.lineDashOffset = d.lineDashOffset);
}
function Qd(d) {
  d.strokeStyle = d.fillStyle = "#000000", d.fillRule = "nonzero", d.globalAlpha = 1, d.lineWidth = 1, d.lineCap = "butt", d.lineJoin = "miter", d.miterLimit = 10, d.globalCompositeOperation = "source-over", d.font = "10px sans-serif", d.setLineDash !== void 0 && (d.setLineDash([]), d.lineDashOffset = 0);
  const {
    filter: t
  } = d;
  t !== "none" && t !== "" && (d.filter = "none");
}
function em(d, t) {
  if (t)
    return !0;
  z.singularValueDecompose2dScale(d, Bi);
  const e = Math.fround(Ss.pixelRatio * Wn.PDF_TO_CSS_UNITS);
  return Bi[0] <= e && Bi[1] <= e;
}
const jy = ["butt", "round", "square"], qy = ["miter", "round", "bevel"], Xy = {}, im = {};
var _s, fp, pp, gp;
const kg = class kg {
  constructor(t, e, i, s, r, {
    optionalContentConfig: a,
    markedContentStack: o = null
  }, l, h, c) {
    g(this, _s);
    this.ctx = t, this.current = new Jg(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.res = null, this.xobjs = null, this.commonObjs = e, this.objs = i, this.canvasFactory = s, this.filterFactory = r, this.groupStack = [], this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.smaskCounter = 0, this.tempSMask = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = o || [], this.optionalContentConfig = a, this.cachedCanvases = new Wy(this.canvasFactory), this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = l, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = h, this._cachedScaleForStroking = [-1, 0], this._cachedGetSinglePixelWidth = null, this._cachedBitmapsMap = /* @__PURE__ */ new Map(), this.dependencyTracker = c ?? null;
  }
  getObject(t, e, i = null) {
    var s;
    return typeof e == "string" ? ((s = this.dependencyTracker) == null || s.recordNamedDependency(t, e), e.startsWith("g_") ? this.commonObjs.get(e) : this.objs.get(e)) : i;
  }
  beginDrawing({
    transform: t,
    viewport: e,
    transparency: i = !1,
    background: s = null
  }) {
    const r = this.ctx.canvas.width, a = this.ctx.canvas.height, o = this.ctx.fillStyle;
    if (this.ctx.fillStyle = s || "#ffffff", this.ctx.fillRect(0, 0, r, a), this.ctx.fillStyle = o, i) {
      const l = this.cachedCanvases.getCanvas("transparent", r, a);
      this.compositeCtx = this.ctx, this.transparentCanvas = l.canvas, this.ctx = l.context, this.ctx.save(), this.ctx.transform(...Vt(this.compositeCtx));
    }
    this.ctx.save(), Qd(this.ctx), t && (this.ctx.transform(...t), this.outputScaleX = t[0], this.outputScaleY = t[0]), this.ctx.transform(...e.transform), this.viewportScale = e.scale, this.baseTransform = Vt(this.ctx);
  }
  executeOperatorList(t, e, i, s, r) {
    var w;
    const a = t.argsArray, o = t.fnArray;
    let l = e || 0;
    const h = a.length;
    if (h === l)
      return l;
    const c = h - l > Zg && typeof i == "function", u = c ? Date.now() + zy : 0;
    let f = 0;
    const m = this.commonObjs, A = this.objs;
    let y, v;
    for (; ; ) {
      if (s !== void 0 && l === s.nextBreakPoint)
        return s.breakIt(l, i), l;
      if (!r || r(l))
        if (y = o[l], v = a[l] ?? null, y !== dh.dependency)
          v === null ? this[y](l) : this[y](l, ...v);
        else
          for (const S of v) {
            (w = this.dependencyTracker) == null || w.recordNamedData(S, l);
            const E = S.startsWith("g_") ? m : A;
            if (!E.has(S))
              return E.get(S, i), l;
          }
      if (l++, l === h)
        return l;
      if (c && ++f > Zg) {
        if (Date.now() > u)
          return i(), l;
        f = 0;
      }
    }
  }
  endDrawing() {
    b(this, _s, fp).call(this), this.cachedCanvases.clear(), this.cachedPatterns.clear();
    for (const t of this._cachedBitmapsMap.values()) {
      for (const e of t.values())
        typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement && (e.width = e.height = 0);
      t.clear();
    }
    this._cachedBitmapsMap.clear(), b(this, _s, pp).call(this);
  }
  _scaleImage(t, e) {
    const i = t.width ?? t.displayWidth, s = t.height ?? t.displayHeight;
    let r = Math.max(Math.hypot(e[0], e[1]), 1), a = Math.max(Math.hypot(e[2], e[3]), 1), o = i, l = s, h = "prescale1", c, u;
    for (; r > 2 && o > 1 || a > 2 && l > 1; ) {
      let f = o, m = l;
      r > 2 && o > 1 && (f = o >= 16384 ? Math.floor(o / 2) - 1 || 1 : Math.ceil(o / 2), r /= o / f), a > 2 && l > 1 && (m = l >= 16384 ? Math.floor(l / 2) - 1 || 1 : Math.ceil(l) / 2, a /= l / m), c = this.cachedCanvases.getCanvas(h, f, m), u = c.context, u.clearRect(0, 0, f, m), u.drawImage(t, 0, 0, o, l, 0, 0, f, m), t = c.canvas, o = f, l = m, h = h === "prescale1" ? "prescale2" : "prescale1";
    }
    return {
      img: t,
      paintWidth: o,
      paintHeight: l
    };
  }
  _createMaskCanvas(t, e) {
    var D, R;
    const i = this.ctx, {
      width: s,
      height: r
    } = e, a = this.current.fillColor, o = this.current.patternFill, l = Vt(i);
    let h, c, u, f;
    if ((e.bitmap || e.data) && e.count > 1) {
      const N = e.bitmap || e.data.buffer;
      c = JSON.stringify(o ? l : [l.slice(0, 4), a]), h = this._cachedBitmapsMap.get(N), h || (h = /* @__PURE__ */ new Map(), this._cachedBitmapsMap.set(N, h));
      const q = h.get(c);
      if (q && !o) {
        const B = Math.round(Math.min(l[0], l[2]) + l[4]), Y = Math.round(Math.min(l[1], l[3]) + l[5]);
        return (D = this.dependencyTracker) == null || D.recordDependencies(t, Wi.transformAndFill), {
          canvas: q,
          offsetX: B,
          offsetY: Y
        };
      }
      u = q;
    }
    u || (f = this.cachedCanvases.getCanvas("maskCanvas", s, r), tm(f.context, e));
    let m = z.transform(l, [1 / s, 0, 0, -1 / r, 0, 0]);
    m = z.transform(m, [1, 0, 0, 1, 0, -r]);
    const A = Ro.slice();
    z.axialAlignedBoundingBox([0, 0, s, r], m, A);
    const [y, v, w, S] = A, E = Math.round(w - y) || 1, _ = Math.round(S - v) || 1, x = this.cachedCanvases.getCanvas("fillCanvas", E, _), C = x.context, T = y, L = v;
    C.translate(-T, -L), C.transform(...m), u || (u = this._scaleImage(f.canvas, xs(C)), u = u.img, h && o && h.set(c, u)), C.imageSmoothingEnabled = em(Vt(C), e.interpolate), Jd(C, u, 0, 0, u.width, u.height, 0, 0, s, r), C.globalCompositeOperation = "source-in";
    const k = z.transform(xs(C), [1, 0, 0, 1, -T, -L]);
    return C.fillStyle = o ? a.getPattern(i, this, k, De.FILL, t) : a, C.fillRect(0, 0, s, r), h && !o && (this.cachedCanvases.delete("fillCanvas"), h.set(c, x.canvas)), (R = this.dependencyTracker) == null || R.recordDependencies(t, Wi.transformAndFill), {
      canvas: x.canvas,
      offsetX: Math.round(T),
      offsetY: Math.round(L)
    };
  }
  setLineWidth(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("lineWidth", t), e !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = e, this.ctx.lineWidth = e;
  }
  setLineCap(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("lineCap", t), this.ctx.lineCap = jy[e];
  }
  setLineJoin(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("lineJoin", t), this.ctx.lineJoin = qy[e];
  }
  setMiterLimit(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("miterLimit", t), this.ctx.miterLimit = e;
  }
  setDash(t, e, i) {
    var r;
    (r = this.dependencyTracker) == null || r.recordSimpleData("dash", t);
    const s = this.ctx;
    s.setLineDash !== void 0 && (s.setLineDash(e), s.lineDashOffset = i);
  }
  setRenderingIntent(t, e) {
  }
  setFlatness(t, e) {
  }
  setGState(t, e) {
    var i, s, r, a, o;
    for (const [l, h] of e)
      switch (l) {
        case "LW":
          this.setLineWidth(t, h);
          break;
        case "LC":
          this.setLineCap(t, h);
          break;
        case "LJ":
          this.setLineJoin(t, h);
          break;
        case "ML":
          this.setMiterLimit(t, h);
          break;
        case "D":
          this.setDash(t, h[0], h[1]);
          break;
        case "RI":
          this.setRenderingIntent(t, h);
          break;
        case "FL":
          this.setFlatness(t, h);
          break;
        case "Font":
          this.setFont(t, h[0], h[1]);
          break;
        case "CA":
          (i = this.dependencyTracker) == null || i.recordSimpleData("strokeAlpha", t), this.current.strokeAlpha = h;
          break;
        case "ca":
          (s = this.dependencyTracker) == null || s.recordSimpleData("fillAlpha", t), this.ctx.globalAlpha = this.current.fillAlpha = h;
          break;
        case "BM":
          (r = this.dependencyTracker) == null || r.recordSimpleData("globalCompositeOperation", t), this.ctx.globalCompositeOperation = h;
          break;
        case "SMask":
          (a = this.dependencyTracker) == null || a.recordSimpleData("SMask", t), this.current.activeSMask = h ? this.tempSMask : null, this.tempSMask = null, this.checkSMaskState();
          break;
        case "TR":
          (o = this.dependencyTracker) == null || o.recordSimpleData("filter", t), this.ctx.filter = this.current.transferMaps = this.filterFactory.addFilter(h);
          break;
      }
  }
  get inSMaskMode() {
    return !!this.suspendedCtx;
  }
  checkSMaskState() {
    const t = this.inSMaskMode;
    this.current.activeSMask && !t ? this.beginSMaskMode() : !this.current.activeSMask && t && this.endSMaskMode();
  }
  beginSMaskMode(t) {
    if (this.inSMaskMode)
      throw new Error("beginSMaskMode called while already in smask mode");
    const e = this.ctx.canvas.width, i = this.ctx.canvas.height, s = "smaskGroupAt" + this.groupLevel, r = this.cachedCanvases.getCanvas(s, e, i);
    this.suspendedCtx = this.ctx;
    const a = this.ctx = r.context;
    a.setTransform(this.suspendedCtx.getTransform()), yh(this.suspendedCtx, a), Gy(a, this.suspendedCtx), this.setGState(t, [["BM", "source-over"]]);
  }
  endSMaskMode() {
    if (!this.inSMaskMode)
      throw new Error("endSMaskMode called while not in smask mode");
    this.ctx._removeMirroring(), yh(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null;
  }
  compose(t) {
    if (!this.current.activeSMask)
      return;
    t ? (t[0] = Math.floor(t[0]), t[1] = Math.floor(t[1]), t[2] = Math.ceil(t[2]), t[3] = Math.ceil(t[3])) : t = [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
    const e = this.current.activeSMask, i = this.suspendedCtx;
    this.composeSMask(i, e, this.ctx, t), this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore();
  }
  composeSMask(t, e, i, s) {
    const r = s[0], a = s[1], o = s[2] - r, l = s[3] - a;
    o === 0 || l === 0 || (this.genericComposeSMask(e.context, i, o, l, e.subtype, e.backdrop, e.transferMap, r, a, e.offsetX, e.offsetY), t.save(), t.globalAlpha = 1, t.globalCompositeOperation = "source-over", t.setTransform(1, 0, 0, 1, 0, 0), t.drawImage(i.canvas, 0, 0), t.restore());
  }
  genericComposeSMask(t, e, i, s, r, a, o, l, h, c, u) {
    let f = t.canvas, m = l - c, A = h - u;
    if (a)
      if (m < 0 || A < 0 || m + i > f.width || A + s > f.height) {
        const v = this.cachedCanvases.getCanvas("maskExtension", i, s), w = v.context;
        w.drawImage(f, -m, -A), w.globalCompositeOperation = "destination-atop", w.fillStyle = a, w.fillRect(0, 0, i, s), w.globalCompositeOperation = "source-over", f = v.canvas, m = A = 0;
      } else {
        t.save(), t.globalAlpha = 1, t.setTransform(1, 0, 0, 1, 0, 0);
        const v = new Path2D();
        v.rect(m, A, i, s), t.clip(v), t.globalCompositeOperation = "destination-atop", t.fillStyle = a, t.fillRect(m, A, i, s), t.restore();
      }
    e.save(), e.globalAlpha = 1, e.setTransform(1, 0, 0, 1, 0, 0), r === "Alpha" && o ? e.filter = this.filterFactory.addAlphaFilter(o) : r === "Luminosity" && (e.filter = this.filterFactory.addLuminosityFilter(o));
    const y = new Path2D();
    y.rect(l, h, i, s), e.clip(y), e.globalCompositeOperation = "destination-in", e.drawImage(f, m, A, i, s, l, h, i, s), e.restore();
  }
  save(t) {
    var i;
    this.inSMaskMode && yh(this.ctx, this.suspendedCtx), this.ctx.save();
    const e = this.current;
    this.stateStack.push(e), this.current = e.clone(), (i = this.dependencyTracker) == null || i.save(t);
  }
  restore(t) {
    var e;
    if ((e = this.dependencyTracker) == null || e.restore(t), this.stateStack.length === 0) {
      this.inSMaskMode && this.endSMaskMode();
      return;
    }
    this.current = this.stateStack.pop(), this.ctx.restore(), this.inSMaskMode && yh(this.suspendedCtx, this.ctx), this.checkSMaskState(), this.pendingClip = null, this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
  }
  transform(t, e, i, s, r, a, o) {
    var l;
    (l = this.dependencyTracker) == null || l.recordIncrementalData("transform", t), this.ctx.transform(e, i, s, r, a, o), this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
  }
  constructPath(t, e, i, s) {
    let [r] = i;
    if (!s) {
      r || (r = i[0] = new Path2D()), this[e](t, r);
      return;
    }
    if (this.dependencyTracker !== null) {
      const a = e === dh.stroke ? this.current.lineWidth / 2 : 0;
      this.dependencyTracker.resetBBox(t).recordBBox(t, this.ctx, s[0] - a, s[2] + a, s[1] - a, s[3] + a).recordDependencies(t, ["transform"]);
    }
    if (!(r instanceof Path2D)) {
      const a = i[0] = new Path2D();
      for (let o = 0, l = r.length; o < l; )
        switch (r[o++]) {
          case jd.moveTo:
            a.moveTo(r[o++], r[o++]);
            break;
          case jd.lineTo:
            a.lineTo(r[o++], r[o++]);
            break;
          case jd.curveTo:
            a.bezierCurveTo(r[o++], r[o++], r[o++], r[o++], r[o++], r[o++]);
            break;
          case jd.closePath:
            a.closePath();
            break;
          default:
            J(`Unrecognized drawing path operator: ${r[o - 1]}`);
            break;
        }
      r = a;
    }
    z.axialAlignedBoundingBox(s, Vt(this.ctx), this.current.minMax), this[e](t, r), this._pathStartIdx = t;
  }
  closePath(t) {
    this.ctx.closePath();
  }
  stroke(t, e, i = !0) {
    var a;
    const s = this.ctx, r = this.current.strokeColor;
    if (s.globalAlpha = this.current.strokeAlpha, this.contentVisible)
      if (typeof r == "object" && (r != null && r.getPattern)) {
        const o = r.isModifyingCurrentTransform() ? s.getTransform() : null;
        if (s.save(), s.strokeStyle = r.getPattern(s, this, xs(s), De.STROKE, t), o) {
          const l = new Path2D();
          l.addPath(e, s.getTransform().invertSelf().multiplySelf(o)), e = l;
        }
        this.rescaleAndStroke(e, !1), s.restore();
      } else
        this.rescaleAndStroke(e, !0);
    (a = this.dependencyTracker) == null || a.recordDependencies(t, Wi.stroke), i && this.consumePath(t, e, this.current.getClippedPathBoundingBox(De.STROKE, Vt(this.ctx))), s.globalAlpha = this.current.fillAlpha;
  }
  closeStroke(t, e) {
    this.stroke(t, e);
  }
  fill(t, e, i = !0) {
    var h, c, u;
    const s = this.ctx, r = this.current.fillColor, a = this.current.patternFill;
    let o = !1;
    if (a) {
      const f = r.isModifyingCurrentTransform() ? s.getTransform() : null;
      if ((h = this.dependencyTracker) == null || h.save(t), s.save(), s.fillStyle = r.getPattern(s, this, xs(s), De.FILL, t), f) {
        const m = new Path2D();
        m.addPath(e, s.getTransform().invertSelf().multiplySelf(f)), e = m;
      }
      o = !0;
    }
    const l = this.current.getClippedPathBoundingBox();
    this.contentVisible && l !== null && (this.pendingEOFill ? (s.fill(e, "evenodd"), this.pendingEOFill = !1) : s.fill(e)), (c = this.dependencyTracker) == null || c.recordDependencies(t, Wi.fill), o && (s.restore(), (u = this.dependencyTracker) == null || u.restore(t)), i && this.consumePath(t, e, l);
  }
  eoFill(t, e) {
    this.pendingEOFill = !0, this.fill(t, e);
  }
  fillStroke(t, e) {
    this.fill(t, e, !1), this.stroke(t, e, !1), this.consumePath(t, e);
  }
  eoFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  closeFillStroke(t, e) {
    this.fillStroke(t, e);
  }
  closeEOFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  endPath(t, e) {
    this.consumePath(t, e);
  }
  rawFillPath(t, e) {
    var i;
    this.ctx.fill(e), (i = this.dependencyTracker) == null || i.recordDependencies(t, Wi.rawFillPath).recordOperation(t);
  }
  clip(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordFutureForcedDependency("clipMode", t), this.pendingClip = Xy;
  }
  eoClip(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordFutureForcedDependency("clipMode", t), this.pendingClip = im;
  }
  beginText(t) {
    var e;
    this.current.textMatrix = null, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0, (e = this.dependencyTracker) == null || e.recordOpenMarker(t).resetIncrementalData("sameLineText").resetIncrementalData("moveText", t);
  }
  endText(t) {
    const e = this.pendingTextPaths, i = this.ctx;
    if (this.dependencyTracker) {
      const {
        dependencyTracker: s
      } = this;
      e !== void 0 && s.recordFutureForcedDependency("textClip", s.getOpenMarker()).recordFutureForcedDependency("textClip", t), s.recordCloseMarker(t);
    }
    if (e !== void 0) {
      const s = new Path2D(), r = i.getTransform().invertSelf();
      for (const {
        transform: a,
        x: o,
        y: l,
        fontSize: h,
        path: c
      } of e)
        c && s.addPath(c, new DOMMatrix(a).preMultiplySelf(r).translate(o, l).scale(h, -h));
      i.clip(s);
    }
    delete this.pendingTextPaths;
  }
  setCharSpacing(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("charSpacing", t), this.current.charSpacing = e;
  }
  setWordSpacing(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("wordSpacing", t), this.current.wordSpacing = e;
  }
  setHScale(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("hScale", t), this.current.textHScale = e / 100;
  }
  setLeading(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("leading", t), this.current.leading = -e;
  }
  setFont(t, e, i) {
    var u, f;
    (u = this.dependencyTracker) == null || u.recordSimpleData("font", t).recordSimpleDataFromNamed("fontObj", e, t);
    const s = this.commonObjs.get(e), r = this.current;
    if (!s)
      throw new Error(`Can't find font for ${e}`);
    if (r.fontMatrix = s.fontMatrix || Bf, (r.fontMatrix[0] === 0 || r.fontMatrix[3] === 0) && J("Invalid font matrix for font " + e), i < 0 ? (i = -i, r.fontDirection = -1) : r.fontDirection = 1, this.current.font = s, this.current.fontSize = i, s.isType3Font)
      return;
    const a = s.loadedName || "sans-serif", o = ((f = s.systemFontInfo) == null ? void 0 : f.css) || `"${a}", ${s.fallbackName}`;
    let l = "normal";
    s.black ? l = "900" : s.bold && (l = "bold");
    const h = s.italic ? "italic" : "normal";
    let c = i;
    i < Yg ? c = Yg : i > Kg && (c = Kg), this.current.fontSizeScale = i / c, this.ctx.font = `${h} ${l} ${c}px ${o}`;
  }
  setTextRenderingMode(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("textRenderingMode", t), this.current.textRenderingMode = e;
  }
  setTextRise(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("textRise", t), this.current.textRise = e;
  }
  moveText(t, e, i) {
    var s;
    (s = this.dependencyTracker) == null || s.resetIncrementalData("sameLineText").recordIncrementalData("moveText", t), this.current.x = this.current.lineX += e, this.current.y = this.current.lineY += i;
  }
  setLeadingMoveText(t, e, i) {
    this.setLeading(t, -i), this.moveText(t, e, i);
  }
  setTextMatrix(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("textMatrix", t);
    const {
      current: i
    } = this;
    i.textMatrix = e, i.textMatrixScale = Math.hypot(e[0], e[1]), i.x = i.lineX = 0, i.y = i.lineY = 0;
  }
  nextLine(t) {
    var e;
    this.moveText(t, 0, this.current.leading), (e = this.dependencyTracker) == null || e.recordIncrementalData("moveText", this.dependencyTracker.getSimpleIndex("leading") ?? t);
  }
  paintChar(t, e, i, s, r, a) {
    var w, S, E, _;
    const o = this.ctx, l = this.current, h = l.font, c = l.textRenderingMode, u = l.fontSize / l.fontSizeScale, f = c & Te.FILL_STROKE_MASK, m = !!(c & Te.ADD_TO_PATH_FLAG), A = l.patternFill && !h.missingFile, y = l.patternStroke && !h.missingFile;
    let v;
    if ((h.disableFontFace || m || A || y) && !h.missingFile && (v = h.getPathGenerator(this.commonObjs, e)), v && (h.disableFontFace || A || y)) {
      o.save(), o.translate(i, s), o.scale(u, -u), (w = this.dependencyTracker) == null || w.recordCharacterBBox(t, o, h);
      let x;
      if (f === Te.FILL || f === Te.FILL_STROKE)
        if (r) {
          x = o.getTransform(), o.setTransform(...r);
          const C = b(this, _s, gp).call(this, v, x, r);
          o.fill(C);
        } else
          o.fill(v);
      if (f === Te.STROKE || f === Te.FILL_STROKE)
        if (a) {
          x || (x = o.getTransform()), o.setTransform(...a);
          const {
            a: C,
            b: T,
            c: L,
            d: k
          } = x, D = z.inverseTransform(a), R = z.transform([C, T, L, k, 0, 0], D);
          z.singularValueDecompose2dScale(R, Bi), o.lineWidth *= Math.max(Bi[0], Bi[1]) / u, o.stroke(b(this, _s, gp).call(this, v, x, a));
        } else
          o.lineWidth /= u, o.stroke(v);
      o.restore();
    } else
      (f === Te.FILL || f === Te.FILL_STROKE) && (o.fillText(e, i, s), (S = this.dependencyTracker) == null || S.recordCharacterBBox(t, o, h, u, i, s, () => o.measureText(e))), (f === Te.STROKE || f === Te.FILL_STROKE) && (this.dependencyTracker && ((E = this.dependencyTracker) == null || E.recordCharacterBBox(t, o, h, u, i, s, () => o.measureText(e)).recordDependencies(t, Wi.stroke)), o.strokeText(e, i, s));
    m && ((this.pendingTextPaths || (this.pendingTextPaths = [])).push({
      transform: Vt(o),
      x: i,
      y: s,
      fontSize: u,
      path: v
    }), (_ = this.dependencyTracker) == null || _.recordCharacterBBox(t, o, h, u, i, s));
  }
  get isFontSubpixelAAEnabled() {
    const {
      context: t
    } = this.cachedCanvases.getCanvas("isFontSubpixelAAEnabled", 10, 10);
    t.scale(1.5, 1), t.fillText("I", 0, 10);
    const e = t.getImageData(0, 0, 10, 10).data;
    let i = !1;
    for (let s = 3; s < e.length; s += 4)
      if (e[s] > 0 && e[s] < 255) {
        i = !0;
        break;
      }
    return st(this, "isFontSubpixelAAEnabled", i);
  }
  showText(t, e) {
    var L, k, D, R;
    this.dependencyTracker && (this.dependencyTracker.recordDependencies(t, Wi.showText).resetBBox(t), this.current.textRenderingMode & Te.ADD_TO_PATH_FLAG && this.dependencyTracker.recordFutureForcedDependency("textClip", t).inheritPendingDependenciesAsFutureForcedDependencies());
    const i = this.current, s = i.font;
    if (s.isType3Font) {
      this.showType3Text(t, e), (L = this.dependencyTracker) == null || L.recordShowTextOperation(t);
      return;
    }
    const r = i.fontSize;
    if (r === 0) {
      (k = this.dependencyTracker) == null || k.recordOperation(t);
      return;
    }
    const a = this.ctx, o = i.fontSizeScale, l = i.charSpacing, h = i.wordSpacing, c = i.fontDirection, u = i.textHScale * c, f = e.length, m = s.vertical, A = m ? 1 : -1, y = s.defaultVMetrics, v = r * i.fontMatrix[0], w = i.textRenderingMode === Te.FILL && !s.disableFontFace && !i.patternFill;
    a.save(), i.textMatrix && a.transform(...i.textMatrix), a.translate(i.x, i.y + i.textRise), c > 0 ? a.scale(u, -1) : a.scale(u, 1);
    let S, E;
    if (i.patternFill) {
      a.save();
      const N = i.fillColor.getPattern(a, this, xs(a), De.FILL, t);
      S = Vt(a), a.restore(), a.fillStyle = N;
    }
    if (i.patternStroke) {
      a.save();
      const N = i.strokeColor.getPattern(a, this, xs(a), De.STROKE, t);
      E = Vt(a), a.restore(), a.strokeStyle = N;
    }
    let _ = i.lineWidth;
    const x = i.textMatrixScale;
    if (x === 0 || _ === 0) {
      const N = i.textRenderingMode & Te.FILL_STROKE_MASK;
      (N === Te.STROKE || N === Te.FILL_STROKE) && (_ = this.getSinglePixelWidth());
    } else
      _ /= x;
    if (o !== 1 && (a.scale(o, o), _ /= o), a.lineWidth = _, s.isInvalidPDFjsFont) {
      const N = [];
      let q = 0;
      for (const Y of e)
        N.push(Y.unicode), q += Y.width;
      const B = N.join("");
      if (a.fillText(B, 0, 0), this.dependencyTracker !== null) {
        const Y = a.measureText(B);
        this.dependencyTracker.recordBBox(t, this.ctx, -Y.actualBoundingBoxLeft, Y.actualBoundingBoxRight, -Y.actualBoundingBoxAscent, Y.actualBoundingBoxDescent).recordShowTextOperation(t);
      }
      i.x += q * v * u, a.restore(), this.compose();
      return;
    }
    let C = 0, T;
    for (T = 0; T < f; ++T) {
      const N = e[T];
      if (typeof N == "number") {
        C += A * N * r / 1e3;
        continue;
      }
      let q = !1;
      const B = (N.isSpace ? h : 0) + l, Y = N.fontChar, O = N.accent;
      let H, it, at = N.width;
      if (m) {
        const lt = N.vmetric || y, tt = -(N.vmetric ? lt[1] : at * 0.5) * v, vt = lt[2] * v;
        at = lt ? -lt[0] : at, H = tt / o, it = (C + vt) / o;
      } else
        H = C / o, it = 0;
      let Jt;
      if (s.remeasure && at > 0) {
        Jt = a.measureText(Y);
        const lt = Jt.width * 1e3 / r * o;
        if (at < lt && this.isFontSubpixelAAEnabled) {
          const tt = at / lt;
          q = !0, a.save(), a.scale(tt, 1), H /= tt;
        } else at !== lt && (H += (at - lt) / 2e3 * r / o);
      }
      if (this.contentVisible && (N.isInFont || s.missingFile)) {
        if (w && !O)
          a.fillText(Y, H, it), (D = this.dependencyTracker) == null || D.recordCharacterBBox(t, a, Jt ? {
            bbox: null
          } : s, r / o, H, it, () => Jt ?? a.measureText(Y));
        else if (this.paintChar(t, Y, H, it, S, E), O) {
          const lt = H + r * O.offset.x / o, tt = it - r * O.offset.y / o;
          this.paintChar(t, O.fontChar, lt, tt, S, E);
        }
      }
      const Xe = m ? at * v - B * c : at * v + B * c;
      C += Xe, q && a.restore();
    }
    m ? i.y -= C : i.x += C * u, a.restore(), this.compose(), (R = this.dependencyTracker) == null || R.recordShowTextOperation(t);
  }
  showType3Text(t, e) {
    const i = this.ctx, s = this.current, r = s.font, a = s.fontSize, o = s.fontDirection, l = r.vertical ? 1 : -1, h = s.charSpacing, c = s.wordSpacing, u = s.textHScale * o, f = s.fontMatrix || Bf, m = e.length, A = s.textRenderingMode === Te.INVISIBLE;
    let y, v, w, S;
    if (A || a === 0)
      return;
    this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null, i.save(), s.textMatrix && i.transform(...s.textMatrix), i.translate(s.x, s.y + s.textRise), i.scale(u, o);
    const E = this.dependencyTracker;
    for (this.dependencyTracker = E ? new Ou(E, t) : null, y = 0; y < m; ++y) {
      if (v = e[y], typeof v == "number") {
        S = l * v * a / 1e3, this.ctx.translate(S, 0), s.x += S * u;
        continue;
      }
      const _ = (v.isSpace ? c : 0) + h, x = r.charProcOperatorList[v.operatorListId];
      x ? this.contentVisible && (this.save(), i.scale(a, a), i.transform(...f), this.executeOperatorList(x), this.restore()) : J(`Type3 character "${v.operatorListId}" is not available.`);
      const C = [v.width, 0];
      z.applyTransform(C, f), w = C[0] * a + _, i.translate(w, 0), s.x += w * u;
    }
    i.restore(), E && (this.dependencyTracker = E);
  }
  setCharWidth(t, e, i) {
  }
  setCharWidthAndBounds(t, e, i, s, r, a, o) {
    var h;
    const l = new Path2D();
    l.rect(s, r, a - s, o - r), this.ctx.clip(l), (h = this.dependencyTracker) == null || h.recordBBox(t, this.ctx, s, a, r, o).recordClipBox(t, this.ctx, s, a, r, o), this.endPath(t);
  }
  getColorN_Pattern(t, e) {
    let i;
    if (e[0] === "TilingPattern") {
      const s = this.baseTransform || Vt(this.ctx), r = {
        createCanvasGraphics: (a, o) => new kg(a, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
          optionalContentConfig: this.optionalContentConfig,
          markedContentStack: this.markedContentStack
        }, void 0, void 0, this.dependencyTracker ? new Ou(this.dependencyTracker, o, !0) : null)
      };
      i = new up(e, this.ctx, r, s);
    } else
      i = this._getPattern(t, e[1], e[2]);
    return i;
  }
  setStrokeColorN(t, ...e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("strokeColor", t), this.current.strokeColor = this.getColorN_Pattern(t, e), this.current.patternStroke = !0;
  }
  setFillColorN(t, ...e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("fillColor", t), this.current.fillColor = this.getColorN_Pattern(t, e), this.current.patternFill = !0;
  }
  setStrokeRGBColor(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = e, this.current.patternStroke = !1;
  }
  setStrokeTransparent(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = "transparent", this.current.patternStroke = !1;
  }
  setFillRGBColor(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = e, this.current.patternFill = !1;
  }
  setFillTransparent(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = "transparent", this.current.patternFill = !1;
  }
  _getPattern(t, e, i = null) {
    let s;
    return this.cachedPatterns.has(e) ? s = this.cachedPatterns.get(e) : (s = $y(this.getObject(t, e)), this.cachedPatterns.set(e, s)), i && (s.matrix = i), s;
  }
  shadingFill(t, e) {
    var a;
    if (!this.contentVisible)
      return;
    const i = this.ctx;
    this.save(t);
    const s = this._getPattern(t, e);
    i.fillStyle = s.getPattern(i, this, xs(i), De.SHADING, t);
    const r = xs(i);
    if (r) {
      const {
        width: o,
        height: l
      } = i.canvas, h = Ro.slice();
      z.axialAlignedBoundingBox([0, 0, o, l], r, h);
      const [c, u, f, m] = h;
      this.ctx.fillRect(c, u, f - c, m - u);
    } else
      this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
    (a = this.dependencyTracker) == null || a.resetBBox(t).recordFullPageBBox(t).recordDependencies(t, Wi.transform).recordDependencies(t, Wi.fill).recordOperation(t), this.compose(this.current.getClippedPathBoundingBox()), this.restore(t);
  }
  beginInlineImage() {
    Dt("Should not call beginInlineImage");
  }
  beginImageData() {
    Dt("Should not call beginImageData");
  }
  paintFormXObjectBegin(t, e, i) {
    var s;
    if (this.contentVisible && (this.save(t), this.baseTransformStack.push(this.baseTransform), e && this.transform(t, ...e), this.baseTransform = Vt(this.ctx), i)) {
      z.axialAlignedBoundingBox(i, this.baseTransform, this.current.minMax);
      const [r, a, o, l] = i, h = new Path2D();
      h.rect(r, a, o - r, l - a), this.ctx.clip(h), (s = this.dependencyTracker) == null || s.recordClipBox(t, this.ctx, r, o, a, l), this.endPath(t);
    }
  }
  paintFormXObjectEnd(t) {
    this.contentVisible && (this.restore(t), this.baseTransform = this.baseTransformStack.pop());
  }
  beginGroup(t, e) {
    var E;
    if (!this.contentVisible)
      return;
    this.save(t), this.inSMaskMode && (this.endSMaskMode(), this.current.activeSMask = null);
    const i = this.ctx;
    e.isolated || ff("TODO: Support non-isolated groups."), e.knockout && J("Knockout groups not supported.");
    const s = Vt(i);
    if (e.matrix && i.transform(...e.matrix), !e.bbox)
      throw new Error("Bounding box is required.");
    let r = Ro.slice();
    z.axialAlignedBoundingBox(e.bbox, Vt(i), r);
    const a = [0, 0, i.canvas.width, i.canvas.height];
    r = z.intersect(r, a) || [0, 0, 0, 0];
    const o = Math.floor(r[0]), l = Math.floor(r[1]), h = Math.max(Math.ceil(r[2]) - o, 1), c = Math.max(Math.ceil(r[3]) - l, 1);
    this.current.startNewPathAndClipBox([0, 0, h, c]);
    let u = "groupAt" + this.groupLevel;
    e.smask && (u += "_smask_" + this.smaskCounter++ % 2);
    const f = this.cachedCanvases.getCanvas(u, h, c), m = f.context;
    m.translate(-o, -l), m.transform(...s);
    let A = new Path2D();
    const [y, v, w, S] = e.bbox;
    if (A.rect(y, v, w - y, S - v), e.matrix) {
      const _ = new Path2D();
      _.addPath(A, new DOMMatrix(e.matrix)), A = _;
    }
    m.clip(A), e.smask && this.smaskStack.push({
      canvas: f.canvas,
      context: m,
      offsetX: o,
      offsetY: l,
      subtype: e.smask.subtype,
      backdrop: e.smask.backdrop,
      transferMap: e.smask.transferMap || null,
      startTransformInverse: null
    }), (!e.smask || this.dependencyTracker) && (i.setTransform(1, 0, 0, 1, 0, 0), i.translate(o, l), i.save()), yh(i, m), this.ctx = m, (E = this.dependencyTracker) == null || E.inheritSimpleDataAsFutureForcedDependencies(["fillAlpha", "strokeAlpha", "globalCompositeOperation"]).pushBaseTransform(i), this.setGState(t, [["BM", "source-over"], ["ca", 1], ["CA", 1]]), this.groupStack.push(i), this.groupLevel++;
  }
  endGroup(t, e) {
    var r;
    if (!this.contentVisible)
      return;
    this.groupLevel--;
    const i = this.ctx, s = this.groupStack.pop();
    if (this.ctx = s, this.ctx.imageSmoothingEnabled = !1, (r = this.dependencyTracker) == null || r.popBaseTransform(), e.smask)
      this.tempSMask = this.smaskStack.pop(), this.restore(t), this.dependencyTracker && this.ctx.restore();
    else {
      this.ctx.restore();
      const a = Vt(this.ctx);
      this.restore(t), this.ctx.save(), this.ctx.setTransform(...a);
      const o = Ro.slice();
      z.axialAlignedBoundingBox([0, 0, i.canvas.width, i.canvas.height], a, o), this.ctx.drawImage(i.canvas, 0, 0), this.ctx.restore(), this.compose(o);
    }
  }
  beginAnnotation(t, e, i, s, r, a) {
    if (b(this, _s, fp).call(this), Qd(this.ctx), this.ctx.save(), this.save(t), this.baseTransform && this.ctx.setTransform(...this.baseTransform), i) {
      const o = i[2] - i[0], l = i[3] - i[1];
      if (a && this.annotationCanvasMap) {
        s = s.slice(), s[4] -= i[0], s[5] -= i[1], i = i.slice(), i[0] = i[1] = 0, i[2] = o, i[3] = l, z.singularValueDecompose2dScale(Vt(this.ctx), Bi);
        const {
          viewportScale: h
        } = this, c = Math.ceil(o * this.outputScaleX * h), u = Math.ceil(l * this.outputScaleY * h);
        this.annotationCanvas = this.canvasFactory.create(c, u);
        const {
          canvas: f,
          context: m
        } = this.annotationCanvas;
        this.annotationCanvasMap.set(e, f), this.annotationCanvas.savedCtx = this.ctx, this.ctx = m, this.ctx.save(), this.ctx.setTransform(Bi[0], 0, 0, -Bi[1], 0, l * Bi[1]), Qd(this.ctx);
      } else {
        Qd(this.ctx), this.endPath(t);
        const h = new Path2D();
        h.rect(i[0], i[1], o, l), this.ctx.clip(h);
      }
    }
    this.current = new Jg(this.ctx.canvas.width, this.ctx.canvas.height), this.transform(t, ...s), this.transform(t, ...r);
  }
  endAnnotation(t) {
    this.annotationCanvas && (this.ctx.restore(), b(this, _s, pp).call(this), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas);
  }
  paintImageMaskXObject(t, e) {
    var o;
    if (!this.contentVisible)
      return;
    const i = e.count;
    e = this.getObject(t, e.data, e), e.count = i;
    const s = this.ctx, r = this._createMaskCanvas(t, e), a = r.canvas;
    s.save(), s.setTransform(1, 0, 0, 1, 0, 0), s.drawImage(a, r.offsetX, r.offsetY), (o = this.dependencyTracker) == null || o.resetBBox(t).recordBBox(t, this.ctx, r.offsetX, r.offsetX + a.width, r.offsetY, r.offsetY + a.height).recordOperation(t), s.restore(), this.compose();
  }
  paintImageMaskXObjectRepeat(t, e, i, s = 0, r = 0, a, o) {
    var u, f, m;
    if (!this.contentVisible)
      return;
    e = this.getObject(t, e.data, e);
    const l = this.ctx;
    l.save();
    const h = Vt(l);
    l.transform(i, s, r, a, 0, 0);
    const c = this._createMaskCanvas(t, e);
    l.setTransform(1, 0, 0, 1, c.offsetX - h[4], c.offsetY - h[5]), (u = this.dependencyTracker) == null || u.resetBBox(t);
    for (let A = 0, y = o.length; A < y; A += 2) {
      const v = z.transform(h, [i, s, r, a, o[A], o[A + 1]]);
      l.drawImage(c.canvas, v[4], v[5]), (f = this.dependencyTracker) == null || f.recordBBox(t, this.ctx, v[4], v[4] + c.canvas.width, v[5], v[5] + c.canvas.height);
    }
    l.restore(), this.compose(), (m = this.dependencyTracker) == null || m.recordOperation(t);
  }
  paintImageMaskXObjectGroup(t, e) {
    var a, o, l;
    if (!this.contentVisible)
      return;
    const i = this.ctx, s = this.current.fillColor, r = this.current.patternFill;
    (a = this.dependencyTracker) == null || a.resetBBox(t).recordDependencies(t, Wi.transformAndFill);
    for (const h of e) {
      const {
        data: c,
        width: u,
        height: f,
        transform: m
      } = h, A = this.cachedCanvases.getCanvas("maskCanvas", u, f), y = A.context;
      y.save();
      const v = this.getObject(t, c, h);
      tm(y, v), y.globalCompositeOperation = "source-in", y.fillStyle = r ? s.getPattern(y, this, xs(i), De.FILL, t) : s, y.fillRect(0, 0, u, f), y.restore(), i.save(), i.transform(...m), i.scale(1, -1), Jd(i, A.canvas, 0, 0, u, f, 0, -1, 1, 1), (o = this.dependencyTracker) == null || o.recordBBox(t, i, 0, u, 0, f), i.restore();
    }
    this.compose(), (l = this.dependencyTracker) == null || l.recordOperation(t);
  }
  paintImageXObject(t, e) {
    if (!this.contentVisible)
      return;
    const i = this.getObject(t, e);
    if (!i) {
      J("Dependent image isn't ready yet");
      return;
    }
    this.paintInlineImageXObject(t, i);
  }
  paintImageXObjectRepeat(t, e, i, s, r) {
    if (!this.contentVisible)
      return;
    const a = this.getObject(t, e);
    if (!a) {
      J("Dependent image isn't ready yet");
      return;
    }
    const o = a.width, l = a.height, h = [];
    for (let c = 0, u = r.length; c < u; c += 2)
      h.push({
        transform: [i, 0, 0, s, r[c], r[c + 1]],
        x: 0,
        y: 0,
        w: o,
        h: l
      });
    this.paintInlineImageXObjectGroup(t, a, h);
  }
  applyTransferMapsToCanvas(t) {
    return this.current.transferMaps !== "none" && (t.filter = this.current.transferMaps, t.drawImage(t.canvas, 0, 0), t.filter = "none"), t.canvas;
  }
  applyTransferMapsToBitmap(t) {
    if (this.current.transferMaps === "none")
      return t.bitmap;
    const {
      bitmap: e,
      width: i,
      height: s
    } = t, r = this.cachedCanvases.getCanvas("inlineImage", i, s), a = r.context;
    return a.filter = this.current.transferMaps, a.drawImage(e, 0, 0), a.filter = "none", r.canvas;
  }
  paintInlineImageXObject(t, e) {
    var h;
    if (!this.contentVisible)
      return;
    const i = e.width, s = e.height, r = this.ctx;
    this.save(t);
    const {
      filter: a
    } = r;
    a !== "none" && a !== "" && (r.filter = "none"), r.scale(1 / i, -1 / s);
    let o;
    if (e.bitmap)
      o = this.applyTransferMapsToBitmap(e);
    else if (typeof HTMLElement == "function" && e instanceof HTMLElement || !e.data)
      o = e;
    else {
      const u = this.cachedCanvases.getCanvas("inlineImage", i, s).context;
      Qg(u, e), o = this.applyTransferMapsToCanvas(u);
    }
    const l = this._scaleImage(o, xs(r));
    r.imageSmoothingEnabled = em(Vt(r), e.interpolate), (h = this.dependencyTracker) == null || h.resetBBox(t).recordBBox(t, r, 0, i, -s, 0).recordDependencies(t, Wi.imageXObject).recordOperation(t), Jd(r, l.img, 0, 0, l.paintWidth, l.paintHeight, 0, -s, i, s), this.compose(), this.restore(t);
  }
  paintInlineImageXObjectGroup(t, e, i) {
    var a, o, l;
    if (!this.contentVisible)
      return;
    const s = this.ctx;
    let r;
    if (e.bitmap)
      r = e.bitmap;
    else {
      const h = e.width, c = e.height, f = this.cachedCanvases.getCanvas("inlineImage", h, c).context;
      Qg(f, e), r = this.applyTransferMapsToCanvas(f);
    }
    (a = this.dependencyTracker) == null || a.resetBBox(t);
    for (const h of i)
      s.save(), s.transform(...h.transform), s.scale(1, -1), Jd(s, r, h.x, h.y, h.w, h.h, 0, -1, 1, 1), (o = this.dependencyTracker) == null || o.recordBBox(t, s, 0, 1, -1, 0), s.restore();
    (l = this.dependencyTracker) == null || l.recordOperation(t), this.compose();
  }
  paintSolidColorImageMask(t) {
    var e;
    this.contentVisible && ((e = this.dependencyTracker) == null || e.resetBBox(t).recordBBox(t, this.ctx, 0, 1, 0, 1).recordDependencies(t, Wi.fill).recordOperation(t), this.ctx.fillRect(0, 0, 1, 1), this.compose());
  }
  markPoint(t, e) {
  }
  markPointProps(t, e, i) {
  }
  beginMarkedContent(t, e) {
    var i;
    (i = this.dependencyTracker) == null || i.beginMarkedContent(t), this.markedContentStack.push({
      visible: !0
    });
  }
  beginMarkedContentProps(t, e, i) {
    var s;
    (s = this.dependencyTracker) == null || s.beginMarkedContent(t), e === "OC" ? this.markedContentStack.push({
      visible: this.optionalContentConfig.isVisible(i)
    }) : this.markedContentStack.push({
      visible: !0
    }), this.contentVisible = this.isContentVisible();
  }
  endMarkedContent(t) {
    var e;
    (e = this.dependencyTracker) == null || e.endMarkedContent(t), this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
  }
  beginCompat(t) {
  }
  endCompat(t) {
  }
  consumePath(t, e, i) {
    var a, o;
    const s = this.current.isEmptyClip();
    this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(i);
    const r = this.ctx;
    this.pendingClip ? (s || (this.pendingClip === im ? r.clip(e, "evenodd") : r.clip(e)), this.pendingClip = null, (a = this.dependencyTracker) == null || a.bboxToClipBoxDropOperation(t).recordFutureForcedDependency("clipPath", t)) : (o = this.dependencyTracker) == null || o.recordOperation(t), this.current.startNewPathAndClipBox(this.current.clipBox);
  }
  getSinglePixelWidth() {
    if (!this._cachedGetSinglePixelWidth) {
      const t = Vt(this.ctx);
      if (t[1] === 0 && t[2] === 0)
        this._cachedGetSinglePixelWidth = 1 / Math.min(Math.abs(t[0]), Math.abs(t[3]));
      else {
        const e = Math.abs(t[0] * t[3] - t[2] * t[1]), i = Math.hypot(t[0], t[2]), s = Math.hypot(t[1], t[3]);
        this._cachedGetSinglePixelWidth = Math.max(i, s) / e;
      }
    }
    return this._cachedGetSinglePixelWidth;
  }
  getScaleForStroking() {
    if (this._cachedScaleForStroking[0] === -1) {
      const {
        lineWidth: t
      } = this.current, {
        a: e,
        b: i,
        c: s,
        d: r
      } = this.ctx.getTransform();
      let a, o;
      if (i === 0 && s === 0) {
        const l = Math.abs(e), h = Math.abs(r);
        if (l === h)
          if (t === 0)
            a = o = 1 / l;
          else {
            const c = l * t;
            a = o = c < 1 ? 1 / c : 1;
          }
        else if (t === 0)
          a = 1 / l, o = 1 / h;
        else {
          const c = l * t, u = h * t;
          a = c < 1 ? 1 / c : 1, o = u < 1 ? 1 / u : 1;
        }
      } else {
        const l = Math.abs(e * r - i * s), h = Math.hypot(e, i), c = Math.hypot(s, r);
        if (t === 0)
          a = c / l, o = h / l;
        else {
          const u = t * l;
          a = c > u ? c / u : 1, o = h > u ? h / u : 1;
        }
      }
      this._cachedScaleForStroking[0] = a, this._cachedScaleForStroking[1] = o;
    }
    return this._cachedScaleForStroking;
  }
  rescaleAndStroke(t, e) {
    const {
      ctx: i,
      current: {
        lineWidth: s
      }
    } = this, [r, a] = this.getScaleForStroking();
    if (r === a) {
      i.lineWidth = (s || 1) * r, i.stroke(t);
      return;
    }
    const o = i.getLineDash();
    e && i.save(), i.scale(r, a), Mf.a = 1 / r, Mf.d = 1 / a;
    const l = new Path2D();
    if (l.addPath(t, Mf), o.length > 0) {
      const h = Math.max(r, a);
      i.setLineDash(o.map((c) => c / h)), i.lineDashOffset /= h;
    }
    i.lineWidth = s || 1, i.stroke(l), e && i.restore();
  }
  isContentVisible() {
    for (let t = this.markedContentStack.length - 1; t >= 0; t--)
      if (!this.markedContentStack[t].visible)
        return !1;
    return !0;
  }
};
_s = new WeakSet(), fp = function() {
  for (; this.stateStack.length || this.inSMaskMode; )
    this.restore();
  this.current.activeSMask = null, this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.transparentCanvas = null);
}, pp = function() {
  if (this.pageColors) {
    const t = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
    if (t !== "none") {
      const e = this.ctx.filter;
      this.ctx.filter = t, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = e;
    }
  }
}, gp = function(t, e, i) {
  const s = new Path2D();
  return s.addPath(t, new DOMMatrix(i).invertSelf().multiplySelf(e)), s;
};
let No = kg;
for (const d in dh)
  No.prototype[d] !== void 0 && (No.prototype[dh[d]] = No.prototype[d]);
var ul, fl, kc, pl, cu;
const Do = class Do {
  constructor(t) {
    g(this, pl);
    g(this, ul);
    g(this, fl);
    g(this, kc);
    p(this, ul, t), p(this, fl, new DataView(n(this, ul))), p(this, kc, new TextDecoder());
  }
  static write(t) {
    const e = new TextEncoder(), i = {};
    let s = 0;
    for (const h of Do.strings) {
      const c = e.encode(t[h]);
      i[h] = c, s += 4 + c.length;
    }
    const r = new ArrayBuffer(s), a = new Uint8Array(r), o = new DataView(r);
    let l = 0;
    for (const h of Do.strings) {
      const c = i[h], u = c.length;
      o.setUint32(l, u), a.set(c, l + 4), l += 4 + u;
    }
    return dt(l === r.byteLength, "CssFontInfo.write: Buffer overflow"), r;
  }
  get fontFamily() {
    return b(this, pl, cu).call(this, 0);
  }
  get fontWeight() {
    return b(this, pl, cu).call(this, 1);
  }
  get italicAngle() {
    return b(this, pl, cu).call(this, 2);
  }
};
ul = new WeakMap(), fl = new WeakMap(), kc = new WeakMap(), pl = new WeakSet(), cu = function(t) {
  dt(t < Do.strings.length, "Invalid string index");
  let e = 0;
  for (let s = 0; s < t; s++)
    e += n(this, fl).getUint32(e) + 4;
  const i = n(this, fl).getUint32(e);
  return n(this, kc).decode(new Uint8Array(n(this, ul), e + 4, i));
}, M(Do, "strings", ["fontFamily", "fontWeight", "italicAngle"]);
let Bu = Do;
var mr, Hs, Ra, Ma, Dh;
const Io = class Io {
  constructor(t) {
    g(this, Ma);
    g(this, mr);
    g(this, Hs);
    g(this, Ra);
    p(this, mr, t), p(this, Hs, new DataView(n(this, mr))), p(this, Ra, new TextDecoder());
  }
  static write(t) {
    const e = new TextEncoder(), i = {};
    let s = 0;
    for (const f of Io.strings) {
      const m = e.encode(t[f]);
      i[f] = m, s += 4 + m.length;
    }
    s += 4;
    let r, a, o = 1 + s;
    t.style && (r = e.encode(t.style.style), a = e.encode(t.style.weight), o += 4 + r.length + 4 + a.length);
    const l = new ArrayBuffer(o), h = new Uint8Array(l), c = new DataView(l);
    let u = 0;
    c.setUint8(u++, t.guessFallback ? 1 : 0), c.setUint32(u, 0), u += 4, s = 0;
    for (const f of Io.strings) {
      const m = i[f], A = m.length;
      s += 4 + A, c.setUint32(u, A), h.set(m, u + 4), u += 4 + A;
    }
    return c.setUint32(u - s - 4, s), t.style && (c.setUint32(u, r.length), h.set(r, u + 4), u += 4 + r.length, c.setUint32(u, a.length), h.set(a, u + 4), u += 4 + a.length), dt(u <= l.byteLength, "SubstitionInfo.write: Buffer overflow"), l.transferToFixedLength(u);
  }
  get guessFallback() {
    return n(this, Hs).getUint8(0) !== 0;
  }
  get css() {
    return b(this, Ma, Dh).call(this, 0);
  }
  get loadedName() {
    return b(this, Ma, Dh).call(this, 1);
  }
  get baseFontName() {
    return b(this, Ma, Dh).call(this, 2);
  }
  get src() {
    return b(this, Ma, Dh).call(this, 3);
  }
  get style() {
    let t = 1;
    t += 4 + n(this, Hs).getUint32(t);
    const e = n(this, Hs).getUint32(t), i = n(this, Ra).decode(new Uint8Array(n(this, mr), t + 4, e));
    t += 4 + e;
    const s = n(this, Hs).getUint32(t), r = n(this, Ra).decode(new Uint8Array(n(this, mr), t + 4, s));
    return {
      style: i,
      weight: r
    };
  }
};
mr = new WeakMap(), Hs = new WeakMap(), Ra = new WeakMap(), Ma = new WeakSet(), Dh = function(t) {
  dt(t < Io.strings.length, "Invalid string index");
  let e = 5;
  for (let s = 0; s < t; s++)
    e += n(this, Hs).getUint32(e) + 4;
  const i = n(this, Hs).getUint32(e);
  return n(this, Ra).decode(new Uint8Array(n(this, mr), e + 4, i));
}, M(Io, "strings", ["css", "loadedName", "baseFontName", "src"]);
let Hu = Io;
var gl, ml, bl, yl, Si, Us, Rc, _t, Zt, ls, du, Ih;
const et = class et {
  constructor({
    data: t,
    extra: e
  }) {
    g(this, Zt);
    g(this, Us);
    g(this, Rc);
    g(this, _t);
    p(this, Us, t), p(this, Rc, new TextDecoder()), p(this, _t, new DataView(n(this, Us))), e && Object.assign(this, e);
  }
  get black() {
    return b(this, Zt, ls).call(this, 0);
  }
  get bold() {
    return b(this, Zt, ls).call(this, 1);
  }
  get disableFontFace() {
    return b(this, Zt, ls).call(this, 2);
  }
  get fontExtraProperties() {
    return b(this, Zt, ls).call(this, 3);
  }
  get isInvalidPDFjsFont() {
    return b(this, Zt, ls).call(this, 4);
  }
  get isType3Font() {
    return b(this, Zt, ls).call(this, 5);
  }
  get italic() {
    return b(this, Zt, ls).call(this, 6);
  }
  get missingFile() {
    return b(this, Zt, ls).call(this, 7);
  }
  get remeasure() {
    return b(this, Zt, ls).call(this, 8);
  }
  get vertical() {
    return b(this, Zt, ls).call(this, 9);
  }
  get ascent() {
    return b(this, Zt, du).call(this, 0);
  }
  get defaultWidth() {
    return b(this, Zt, du).call(this, 1);
  }
  get descent() {
    return b(this, Zt, du).call(this, 2);
  }
  get bbox() {
    let t = n(et, ml);
    if (n(this, _t).getUint8(t) === 0)
      return;
    t += 1;
    const i = [];
    for (let s = 0; s < 4; s++)
      i.push(n(this, _t).getInt16(t, !0)), t += 2;
    return i;
  }
  get fontMatrix() {
    let t = n(et, bl);
    if (n(this, _t).getUint8(t) === 0)
      return;
    t += 1;
    const i = [];
    for (let s = 0; s < 6; s++)
      i.push(n(this, _t).getFloat64(t, !0)), t += 8;
    return i;
  }
  get defaultVMetrics() {
    let t = n(et, yl);
    if (n(this, _t).getUint8(t) === 0)
      return;
    t += 1;
    const i = [];
    for (let s = 0; s < 3; s++)
      i.push(n(this, _t).getInt16(t, !0)), t += 2;
    return i;
  }
  get fallbackName() {
    return b(this, Zt, Ih).call(this, 0);
  }
  get loadedName() {
    return b(this, Zt, Ih).call(this, 1);
  }
  get mimetype() {
    return b(this, Zt, Ih).call(this, 2);
  }
  get name() {
    return b(this, Zt, Ih).call(this, 3);
  }
  get data() {
    let t = n(et, Si);
    const e = n(this, _t).getUint32(t);
    t += 4 + e;
    const i = n(this, _t).getUint32(t);
    t += 4 + i;
    const s = n(this, _t).getUint32(t);
    t += 4 + s;
    const r = n(this, _t).getUint32(t);
    if (r !== 0)
      return new Uint8Array(n(this, Us), t + 4, r);
  }
  clearData() {
    let t = n(et, Si);
    const e = n(this, _t).getUint32(t);
    t += 4 + e;
    const i = n(this, _t).getUint32(t);
    t += 4 + i;
    const s = n(this, _t).getUint32(t);
    t += 4 + s;
    const r = n(this, _t).getUint32(t);
    new Uint8Array(n(this, Us), t + 4, r).fill(0), n(this, _t).setUint32(t, 0);
  }
  get cssFontInfo() {
    let t = n(et, Si);
    const e = n(this, _t).getUint32(t);
    t += 4 + e;
    const i = n(this, _t).getUint32(t);
    t += 4 + i;
    const s = n(this, _t).getUint32(t);
    if (s === 0)
      return null;
    const r = new Uint8Array(s);
    return r.set(new Uint8Array(n(this, Us), t + 4, s)), new Bu(r.buffer);
  }
  get systemFontInfo() {
    let t = n(et, Si);
    const e = n(this, _t).getUint32(t);
    t += 4 + e;
    const i = n(this, _t).getUint32(t);
    if (i === 0)
      return null;
    const s = new Uint8Array(i);
    return s.set(new Uint8Array(n(this, Us), t + 4, i)), new Hu(s.buffer);
  }
  static write(t) {
    const e = t.systemFontInfo ? Hu.write(t.systemFontInfo) : null, i = t.cssFontInfo ? Bu.write(t.cssFontInfo) : null, s = new TextEncoder(), r = {};
    let a = 0;
    for (const y of et.strings)
      r[y] = s.encode(t[y]), a += 4 + r[y].length;
    const o = n(et, Si) + 4 + a + 4 + (e ? e.byteLength : 0) + 4 + (i ? i.byteLength : 0) + 4 + (t.data ? t.data.length : 0), l = new ArrayBuffer(o), h = new Uint8Array(l), c = new DataView(l);
    let u = 0;
    const f = et.bools.length;
    let m = 0, A = 0;
    for (let y = 0; y < f; y++) {
      const v = t[et.bools[y]];
      m |= (v === void 0 ? 0 : v ? 2 : 1) << A, A += 2, (A === 8 || y === f - 1) && (c.setUint8(u++, m), m = 0, A = 0);
    }
    dt(u === n(et, gl), "FontInfo.write: Boolean properties offset mismatch");
    for (const y of et.numbers)
      c.setFloat64(u, t[y]), u += 8;
    if (dt(u === n(et, ml), "FontInfo.write: Number properties offset mismatch"), t.bbox) {
      c.setUint8(u++, 4);
      for (const y of t.bbox)
        c.setInt16(u, y, !0), u += 2;
    } else
      c.setUint8(u++, 0), u += 8;
    if (dt(u === n(et, bl), "FontInfo.write: BBox properties offset mismatch"), t.fontMatrix) {
      c.setUint8(u++, 6);
      for (const y of t.fontMatrix)
        c.setFloat64(u, y, !0), u += 8;
    } else
      c.setUint8(u++, 0), u += 48;
    if (dt(u === n(et, yl), "FontInfo.write: FontMatrix properties offset mismatch"), t.defaultVMetrics) {
      c.setUint8(u++, 1);
      for (const y of t.defaultVMetrics)
        c.setInt16(u, y, !0), u += 2;
    } else
      c.setUint8(u++, 0), u += 6;
    dt(u === n(et, Si), "FontInfo.write: DefaultVMetrics properties offset mismatch"), c.setUint32(n(et, Si), 0), u += 4;
    for (const y of et.strings) {
      const v = r[y], w = v.length;
      c.setUint32(u, w), h.set(v, u + 4), u += 4 + w;
    }
    if (c.setUint32(n(et, Si), u - n(et, Si) - 4), !e)
      c.setUint32(u, 0), u += 4;
    else {
      const y = e.byteLength;
      c.setUint32(u, y), dt(u + 4 + y <= l.byteLength, "FontInfo.write: Buffer overflow at systemFontInfo"), h.set(new Uint8Array(e), u + 4), u += 4 + y;
    }
    if (!i)
      c.setUint32(u, 0), u += 4;
    else {
      const y = i.byteLength;
      c.setUint32(u, y), dt(u + 4 + y <= l.byteLength, "FontInfo.write: Buffer overflow at cssFontInfo"), h.set(new Uint8Array(i), u + 4), u += 4 + y;
    }
    return t.data === void 0 ? (c.setUint32(u, 0), u += 4) : (c.setUint32(u, t.data.length), h.set(t.data, u + 4), u += 4 + t.data.length), dt(u <= l.byteLength, "FontInfo.write: Buffer overflow"), l.transferToFixedLength(u);
  }
};
gl = new WeakMap(), ml = new WeakMap(), bl = new WeakMap(), yl = new WeakMap(), Si = new WeakMap(), Us = new WeakMap(), Rc = new WeakMap(), _t = new WeakMap(), Zt = new WeakSet(), ls = function(t) {
  dt(t < et.bools.length, "Invalid boolean index");
  const e = Math.floor(t / 4), i = t * 2 % 8, s = n(this, _t).getUint8(e) >> i & 3;
  return s === 0 ? void 0 : s === 2;
}, du = function(t) {
  return dt(t < et.numbers.length, "Invalid number index"), n(this, _t).getFloat64(n(et, gl) + t * 8);
}, Ih = function(t) {
  dt(t < et.strings.length, "Invalid string index");
  let e = n(et, Si) + 4;
  for (let r = 0; r < t; r++)
    e += n(this, _t).getUint32(e) + 4;
  const i = n(this, _t).getUint32(e), s = new Uint8Array(i);
  return s.set(new Uint8Array(n(this, Us), e + 4, i)), n(this, Rc).decode(s);
}, M(et, "bools", ["black", "bold", "disableFontFace", "fontExtraProperties", "isInvalidPDFjsFont", "isType3Font", "italic", "missingFile", "remeasure", "vertical"]), M(et, "numbers", ["ascent", "defaultWidth", "descent"]), M(et, "strings", ["fallbackName", "loadedName", "mimetype", "name"]), g(et, gl, Math.ceil(et.bools.length * 2 / 8)), g(et, ml, n(et, gl) + et.numbers.length * 8), g(et, bl, n(et, ml) + 1 + 8), g(et, yl, n(et, bl) + 1 + 48), g(et, Si, n(et, yl) + 1 + 6);
let mp = et;
var Mc, Dc;
class ns {
  static get workerPort() {
    return n(this, Mc);
  }
  static set workerPort(t) {
    if (!(typeof Worker < "u" && t instanceof Worker) && t !== null)
      throw new Error("Invalid `workerPort` type.");
    p(this, Mc, t);
  }
  static get workerSrc() {
    return n(this, Dc);
  }
  static set workerSrc(t) {
    if (typeof t != "string")
      throw new Error("Invalid `workerSrc` type.");
    p(this, Dc, t);
  }
}
Mc = new WeakMap(), Dc = new WeakMap(), g(ns, Mc, null), g(ns, Dc, "");
var Al, Ic;
class Yy {
  constructor({
    parsedData: t,
    rawData: e
  }) {
    g(this, Al);
    g(this, Ic);
    p(this, Al, t), p(this, Ic, e);
  }
  getRaw() {
    return n(this, Ic);
  }
  get(t) {
    return n(this, Al).get(t) ?? null;
  }
  [Symbol.iterator]() {
    return n(this, Al).entries();
  }
}
Al = new WeakMap(), Ic = new WeakMap();
const Po = Symbol("INTERNAL");
var Fc, Nc, Oc, wl;
class Ky {
  constructor(t, {
    name: e,
    intent: i,
    usage: s,
    rbGroups: r
  }) {
    g(this, Fc, !1);
    g(this, Nc, !1);
    g(this, Oc, !1);
    g(this, wl, !0);
    p(this, Fc, !!(t & Oi.DISPLAY)), p(this, Nc, !!(t & Oi.PRINT)), this.name = e, this.intent = i, this.usage = s, this.rbGroups = r;
  }
  get visible() {
    if (n(this, Oc))
      return n(this, wl);
    if (!n(this, wl))
      return !1;
    const {
      print: t,
      view: e
    } = this.usage;
    return n(this, Fc) ? (e == null ? void 0 : e.viewState) !== "OFF" : n(this, Nc) ? (t == null ? void 0 : t.printState) !== "OFF" : !0;
  }
  _setVisible(t, e, i = !1) {
    t !== Po && Dt("Internal method `_setVisible` called."), p(this, Oc, i), p(this, wl, e);
  }
}
Fc = new WeakMap(), Nc = new WeakMap(), Oc = new WeakMap(), wl = new WeakMap();
var br, xt, vl, El, Bc, bp;
class Zy {
  constructor(t, e = Oi.DISPLAY) {
    g(this, Bc);
    g(this, br, null);
    g(this, xt, /* @__PURE__ */ new Map());
    g(this, vl, null);
    g(this, El, null);
    if (this.renderingIntent = e, this.name = null, this.creator = null, t !== null) {
      this.name = t.name, this.creator = t.creator, p(this, El, t.order);
      for (const i of t.groups)
        n(this, xt).set(i.id, new Ky(e, i));
      if (t.baseState === "OFF")
        for (const i of n(this, xt).values())
          i._setVisible(Po, !1);
      for (const i of t.on)
        n(this, xt).get(i)._setVisible(Po, !0);
      for (const i of t.off)
        n(this, xt).get(i)._setVisible(Po, !1);
      p(this, vl, this.getHash());
    }
  }
  isVisible(t) {
    if (n(this, xt).size === 0)
      return !0;
    if (!t)
      return ff("Optional content group not defined."), !0;
    if (t.type === "OCG")
      return n(this, xt).has(t.id) ? n(this, xt).get(t.id).visible : (J(`Optional content group not found: ${t.id}`), !0);
    if (t.type === "OCMD") {
      if (t.expression)
        return b(this, Bc, bp).call(this, t.expression);
      if (!t.policy || t.policy === "AnyOn") {
        for (const e of t.ids) {
          if (!n(this, xt).has(e))
            return J(`Optional content group not found: ${e}`), !0;
          if (n(this, xt).get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOn") {
        for (const e of t.ids) {
          if (!n(this, xt).has(e))
            return J(`Optional content group not found: ${e}`), !0;
          if (!n(this, xt).get(e).visible)
            return !1;
        }
        return !0;
      } else if (t.policy === "AnyOff") {
        for (const e of t.ids) {
          if (!n(this, xt).has(e))
            return J(`Optional content group not found: ${e}`), !0;
          if (!n(this, xt).get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOff") {
        for (const e of t.ids) {
          if (!n(this, xt).has(e))
            return J(`Optional content group not found: ${e}`), !0;
          if (n(this, xt).get(e).visible)
            return !1;
        }
        return !0;
      }
      return J(`Unknown optional content policy ${t.policy}.`), !0;
    }
    return J(`Unknown group type ${t.type}.`), !0;
  }
  setVisibility(t, e = !0, i = !0) {
    var r;
    const s = n(this, xt).get(t);
    if (!s) {
      J(`Optional content group not found: ${t}`);
      return;
    }
    if (i && e && s.rbGroups.length)
      for (const a of s.rbGroups)
        for (const o of a)
          o !== t && ((r = n(this, xt).get(o)) == null || r._setVisible(Po, !1, !0));
    s._setVisible(Po, !!e, !0), p(this, br, null);
  }
  setOCGState({
    state: t,
    preserveRB: e
  }) {
    let i;
    for (const s of t) {
      switch (s) {
        case "ON":
        case "OFF":
        case "Toggle":
          i = s;
          continue;
      }
      const r = n(this, xt).get(s);
      if (r)
        switch (i) {
          case "ON":
            this.setVisibility(s, !0, e);
            break;
          case "OFF":
            this.setVisibility(s, !1, e);
            break;
          case "Toggle":
            this.setVisibility(s, !r.visible, e);
            break;
        }
    }
    p(this, br, null);
  }
  get hasInitialVisibility() {
    return n(this, vl) === null || this.getHash() === n(this, vl);
  }
  getOrder() {
    return n(this, xt).size ? n(this, El) ? n(this, El).slice() : [...n(this, xt).keys()] : null;
  }
  getGroup(t) {
    return n(this, xt).get(t) || null;
  }
  getHash() {
    if (n(this, br) !== null)
      return n(this, br);
    const t = new ob();
    for (const [e, i] of n(this, xt))
      t.update(`${e}:${i.visible}`);
    return p(this, br, t.hexdigest());
  }
  [Symbol.iterator]() {
    return n(this, xt).entries();
  }
}
br = new WeakMap(), xt = new WeakMap(), vl = new WeakMap(), El = new WeakMap(), Bc = new WeakSet(), bp = function(t) {
  const e = t.length;
  if (e < 2)
    return !0;
  const i = t[0];
  for (let s = 1; s < e; s++) {
    const r = t[s];
    let a;
    if (Array.isArray(r))
      a = b(this, Bc, bp).call(this, r);
    else if (n(this, xt).has(r))
      a = n(this, xt).get(r).visible;
    else
      return J(`Optional content group not found: ${r}`), !0;
    switch (i) {
      case "And":
        if (!a)
          return !1;
        break;
      case "Or":
        if (a)
          return !0;
        break;
      case "Not":
        return !a;
      default:
        return !0;
    }
  }
  return i === "And";
};
class Jy {
  constructor(t, {
    disableRange: e = !1,
    disableStream: i = !1
  }) {
    dt(t, 'PDFDataTransportStream - missing required "pdfDataRangeTransport" argument.');
    const {
      length: s,
      initialData: r,
      progressiveDone: a,
      contentDispositionFilename: o
    } = t;
    if (this._queuedChunks = [], this._progressiveDone = a, this._contentDispositionFilename = o, (r == null ? void 0 : r.length) > 0) {
      const l = r instanceof Uint8Array && r.byteLength === r.buffer.byteLength ? r.buffer : new Uint8Array(r).buffer;
      this._queuedChunks.push(l);
    }
    this._pdfDataRangeTransport = t, this._isStreamingSupported = !i, this._isRangeSupported = !e, this._contentLength = s, this._fullRequestReader = null, this._rangeReaders = [], t.addRangeListener((l, h) => {
      this._onReceiveData({
        begin: l,
        chunk: h
      });
    }), t.addProgressListener((l, h) => {
      this._onProgress({
        loaded: l,
        total: h
      });
    }), t.addProgressiveReadListener((l) => {
      this._onReceiveData({
        chunk: l
      });
    }), t.addProgressiveDoneListener(() => {
      this._onProgressiveDone();
    }), t.transportReady();
  }
  _onReceiveData({
    begin: t,
    chunk: e
  }) {
    const i = e instanceof Uint8Array && e.byteLength === e.buffer.byteLength ? e.buffer : new Uint8Array(e).buffer;
    if (t === void 0)
      this._fullRequestReader ? this._fullRequestReader._enqueue(i) : this._queuedChunks.push(i);
    else {
      const s = this._rangeReaders.some(function(r) {
        return r._begin !== t ? !1 : (r._enqueue(i), !0);
      });
      dt(s, "_onReceiveData - no `PDFDataTransportStreamRangeReader` instance found.");
    }
  }
  get _progressiveDataLength() {
    var t;
    return ((t = this._fullRequestReader) == null ? void 0 : t._loaded) ?? 0;
  }
  _onProgress(t) {
    var e, i, s, r;
    t.total === void 0 ? (i = (e = this._rangeReaders[0]) == null ? void 0 : e.onProgress) == null || i.call(e, {
      loaded: t.loaded
    }) : (r = (s = this._fullRequestReader) == null ? void 0 : s.onProgress) == null || r.call(s, {
      loaded: t.loaded,
      total: t.total
    });
  }
  _onProgressiveDone() {
    var t;
    (t = this._fullRequestReader) == null || t.progressiveDone(), this._progressiveDone = !0;
  }
  _removeRangeReader(t) {
    const e = this._rangeReaders.indexOf(t);
    e >= 0 && this._rangeReaders.splice(e, 1);
  }
  getFullReader() {
    dt(!this._fullRequestReader, "PDFDataTransportStream.getFullReader can only be called once.");
    const t = this._queuedChunks;
    return this._queuedChunks = null, new Qy(this, t, this._progressiveDone, this._contentDispositionFilename);
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const i = new tA(this, t, e);
    return this._pdfDataRangeTransport.requestDataRange(t, e), this._rangeReaders.push(i), i;
  }
  cancelAllRequests(t) {
    var e;
    (e = this._fullRequestReader) == null || e.cancel(t);
    for (const i of this._rangeReaders.slice(0))
      i.cancel(t);
    this._pdfDataRangeTransport.abort();
  }
}
class Qy {
  constructor(t, e, i = !1, s = null) {
    this._stream = t, this._done = i || !1, this._filename = gf(s) ? s : null, this._queuedChunks = e || [], this._loaded = 0;
    for (const r of this._queuedChunks)
      this._loaded += r.byteLength;
    this._requests = [], this._headersReady = Promise.resolve(), t._fullRequestReader = this, this.onProgress = null;
  }
  _enqueue(t) {
    this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._queuedChunks.push(t), this._loaded += t.byteLength);
  }
  get headersReady() {
    return this._headersReady;
  }
  get filename() {
    return this._filename;
  }
  get isRangeSupported() {
    return this._stream._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._stream._isStreamingSupported;
  }
  get contentLength() {
    return this._stream._contentLength;
  }
  async read() {
    if (this._queuedChunks.length > 0)
      return {
        value: this._queuedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0;
  }
  progressiveDone() {
    this._done || (this._done = !0);
  }
}
class tA {
  constructor(t, e, i) {
    this._stream = t, this._begin = e, this._end = i, this._queuedChunk = null, this._requests = [], this._done = !1, this.onProgress = null;
  }
  _enqueue(t) {
    if (!this._done) {
      if (this._requests.length === 0)
        this._queuedChunk = t;
      else {
        this._requests.shift().resolve({
          value: t,
          done: !1
        });
        for (const i of this._requests)
          i.resolve({
            value: void 0,
            done: !0
          });
        this._requests.length = 0;
      }
      this._done = !0, this._stream._removeRangeReader(this);
    }
  }
  get isStreamingSupported() {
    return !1;
  }
  async read() {
    if (this._queuedChunk) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._stream._removeRangeReader(this);
  }
}
function eA(d) {
  let t = !0, e = i("filename\\*", "i").exec(d);
  if (e) {
    e = e[1];
    let c = o(e);
    return c = unescape(c), c = l(c), c = h(c), r(c);
  }
  if (e = a(d), e) {
    const c = h(e);
    return r(c);
  }
  if (e = i("filename", "i").exec(d), e) {
    e = e[1];
    let c = o(e);
    return c = h(c), r(c);
  }
  function i(c, u) {
    return new RegExp("(?:^|;)\\s*" + c + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', u);
  }
  function s(c, u) {
    if (c) {
      if (!/^[\x00-\xFF]+$/.test(u))
        return u;
      try {
        const f = new TextDecoder(c, {
          fatal: !0
        }), m = Id(u);
        u = f.decode(m), t = !1;
      } catch {
      }
    }
    return u;
  }
  function r(c) {
    return t && /[\x80-\xff]/.test(c) && (c = s("utf-8", c), t && (c = s("iso-8859-1", c))), c;
  }
  function a(c) {
    const u = [];
    let f;
    const m = i("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
    for (; (f = m.exec(c)) !== null; ) {
      let [, y, v, w] = f;
      if (y = parseInt(y, 10), y in u) {
        if (y === 0)
          break;
        continue;
      }
      u[y] = [v, w];
    }
    const A = [];
    for (let y = 0; y < u.length && y in u; ++y) {
      let [v, w] = u[y];
      w = o(w), v && (w = unescape(w), y === 0 && (w = l(w))), A.push(w);
    }
    return A.join("");
  }
  function o(c) {
    if (c.startsWith('"')) {
      const u = c.slice(1).split('\\"');
      for (let f = 0; f < u.length; ++f) {
        const m = u[f].indexOf('"');
        m !== -1 && (u[f] = u[f].slice(0, m), u.length = f + 1), u[f] = u[f].replaceAll(/\\(.)/g, "$1");
      }
      c = u.join('"');
    }
    return c;
  }
  function l(c) {
    const u = c.indexOf("'");
    if (u === -1)
      return c;
    const f = c.slice(0, u), A = c.slice(u + 1).replace(/^[^']*'/, "");
    return s(f, A);
  }
  function h(c) {
    return !c.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(c) ? c : c.replaceAll(/=\?([\w-]*)\?([QqBb])\?((?:[^?]|\?(?!=))*)\?=/g, function(u, f, m, A) {
      if (m === "q" || m === "Q")
        return A = A.replaceAll("_", " "), A = A.replaceAll(/=([0-9a-fA-F]{2})/g, function(y, v) {
          return String.fromCharCode(parseInt(v, 16));
        }), s(f, A);
      try {
        A = atob(A);
      } catch {
      }
      return s(f, A);
    });
  }
  return "";
}
function wb(d, t) {
  const e = new Headers();
  if (!d || !t || typeof t != "object")
    return e;
  for (const i in t) {
    const s = t[i];
    s !== void 0 && e.append(i, s);
  }
  return e;
}
function mf(d) {
  var t;
  return ((t = URL.parse(d)) == null ? void 0 : t.origin) ?? null;
}
function vb({
  responseHeaders: d,
  isHttp: t,
  rangeChunkSize: e,
  disableRange: i
}) {
  const s = {
    allowRangeRequests: !1,
    suggestedLength: void 0
  }, r = parseInt(d.get("Content-Length"), 10);
  return !Number.isInteger(r) || (s.suggestedLength = r, r <= 2 * e) || i || !t || d.get("Accept-Ranges") !== "bytes" || (d.get("Content-Encoding") || "identity") !== "identity" || (s.allowRangeRequests = !0), s;
}
function Eb(d) {
  const t = d.get("Content-Disposition");
  if (t) {
    let e = eA(t);
    if (e.includes("%"))
      try {
        e = decodeURIComponent(e);
      } catch {
      }
    if (gf(e))
      return e;
  }
  return null;
}
function Bd(d, t) {
  return new Wh(`Unexpected server response (${d}) while retrieving PDF "${t}".`, d, d === 404 || d === 0 && t.startsWith("file:"));
}
function Sb(d) {
  return d === 200 || d === 206;
}
function _b(d, t, e) {
  return {
    method: "GET",
    headers: d,
    signal: e.signal,
    mode: "cors",
    credentials: t ? "include" : "same-origin",
    redirect: "follow"
  };
}
function xb(d) {
  return d instanceof Uint8Array ? d.buffer : d instanceof ArrayBuffer ? d : (J(`getArrayBuffer - unexpected data format: ${d}`), new Uint8Array(d).buffer);
}
class iA {
  constructor(t) {
    M(this, "_responseOrigin", null);
    this.source = t, this.isHttp = /^https?:/i.test(t.url), this.headers = wb(this.isHttp, t.httpHeaders), this._fullRequestReader = null, this._rangeRequestReaders = [];
  }
  get _progressiveDataLength() {
    var t;
    return ((t = this._fullRequestReader) == null ? void 0 : t._loaded) ?? 0;
  }
  getFullReader() {
    return dt(!this._fullRequestReader, "PDFFetchStream.getFullReader can only be called once."), this._fullRequestReader = new sA(this), this._fullRequestReader;
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const i = new nA(this, t, e);
    return this._rangeRequestReaders.push(i), i;
  }
  cancelAllRequests(t) {
    var e;
    (e = this._fullRequestReader) == null || e.cancel(t);
    for (const i of this._rangeRequestReaders.slice(0))
      i.cancel(t);
  }
}
class sA {
  constructor(t) {
    this._stream = t, this._reader = null, this._loaded = 0, this._filename = null;
    const e = t.source;
    this._withCredentials = e.withCredentials || !1, this._contentLength = e.length, this._headersCapability = Promise.withResolvers(), this._disableRange = e.disableRange || !1, this._rangeChunkSize = e.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._abortController = new AbortController(), this._isStreamingSupported = !e.disableStream, this._isRangeSupported = !e.disableRange;
    const i = new Headers(t.headers), s = e.url;
    fetch(s, _b(i, this._withCredentials, this._abortController)).then((r) => {
      if (t._responseOrigin = mf(r.url), !Sb(r.status))
        throw Bd(r.status, s);
      this._reader = r.body.getReader(), this._headersCapability.resolve();
      const a = r.headers, {
        allowRangeRequests: o,
        suggestedLength: l
      } = vb({
        responseHeaders: a,
        isHttp: t.isHttp,
        rangeChunkSize: this._rangeChunkSize,
        disableRange: this._disableRange
      });
      this._isRangeSupported = o, this._contentLength = l || this._contentLength, this._filename = Eb(a), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new Gn("Streaming is disabled."));
    }).catch(this._headersCapability.reject), this.onProgress = null;
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  get filename() {
    return this._filename;
  }
  get contentLength() {
    return this._contentLength;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    var i;
    await this._headersCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.byteLength, (i = this.onProgress) == null || i.call(this, {
      loaded: this._loaded,
      total: this._contentLength
    }), {
      value: xb(t),
      done: !1
    });
  }
  cancel(t) {
    var e;
    (e = this._reader) == null || e.cancel(t), this._abortController.abort();
  }
}
class nA {
  constructor(t, e, i) {
    this._stream = t, this._reader = null, this._loaded = 0;
    const s = t.source;
    this._withCredentials = s.withCredentials || !1, this._readCapability = Promise.withResolvers(), this._isStreamingSupported = !s.disableStream, this._abortController = new AbortController();
    const r = new Headers(t.headers);
    r.append("Range", `bytes=${e}-${i - 1}`);
    const a = s.url;
    fetch(a, _b(r, this._withCredentials, this._abortController)).then((o) => {
      const l = mf(o.url);
      if (l !== t._responseOrigin)
        throw new Error(`Expected range response-origin "${l}" to match "${t._responseOrigin}".`);
      if (!Sb(o.status))
        throw Bd(o.status, a);
      this._readCapability.resolve(), this._reader = o.body.getReader();
    }).catch(this._readCapability.reject), this.onProgress = null;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    var i;
    await this._readCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.byteLength, (i = this.onProgress) == null || i.call(this, {
      loaded: this._loaded
    }), {
      value: xb(t),
      done: !1
    });
  }
  cancel(t) {
    var e;
    (e = this._reader) == null || e.cancel(t), this._abortController.abort();
  }
}
const Df = 200, If = 206;
function rA(d) {
  const t = d.response;
  return typeof t != "string" ? t : Id(t).buffer;
}
class aA {
  constructor({
    url: t,
    httpHeaders: e,
    withCredentials: i
  }) {
    M(this, "_responseOrigin", null);
    this.url = t, this.isHttp = /^https?:/i.test(t), this.headers = wb(this.isHttp, e), this.withCredentials = i || !1, this.currXhrId = 0, this.pendingRequests = /* @__PURE__ */ Object.create(null);
  }
  request(t) {
    const e = new XMLHttpRequest(), i = this.currXhrId++, s = this.pendingRequests[i] = {
      xhr: e
    };
    e.open("GET", this.url), e.withCredentials = this.withCredentials;
    for (const [r, a] of this.headers)
      e.setRequestHeader(r, a);
    return this.isHttp && "begin" in t && "end" in t ? (e.setRequestHeader("Range", `bytes=${t.begin}-${t.end - 1}`), s.expectedStatus = If) : s.expectedStatus = Df, e.responseType = "arraybuffer", dt(t.onError, "Expected `onError` callback to be provided."), e.onerror = () => {
      t.onError(e.status);
    }, e.onreadystatechange = this.onStateChange.bind(this, i), e.onprogress = this.onProgress.bind(this, i), s.onHeadersReceived = t.onHeadersReceived, s.onDone = t.onDone, s.onError = t.onError, s.onProgress = t.onProgress, e.send(null), i;
  }
  onProgress(t, e) {
    var s;
    const i = this.pendingRequests[t];
    i && ((s = i.onProgress) == null || s.call(i, e));
  }
  onStateChange(t, e) {
    const i = this.pendingRequests[t];
    if (!i)
      return;
    const s = i.xhr;
    if (s.readyState >= 2 && i.onHeadersReceived && (i.onHeadersReceived(), delete i.onHeadersReceived), s.readyState !== 4 || !(t in this.pendingRequests))
      return;
    if (delete this.pendingRequests[t], s.status === 0 && this.isHttp) {
      i.onError(s.status);
      return;
    }
    const r = s.status || Df;
    if (!(r === Df && i.expectedStatus === If) && r !== i.expectedStatus) {
      i.onError(s.status);
      return;
    }
    const o = rA(s);
    if (r === If) {
      const l = s.getResponseHeader("Content-Range"), h = /bytes (\d+)-(\d+)\/(\d+)/.exec(l);
      h ? i.onDone({
        begin: parseInt(h[1], 10),
        chunk: o
      }) : (J('Missing or invalid "Content-Range" header.'), i.onError(0));
    } else o ? i.onDone({
      begin: 0,
      chunk: o
    }) : i.onError(s.status);
  }
  getRequestXhr(t) {
    return this.pendingRequests[t].xhr;
  }
  isPendingRequest(t) {
    return t in this.pendingRequests;
  }
  abortRequest(t) {
    const e = this.pendingRequests[t].xhr;
    delete this.pendingRequests[t], e.abort();
  }
}
class oA {
  constructor(t) {
    this._source = t, this._manager = new aA(t), this._rangeChunkSize = t.rangeChunkSize, this._fullRequestReader = null, this._rangeRequestReaders = [];
  }
  _onRangeRequestReaderClosed(t) {
    const e = this._rangeRequestReaders.indexOf(t);
    e >= 0 && this._rangeRequestReaders.splice(e, 1);
  }
  getFullReader() {
    return dt(!this._fullRequestReader, "PDFNetworkStream.getFullReader can only be called once."), this._fullRequestReader = new lA(this._manager, this._source), this._fullRequestReader;
  }
  getRangeReader(t, e) {
    const i = new hA(this._manager, t, e);
    return i.onClosed = this._onRangeRequestReaderClosed.bind(this), this._rangeRequestReaders.push(i), i;
  }
  cancelAllRequests(t) {
    var e;
    (e = this._fullRequestReader) == null || e.cancel(t);
    for (const i of this._rangeRequestReaders.slice(0))
      i.cancel(t);
  }
}
class lA {
  constructor(t, e) {
    this._manager = t, this._url = e.url, this._fullRequestId = t.request({
      onHeadersReceived: this._onHeadersReceived.bind(this),
      onDone: this._onDone.bind(this),
      onError: this._onError.bind(this),
      onProgress: this._onProgress.bind(this)
    }), this._headersCapability = Promise.withResolvers(), this._disableRange = e.disableRange || !1, this._contentLength = e.length, this._rangeChunkSize = e.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !1, this._isRangeSupported = !1, this._cachedChunks = [], this._requests = [], this._done = !1, this._storedError = void 0, this._filename = null, this.onProgress = null;
  }
  _onHeadersReceived() {
    const t = this._fullRequestId, e = this._manager.getRequestXhr(t);
    this._manager._responseOrigin = mf(e.responseURL);
    const i = e.getAllResponseHeaders(), s = new Headers(i ? i.trimStart().replace(/[^\S ]+$/, "").split(/[\r\n]+/).map((o) => {
      const [l, ...h] = o.split(": ");
      return [l, h.join(": ")];
    }) : []), {
      allowRangeRequests: r,
      suggestedLength: a
    } = vb({
      responseHeaders: s,
      isHttp: this._manager.isHttp,
      rangeChunkSize: this._rangeChunkSize,
      disableRange: this._disableRange
    });
    r && (this._isRangeSupported = !0), this._contentLength = a || this._contentLength, this._filename = Eb(s), this._isRangeSupported && this._manager.abortRequest(t), this._headersCapability.resolve();
  }
  _onDone(t) {
    if (t && (this._requests.length > 0 ? this._requests.shift().resolve({
      value: t.chunk,
      done: !1
    }) : this._cachedChunks.push(t.chunk)), this._done = !0, !(this._cachedChunks.length > 0)) {
      for (const e of this._requests)
        e.resolve({
          value: void 0,
          done: !0
        });
      this._requests.length = 0;
    }
  }
  _onError(t) {
    this._storedError = Bd(t, this._url), this._headersCapability.reject(this._storedError);
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._cachedChunks.length = 0;
  }
  _onProgress(t) {
    var e;
    (e = this.onProgress) == null || e.call(this, {
      loaded: t.loaded,
      total: t.lengthComputable ? t.total : this._contentLength
    });
  }
  get filename() {
    return this._filename;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  get contentLength() {
    return this._contentLength;
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  async read() {
    if (await this._headersCapability.promise, this._storedError)
      throw this._storedError;
    if (this._cachedChunks.length > 0)
      return {
        value: this._cachedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this._headersCapability.reject(t);
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._manager.isPendingRequest(this._fullRequestId) && this._manager.abortRequest(this._fullRequestId), this._fullRequestReader = null;
  }
}
class hA {
  constructor(t, e, i) {
    this._manager = t, this._url = t.url, this._requestId = t.request({
      begin: e,
      end: i,
      onHeadersReceived: this._onHeadersReceived.bind(this),
      onDone: this._onDone.bind(this),
      onError: this._onError.bind(this),
      onProgress: this._onProgress.bind(this)
    }), this._requests = [], this._queuedChunk = null, this._done = !1, this._storedError = void 0, this.onProgress = null, this.onClosed = null;
  }
  _onHeadersReceived() {
    var e;
    const t = mf((e = this._manager.getRequestXhr(this._requestId)) == null ? void 0 : e.responseURL);
    t !== this._manager._responseOrigin && (this._storedError = new Error(`Expected range response-origin "${t}" to match "${this._manager._responseOrigin}".`), this._onError(0));
  }
  _close() {
    var t;
    (t = this.onClosed) == null || t.call(this, this);
  }
  _onDone(t) {
    const e = t.chunk;
    this._requests.length > 0 ? this._requests.shift().resolve({
      value: e,
      done: !1
    }) : this._queuedChunk = e, this._done = !0;
    for (const i of this._requests)
      i.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._close();
  }
  _onError(t) {
    this._storedError ?? (this._storedError = Bd(t, this._url));
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._queuedChunk = null;
  }
  _onProgress(t) {
    var e;
    this.isStreamingSupported || (e = this.onProgress) == null || e.call(this, {
      loaded: t.loaded
    });
  }
  get isStreamingSupported() {
    return !1;
  }
  async read() {
    if (this._storedError)
      throw this._storedError;
    if (this._queuedChunk !== null) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0;
    for (const e of this._requests)
      e.resolve({
        value: void 0,
        done: !0
      });
    this._requests.length = 0, this._manager.isPendingRequest(this._requestId) && this._manager.abortRequest(this._requestId), this._close();
  }
}
const cA = /^[a-z][a-z0-9\-+.]+:/i;
function dA(d) {
  if (cA.test(d))
    return new URL(d);
  const t = process.getBuiltinModule("url");
  return new URL(t.pathToFileURL(d));
}
class uA {
  constructor(t) {
    this.source = t, this.url = dA(t.url), dt(this.url.protocol === "file:", "PDFNodeStream only supports file:// URLs."), this._fullRequestReader = null, this._rangeRequestReaders = [];
  }
  get _progressiveDataLength() {
    var t;
    return ((t = this._fullRequestReader) == null ? void 0 : t._loaded) ?? 0;
  }
  getFullReader() {
    return dt(!this._fullRequestReader, "PDFNodeStream.getFullReader can only be called once."), this._fullRequestReader = new fA(this), this._fullRequestReader;
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const i = new pA(this, t, e);
    return this._rangeRequestReaders.push(i), i;
  }
  cancelAllRequests(t) {
    var e;
    (e = this._fullRequestReader) == null || e.cancel(t);
    for (const i of this._rangeRequestReaders.slice(0))
      i.cancel(t);
  }
}
class fA {
  constructor(t) {
    this._url = t.url, this._done = !1, this._storedError = null, this.onProgress = null;
    const e = t.source;
    this._contentLength = e.length, this._loaded = 0, this._filename = null, this._disableRange = e.disableRange || !1, this._rangeChunkSize = e.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !e.disableStream, this._isRangeSupported = !e.disableRange, this._readableStream = null, this._readCapability = Promise.withResolvers(), this._headersCapability = Promise.withResolvers();
    const i = process.getBuiltinModule("fs");
    i.promises.lstat(this._url).then((s) => {
      this._contentLength = s.size, this._setReadableStream(i.createReadStream(this._url)), this._headersCapability.resolve();
    }, (s) => {
      s.code === "ENOENT" && (s = Bd(0, this._url.href)), this._storedError = s, this._headersCapability.reject(s);
    });
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  get filename() {
    return this._filename;
  }
  get contentLength() {
    return this._contentLength;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    var i;
    if (await this._readCapability.promise, this._done)
      return {
        value: void 0,
        done: !0
      };
    if (this._storedError)
      throw this._storedError;
    const t = this._readableStream.read();
    return t === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += t.length, (i = this.onProgress) == null || i.call(this, {
      loaded: this._loaded,
      total: this._contentLength
    }), {
      value: new Uint8Array(t).buffer,
      done: !1
    });
  }
  cancel(t) {
    if (!this._readableStream) {
      this._error(t);
      return;
    }
    this._readableStream.destroy(t);
  }
  _error(t) {
    this._storedError = t, this._readCapability.resolve();
  }
  _setReadableStream(t) {
    this._readableStream = t, t.on("readable", () => {
      this._readCapability.resolve();
    }), t.on("end", () => {
      t.destroy(), this._done = !0, this._readCapability.resolve();
    }), t.on("error", (e) => {
      this._error(e);
    }), !this._isStreamingSupported && this._isRangeSupported && this._error(new Gn("streaming is disabled")), this._storedError && this._readableStream.destroy(this._storedError);
  }
}
class pA {
  constructor(t, e, i) {
    this._url = t.url, this._done = !1, this._storedError = null, this.onProgress = null, this._loaded = 0, this._readableStream = null, this._readCapability = Promise.withResolvers();
    const s = t.source;
    this._isStreamingSupported = !s.disableStream;
    const r = process.getBuiltinModule("fs");
    this._setReadableStream(r.createReadStream(this._url, {
      start: e,
      end: i - 1
    }));
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    var i;
    if (await this._readCapability.promise, this._done)
      return {
        value: void 0,
        done: !0
      };
    if (this._storedError)
      throw this._storedError;
    const t = this._readableStream.read();
    return t === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += t.length, (i = this.onProgress) == null || i.call(this, {
      loaded: this._loaded
    }), {
      value: new Uint8Array(t).buffer,
      done: !1
    });
  }
  cancel(t) {
    if (!this._readableStream) {
      this._error(t);
      return;
    }
    this._readableStream.destroy(t);
  }
  _error(t) {
    this._storedError = t, this._readCapability.resolve();
  }
  _setReadableStream(t) {
    this._readableStream = t, t.on("readable", () => {
      this._readCapability.resolve();
    }), t.on("end", () => {
      t.destroy(), this._done = !0, this._readCapability.resolve();
    }), t.on("error", (e) => {
      this._error(e);
    }), this._storedError && this._readableStream.destroy(this._storedError);
  }
}
const Ah = Symbol("INITIAL_DATA");
var _i, Hc, yp;
class Cb {
  constructor() {
    g(this, Hc);
    g(this, _i, /* @__PURE__ */ Object.create(null));
  }
  get(t, e = null) {
    if (e) {
      const s = b(this, Hc, yp).call(this, t);
      return s.promise.then(() => e(s.data)), null;
    }
    const i = n(this, _i)[t];
    if (!i || i.data === Ah)
      throw new Error(`Requesting object that isn't resolved yet ${t}.`);
    return i.data;
  }
  has(t) {
    const e = n(this, _i)[t];
    return !!e && e.data !== Ah;
  }
  delete(t) {
    const e = n(this, _i)[t];
    return !e || e.data === Ah ? !1 : (delete n(this, _i)[t], !0);
  }
  resolve(t, e = null) {
    const i = b(this, Hc, yp).call(this, t);
    i.data = e, i.resolve();
  }
  clear() {
    var t;
    for (const e in n(this, _i)) {
      const {
        data: i
      } = n(this, _i)[e];
      (t = i == null ? void 0 : i.bitmap) == null || t.close();
    }
    p(this, _i, /* @__PURE__ */ Object.create(null));
  }
  *[Symbol.iterator]() {
    for (const t in n(this, _i)) {
      const {
        data: e
      } = n(this, _i)[t];
      e !== Ah && (yield [t, e]);
    }
  }
}
_i = new WeakMap(), Hc = new WeakSet(), yp = function(t) {
  var e;
  return (e = n(this, _i))[t] || (e[t] = {
    ...Promise.withResolvers(),
    data: Ah
  });
};
const gA = 1e5, sm = 30;
var ym, yr, fi, Uc, $c, Da, xn, Vc, zc, Ia, Sl, _l, Ar, xl, Gc, Cl, Fa, Wc, jc, Kt, Tl, Na, qc, wr, Pl, qn, Tb, Pb, Ap, Ui, uu, wp, Lb, kb;
let Yh = (Kt = class {
  constructor({
    textContentSource: t,
    container: e,
    viewport: i
  }) {
    g(this, qn);
    g(this, yr, Promise.withResolvers());
    g(this, fi, null);
    g(this, Uc, !1);
    g(this, $c, !!((ym = globalThis.FontInspector) != null && ym.enabled));
    g(this, Da, null);
    g(this, xn, null);
    g(this, Vc, 0);
    g(this, zc, 0);
    g(this, Ia, null);
    g(this, Sl, null);
    g(this, _l, 0);
    g(this, Ar, 0);
    g(this, xl, /* @__PURE__ */ Object.create(null));
    g(this, Gc, []);
    g(this, Cl, null);
    g(this, Fa, []);
    g(this, Wc, /* @__PURE__ */ new WeakMap());
    g(this, jc, null);
    var l;
    if (t instanceof ReadableStream)
      p(this, Cl, t);
    else if (typeof t == "object")
      p(this, Cl, new ReadableStream({
        start(h) {
          h.enqueue(t), h.close();
        }
      }));
    else
      throw new Error('No "textContentSource" parameter specified.');
    p(this, fi, p(this, Sl, e)), p(this, Ar, i.scale * Ss.pixelRatio), p(this, _l, i.rotation), p(this, xn, {
      div: null,
      properties: null,
      ctx: null
    });
    const {
      pageWidth: s,
      pageHeight: r,
      pageX: a,
      pageY: o
    } = i.rawDims;
    p(this, jc, [1, 0, 0, -1, -a, o + r]), p(this, zc, s), p(this, Vc, r), b(l = Kt, Ui, Lb).call(l), Wr(e, i), n(this, yr).promise.finally(() => {
      n(Kt, Pl).delete(this), p(this, xn, null), p(this, xl, null);
    }).catch(() => {
    });
  }
  static get fontFamilyMap() {
    const {
      isWindows: t,
      isFirefox: e
    } = _e.platform;
    return st(this, "fontFamilyMap", /* @__PURE__ */ new Map([["sans-serif", `${t && e ? "Calibri, " : ""}sans-serif`], ["monospace", `${t && e ? "Lucida Console, " : ""}monospace`]]));
  }
  render() {
    const t = () => {
      n(this, Ia).read().then(({
        value: e,
        done: i
      }) => {
        if (i) {
          n(this, yr).resolve();
          return;
        }
        n(this, Da) ?? p(this, Da, e.lang), Object.assign(n(this, xl), e.styles), b(this, qn, Tb).call(this, e.items), t();
      }, n(this, yr).reject);
    };
    return p(this, Ia, n(this, Cl).getReader()), n(Kt, Pl).add(this), t(), n(this, yr).promise;
  }
  update({
    viewport: t,
    onBefore: e = null
  }) {
    var r;
    const i = t.scale * Ss.pixelRatio, s = t.rotation;
    if (s !== n(this, _l) && (e == null || e(), p(this, _l, s), Wr(n(this, Sl), {
      rotation: s
    })), i !== n(this, Ar)) {
      e == null || e(), p(this, Ar, i);
      const a = {
        div: null,
        properties: null,
        ctx: b(r = Kt, Ui, uu).call(r, n(this, Da))
      };
      for (const o of n(this, Fa))
        a.properties = n(this, Wc).get(o), a.div = o, b(this, qn, Ap).call(this, a);
    }
  }
  cancel() {
    var e;
    const t = new Gn("TextLayer task cancelled.");
    (e = n(this, Ia)) == null || e.cancel(t).catch(() => {
    }), p(this, Ia, null), n(this, yr).reject(t);
  }
  get textDivs() {
    return n(this, Fa);
  }
  get textContentItemsStr() {
    return n(this, Gc);
  }
  static cleanup() {
    if (!(n(this, Pl).size > 0)) {
      n(this, Tl).clear();
      for (const {
        canvas: t
      } of n(this, Na).values())
        t.remove();
      n(this, Na).clear();
    }
  }
}, yr = new WeakMap(), fi = new WeakMap(), Uc = new WeakMap(), $c = new WeakMap(), Da = new WeakMap(), xn = new WeakMap(), Vc = new WeakMap(), zc = new WeakMap(), Ia = new WeakMap(), Sl = new WeakMap(), _l = new WeakMap(), Ar = new WeakMap(), xl = new WeakMap(), Gc = new WeakMap(), Cl = new WeakMap(), Fa = new WeakMap(), Wc = new WeakMap(), jc = new WeakMap(), Tl = new WeakMap(), Na = new WeakMap(), qc = new WeakMap(), wr = new WeakMap(), Pl = new WeakMap(), qn = new WeakSet(), Tb = function(t) {
  var s, r;
  if (n(this, Uc))
    return;
  (r = n(this, xn)).ctx ?? (r.ctx = b(s = Kt, Ui, uu).call(s, n(this, Da)));
  const e = n(this, Fa), i = n(this, Gc);
  for (const a of t) {
    if (e.length > gA) {
      J("Ignoring additional textDivs for performance reasons."), p(this, Uc, !0);
      return;
    }
    if (a.str === void 0) {
      if (a.type === "beginMarkedContentProps" || a.type === "beginMarkedContent") {
        const o = n(this, fi);
        p(this, fi, document.createElement("span")), n(this, fi).classList.add("markedContent"), a.id && n(this, fi).setAttribute("id", `${a.id}`), o.append(n(this, fi));
      } else a.type === "endMarkedContent" && p(this, fi, n(this, fi).parentNode);
      continue;
    }
    i.push(a.str), b(this, qn, Pb).call(this, a);
  }
}, Pb = function(t) {
  var y;
  const e = document.createElement("span"), i = {
    angle: 0,
    canvasWidth: 0,
    hasText: t.str !== "",
    hasEOL: t.hasEOL,
    fontSize: 0
  };
  n(this, Fa).push(e);
  const s = z.transform(n(this, jc), t.transform);
  let r = Math.atan2(s[1], s[0]);
  const a = n(this, xl)[t.fontName];
  a.vertical && (r += Math.PI / 2);
  let o = n(this, $c) && a.fontSubstitution || a.fontFamily;
  o = Kt.fontFamilyMap.get(o) || o;
  const l = Math.hypot(s[2], s[3]), h = l * b(y = Kt, Ui, kb).call(y, o, a, n(this, Da));
  let c, u;
  r === 0 ? (c = s[4], u = s[5] - h) : (c = s[4] + h * Math.sin(r), u = s[5] - h * Math.cos(r));
  const f = "calc(var(--total-scale-factor) *", m = e.style;
  n(this, fi) === n(this, Sl) ? (m.left = `${(100 * c / n(this, zc)).toFixed(2)}%`, m.top = `${(100 * u / n(this, Vc)).toFixed(2)}%`) : (m.left = `${f}${c.toFixed(2)}px)`, m.top = `${f}${u.toFixed(2)}px)`), m.fontSize = `${f}${(n(Kt, wr) * l).toFixed(2)}px)`, m.fontFamily = o, i.fontSize = l, e.setAttribute("role", "presentation"), e.textContent = t.str, e.dir = t.dir, n(this, $c) && (e.dataset.fontName = a.fontSubstitutionLoadedName || t.fontName), r !== 0 && (i.angle = r * (180 / Math.PI));
  let A = !1;
  if (t.str.length > 1)
    A = !0;
  else if (t.str !== " " && t.transform[0] !== t.transform[3]) {
    const v = Math.abs(t.transform[0]), w = Math.abs(t.transform[3]);
    v !== w && Math.max(v, w) / Math.min(v, w) > 1.5 && (A = !0);
  }
  if (A && (i.canvasWidth = a.vertical ? t.height : t.width), n(this, Wc).set(e, i), n(this, xn).div = e, n(this, xn).properties = i, b(this, qn, Ap).call(this, n(this, xn)), i.hasText && n(this, fi).append(e), i.hasEOL) {
    const v = document.createElement("br");
    v.setAttribute("role", "presentation"), n(this, fi).append(v);
  }
}, Ap = function(t) {
  var o;
  const {
    div: e,
    properties: i,
    ctx: s
  } = t, {
    style: r
  } = e;
  let a = "";
  if (n(Kt, wr) > 1 && (a = `scale(${1 / n(Kt, wr)})`), i.canvasWidth !== 0 && i.hasText) {
    const {
      fontFamily: l
    } = r, {
      canvasWidth: h,
      fontSize: c
    } = i;
    b(o = Kt, Ui, wp).call(o, s, c * n(this, Ar), l);
    const {
      width: u
    } = s.measureText(e.textContent);
    u > 0 && (a = `scaleX(${h * n(this, Ar) / u}) ${a}`);
  }
  i.angle !== 0 && (a = `rotate(${i.angle}deg) ${a}`), a.length > 0 && (r.transform = a);
}, Ui = new WeakSet(), uu = function(t = null) {
  let e = n(this, Na).get(t || (t = ""));
  if (!e) {
    const i = document.createElement("canvas");
    i.className = "hiddenCanvasElement", i.lang = t, document.body.append(i), e = i.getContext("2d", {
      alpha: !1,
      willReadFrequently: !0
    }), n(this, Na).set(t, e), n(this, qc).set(e, {
      size: 0,
      family: ""
    });
  }
  return e;
}, wp = function(t, e, i) {
  const s = n(this, qc).get(t);
  e === s.size && i === s.family || (t.font = `${e}px ${i}`, s.size = e, s.family = i);
}, Lb = function() {
  if (n(this, wr) !== null)
    return;
  const t = document.createElement("div");
  t.style.opacity = 0, t.style.lineHeight = 1, t.style.fontSize = "1px", t.style.position = "absolute", t.textContent = "X", document.body.append(t), p(this, wr, t.getBoundingClientRect().height), t.remove();
}, kb = function(t, e, i) {
  const s = n(this, Tl).get(t);
  if (s)
    return s;
  const r = b(this, Ui, uu).call(this, i);
  r.canvas.width = r.canvas.height = sm, b(this, Ui, wp).call(this, r, sm, t);
  const a = r.measureText(""), o = a.fontBoundingBoxAscent, l = Math.abs(a.fontBoundingBoxDescent);
  r.canvas.width = r.canvas.height = 0;
  let h = 0.8;
  return o ? h = o / (o + l) : (_e.platform.isFirefox && J("Enable the `dom.textMetrics.fontBoundingBox.enabled` preference in `about:config` to improve TextLayer rendering."), e.ascent ? h = e.ascent : e.descent && (h = 1 + e.descent)), n(this, Tl).set(t, h), h;
}, g(Kt, Ui), g(Kt, Tl, /* @__PURE__ */ new Map()), g(Kt, Na, /* @__PURE__ */ new Map()), g(Kt, qc, /* @__PURE__ */ new WeakMap()), g(Kt, wr, null), g(Kt, Pl, /* @__PURE__ */ new Set()), Kt);
const mA = 100;
function wg(d = {}) {
  typeof d == "string" || d instanceof URL ? d = {
    url: d
  } : (d instanceof ArrayBuffer || ArrayBuffer.isView(d)) && (d = {
    data: d
  });
  const t = new vp(), {
    docId: e
  } = t, i = d.url ? _y(d.url) : null, s = d.data ? xy(d.data) : null, r = d.httpHeaders || null, a = d.withCredentials === !0, o = d.password ?? null, l = d.range instanceof vg ? d.range : null, h = Number.isInteger(d.rangeChunkSize) && d.rangeChunkSize > 0 ? d.rangeChunkSize : 2 ** 16;
  let c = d.worker instanceof uh ? d.worker : null;
  const u = d.verbosity, f = typeof d.docBaseUrl == "string" && !Nd(d.docBaseUrl) ? d.docBaseUrl : null, m = Xd(d.cMapUrl), A = d.cMapPacked !== !1, y = d.CMapReaderFactory || (ii ? My : zg), v = Xd(d.iccUrl), w = Xd(d.standardFontDataUrl), S = d.StandardFontDataFactory || (ii ? Dy : Gg), E = Xd(d.wasmUrl), _ = d.WasmFactory || (ii ? Iy : Wg), x = d.stopAtErrors !== !0, C = Number.isInteger(d.maxImageSize) && d.maxImageSize > -1 ? d.maxImageSize : -1, T = d.isEvalSupported !== !1, L = typeof d.isOffscreenCanvasSupported == "boolean" ? d.isOffscreenCanvasSupported : !ii, k = typeof d.isImageDecoderSupported == "boolean" ? d.isImageDecoderSupported : !ii && (_e.platform.isFirefox || !globalThis.chrome), D = Number.isInteger(d.canvasMaxAreaInBytes) ? d.canvasMaxAreaInBytes : -1, R = typeof d.disableFontFace == "boolean" ? d.disableFontFace : ii, N = d.fontExtraProperties === !0, q = d.enableXfa === !0, B = d.ownerDocument || globalThis.document, Y = d.disableRange === !0, O = d.disableStream === !0, H = d.disableAutoFetch === !0, it = d.pdfBug === !0, at = d.CanvasFactory || (ii ? Ry : Py), Jt = d.FilterFactory || (ii ? ky : Ly), Xe = d.enableHWA === !0, lt = d.useWasm !== !1, tt = l ? l.length : d.length ?? NaN, vt = typeof d.useSystemFonts == "boolean" ? d.useSystemFonts : !ii && !R, se = typeof d.useWorkerFetch == "boolean" ? d.useWorkerFetch : !!(y === zg && S === Gg && _ === Wg && m && w && E && Eh(m, document.baseURI) && Eh(w, document.baseURI) && Eh(E, document.baseURI)), fe = null;
  ry(u);
  const ct = {
    canvasFactory: new at({
      ownerDocument: B,
      enableHWA: Xe
    }),
    filterFactory: new Jt({
      docId: e,
      ownerDocument: B
    }),
    cMapReaderFactory: se ? null : new y({
      baseUrl: m,
      isCompressed: A
    }),
    standardFontDataFactory: se ? null : new S({
      baseUrl: w
    }),
    wasmFactory: se ? null : new _({
      baseUrl: E
    })
  };
  c || (c = uh.create({
    verbosity: u,
    port: ns.workerPort
  }), t._worker = c);
  const bi = {
    docId: e,
    apiVersion: "5.4.296",
    data: s,
    password: o,
    disableAutoFetch: H,
    rangeChunkSize: h,
    length: tt,
    docBaseUrl: f,
    enableXfa: q,
    evaluatorOptions: {
      maxImageSize: C,
      disableFontFace: R,
      ignoreErrors: x,
      isEvalSupported: T,
      isOffscreenCanvasSupported: L,
      isImageDecoderSupported: k,
      canvasMaxAreaInBytes: D,
      fontExtraProperties: N,
      useSystemFonts: vt,
      useWasm: lt,
      useWorkerFetch: se,
      cMapUrl: m,
      iccUrl: v,
      standardFontDataUrl: w,
      wasmUrl: E
    }
  }, Ye = {
    ownerDocument: B,
    pdfBug: it,
    styleElement: fe,
    loadingParams: {
      disableAutoFetch: H,
      enableXfa: q
    }
  };
  return c.promise.then(function() {
    if (t.destroyed)
      throw new Error("Loading aborted");
    if (c.destroyed)
      throw new Error("Worker was destroyed");
    const Vi = c.messageHandler.sendWithPromise("GetDocRequest", bi, s ? [s.buffer] : null);
    let xe;
    if (l)
      xe = new Jy(l, {
        disableRange: Y,
        disableStream: O
      });
    else if (!s) {
      if (!i)
        throw new Error("getDocument - no `url` parameter provided.");
      const Tt = Eh(i) ? iA : ii ? uA : oA;
      xe = new Tt({
        url: i,
        length: tt,
        httpHeaders: r,
        withCredentials: a,
        rangeChunkSize: h,
        disableRange: Y,
        disableStream: O
      });
    }
    return Vi.then((Tt) => {
      if (t.destroyed)
        throw new Error("Loading aborted");
      if (c.destroyed)
        throw new Error("Worker was destroyed");
      const Pt = new Ph(e, Tt, c.port), Wt = new AA(Pt, t, xe, Ye, ct, Xe);
      t._transport = Wt, Pt.send("Ready", null);
    });
  }).catch(t._capability.reject), t;
}
var ef;
const sf = class sf {
  constructor() {
    M(this, "_capability", Promise.withResolvers());
    M(this, "_transport", null);
    M(this, "_worker", null);
    M(this, "docId", `d${oe(sf, ef)._++}`);
    M(this, "destroyed", !1);
    M(this, "onPassword", null);
    M(this, "onProgress", null);
  }
  get promise() {
    return this._capability.promise;
  }
  async destroy() {
    var t, e, i, s;
    this.destroyed = !0;
    try {
      (t = this._worker) != null && t.port && (this._worker._pendingDestroy = !0), await ((e = this._transport) == null ? void 0 : e.destroy());
    } catch (r) {
      throw (i = this._worker) != null && i.port && delete this._worker._pendingDestroy, r;
    }
    this._transport = null, (s = this._worker) == null || s.destroy(), this._worker = null;
  }
  async getData() {
    return this._transport.getData();
  }
};
ef = new WeakMap(), g(sf, ef, 0);
let vp = sf;
var Oa, Xc, Yc, Kc, Zc, Am;
let vg = (Am = class {
  constructor(t, e, i = !1, s = null) {
    g(this, Oa, Promise.withResolvers());
    g(this, Xc, []);
    g(this, Yc, []);
    g(this, Kc, []);
    g(this, Zc, []);
    this.length = t, this.initialData = e, this.progressiveDone = i, this.contentDispositionFilename = s;
  }
  addRangeListener(t) {
    n(this, Zc).push(t);
  }
  addProgressListener(t) {
    n(this, Kc).push(t);
  }
  addProgressiveReadListener(t) {
    n(this, Yc).push(t);
  }
  addProgressiveDoneListener(t) {
    n(this, Xc).push(t);
  }
  onDataRange(t, e) {
    for (const i of n(this, Zc))
      i(t, e);
  }
  onDataProgress(t, e) {
    n(this, Oa).promise.then(() => {
      for (const i of n(this, Kc))
        i(t, e);
    });
  }
  onDataProgressiveRead(t) {
    n(this, Oa).promise.then(() => {
      for (const e of n(this, Yc))
        e(t);
    });
  }
  onDataProgressiveDone() {
    n(this, Oa).promise.then(() => {
      for (const t of n(this, Xc))
        t();
    });
  }
  transportReady() {
    n(this, Oa).resolve();
  }
  requestDataRange(t, e) {
    Dt("Abstract method PDFDataRangeTransport.requestDataRange");
  }
  abort() {
  }
}, Oa = new WeakMap(), Xc = new WeakMap(), Yc = new WeakMap(), Kc = new WeakMap(), Zc = new WeakMap(), Am);
class bA {
  constructor(t, e) {
    this._pdfInfo = t, this._transport = e;
  }
  get annotationStorage() {
    return this._transport.annotationStorage;
  }
  get canvasFactory() {
    return this._transport.canvasFactory;
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get numPages() {
    return this._pdfInfo.numPages;
  }
  get fingerprints() {
    return this._pdfInfo.fingerprints;
  }
  get isPureXfa() {
    return st(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  get allXfaHtml() {
    return this._transport._htmlForXfa;
  }
  getPage(t) {
    return this._transport.getPage(t);
  }
  getPageIndex(t) {
    return this._transport.getPageIndex(t);
  }
  getDestinations() {
    return this._transport.getDestinations();
  }
  getDestination(t) {
    return this._transport.getDestination(t);
  }
  getPageLabels() {
    return this._transport.getPageLabels();
  }
  getPageLayout() {
    return this._transport.getPageLayout();
  }
  getPageMode() {
    return this._transport.getPageMode();
  }
  getViewerPreferences() {
    return this._transport.getViewerPreferences();
  }
  getOpenAction() {
    return this._transport.getOpenAction();
  }
  getAttachments() {
    return this._transport.getAttachments();
  }
  getAnnotationsByType(t, e) {
    return this._transport.getAnnotationsByType(t, e);
  }
  getJSActions() {
    return this._transport.getDocJSActions();
  }
  getOutline() {
    return this._transport.getOutline();
  }
  getOptionalContentConfig({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getOptionalContentConfig(e);
  }
  getPermissions() {
    return this._transport.getPermissions();
  }
  getMetadata() {
    return this._transport.getMetadata();
  }
  getMarkInfo() {
    return this._transport.getMarkInfo();
  }
  getData() {
    return this._transport.getData();
  }
  saveDocument() {
    return this._transport.saveDocument();
  }
  getDownloadInfo() {
    return this._transport.downloadInfoCapability.promise;
  }
  cleanup(t = !1) {
    return this._transport.startCleanup(t || this.isPureXfa);
  }
  destroy() {
    return this.loadingTask.destroy();
  }
  cachedPageNumber(t) {
    return this._transport.cachedPageNumber(t);
  }
  get loadingParams() {
    return this._transport.loadingParams;
  }
  get loadingTask() {
    return this._transport.loadingTask;
  }
  getFieldObjects() {
    return this._transport.getFieldObjects();
  }
  hasJSActions() {
    return this._transport.hasJSActions();
  }
  getCalculationOrderIds() {
    return this._transport.getCalculationOrderIds();
  }
}
var Cn, Ba, Fh;
class yA {
  constructor(t, e, i, s = !1) {
    g(this, Ba);
    g(this, Cn, !1);
    this._pageIndex = t, this._pageInfo = e, this._transport = i, this._stats = s ? new Ng() : null, this._pdfBug = s, this.commonObjs = i.commonObjs, this.objs = new Cb(), this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1, this.recordedBBoxes = null;
  }
  get pageNumber() {
    return this._pageIndex + 1;
  }
  get rotate() {
    return this._pageInfo.rotate;
  }
  get ref() {
    return this._pageInfo.ref;
  }
  get userUnit() {
    return this._pageInfo.userUnit;
  }
  get view() {
    return this._pageInfo.view;
  }
  getViewport({
    scale: t,
    rotation: e = this.rotate,
    offsetX: i = 0,
    offsetY: s = 0,
    dontFlip: r = !1
  } = {}) {
    return new Fd({
      viewBox: this.view,
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: i,
      offsetY: s,
      dontFlip: r
    });
  }
  getAnnotations({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getAnnotations(this._pageIndex, e);
  }
  getJSActions() {
    return this._transport.getPageJSActions(this._pageIndex);
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get isPureXfa() {
    return st(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  async getXfa() {
    var t;
    return ((t = this._transport._htmlForXfa) == null ? void 0 : t.children[this._pageIndex]) || null;
  }
  render({
    canvasContext: t,
    canvas: e = t.canvas,
    viewport: i,
    intent: s = "display",
    annotationMode: r = Zs.ENABLE,
    transform: a = null,
    background: o = null,
    optionalContentConfigPromise: l = null,
    annotationCanvasMap: h = null,
    pageColors: c = null,
    printAnnotationStorage: u = null,
    isEditing: f = !1,
    recordOperations: m = !1,
    operationsFilter: A = null
  }) {
    var k, D, R;
    (k = this._stats) == null || k.time("Overall");
    const y = this._transport.getRenderingIntent(s, r, u, f), {
      renderingIntent: v,
      cacheKey: w
    } = y;
    p(this, Cn, !1), l || (l = this._transport.getOptionalContentConfig(v));
    let S = this._intentStates.get(w);
    S || (S = /* @__PURE__ */ Object.create(null), this._intentStates.set(w, S)), S.streamReaderCancelTimeout && (clearTimeout(S.streamReaderCancelTimeout), S.streamReaderCancelTimeout = null);
    const E = !!(v & Oi.PRINT);
    S.displayReadyCapability || (S.displayReadyCapability = Promise.withResolvers(), S.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, (D = this._stats) == null || D.time("Page Request"), this._pumpOperatorList(y));
    const _ = !!(this._pdfBug && ((R = globalThis.StepperManager) != null && R.enabled)), x = !this.recordedBBoxes && (m || _), C = (N) => {
      var q, B;
      if (S.renderTasks.delete(T), x) {
        const Y = (q = T.gfx) == null ? void 0 : q.dependencyTracker.take();
        Y && (T.stepper && T.stepper.setOperatorBBoxes(Y, T.gfx.dependencyTracker.takeDebugMetadata()), m && (this.recordedBBoxes = Y));
      }
      E && p(this, Cn, !0), b(this, Ba, Fh).call(this), N ? (T.capability.reject(N), this._abortOperatorList({
        intentState: S,
        reason: N instanceof Error ? N : new Error(N)
      })) : T.capability.resolve(), this._stats && (this._stats.timeEnd("Rendering"), this._stats.timeEnd("Overall"), (B = globalThis.Stats) != null && B.enabled && globalThis.Stats.add(this.pageNumber, this._stats));
    }, T = new Ep({
      callback: C,
      params: {
        canvas: e,
        canvasContext: t,
        dependencyTracker: x ? new Ny(e, S.operatorList.length, _) : null,
        viewport: i,
        transform: a,
        background: o
      },
      objs: this.objs,
      commonObjs: this.commonObjs,
      annotationCanvasMap: h,
      operatorList: S.operatorList,
      pageIndex: this._pageIndex,
      canvasFactory: this._transport.canvasFactory,
      filterFactory: this._transport.filterFactory,
      useRequestAnimationFrame: !E,
      pdfBug: this._pdfBug,
      pageColors: c,
      enableHWA: this._transport.enableHWA,
      operationsFilter: A
    });
    (S.renderTasks || (S.renderTasks = /* @__PURE__ */ new Set())).add(T);
    const L = T.task;
    return Promise.all([S.displayReadyCapability.promise, l]).then(([N, q]) => {
      var B;
      if (this.destroyed) {
        C();
        return;
      }
      if ((B = this._stats) == null || B.time("Rendering"), !(q.renderingIntent & v))
        throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");
      T.initializeGraphics({
        transparency: N,
        optionalContentConfig: q
      }), T.operatorListChanged();
    }).catch(C), L;
  }
  getOperatorList({
    intent: t = "display",
    annotationMode: e = Zs.ENABLE,
    printAnnotationStorage: i = null,
    isEditing: s = !1
  } = {}) {
    var h;
    function r() {
      o.operatorList.lastChunk && (o.opListReadCapability.resolve(o.operatorList), o.renderTasks.delete(l));
    }
    const a = this._transport.getRenderingIntent(t, e, i, s, !0);
    let o = this._intentStates.get(a.cacheKey);
    o || (o = /* @__PURE__ */ Object.create(null), this._intentStates.set(a.cacheKey, o));
    let l;
    return o.opListReadCapability || (l = /* @__PURE__ */ Object.create(null), l.operatorListChanged = r, o.opListReadCapability = Promise.withResolvers(), (o.renderTasks || (o.renderTasks = /* @__PURE__ */ new Set())).add(l), o.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, (h = this._stats) == null || h.time("Page Request"), this._pumpOperatorList(a)), o.opListReadCapability.promise;
  }
  streamTextContent({
    includeMarkedContent: t = !1,
    disableNormalization: e = !1
  } = {}) {
    return this._transport.messageHandler.sendWithStream("GetTextContent", {
      pageIndex: this._pageIndex,
      includeMarkedContent: t === !0,
      disableNormalization: e === !0
    }, {
      highWaterMark: 100,
      size(s) {
        return s.items.length;
      }
    });
  }
  getTextContent(t = {}) {
    if (this._transport._htmlForXfa)
      return this.getXfa().then((i) => jh.textContent(i));
    const e = this.streamTextContent(t);
    return new Promise(function(i, s) {
      function r() {
        a.read().then(function({
          value: l,
          done: h
        }) {
          if (h) {
            i(o);
            return;
          }
          o.lang ?? (o.lang = l.lang), Object.assign(o.styles, l.styles), o.items.push(...l.items), r();
        }, s);
      }
      const a = e.getReader(), o = {
        items: [],
        styles: /* @__PURE__ */ Object.create(null),
        lang: null
      };
      r();
    });
  }
  getStructTree() {
    return this._transport.getStructTree(this._pageIndex);
  }
  _destroy() {
    this.destroyed = !0;
    const t = [];
    for (const e of this._intentStates.values())
      if (this._abortOperatorList({
        intentState: e,
        reason: new Error("Page was destroyed."),
        force: !0
      }), !e.opListReadCapability)
        for (const i of e.renderTasks)
          t.push(i.completed), i.cancel();
    return this.objs.clear(), p(this, Cn, !1), Promise.all(t);
  }
  cleanup(t = !1) {
    p(this, Cn, !0);
    const e = b(this, Ba, Fh).call(this);
    return t && e && this._stats && (this._stats = new Ng()), e;
  }
  _startRenderPage(t, e) {
    var s, r;
    const i = this._intentStates.get(e);
    i && ((s = this._stats) == null || s.timeEnd("Page Request"), (r = i.displayReadyCapability) == null || r.resolve(t));
  }
  _renderPageChunk(t, e) {
    for (let i = 0, s = t.length; i < s; i++)
      e.operatorList.fnArray.push(t.fnArray[i]), e.operatorList.argsArray.push(t.argsArray[i]);
    e.operatorList.lastChunk = t.lastChunk, e.operatorList.separateAnnots = t.separateAnnots;
    for (const i of e.renderTasks)
      i.operatorListChanged();
    t.lastChunk && b(this, Ba, Fh).call(this);
  }
  _pumpOperatorList({
    renderingIntent: t,
    cacheKey: e,
    annotationStorageSerializable: i,
    modifiedIds: s
  }) {
    const {
      map: r,
      transfer: a
    } = i, l = this._transport.messageHandler.sendWithStream("GetOperatorList", {
      pageIndex: this._pageIndex,
      intent: t,
      cacheKey: e,
      annotationStorage: r,
      modifiedIds: s
    }, a).getReader(), h = this._intentStates.get(e);
    h.streamReader = l;
    const c = () => {
      l.read().then(({
        value: u,
        done: f
      }) => {
        if (f) {
          h.streamReader = null;
          return;
        }
        this._transport.destroyed || (this._renderPageChunk(u, h), c());
      }, (u) => {
        if (h.streamReader = null, !this._transport.destroyed) {
          if (h.operatorList) {
            h.operatorList.lastChunk = !0;
            for (const f of h.renderTasks)
              f.operatorListChanged();
            b(this, Ba, Fh).call(this);
          }
          if (h.displayReadyCapability)
            h.displayReadyCapability.reject(u);
          else if (h.opListReadCapability)
            h.opListReadCapability.reject(u);
          else
            throw u;
        }
      });
    };
    c();
  }
  _abortOperatorList({
    intentState: t,
    reason: e,
    force: i = !1
  }) {
    if (t.streamReader) {
      if (t.streamReaderCancelTimeout && (clearTimeout(t.streamReaderCancelTimeout), t.streamReaderCancelTimeout = null), !i) {
        if (t.renderTasks.size > 0)
          return;
        if (e instanceof pf) {
          let s = mA;
          e.extraDelay > 0 && e.extraDelay < 1e3 && (s += e.extraDelay), t.streamReaderCancelTimeout = setTimeout(() => {
            t.streamReaderCancelTimeout = null, this._abortOperatorList({
              intentState: t,
              reason: e,
              force: !0
            });
          }, s);
          return;
        }
      }
      if (t.streamReader.cancel(new Gn(e.message)).catch(() => {
      }), t.streamReader = null, !this._transport.destroyed) {
        for (const [s, r] of this._intentStates)
          if (r === t) {
            this._intentStates.delete(s);
            break;
          }
        this.cleanup();
      }
    }
  }
  get stats() {
    return this._stats;
  }
}
Cn = new WeakMap(), Ba = new WeakSet(), Fh = function() {
  if (!n(this, Cn) || this.destroyed)
    return !1;
  for (const {
    renderTasks: t,
    operatorList: e
  } of this._intentStates.values())
    if (t.size > 0 || !e.lastChunk)
      return !1;
  return this._intentStates.clear(), this.objs.clear(), p(this, Cn, !1), !0;
};
var vr, gs, Tn, Ha, nf, Ua, $a, si, fu, Rb, Mb, Nh, Ll, pu;
const Bt = class Bt {
  constructor({
    name: t = null,
    port: e = null,
    verbosity: i = ay()
  } = {}) {
    g(this, si);
    g(this, vr, Promise.withResolvers());
    g(this, gs, null);
    g(this, Tn, null);
    g(this, Ha, null);
    if (this.name = t, this.destroyed = !1, this.verbosity = i, e) {
      if (n(Bt, $a).has(e))
        throw new Error("Cannot use more than one PDFWorker per port.");
      n(Bt, $a).set(e, this), b(this, si, Rb).call(this, e);
    } else
      b(this, si, Mb).call(this);
  }
  get promise() {
    return n(this, vr).promise;
  }
  get port() {
    return n(this, Tn);
  }
  get messageHandler() {
    return n(this, gs);
  }
  destroy() {
    var t, e;
    this.destroyed = !0, (t = n(this, Ha)) == null || t.terminate(), p(this, Ha, null), n(Bt, $a).delete(n(this, Tn)), p(this, Tn, null), (e = n(this, gs)) == null || e.destroy(), p(this, gs, null);
  }
  static create(t) {
    const e = n(this, $a).get(t == null ? void 0 : t.port);
    if (e) {
      if (e._pendingDestroy)
        throw new Error("PDFWorker.create - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
      return e;
    }
    return new Bt(t);
  }
  static get workerSrc() {
    if (ns.workerSrc)
      return ns.workerSrc;
    throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
  }
  static get _setupFakeWorkerGlobal() {
    return st(this, "_setupFakeWorkerGlobal", (async () => n(this, Ll, pu) ? n(this, Ll, pu) : (await import(
      /*webpackIgnore: true*/
      /*@vite-ignore*/
      this.workerSrc
    )).WorkerMessageHandler)());
  }
};
vr = new WeakMap(), gs = new WeakMap(), Tn = new WeakMap(), Ha = new WeakMap(), nf = new WeakMap(), Ua = new WeakMap(), $a = new WeakMap(), si = new WeakSet(), fu = function() {
  n(this, vr).resolve(), n(this, gs).send("configure", {
    verbosity: this.verbosity
  });
}, Rb = function(t) {
  p(this, Tn, t), p(this, gs, new Ph("main", "worker", t)), n(this, gs).on("ready", () => {
  }), b(this, si, fu).call(this);
}, Mb = function() {
  if (n(Bt, Ua) || n(Bt, Ll, pu)) {
    b(this, si, Nh).call(this);
    return;
  }
  let {
    workerSrc: t
  } = Bt;
  try {
    Bt._isSameOrigin(window.location, t) || (t = Bt._createCDNWrapper(new URL(t, window.location).href));
    const e = new Worker(t, {
      type: "module"
    }), i = new Ph("main", "worker", e), s = () => {
      r.abort(), i.destroy(), e.terminate(), this.destroyed ? n(this, vr).reject(new Error("Worker was destroyed")) : b(this, si, Nh).call(this);
    }, r = new AbortController();
    e.addEventListener("error", () => {
      n(this, Ha) || s();
    }, {
      signal: r.signal
    }), i.on("test", (o) => {
      if (r.abort(), this.destroyed || !o) {
        s();
        return;
      }
      p(this, gs, i), p(this, Tn, e), p(this, Ha, e), b(this, si, fu).call(this);
    }), i.on("ready", (o) => {
      if (r.abort(), this.destroyed) {
        s();
        return;
      }
      try {
        a();
      } catch {
        b(this, si, Nh).call(this);
      }
    });
    const a = () => {
      const o = new Uint8Array();
      i.send("test", o, [o.buffer]);
    };
    a();
    return;
  } catch {
    ff("The worker has been disabled.");
  }
  b(this, si, Nh).call(this);
}, Nh = function() {
  n(Bt, Ua) || (J("Setting up fake worker."), p(Bt, Ua, !0)), Bt._setupFakeWorkerGlobal.then((t) => {
    if (this.destroyed) {
      n(this, vr).reject(new Error("Worker was destroyed"));
      return;
    }
    const e = new Ty();
    p(this, Tn, e);
    const i = `fake${oe(Bt, nf)._++}`, s = new Ph(i + "_worker", i, e);
    t.setup(s, e), p(this, gs, new Ph(i, i + "_worker", e)), b(this, si, fu).call(this);
  }).catch((t) => {
    n(this, vr).reject(new Error(`Setting up fake worker failed: "${t.message}".`));
  });
}, Ll = new WeakSet(), pu = function() {
  var t;
  try {
    return ((t = globalThis.pdfjsWorker) == null ? void 0 : t.WorkerMessageHandler) || null;
  } catch {
    return null;
  }
}, g(Bt, Ll), g(Bt, nf, 0), g(Bt, Ua, !1), g(Bt, $a, /* @__PURE__ */ new WeakMap()), ii && (p(Bt, Ua, !0), ns.workerSrc || (ns.workerSrc = "./pdf.worker.mjs")), Bt._isSameOrigin = (t, e) => {
  const i = URL.parse(t);
  if (!(i != null && i.origin) || i.origin === "null")
    return !1;
  const s = new URL(e, i);
  return i.origin === s.origin;
}, Bt._createCDNWrapper = (t) => {
  const e = `await import("${t}");`;
  return URL.createObjectURL(new Blob([e], {
    type: "text/javascript"
  }));
}, Bt.fromPort = (t) => {
  if (gy("`PDFWorker.fromPort` - please use `PDFWorker.create` instead."), !(t != null && t.port))
    throw new Error("PDFWorker.fromPort - invalid method signature.");
  return Bt.create(t);
};
let uh = Bt;
var Pn, $s, kl, Rl, Ln, Va, Oh;
class AA {
  constructor(t, e, i, s, r, a) {
    g(this, Va);
    g(this, Pn, /* @__PURE__ */ new Map());
    g(this, $s, /* @__PURE__ */ new Map());
    g(this, kl, /* @__PURE__ */ new Map());
    g(this, Rl, /* @__PURE__ */ new Map());
    g(this, Ln, null);
    this.messageHandler = t, this.loadingTask = e, this.commonObjs = new Cb(), this.fontLoader = new Ey({
      ownerDocument: s.ownerDocument,
      styleElement: s.styleElement
    }), this.loadingParams = s.loadingParams, this._params = s, this.canvasFactory = r.canvasFactory, this.filterFactory = r.filterFactory, this.cMapReaderFactory = r.cMapReaderFactory, this.standardFontDataFactory = r.standardFontDataFactory, this.wasmFactory = r.wasmFactory, this.destroyed = !1, this.destroyCapability = null, this._networkStream = i, this._fullReader = null, this._lastProgress = null, this.downloadInfoCapability = Promise.withResolvers(), this.enableHWA = a, this.setupMessageHandler();
  }
  get annotationStorage() {
    return st(this, "annotationStorage", new bg());
  }
  getRenderingIntent(t, e = Zs.ENABLE, i = null, s = !1, r = !1) {
    let a = Oi.DISPLAY, o = rp;
    switch (t) {
      case "any":
        a = Oi.ANY;
        break;
      case "display":
        break;
      case "print":
        a = Oi.PRINT;
        break;
      default:
        J(`getRenderingIntent - invalid intent: ${t}`);
    }
    const l = a & Oi.PRINT && i instanceof hb ? i : this.annotationStorage;
    switch (e) {
      case Zs.DISABLE:
        a += Oi.ANNOTATIONS_DISABLE;
        break;
      case Zs.ENABLE:
        break;
      case Zs.ENABLE_FORMS:
        a += Oi.ANNOTATIONS_FORMS;
        break;
      case Zs.ENABLE_STORAGE:
        a += Oi.ANNOTATIONS_STORAGE, o = l.serializable;
        break;
      default:
        J(`getRenderingIntent - invalid annotationMode: ${e}`);
    }
    s && (a += Oi.IS_EDITING), r && (a += Oi.OPLIST);
    const {
      ids: h,
      hash: c
    } = l.modifiedIds, u = [a, o.hash, c];
    return {
      renderingIntent: a,
      cacheKey: u.join("_"),
      annotationStorageSerializable: o,
      modifiedIds: h
    };
  }
  destroy() {
    var i;
    if (this.destroyCapability)
      return this.destroyCapability.promise;
    this.destroyed = !0, this.destroyCapability = Promise.withResolvers(), (i = n(this, Ln)) == null || i.reject(new Error("Worker was destroyed during onPassword callback"));
    const t = [];
    for (const s of n(this, $s).values())
      t.push(s._destroy());
    n(this, $s).clear(), n(this, kl).clear(), n(this, Rl).clear(), this.hasOwnProperty("annotationStorage") && this.annotationStorage.resetModified();
    const e = this.messageHandler.sendWithPromise("Terminate", null);
    return t.push(e), Promise.all(t).then(() => {
      var s, r;
      this.commonObjs.clear(), this.fontLoader.clear(), n(this, Pn).clear(), this.filterFactory.destroy(), Yh.cleanup(), (s = this._networkStream) == null || s.cancelAllRequests(new Gn("Worker was terminated.")), (r = this.messageHandler) == null || r.destroy(), this.messageHandler = null, this.destroyCapability.resolve();
    }, this.destroyCapability.reject), this.destroyCapability.promise;
  }
  setupMessageHandler() {
    const {
      messageHandler: t,
      loadingTask: e
    } = this;
    t.on("GetReader", (i, s) => {
      dt(this._networkStream, "GetReader - no `IPDFStream` instance available."), this._fullReader = this._networkStream.getFullReader(), this._fullReader.onProgress = (r) => {
        this._lastProgress = {
          loaded: r.loaded,
          total: r.total
        };
      }, s.onPull = () => {
        this._fullReader.read().then(function({
          value: r,
          done: a
        }) {
          if (a) {
            s.close();
            return;
          }
          dt(r instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), s.enqueue(new Uint8Array(r), 1, [r]);
        }).catch((r) => {
          s.error(r);
        });
      }, s.onCancel = (r) => {
        this._fullReader.cancel(r), s.ready.catch((a) => {
          if (!this.destroyed)
            throw a;
        });
      };
    }), t.on("ReaderHeadersReady", async (i) => {
      var o;
      await this._fullReader.headersReady;
      const {
        isStreamingSupported: s,
        isRangeSupported: r,
        contentLength: a
      } = this._fullReader;
      return (!s || !r) && (this._lastProgress && ((o = e.onProgress) == null || o.call(e, this._lastProgress)), this._fullReader.onProgress = (l) => {
        var h;
        (h = e.onProgress) == null || h.call(e, {
          loaded: l.loaded,
          total: l.total
        });
      }), {
        isStreamingSupported: s,
        isRangeSupported: r,
        contentLength: a
      };
    }), t.on("GetRangeReader", (i, s) => {
      dt(this._networkStream, "GetRangeReader - no `IPDFStream` instance available.");
      const r = this._networkStream.getRangeReader(i.begin, i.end);
      if (!r) {
        s.close();
        return;
      }
      s.onPull = () => {
        r.read().then(function({
          value: a,
          done: o
        }) {
          if (o) {
            s.close();
            return;
          }
          dt(a instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), s.enqueue(new Uint8Array(a), 1, [a]);
        }).catch((a) => {
          s.error(a);
        });
      }, s.onCancel = (a) => {
        r.cancel(a), s.ready.catch((o) => {
          if (!this.destroyed)
            throw o;
        });
      };
    }), t.on("GetDoc", ({
      pdfInfo: i
    }) => {
      this._numPages = i.numPages, this._htmlForXfa = i.htmlForXfa, delete i.htmlForXfa, e._capability.resolve(new bA(i, this));
    }), t.on("DocException", (i) => {
      e._capability.reject(oi(i));
    }), t.on("PasswordRequest", (i) => {
      p(this, Ln, Promise.withResolvers());
      try {
        if (!e.onPassword)
          throw oi(i);
        const s = (r) => {
          r instanceof Error ? n(this, Ln).reject(r) : n(this, Ln).resolve({
            password: r
          });
        };
        e.onPassword(s, i.code);
      } catch (s) {
        n(this, Ln).reject(s);
      }
      return n(this, Ln).promise;
    }), t.on("DataLoaded", (i) => {
      var s;
      (s = e.onProgress) == null || s.call(e, {
        loaded: i.length,
        total: i.length
      }), this.downloadInfoCapability.resolve(i);
    }), t.on("StartRenderPage", (i) => {
      if (this.destroyed)
        return;
      n(this, $s).get(i.pageIndex)._startRenderPage(i.transparency, i.cacheKey);
    }), t.on("commonobj", ([i, s, r]) => {
      var a;
      if (this.destroyed || this.commonObjs.has(i))
        return null;
      switch (s) {
        case "Font":
          if ("error" in r) {
            const u = r.error;
            J(`Error during font loading: ${u}`), this.commonObjs.resolve(i, u);
            break;
          }
          const o = new mp(r), l = this._params.pdfBug && ((a = globalThis.FontInspector) != null && a.enabled) ? (u, f) => globalThis.FontInspector.fontAdded(u, f) : null, h = new Sy(o, l, r.extra, r.charProcOperatorList);
          this.fontLoader.bind(h).catch(() => t.sendWithPromise("FontFallback", {
            id: i
          })).finally(() => {
            !h.fontExtraProperties && h.data && h.clearData(), this.commonObjs.resolve(i, h);
          });
          break;
        case "CopyLocalImage":
          const {
            imageRef: c
          } = r;
          dt(c, "The imageRef must be defined.");
          for (const u of n(this, $s).values())
            for (const [, f] of u.objs)
              if ((f == null ? void 0 : f.ref) === c)
                return f.dataLen ? (this.commonObjs.resolve(i, structuredClone(f)), f.dataLen) : null;
          break;
        case "FontPath":
        case "Image":
        case "Pattern":
          this.commonObjs.resolve(i, r);
          break;
        default:
          throw new Error(`Got unknown common object type ${s}`);
      }
      return null;
    }), t.on("obj", ([i, s, r, a]) => {
      var l;
      if (this.destroyed)
        return;
      const o = n(this, $s).get(s);
      if (!o.objs.has(i)) {
        if (o._intentStates.size === 0) {
          (l = a == null ? void 0 : a.bitmap) == null || l.close();
          return;
        }
        switch (r) {
          case "Image":
          case "Pattern":
            o.objs.resolve(i, a);
            break;
          default:
            throw new Error(`Got unknown object type ${r}`);
        }
      }
    }), t.on("DocProgress", (i) => {
      var s;
      this.destroyed || (s = e.onProgress) == null || s.call(e, {
        loaded: i.loaded,
        total: i.total
      });
    }), t.on("FetchBinaryData", async (i) => {
      if (this.destroyed)
        throw new Error("Worker was destroyed.");
      const s = this[i.type];
      if (!s)
        throw new Error(`${i.type} not initialized, see the \`useWorkerFetch\` parameter.`);
      return s.fetch(i);
    });
  }
  getData() {
    return this.messageHandler.sendWithPromise("GetData", null);
  }
  saveDocument() {
    var i;
    this.annotationStorage.size <= 0 && J("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
    const {
      map: t,
      transfer: e
    } = this.annotationStorage.serializable;
    return this.messageHandler.sendWithPromise("SaveDocument", {
      isPureXfa: !!this._htmlForXfa,
      numPages: this._numPages,
      annotationStorage: t,
      filename: ((i = this._fullReader) == null ? void 0 : i.filename) ?? null
    }, e).finally(() => {
      this.annotationStorage.resetModified();
    });
  }
  getPage(t) {
    if (!Number.isInteger(t) || t <= 0 || t > this._numPages)
      return Promise.reject(new Error("Invalid page request."));
    const e = t - 1, i = n(this, kl).get(e);
    if (i)
      return i;
    const s = this.messageHandler.sendWithPromise("GetPage", {
      pageIndex: e
    }).then((r) => {
      if (this.destroyed)
        throw new Error("Transport destroyed");
      r.refStr && n(this, Rl).set(r.refStr, t);
      const a = new yA(e, r, this, this._params.pdfBug);
      return n(this, $s).set(e, a), a;
    });
    return n(this, kl).set(e, s), s;
  }
  getPageIndex(t) {
    return ap(t) ? this.messageHandler.sendWithPromise("GetPageIndex", {
      num: t.num,
      gen: t.gen
    }) : Promise.reject(new Error("Invalid pageIndex request."));
  }
  getAnnotations(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotations", {
      pageIndex: t,
      intent: e
    });
  }
  getFieldObjects() {
    return b(this, Va, Oh).call(this, "GetFieldObjects");
  }
  hasJSActions() {
    return b(this, Va, Oh).call(this, "HasJSActions");
  }
  getCalculationOrderIds() {
    return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
  }
  getDestinations() {
    return this.messageHandler.sendWithPromise("GetDestinations", null);
  }
  getDestination(t) {
    return typeof t != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
      id: t
    });
  }
  getPageLabels() {
    return this.messageHandler.sendWithPromise("GetPageLabels", null);
  }
  getPageLayout() {
    return this.messageHandler.sendWithPromise("GetPageLayout", null);
  }
  getPageMode() {
    return this.messageHandler.sendWithPromise("GetPageMode", null);
  }
  getViewerPreferences() {
    return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
  }
  getOpenAction() {
    return this.messageHandler.sendWithPromise("GetOpenAction", null);
  }
  getAttachments() {
    return this.messageHandler.sendWithPromise("GetAttachments", null);
  }
  getAnnotationsByType(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotationsByType", {
      types: t,
      pageIndexesToSkip: e
    });
  }
  getDocJSActions() {
    return b(this, Va, Oh).call(this, "GetDocJSActions");
  }
  getPageJSActions(t) {
    return this.messageHandler.sendWithPromise("GetPageJSActions", {
      pageIndex: t
    });
  }
  getStructTree(t) {
    return this.messageHandler.sendWithPromise("GetStructTree", {
      pageIndex: t
    });
  }
  getOutline() {
    return this.messageHandler.sendWithPromise("GetOutline", null);
  }
  getOptionalContentConfig(t) {
    return b(this, Va, Oh).call(this, "GetOptionalContentConfig").then((e) => new Zy(e, t));
  }
  getPermissions() {
    return this.messageHandler.sendWithPromise("GetPermissions", null);
  }
  getMetadata() {
    const t = "GetMetadata", e = n(this, Pn).get(t);
    if (e)
      return e;
    const i = this.messageHandler.sendWithPromise(t, null).then((s) => {
      var r, a;
      return {
        info: s[0],
        metadata: s[1] ? new Yy(s[1]) : null,
        contentDispositionFilename: ((r = this._fullReader) == null ? void 0 : r.filename) ?? null,
        contentLength: ((a = this._fullReader) == null ? void 0 : a.contentLength) ?? null
      };
    });
    return n(this, Pn).set(t, i), i;
  }
  getMarkInfo() {
    return this.messageHandler.sendWithPromise("GetMarkInfo", null);
  }
  async startCleanup(t = !1) {
    if (!this.destroyed) {
      await this.messageHandler.sendWithPromise("Cleanup", null);
      for (const e of n(this, $s).values())
        if (!e.cleanup())
          throw new Error(`startCleanup: Page ${e.pageNumber} is currently rendering.`);
      this.commonObjs.clear(), t || this.fontLoader.clear(), n(this, Pn).clear(), this.filterFactory.destroy(!0), Yh.cleanup();
    }
  }
  cachedPageNumber(t) {
    if (!ap(t))
      return null;
    const e = t.gen === 0 ? `${t.num}R` : `${t.num}R${t.gen}`;
    return n(this, Rl).get(e) ?? null;
  }
}
Pn = new WeakMap(), $s = new WeakMap(), kl = new WeakMap(), Rl = new WeakMap(), Ln = new WeakMap(), Va = new WeakSet(), Oh = function(t, e = null) {
  const i = n(this, Pn).get(t);
  if (i)
    return i;
  const s = this.messageHandler.sendWithPromise(t, e);
  return n(this, Pn).set(t, s), s;
};
var Er;
class wA {
  constructor(t) {
    g(this, Er, null);
    M(this, "onContinue", null);
    M(this, "onError", null);
    p(this, Er, t);
  }
  get promise() {
    return n(this, Er).capability.promise;
  }
  cancel(t = 0) {
    n(this, Er).cancel(null, t);
  }
  get separateAnnots() {
    const {
      separateAnnots: t
    } = n(this, Er).operatorList;
    if (!t)
      return !1;
    const {
      annotationCanvasMap: e
    } = n(this, Er);
    return t.form || t.canvas && (e == null ? void 0 : e.size) > 0;
  }
}
Er = new WeakMap();
var Sr, za;
const sa = class sa {
  constructor({
    callback: t,
    params: e,
    objs: i,
    commonObjs: s,
    annotationCanvasMap: r,
    operatorList: a,
    pageIndex: o,
    canvasFactory: l,
    filterFactory: h,
    useRequestAnimationFrame: c = !1,
    pdfBug: u = !1,
    pageColors: f = null,
    enableHWA: m = !1,
    operationsFilter: A = null
  }) {
    g(this, Sr, null);
    this.callback = t, this.params = e, this.objs = i, this.commonObjs = s, this.annotationCanvasMap = r, this.operatorListIdx = null, this.operatorList = a, this._pageIndex = o, this.canvasFactory = l, this.filterFactory = h, this._pdfBug = u, this.pageColors = f, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = c === !0 && typeof window < "u", this.cancelled = !1, this.capability = Promise.withResolvers(), this.task = new wA(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = e.canvas, this._canvasContext = e.canvas ? null : e.canvasContext, this._enableHWA = m, this._dependencyTracker = e.dependencyTracker, this._operationsFilter = A;
  }
  get completed() {
    return this.capability.promise.catch(function() {
    });
  }
  initializeGraphics({
    transparency: t = !1,
    optionalContentConfig: e
  }) {
    var l, h;
    if (this.cancelled)
      return;
    if (this._canvas) {
      if (n(sa, za).has(this._canvas))
        throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
      n(sa, za).add(this._canvas);
    }
    this._pdfBug && ((l = globalThis.StepperManager) != null && l.enabled) && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint());
    const {
      viewport: i,
      transform: s,
      background: r,
      dependencyTracker: a
    } = this.params, o = this._canvasContext || this._canvas.getContext("2d", {
      alpha: !1,
      willReadFrequently: !this._enableHWA
    });
    this.gfx = new No(o, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
      optionalContentConfig: e
    }, this.annotationCanvasMap, this.pageColors, a), this.gfx.beginDrawing({
      transform: s,
      viewport: i,
      transparency: t,
      background: r
    }), this.operatorListIdx = 0, this.graphicsReady = !0, (h = this.graphicsReadyCallback) == null || h.call(this);
  }
  cancel(t = null, e = 0) {
    var i, s, r;
    this.running = !1, this.cancelled = !0, (i = this.gfx) == null || i.endDrawing(), n(this, Sr) && (window.cancelAnimationFrame(n(this, Sr)), p(this, Sr, null)), n(sa, za).delete(this._canvas), t || (t = new pf(`Rendering cancelled, page ${this._pageIndex + 1}`, e)), this.callback(t), (r = (s = this.task).onError) == null || r.call(s, t);
  }
  operatorListChanged() {
    var t, e;
    if (!this.graphicsReady) {
      this.graphicsReadyCallback || (this.graphicsReadyCallback = this._continueBound);
      return;
    }
    (t = this.gfx.dependencyTracker) == null || t.growOperationsCount(this.operatorList.fnArray.length), (e = this.stepper) == null || e.updateOperatorList(this.operatorList), !this.running && this._continue();
  }
  _continue() {
    this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
  }
  _scheduleNext() {
    this._useRequestAnimationFrame ? p(this, Sr, window.requestAnimationFrame(() => {
      p(this, Sr, null), this._nextBound().catch(this._cancelBound);
    })) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
  }
  async _next() {
    this.cancelled || (this.operatorListIdx = this.gfx.executeOperatorList(this.operatorList, this.operatorListIdx, this._continueBound, this.stepper, this._operationsFilter), this.operatorListIdx === this.operatorList.argsArray.length && (this.running = !1, this.operatorList.lastChunk && (this.gfx.endDrawing(), n(sa, za).delete(this._canvas), this.callback())));
  }
};
Sr = new WeakMap(), za = new WeakMap(), g(sa, za, /* @__PURE__ */ new WeakSet());
let Ep = sa;
const Kh = "5.4.296", Db = "f56dc8601";
var xi, Ga, Ml, de, Jc, Dl, kn, Qc, _r, ms, td, Ct, Sp, _p, xp, Qr, Ib, Kn;
const li = class li {
  constructor({
    editor: t = null,
    uiManager: e = null
  }) {
    g(this, Ct);
    g(this, xi, null);
    g(this, Ga, null);
    g(this, Ml);
    g(this, de, null);
    g(this, Jc, !1);
    g(this, Dl, !1);
    g(this, kn, null);
    g(this, Qc);
    g(this, _r, null);
    g(this, ms, null);
    var i, s;
    t ? (p(this, Dl, !1), p(this, kn, t)) : p(this, Dl, !0), p(this, ms, (t == null ? void 0 : t._uiManager) || e), p(this, Qc, n(this, ms)._eventBus), p(this, Ml, ((i = t == null ? void 0 : t.color) == null ? void 0 : i.toUpperCase()) || ((s = n(this, ms)) == null ? void 0 : s.highlightColors.values().next().value) || "#FFFF98"), n(li, td) || p(li, td, Object.freeze({
      blue: "pdfjs-editor-colorpicker-blue",
      green: "pdfjs-editor-colorpicker-green",
      pink: "pdfjs-editor-colorpicker-pink",
      red: "pdfjs-editor-colorpicker-red",
      yellow: "pdfjs-editor-colorpicker-yellow"
    }));
  }
  static get _keyboardManager() {
    return st(this, "_keyboardManager", new Od([[["Escape", "mac+Escape"], li.prototype._hideDropdownFromKeyboard], [[" ", "mac+ "], li.prototype._colorSelectFromKeyboard], [["ArrowDown", "ArrowRight", "mac+ArrowDown", "mac+ArrowRight"], li.prototype._moveToNext], [["ArrowUp", "ArrowLeft", "mac+ArrowUp", "mac+ArrowLeft"], li.prototype._moveToPrevious], [["Home", "mac+Home"], li.prototype._moveToBeginning], [["End", "mac+End"], li.prototype._moveToEnd]]));
  }
  renderButton() {
    const t = p(this, xi, document.createElement("button"));
    t.className = "colorPicker", t.tabIndex = "0", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-button"), t.ariaHasPopup = "true", n(this, kn) && (t.ariaControls = `${n(this, kn).id}_colorpicker_dropdown`);
    const e = n(this, ms)._signal;
    t.addEventListener("click", b(this, Ct, Qr).bind(this), {
      signal: e
    }), t.addEventListener("keydown", b(this, Ct, xp).bind(this), {
      signal: e
    });
    const i = p(this, Ga, document.createElement("span"));
    return i.className = "swatch", i.ariaHidden = "true", i.style.backgroundColor = n(this, Ml), t.append(i), t;
  }
  renderMainDropdown() {
    const t = p(this, de, b(this, Ct, Sp).call(this));
    return t.ariaOrientation = "horizontal", t.ariaLabelledBy = "highlightColorPickerLabel", t;
  }
  _colorSelectFromKeyboard(t) {
    if (t.target === n(this, xi)) {
      b(this, Ct, Qr).call(this, t);
      return;
    }
    const e = t.target.getAttribute("data-color");
    e && b(this, Ct, _p).call(this, e, t);
  }
  _moveToNext(t) {
    var e, i;
    if (!n(this, Ct, Kn)) {
      b(this, Ct, Qr).call(this, t);
      return;
    }
    if (t.target === n(this, xi)) {
      (e = n(this, de).firstChild) == null || e.focus();
      return;
    }
    (i = t.target.nextSibling) == null || i.focus();
  }
  _moveToPrevious(t) {
    var e, i;
    if (t.target === ((e = n(this, de)) == null ? void 0 : e.firstChild) || t.target === n(this, xi)) {
      n(this, Ct, Kn) && this._hideDropdownFromKeyboard();
      return;
    }
    n(this, Ct, Kn) || b(this, Ct, Qr).call(this, t), (i = t.target.previousSibling) == null || i.focus();
  }
  _moveToBeginning(t) {
    var e;
    if (!n(this, Ct, Kn)) {
      b(this, Ct, Qr).call(this, t);
      return;
    }
    (e = n(this, de).firstChild) == null || e.focus();
  }
  _moveToEnd(t) {
    var e;
    if (!n(this, Ct, Kn)) {
      b(this, Ct, Qr).call(this, t);
      return;
    }
    (e = n(this, de).lastChild) == null || e.focus();
  }
  hideDropdown() {
    var t, e;
    (t = n(this, de)) == null || t.classList.add("hidden"), n(this, xi).ariaExpanded = "false", (e = n(this, _r)) == null || e.abort(), p(this, _r, null);
  }
  _hideDropdownFromKeyboard() {
    var t;
    if (!n(this, Dl)) {
      if (!n(this, Ct, Kn)) {
        (t = n(this, kn)) == null || t.unselect();
        return;
      }
      this.hideDropdown(), n(this, xi).focus({
        preventScroll: !0,
        focusVisible: n(this, Jc)
      });
    }
  }
  updateColor(t) {
    if (n(this, Ga) && (n(this, Ga).style.backgroundColor = t), !n(this, de))
      return;
    const e = n(this, ms).highlightColors.values();
    for (const i of n(this, de).children)
      i.ariaSelected = e.next().value === t.toUpperCase();
  }
  destroy() {
    var t, e;
    (t = n(this, xi)) == null || t.remove(), p(this, xi, null), p(this, Ga, null), (e = n(this, de)) == null || e.remove(), p(this, de, null);
  }
};
xi = new WeakMap(), Ga = new WeakMap(), Ml = new WeakMap(), de = new WeakMap(), Jc = new WeakMap(), Dl = new WeakMap(), kn = new WeakMap(), Qc = new WeakMap(), _r = new WeakMap(), ms = new WeakMap(), td = new WeakMap(), Ct = new WeakSet(), Sp = function() {
  const t = document.createElement("div"), e = n(this, ms)._signal;
  t.addEventListener("contextmenu", $i, {
    signal: e
  }), t.className = "dropdown", t.role = "listbox", t.ariaMultiSelectable = "false", t.ariaOrientation = "vertical", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-dropdown"), n(this, kn) && (t.id = `${n(this, kn).id}_colorpicker_dropdown`);
  for (const [i, s] of n(this, ms).highlightColors) {
    const r = document.createElement("button");
    r.tabIndex = "0", r.role = "option", r.setAttribute("data-color", s), r.title = i, r.setAttribute("data-l10n-id", n(li, td)[i]);
    const a = document.createElement("span");
    r.append(a), a.className = "swatch", a.style.backgroundColor = s, r.ariaSelected = s === n(this, Ml), r.addEventListener("click", b(this, Ct, _p).bind(this, s), {
      signal: e
    }), t.append(r);
  }
  return t.addEventListener("keydown", b(this, Ct, xp).bind(this), {
    signal: e
  }), t;
}, _p = function(t, e) {
  e.stopPropagation(), n(this, Qc).dispatch("switchannotationeditorparams", {
    source: this,
    type: ht.HIGHLIGHT_COLOR,
    value: t
  }), this.updateColor(t);
}, xp = function(t) {
  li._keyboardManager.exec(this, t);
}, Qr = function(t) {
  if (n(this, Ct, Kn)) {
    this.hideDropdown();
    return;
  }
  if (p(this, Jc, t.detail === 0), n(this, _r) || (p(this, _r, new AbortController()), window.addEventListener("pointerdown", b(this, Ct, Ib).bind(this), {
    signal: n(this, ms).combinedSignal(n(this, _r))
  })), n(this, xi).ariaExpanded = "true", n(this, de)) {
    n(this, de).classList.remove("hidden");
    return;
  }
  const e = p(this, de, b(this, Ct, Sp).call(this));
  n(this, xi).append(e);
}, Ib = function(t) {
  var e;
  (e = n(this, de)) != null && e.contains(t.target) || this.hideDropdown();
}, Kn = function() {
  return n(this, de) && !n(this, de).classList.contains("hidden");
}, g(li, td, null);
let Zh = li;
var Vs, ed, Il, id;
const na = class na {
  constructor(t) {
    g(this, Vs, null);
    g(this, ed, null);
    g(this, Il, null);
    p(this, ed, t), p(this, Il, t._uiManager), n(na, id) || p(na, id, Object.freeze({
      freetext: "pdfjs-editor-color-picker-free-text-input",
      ink: "pdfjs-editor-color-picker-ink-input"
    }));
  }
  renderButton() {
    if (n(this, Vs))
      return n(this, Vs);
    const {
      editorType: t,
      colorType: e,
      colorValue: i
    } = n(this, ed), s = p(this, Vs, document.createElement("input"));
    return s.type = "color", s.value = i || "#000000", s.className = "basicColorPicker", s.tabIndex = 0, s.setAttribute("data-l10n-id", n(na, id)[t]), s.addEventListener("input", () => {
      n(this, Il).updateParams(e, s.value);
    }, {
      signal: n(this, Il)._signal
    }), s;
  }
  update(t) {
    n(this, Vs) && (n(this, Vs).value = t);
  }
  destroy() {
    var t;
    (t = n(this, Vs)) == null || t.remove(), p(this, Vs, null);
  }
  hideDropdown() {
  }
};
Vs = new WeakMap(), ed = new WeakMap(), Il = new WeakMap(), id = new WeakMap(), g(na, id, null);
let Uu = na;
function nm(d) {
  return Math.floor(Math.max(0, Math.min(1, d)) * 255).toString(16).padStart(2, "0");
}
function wh(d) {
  return Math.max(0, Math.min(255, 255 * d));
}
class rm {
  static CMYK_G([t, e, i, s]) {
    return ["G", 1 - Math.min(1, 0.3 * t + 0.59 * i + 0.11 * e + s)];
  }
  static G_CMYK([t]) {
    return ["CMYK", 0, 0, 0, 1 - t];
  }
  static G_RGB([t]) {
    return ["RGB", t, t, t];
  }
  static G_rgb([t]) {
    return t = wh(t), [t, t, t];
  }
  static G_HTML([t]) {
    const e = nm(t);
    return `#${e}${e}${e}`;
  }
  static RGB_G([t, e, i]) {
    return ["G", 0.3 * t + 0.59 * e + 0.11 * i];
  }
  static RGB_rgb(t) {
    return t.map(wh);
  }
  static RGB_HTML(t) {
    return `#${t.map(nm).join("")}`;
  }
  static T_HTML() {
    return "#00000000";
  }
  static T_rgb() {
    return [null];
  }
  static CMYK_RGB([t, e, i, s]) {
    return ["RGB", 1 - Math.min(1, t + s), 1 - Math.min(1, i + s), 1 - Math.min(1, e + s)];
  }
  static CMYK_rgb([t, e, i, s]) {
    return [wh(1 - Math.min(1, t + s)), wh(1 - Math.min(1, i + s)), wh(1 - Math.min(1, e + s))];
  }
  static CMYK_HTML(t) {
    const e = this.CMYK_RGB(t).slice(1);
    return this.RGB_HTML(e);
  }
  static RGB_CMYK([t, e, i]) {
    const s = 1 - t, r = 1 - e, a = 1 - i, o = Math.min(s, r, a);
    return ["CMYK", s, r, a, o];
  }
}
class vA {
  create(t, e, i = !1) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid SVG dimensions");
    const s = this._createSVG("svg:svg");
    return s.setAttribute("version", "1.1"), i || (s.setAttribute("width", `${t}px`), s.setAttribute("height", `${e}px`)), s.setAttribute("preserveAspectRatio", "none"), s.setAttribute("viewBox", `0 0 ${t} ${e}`), s;
  }
  createElement(t) {
    if (typeof t != "string")
      throw new Error("Invalid SVG element type");
    return this._createSVG(t);
  }
  _createSVG(t) {
    Dt("Abstract method `_createSVG` called.");
  }
}
class Jh extends vA {
  _createSVG(t) {
    return document.createElementNS(sn, t);
  }
}
const EA = 9, yo = /* @__PURE__ */ new WeakSet(), SA = (/* @__PURE__ */ new Date()).getTimezoneOffset() * 60 * 1e3;
class am {
  static create(t) {
    switch (t.data.annotationType) {
      case te.LINK:
        return new Eg(t);
      case te.TEXT:
        return new xA(t);
      case te.WIDGET:
        switch (t.data.fieldType) {
          case "Tx":
            return new CA(t);
          case "Btn":
            return t.data.radioButton ? new Ob(t) : t.data.checkBox ? new PA(t) : new LA(t);
          case "Ch":
            return new kA(t);
          case "Sig":
            return new TA(t);
        }
        return new vo(t);
      case te.POPUP:
        return new Tp(t);
      case te.FREETEXT:
        return new Vb(t);
      case te.LINE:
        return new MA(t);
      case te.SQUARE:
        return new DA(t);
      case te.CIRCLE:
        return new IA(t);
      case te.POLYLINE:
        return new zb(t);
      case te.CARET:
        return new NA(t);
      case te.INK:
        return new Sg(t);
      case te.POLYGON:
        return new FA(t);
      case te.HIGHLIGHT:
        return new Gb(t);
      case te.UNDERLINE:
        return new OA(t);
      case te.SQUIGGLY:
        return new BA(t);
      case te.STRIKEOUT:
        return new HA(t);
      case te.STAMP:
        return new Wb(t);
      case te.FILEATTACHMENT:
        return new UA(t);
      default:
        return new Gt(t);
    }
  }
}
var Wa, Fl, ts, sd, Cp;
const Rg = class Rg {
  constructor(t, {
    isRenderable: e = !1,
    ignoreBorder: i = !1,
    createQuadrilaterals: s = !1
  } = {}) {
    g(this, sd);
    g(this, Wa, null);
    g(this, Fl, !1);
    g(this, ts, null);
    this.isRenderable = e, this.data = t.data, this.layer = t.layer, this.linkService = t.linkService, this.downloadManager = t.downloadManager, this.imageResourcesPath = t.imageResourcesPath, this.renderForms = t.renderForms, this.svgFactory = t.svgFactory, this.annotationStorage = t.annotationStorage, this.enableComment = t.enableComment, this.enableScripting = t.enableScripting, this.hasJSActions = t.hasJSActions, this._fieldObjects = t.fieldObjects, this.parent = t.parent, e && (this.container = this._createContainer(i)), s && this._createQuadrilaterals();
  }
  static _hasPopupData({
    contentsObj: t,
    richText: e
  }) {
    return !!(t != null && t.str || e != null && e.str);
  }
  get _isEditable() {
    return this.data.isEditable;
  }
  get hasPopupData() {
    return Rg._hasPopupData(this.data) || this.enableComment && !!this.commentText;
  }
  get commentData() {
    var i;
    const {
      data: t
    } = this, e = (i = this.annotationStorage) == null ? void 0 : i.getEditor(t.id);
    return e ? e.getData() : t;
  }
  get hasCommentButton() {
    return this.enableComment && this.hasPopupElement;
  }
  get commentButtonPosition() {
    var o;
    const t = (o = this.annotationStorage) == null ? void 0 : o.getEditor(this.data.id);
    if (t)
      return t.commentButtonPositionInPage;
    const {
      quadPoints: e,
      inkLists: i,
      rect: s
    } = this.data;
    let r = -1 / 0, a = -1 / 0;
    if ((e == null ? void 0 : e.length) >= 8) {
      for (let l = 0; l < e.length; l += 8)
        e[l + 1] > a ? (a = e[l + 1], r = e[l + 2]) : e[l + 1] === a && (r = Math.max(r, e[l + 2]));
      return [r, a];
    }
    if ((i == null ? void 0 : i.length) >= 1) {
      for (const l of i)
        for (let h = 0, c = l.length; h < c; h += 2)
          l[h + 1] > a ? (a = l[h + 1], r = l[h]) : l[h + 1] === a && (r = Math.max(r, l[h]));
      if (r !== 1 / 0)
        return [r, a];
    }
    return s ? [s[2], s[3]] : null;
  }
  _normalizePoint(t) {
    const {
      page: {
        view: e
      },
      viewport: {
        rawDims: {
          pageWidth: i,
          pageHeight: s,
          pageX: r,
          pageY: a
        }
      }
    } = this.parent;
    return t[1] = e[3] - t[1] + e[1], t[0] = 100 * (t[0] - r) / i, t[1] = 100 * (t[1] - a) / s, t;
  }
  get commentText() {
    var e, i, s;
    const {
      data: t
    } = this;
    return ((i = (e = this.annotationStorage.getRawValue(`${Gh}${t.id}`)) == null ? void 0 : e.popup) == null ? void 0 : i.contents) || ((s = t.contentsObj) == null ? void 0 : s.str) || "";
  }
  set commentText(t) {
    const {
      data: e
    } = this, i = {
      deleted: !t,
      contents: t || ""
    };
    this.annotationStorage.updateEditor(e.id, {
      popup: i
    }) || this.annotationStorage.setValue(`${Gh}${e.id}`, {
      id: e.id,
      annotationType: e.annotationType,
      pageIndex: this.parent.page._pageIndex,
      popup: i,
      popupRef: e.popupRef,
      modificationDate: /* @__PURE__ */ new Date()
    }), t || this.removePopup();
  }
  removePopup() {
    var t, e;
    (e = ((t = n(this, ts)) == null ? void 0 : t.popup) || this.popup) == null || e.remove(), p(this, ts, this.popup = null);
  }
  updateEdited(t) {
    var r;
    if (!this.container)
      return;
    t.rect && (n(this, Wa) || p(this, Wa, {
      rect: this.data.rect.slice(0)
    }));
    const {
      rect: e,
      popup: i
    } = t;
    e && b(this, sd, Cp).call(this, e);
    let s = ((r = n(this, ts)) == null ? void 0 : r.popup) || this.popup;
    !s && (i != null && i.text) && (this._createPopup(i), s = n(this, ts).popup), s && (s.updateEdited(t), i != null && i.deleted && (s.remove(), p(this, ts, null), this.popup = null));
  }
  resetEdited() {
    var t;
    n(this, Wa) && (b(this, sd, Cp).call(this, n(this, Wa).rect), (t = n(this, ts)) == null || t.popup.resetEdited(), p(this, Wa, null));
  }
  _createContainer(t) {
    const {
      data: e,
      parent: {
        page: i,
        viewport: s
      }
    } = this, r = document.createElement("section");
    r.setAttribute("data-annotation-id", e.id), !(this instanceof vo) && !(this instanceof Eg) && (r.tabIndex = 0);
    const {
      style: a
    } = r;
    if (a.zIndex = this.parent.zIndex, this.parent.zIndex += 2, e.alternativeText && (r.title = e.alternativeText), e.noRotate && r.classList.add("norotate"), !e.rect || this instanceof Tp) {
      const {
        rotation: y
      } = e;
      return !e.hasOwnCanvas && y !== 0 && this.setRotation(y, r), r;
    }
    const {
      width: o,
      height: l
    } = this;
    if (!t && e.borderStyle.width > 0) {
      a.borderWidth = `${e.borderStyle.width}px`;
      const y = e.borderStyle.horizontalCornerRadius, v = e.borderStyle.verticalCornerRadius;
      if (y > 0 || v > 0) {
        const S = `calc(${y}px * var(--total-scale-factor)) / calc(${v}px * var(--total-scale-factor))`;
        a.borderRadius = S;
      } else if (this instanceof Ob) {
        const S = `calc(${o}px * var(--total-scale-factor)) / calc(${l}px * var(--total-scale-factor))`;
        a.borderRadius = S;
      }
      switch (e.borderStyle.style) {
        case So.SOLID:
          a.borderStyle = "solid";
          break;
        case So.DASHED:
          a.borderStyle = "dashed";
          break;
        case So.BEVELED:
          J("Unimplemented border style: beveled");
          break;
        case So.INSET:
          J("Unimplemented border style: inset");
          break;
        case So.UNDERLINE:
          a.borderBottomStyle = "solid";
          break;
      }
      const w = e.borderColor || null;
      w ? (p(this, Fl, !0), a.borderColor = z.makeHexColor(w[0] | 0, w[1] | 0, w[2] | 0)) : a.borderWidth = 0;
    }
    const h = z.normalizeRect([e.rect[0], i.view[3] - e.rect[1] + i.view[1], e.rect[2], i.view[3] - e.rect[3] + i.view[1]]), {
      pageWidth: c,
      pageHeight: u,
      pageX: f,
      pageY: m
    } = s.rawDims;
    a.left = `${100 * (h[0] - f) / c}%`, a.top = `${100 * (h[1] - m) / u}%`;
    const {
      rotation: A
    } = e;
    return e.hasOwnCanvas || A === 0 ? (a.width = `${100 * o / c}%`, a.height = `${100 * l / u}%`) : this.setRotation(A, r), r;
  }
  setRotation(t, e = this.container) {
    if (!this.data.rect)
      return;
    const {
      pageWidth: i,
      pageHeight: s
    } = this.parent.viewport.rawDims;
    let {
      width: r,
      height: a
    } = this;
    t % 180 !== 0 && ([r, a] = [a, r]), e.style.width = `${100 * r / i}%`, e.style.height = `${100 * a / s}%`, e.setAttribute("data-main-rotation", (360 - t) % 360);
  }
  get _commonActions() {
    const t = (e, i, s) => {
      const r = s.detail[e], a = r[0], o = r.slice(1);
      s.target.style[i] = rm[`${a}_HTML`](o), this.annotationStorage.setValue(this.data.id, {
        [i]: rm[`${a}_rgb`](o)
      });
    };
    return st(this, "_commonActions", {
      display: (e) => {
        const {
          display: i
        } = e.detail, s = i % 2 === 1;
        this.container.style.visibility = s ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noView: s,
          noPrint: i === 1 || i === 2
        });
      },
      print: (e) => {
        this.annotationStorage.setValue(this.data.id, {
          noPrint: !e.detail.print
        });
      },
      hidden: (e) => {
        const {
          hidden: i
        } = e.detail;
        this.container.style.visibility = i ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noPrint: i,
          noView: i
        });
      },
      focus: (e) => {
        setTimeout(() => e.target.focus({
          preventScroll: !1
        }), 0);
      },
      userName: (e) => {
        e.target.title = e.detail.userName;
      },
      readonly: (e) => {
        e.target.disabled = e.detail.readonly;
      },
      required: (e) => {
        this._setRequired(e.target, e.detail.required);
      },
      bgColor: (e) => {
        t("bgColor", "backgroundColor", e);
      },
      fillColor: (e) => {
        t("fillColor", "backgroundColor", e);
      },
      fgColor: (e) => {
        t("fgColor", "color", e);
      },
      textColor: (e) => {
        t("textColor", "color", e);
      },
      borderColor: (e) => {
        t("borderColor", "borderColor", e);
      },
      strokeColor: (e) => {
        t("strokeColor", "borderColor", e);
      },
      rotation: (e) => {
        const i = e.detail.rotation;
        this.setRotation(i), this.annotationStorage.setValue(this.data.id, {
          rotation: i
        });
      }
    });
  }
  _dispatchEventFromSandbox(t, e) {
    const i = this._commonActions;
    for (const s of Object.keys(e.detail)) {
      const r = t[s] || i[s];
      r == null || r(e);
    }
  }
  _setDefaultPropertiesFromJS(t) {
    if (!this.enableScripting)
      return;
    const e = this.annotationStorage.getRawValue(this.data.id);
    if (!e)
      return;
    const i = this._commonActions;
    for (const [s, r] of Object.entries(e)) {
      const a = i[s];
      if (a) {
        const o = {
          detail: {
            [s]: r
          },
          target: t
        };
        a(o), delete e[s];
      }
    }
  }
  _createQuadrilaterals() {
    if (!this.container)
      return;
    const {
      quadPoints: t
    } = this.data;
    if (!t)
      return;
    const [e, i, s, r] = this.data.rect.map((y) => Math.fround(y));
    if (t.length === 8) {
      const [y, v, w, S] = t.subarray(2, 6);
      if (s === y && r === v && e === w && i === S)
        return;
    }
    const {
      style: a
    } = this.container;
    let o;
    if (n(this, Fl)) {
      const {
        borderColor: y,
        borderWidth: v
      } = a;
      a.borderWidth = 0, o = ["url('data:image/svg+xml;utf8,", '<svg xmlns="http://www.w3.org/2000/svg"', ' preserveAspectRatio="none" viewBox="0 0 1 1">', `<g fill="transparent" stroke="${y}" stroke-width="${v}">`], this.container.classList.add("hasBorder");
    }
    const l = s - e, h = r - i, {
      svgFactory: c
    } = this, u = c.createElement("svg");
    u.classList.add("quadrilateralsContainer"), u.setAttribute("width", 0), u.setAttribute("height", 0), u.role = "none";
    const f = c.createElement("defs");
    u.append(f);
    const m = c.createElement("clipPath"), A = `clippath_${this.data.id}`;
    m.setAttribute("id", A), m.setAttribute("clipPathUnits", "objectBoundingBox"), f.append(m);
    for (let y = 2, v = t.length; y < v; y += 8) {
      const w = t[y], S = t[y + 1], E = t[y + 2], _ = t[y + 3], x = c.createElement("rect"), C = (E - e) / l, T = (r - S) / h, L = (w - E) / l, k = (S - _) / h;
      x.setAttribute("x", C), x.setAttribute("y", T), x.setAttribute("width", L), x.setAttribute("height", k), m.append(x), o == null || o.push(`<rect vector-effect="non-scaling-stroke" x="${C}" y="${T}" width="${L}" height="${k}"/>`);
    }
    n(this, Fl) && (o.push("</g></svg>')"), a.backgroundImage = o.join("")), this.container.append(u), this.container.style.clipPath = `url(#${A})`;
  }
  _createPopup(t = null) {
    const {
      data: e
    } = this;
    let i, s;
    t ? (i = {
      str: t.text
    }, s = t.date) : (i = e.contentsObj, s = e.modificationDate);
    const r = p(this, ts, new Tp({
      data: {
        color: e.color,
        titleObj: e.titleObj,
        modificationDate: s,
        contentsObj: i,
        richText: e.richText,
        parentRect: e.rect,
        borderStyle: 0,
        id: `popup_${e.id}`,
        rotation: e.rotation,
        noRotate: !0
      },
      linkService: this.linkService,
      parent: this.parent,
      elements: [this]
    }));
    this.parent._commentManager || this.parent.div.append(r.render());
  }
  get hasPopupElement() {
    return !!(n(this, ts) || this.popup || this.data.popupRef);
  }
  get extraPopupElement() {
    return n(this, ts);
  }
  render() {
    Dt("Abstract method `AnnotationElement.render` called");
  }
  _getElementsByName(t, e = null) {
    const i = [];
    if (this._fieldObjects) {
      const s = this._fieldObjects[t];
      if (s)
        for (const {
          page: r,
          id: a,
          exportValues: o
        } of s) {
          if (r === -1 || a === e)
            continue;
          const l = typeof o == "string" ? o : null, h = document.querySelector(`[data-element-id="${a}"]`);
          if (h && !yo.has(h)) {
            J(`_getElementsByName - element not allowed: ${a}`);
            continue;
          }
          i.push({
            id: a,
            exportValue: l,
            domElement: h
          });
        }
      return i;
    }
    for (const s of document.getElementsByName(t)) {
      const {
        exportValue: r
      } = s, a = s.getAttribute("data-element-id");
      a !== e && yo.has(s) && i.push({
        id: a,
        exportValue: r,
        domElement: s
      });
    }
    return i;
  }
  show() {
    var t;
    this.container && (this.container.hidden = !1), (t = this.popup) == null || t.maybeShow();
  }
  hide() {
    var t;
    this.container && (this.container.hidden = !0), (t = this.popup) == null || t.forceHide();
  }
  getElementsToTriggerPopup() {
    return this.container;
  }
  addHighlightArea() {
    const t = this.getElementsToTriggerPopup();
    if (Array.isArray(t))
      for (const e of t)
        e.classList.add("highlightArea");
    else
      t.classList.add("highlightArea");
  }
  _editOnDoubleClick() {
    if (!this._isEditable)
      return;
    const {
      annotationEditorType: t,
      data: {
        id: e
      }
    } = this;
    this.container.addEventListener("dblclick", () => {
      var i;
      (i = this.linkService.eventBus) == null || i.dispatch("switchannotationeditormode", {
        source: this,
        mode: t,
        editId: e,
        mustEnterInEditMode: !0
      });
    });
  }
  get width() {
    return this.data.rect[2] - this.data.rect[0];
  }
  get height() {
    return this.data.rect[3] - this.data.rect[1];
  }
};
Wa = new WeakMap(), Fl = new WeakMap(), ts = new WeakMap(), sd = new WeakSet(), Cp = function(t) {
  const {
    container: {
      style: e
    },
    data: {
      rect: i,
      rotation: s
    },
    parent: {
      viewport: {
        rawDims: {
          pageWidth: r,
          pageHeight: a,
          pageX: o,
          pageY: l
        }
      }
    }
  } = this;
  i == null || i.splice(0, 4, ...t), e.left = `${100 * (t[0] - o) / r}%`, e.top = `${100 * (a - t[3] + l) / a}%`, s === 0 ? (e.width = `${100 * (t[2] - t[0]) / r}%`, e.height = `${100 * (t[3] - t[1]) / a}%`) : this.setRotation(s);
};
let Gt = Rg;
class _A extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.editor = t.editor;
  }
  render() {
    return this.container.className = "editorAnnotation", this.container;
  }
  createOrUpdatePopup() {
    const {
      editor: t
    } = this;
    t.hasComment && (this._createPopup(t.comment), this.extraPopupElement.popup.renderCommentButton());
  }
  get hasCommentButton() {
    return this.enableComment && this.editor.hasComment;
  }
  get commentButtonPosition() {
    return this.editor.commentButtonPositionInPage;
  }
  get commentText() {
    return this.editor.comment.text;
  }
  set commentText(t) {
    this.editor.comment = t, t || this.removePopup();
  }
  get commentData() {
    return this.editor.getData();
  }
  remove() {
    this.container.remove(), this.container = null, this.removePopup();
  }
}
var Hi, ta, Fb, Nb;
class Eg extends Gt {
  constructor(e, i = null) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !!(i != null && i.ignoreBorder),
      createQuadrilaterals: !0
    });
    g(this, Hi);
    this.isTooltipOnly = e.data.isTooltipOnly;
  }
  render() {
    const {
      data: e,
      linkService: i
    } = this, s = document.createElement("a");
    s.setAttribute("data-element-id", e.id);
    let r = !1;
    return e.url ? (i.addLinkAttributes(s, e.url, e.newWindow), r = !0) : e.action ? (this._bindNamedAction(s, e.action, e.overlaidText), r = !0) : e.attachment ? (b(this, Hi, Fb).call(this, s, e.attachment, e.overlaidText, e.attachmentDest), r = !0) : e.setOCGState ? (b(this, Hi, Nb).call(this, s, e.setOCGState, e.overlaidText), r = !0) : e.dest ? (this._bindLink(s, e.dest, e.overlaidText), r = !0) : (e.actions && (e.actions.Action || e.actions["Mouse Up"] || e.actions["Mouse Down"]) && this.enableScripting && this.hasJSActions && (this._bindJSAction(s, e), r = !0), e.resetForm ? (this._bindResetFormAction(s, e.resetForm), r = !0) : this.isTooltipOnly && !r && (this._bindLink(s, ""), r = !0)), this.container.classList.add("linkAnnotation"), r && this.container.append(s), this.container;
  }
  _bindLink(e, i, s = "") {
    e.href = this.linkService.getDestinationHash(i), e.onclick = () => (i && this.linkService.goToDestination(i), !1), (i || i === "") && b(this, Hi, ta).call(this), s && (e.title = s);
  }
  _bindNamedAction(e, i, s = "") {
    e.href = this.linkService.getAnchorUrl(""), e.onclick = () => (this.linkService.executeNamedAction(i), !1), s && (e.title = s), b(this, Hi, ta).call(this);
  }
  _bindJSAction(e, i) {
    e.href = this.linkService.getAnchorUrl("");
    const s = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
    for (const r of Object.keys(i.actions)) {
      const a = s.get(r);
      a && (e[a] = () => {
        var o;
        return (o = this.linkService.eventBus) == null || o.dispatch("dispatcheventinsandbox", {
          source: this,
          detail: {
            id: i.id,
            name: r
          }
        }), !1;
      });
    }
    i.overlaidText && (e.title = i.overlaidText), e.onclick || (e.onclick = () => !1), b(this, Hi, ta).call(this);
  }
  _bindResetFormAction(e, i) {
    const s = e.onclick;
    if (s || (e.href = this.linkService.getAnchorUrl("")), b(this, Hi, ta).call(this), !this._fieldObjects) {
      J('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), s || (e.onclick = () => !1);
      return;
    }
    e.onclick = () => {
      var u;
      s == null || s();
      const {
        fields: r,
        refs: a,
        include: o
      } = i, l = [];
      if (r.length !== 0 || a.length !== 0) {
        const f = new Set(a);
        for (const m of r) {
          const A = this._fieldObjects[m] || [];
          for (const {
            id: y
          } of A)
            f.add(y);
        }
        for (const m of Object.values(this._fieldObjects))
          for (const A of m)
            f.has(A.id) === o && l.push(A);
      } else
        for (const f of Object.values(this._fieldObjects))
          l.push(...f);
      const h = this.annotationStorage, c = [];
      for (const f of l) {
        const {
          id: m
        } = f;
        switch (c.push(m), f.type) {
          case "text": {
            const y = f.defaultValue || "";
            h.setValue(m, {
              value: y
            });
            break;
          }
          case "checkbox":
          case "radiobutton": {
            const y = f.defaultValue === f.exportValues;
            h.setValue(m, {
              value: y
            });
            break;
          }
          case "combobox":
          case "listbox": {
            const y = f.defaultValue || "";
            h.setValue(m, {
              value: y
            });
            break;
          }
          default:
            continue;
        }
        const A = document.querySelector(`[data-element-id="${m}"]`);
        if (A) {
          if (!yo.has(A)) {
            J(`_bindResetFormAction - element not allowed: ${m}`);
            continue;
          }
        } else continue;
        A.dispatchEvent(new Event("resetform"));
      }
      return this.enableScripting && ((u = this.linkService.eventBus) == null || u.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: "app",
          ids: c,
          name: "ResetForm"
        }
      })), !1;
    };
  }
}
Hi = new WeakSet(), ta = function() {
  this.container.setAttribute("data-internal-link", "");
}, Fb = function(e, i, s = "", r = null) {
  e.href = this.linkService.getAnchorUrl(""), i.description ? e.title = i.description : s && (e.title = s), e.onclick = () => {
    var a;
    return (a = this.downloadManager) == null || a.openOrDownloadData(i.content, i.filename, r), !1;
  }, b(this, Hi, ta).call(this);
}, Nb = function(e, i, s = "") {
  e.href = this.linkService.getAnchorUrl(""), e.onclick = () => (this.linkService.executeSetOCGState(i), !1), s && (e.title = s), b(this, Hi, ta).call(this);
};
class xA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0
    });
  }
  render() {
    this.container.classList.add("textAnnotation");
    const t = document.createElement("img");
    return t.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", t.setAttribute("data-l10n-id", "pdfjs-text-annotation-type"), t.setAttribute("data-l10n-args", JSON.stringify({
      type: this.data.name
    })), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.append(t), this.container;
  }
}
class vo extends Gt {
  render() {
    return this.container;
  }
  showElementAndHideCanvas(t) {
    var e;
    this.data.hasOwnCanvas && (((e = t.previousSibling) == null ? void 0 : e.nodeName) === "CANVAS" && (t.previousSibling.hidden = !0), t.hidden = !1);
  }
  _getKeyModifier(t) {
    return _e.platform.isMac ? t.metaKey : t.ctrlKey;
  }
  _setEventListener(t, e, i, s, r) {
    i.includes("mouse") ? t.addEventListener(i, (a) => {
      var o;
      (o = this.linkService.eventBus) == null || o.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: s,
          value: r(a),
          shift: a.shiftKey,
          modifier: this._getKeyModifier(a)
        }
      });
    }) : t.addEventListener(i, (a) => {
      var o;
      if (i === "blur") {
        if (!e.focused || !a.relatedTarget)
          return;
        e.focused = !1;
      } else if (i === "focus") {
        if (e.focused)
          return;
        e.focused = !0;
      }
      r && ((o = this.linkService.eventBus) == null || o.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: s,
          value: r(a)
        }
      }));
    });
  }
  _setEventListeners(t, e, i, s) {
    var r, a, o;
    for (const [l, h] of i)
      (h === "Action" || (r = this.data.actions) != null && r[h]) && ((h === "Focus" || h === "Blur") && (e || (e = {
        focused: !1
      })), this._setEventListener(t, e, l, h, s), h === "Focus" && !((a = this.data.actions) != null && a.Blur) ? this._setEventListener(t, e, "blur", "Blur", null) : h === "Blur" && !((o = this.data.actions) != null && o.Focus) && this._setEventListener(t, e, "focus", "Focus", null));
  }
  _setBackgroundColor(t) {
    const e = this.data.backgroundColor || null;
    t.style.backgroundColor = e === null ? "transparent" : z.makeHexColor(e[0], e[1], e[2]);
  }
  _setTextStyle(t) {
    const e = ["left", "center", "right"], {
      fontColor: i
    } = this.data.defaultAppearanceData, s = this.data.defaultAppearanceData.fontSize || EA, r = t.style;
    let a;
    const o = 2, l = (h) => Math.round(10 * h) / 10;
    if (this.data.multiLine) {
      const h = Math.abs(this.data.rect[3] - this.data.rect[1] - o), c = Math.round(h / (Tf * s)) || 1, u = h / c;
      a = Math.min(s, l(u / Tf));
    } else {
      const h = Math.abs(this.data.rect[3] - this.data.rect[1] - o);
      a = Math.min(s, l(h / Tf));
    }
    r.fontSize = `calc(${a}px * var(--total-scale-factor))`, r.color = z.makeHexColor(i[0], i[1], i[2]), this.data.textAlignment !== null && (r.textAlign = e[this.data.textAlignment]);
  }
  _setRequired(t, e) {
    e ? t.setAttribute("required", !0) : t.removeAttribute("required"), t.setAttribute("aria-required", e);
  }
}
class CA extends vo {
  constructor(t) {
    const e = t.renderForms || t.data.hasOwnCanvas || !t.data.hasAppearance && !!t.data.fieldValue;
    super(t, {
      isRenderable: e
    });
  }
  setPropertyOnSiblings(t, e, i, s) {
    const r = this.annotationStorage;
    for (const a of this._getElementsByName(t.name, t.id))
      a.domElement && (a.domElement[e] = i), r.setValue(a.id, {
        [s]: i
      });
  }
  render() {
    var s, r;
    const t = this.annotationStorage, e = this.data.id;
    this.container.classList.add("textWidgetAnnotation");
    let i = null;
    if (this.renderForms) {
      const a = t.getValue(e, {
        value: this.data.fieldValue
      });
      let o = a.value || "";
      const l = t.getValue(e, {
        charLimit: this.data.maxLen
      }).charLimit;
      l && o.length > l && (o = o.slice(0, l));
      let h = a.formattedValue || ((s = this.data.textContent) == null ? void 0 : s.join(`
`)) || null;
      h && this.data.comb && (h = h.replaceAll(/\s+/g, ""));
      const c = {
        userValue: o,
        formattedValue: h,
        lastCommittedValue: null,
        commitKey: 1,
        focused: !1
      };
      this.data.multiLine ? (i = document.createElement("textarea"), i.textContent = h ?? o, this.data.doNotScroll && (i.style.overflowY = "hidden")) : (i = document.createElement("input"), i.type = this.data.password ? "password" : "text", i.setAttribute("value", h ?? o), this.data.doNotScroll && (i.style.overflowX = "hidden")), this.data.hasOwnCanvas && (i.hidden = !0), yo.add(i), i.setAttribute("data-element-id", e), i.disabled = this.data.readOnly, i.name = this.data.fieldName, i.tabIndex = 0;
      const {
        datetimeFormat: u,
        datetimeType: f,
        timeStep: m
      } = this.data, A = !!f && this.enableScripting;
      u && (i.title = u), this._setRequired(i, this.data.required), l && (i.maxLength = l), i.addEventListener("input", (v) => {
        t.setValue(e, {
          value: v.target.value
        }), this.setPropertyOnSiblings(i, "value", v.target.value, "value"), c.formattedValue = null;
      }), i.addEventListener("resetform", (v) => {
        const w = this.data.defaultFieldValue ?? "";
        i.value = c.userValue = w, c.formattedValue = null;
      });
      let y = (v) => {
        const {
          formattedValue: w
        } = c;
        w != null && (v.target.value = w), v.target.scrollLeft = 0;
      };
      if (this.enableScripting && this.hasJSActions) {
        i.addEventListener("focus", (w) => {
          var E;
          if (c.focused)
            return;
          const {
            target: S
          } = w;
          if (A && (S.type = f, m && (S.step = m)), c.userValue) {
            const _ = c.userValue;
            if (A)
              if (f === "time") {
                const x = new Date(_), C = [x.getHours(), x.getMinutes(), x.getSeconds()];
                S.value = C.map((T) => T.toString().padStart(2, "0")).join(":");
              } else
                S.value = new Date(_ - SA).toISOString().split(f === "date" ? "T" : ".", 1)[0];
            else
              S.value = _;
          }
          c.lastCommittedValue = S.value, c.commitKey = 1, (E = this.data.actions) != null && E.Focus || (c.focused = !0);
        }), i.addEventListener("updatefromsandbox", (w) => {
          this.showElementAndHideCanvas(w.target);
          const S = {
            value(E) {
              c.userValue = E.detail.value ?? "", A || t.setValue(e, {
                value: c.userValue.toString()
              }), E.target.value = c.userValue;
            },
            formattedValue(E) {
              const {
                formattedValue: _
              } = E.detail;
              c.formattedValue = _, _ != null && E.target !== document.activeElement && (E.target.value = _);
              const x = {
                formattedValue: _
              };
              A && (x.value = _), t.setValue(e, x);
            },
            selRange(E) {
              E.target.setSelectionRange(...E.detail.selRange);
            },
            charLimit: (E) => {
              var T;
              const {
                charLimit: _
              } = E.detail, {
                target: x
              } = E;
              if (_ === 0) {
                x.removeAttribute("maxLength");
                return;
              }
              x.setAttribute("maxLength", _);
              let C = c.userValue;
              !C || C.length <= _ || (C = C.slice(0, _), x.value = c.userValue = C, t.setValue(e, {
                value: C
              }), (T = this.linkService.eventBus) == null || T.dispatch("dispatcheventinsandbox", {
                source: this,
                detail: {
                  id: e,
                  name: "Keystroke",
                  value: C,
                  willCommit: !0,
                  commitKey: 1,
                  selStart: x.selectionStart,
                  selEnd: x.selectionEnd
                }
              }));
            }
          };
          this._dispatchEventFromSandbox(S, w);
        }), i.addEventListener("keydown", (w) => {
          var _;
          c.commitKey = 1;
          let S = -1;
          if (w.key === "Escape" ? S = 0 : w.key === "Enter" && !this.data.multiLine ? S = 2 : w.key === "Tab" && (c.commitKey = 3), S === -1)
            return;
          const {
            value: E
          } = w.target;
          c.lastCommittedValue !== E && (c.lastCommittedValue = E, c.userValue = E, (_ = this.linkService.eventBus) == null || _.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: E,
              willCommit: !0,
              commitKey: S,
              selStart: w.target.selectionStart,
              selEnd: w.target.selectionEnd
            }
          }));
        });
        const v = y;
        y = null, i.addEventListener("blur", (w) => {
          var _, x;
          if (!c.focused || !w.relatedTarget)
            return;
          (_ = this.data.actions) != null && _.Blur || (c.focused = !1);
          const {
            target: S
          } = w;
          let {
            value: E
          } = S;
          if (A) {
            if (E && f === "time") {
              const C = E.split(":").map((T) => parseInt(T, 10));
              E = new Date(2e3, 0, 1, C[0], C[1], C[2] || 0).valueOf(), S.step = "";
            } else
              E.includes("T") || (E = `${E}T00:00`), E = new Date(E).valueOf();
            S.type = "text";
          }
          c.userValue = E, c.lastCommittedValue !== E && ((x = this.linkService.eventBus) == null || x.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: E,
              willCommit: !0,
              commitKey: c.commitKey,
              selStart: w.target.selectionStart,
              selEnd: w.target.selectionEnd
            }
          })), v(w);
        }), (r = this.data.actions) != null && r.Keystroke && i.addEventListener("beforeinput", (w) => {
          var k;
          c.lastCommittedValue = null;
          const {
            data: S,
            target: E
          } = w, {
            value: _,
            selectionStart: x,
            selectionEnd: C
          } = E;
          let T = x, L = C;
          switch (w.inputType) {
            case "deleteWordBackward": {
              const D = _.substring(0, x).match(/\w*[^\w]*$/);
              D && (T -= D[0].length);
              break;
            }
            case "deleteWordForward": {
              const D = _.substring(x).match(/^[^\w]*\w*/);
              D && (L += D[0].length);
              break;
            }
            case "deleteContentBackward":
              x === C && (T -= 1);
              break;
            case "deleteContentForward":
              x === C && (L += 1);
              break;
          }
          w.preventDefault(), (k = this.linkService.eventBus) == null || k.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: _,
              change: S || "",
              willCommit: !1,
              selStart: T,
              selEnd: L
            }
          });
        }), this._setEventListeners(i, c, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (w) => w.target.value);
      }
      if (y && i.addEventListener("blur", y), this.data.comb) {
        const w = (this.data.rect[2] - this.data.rect[0]) / l;
        i.classList.add("comb"), i.style.letterSpacing = `calc(${w}px * var(--total-scale-factor) - 1ch)`;
      }
    } else
      i = document.createElement("div"), i.textContent = this.data.fieldValue, i.style.verticalAlign = "middle", i.style.display = "table-cell", this.data.hasOwnCanvas && (i.hidden = !0);
    return this._setTextStyle(i), this._setBackgroundColor(i), this._setDefaultPropertiesFromJS(i), this.container.append(i), this.container;
  }
}
class TA extends vo {
  constructor(t) {
    super(t, {
      isRenderable: !!t.data.hasOwnCanvas
    });
  }
}
class PA extends vo {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    const t = this.annotationStorage, e = this.data, i = e.id;
    let s = t.getValue(i, {
      value: e.exportValue === e.fieldValue
    }).value;
    typeof s == "string" && (s = s !== "Off", t.setValue(i, {
      value: s
    })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
    const r = document.createElement("input");
    return yo.add(r), r.setAttribute("data-element-id", i), r.disabled = e.readOnly, this._setRequired(r, this.data.required), r.type = "checkbox", r.name = e.fieldName, s && r.setAttribute("checked", !0), r.setAttribute("exportValue", e.exportValue), r.tabIndex = 0, r.addEventListener("change", (a) => {
      const {
        name: o,
        checked: l
      } = a.target;
      for (const h of this._getElementsByName(o, i)) {
        const c = l && h.exportValue === e.exportValue;
        h.domElement && (h.domElement.checked = c), t.setValue(h.id, {
          value: c
        });
      }
      t.setValue(i, {
        value: l
      });
    }), r.addEventListener("resetform", (a) => {
      const o = e.defaultFieldValue || "Off";
      a.target.checked = o === e.exportValue;
    }), this.enableScripting && this.hasJSActions && (r.addEventListener("updatefromsandbox", (a) => {
      const o = {
        value(l) {
          l.target.checked = l.detail.value !== "Off", t.setValue(i, {
            value: l.target.checked
          });
        }
      };
      this._dispatchEventFromSandbox(o, a);
    }), this._setEventListeners(r, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (a) => a.target.checked)), this._setBackgroundColor(r), this._setDefaultPropertiesFromJS(r), this.container.append(r), this.container;
  }
}
class Ob extends vo {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("buttonWidgetAnnotation", "radioButton");
    const t = this.annotationStorage, e = this.data, i = e.id;
    let s = t.getValue(i, {
      value: e.fieldValue === e.buttonValue
    }).value;
    if (typeof s == "string" && (s = s !== e.buttonValue, t.setValue(i, {
      value: s
    })), s)
      for (const a of this._getElementsByName(e.fieldName, i))
        t.setValue(a.id, {
          value: !1
        });
    const r = document.createElement("input");
    if (yo.add(r), r.setAttribute("data-element-id", i), r.disabled = e.readOnly, this._setRequired(r, this.data.required), r.type = "radio", r.name = e.fieldName, s && r.setAttribute("checked", !0), r.tabIndex = 0, r.addEventListener("change", (a) => {
      const {
        name: o,
        checked: l
      } = a.target;
      for (const h of this._getElementsByName(o, i))
        t.setValue(h.id, {
          value: !1
        });
      t.setValue(i, {
        value: l
      });
    }), r.addEventListener("resetform", (a) => {
      const o = e.defaultFieldValue;
      a.target.checked = o != null && o === e.buttonValue;
    }), this.enableScripting && this.hasJSActions) {
      const a = e.buttonValue;
      r.addEventListener("updatefromsandbox", (o) => {
        const l = {
          value: (h) => {
            const c = a === h.detail.value;
            for (const u of this._getElementsByName(h.target.name)) {
              const f = c && u.id === i;
              u.domElement && (u.domElement.checked = f), t.setValue(u.id, {
                value: f
              });
            }
          }
        };
        this._dispatchEventFromSandbox(l, o);
      }), this._setEventListeners(r, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (o) => o.target.checked);
    }
    return this._setBackgroundColor(r), this._setDefaultPropertiesFromJS(r), this.container.append(r), this.container;
  }
}
class LA extends Eg {
  constructor(t) {
    super(t, {
      ignoreBorder: t.data.hasAppearance
    });
  }
  render() {
    const t = super.render();
    t.classList.add("buttonWidgetAnnotation", "pushButton");
    const e = t.lastChild;
    return this.enableScripting && this.hasJSActions && e && (this._setDefaultPropertiesFromJS(e), e.addEventListener("updatefromsandbox", (i) => {
      this._dispatchEventFromSandbox({}, i);
    })), t;
  }
}
class kA extends vo {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("choiceWidgetAnnotation");
    const t = this.annotationStorage, e = this.data.id, i = t.getValue(e, {
      value: this.data.fieldValue
    }), s = document.createElement("select");
    yo.add(s), s.setAttribute("data-element-id", e), s.disabled = this.data.readOnly, this._setRequired(s, this.data.required), s.name = this.data.fieldName, s.tabIndex = 0;
    let r = this.data.combo && this.data.options.length > 0;
    this.data.combo || (s.size = this.data.options.length, this.data.multiSelect && (s.multiple = !0)), s.addEventListener("resetform", (c) => {
      const u = this.data.defaultFieldValue;
      for (const f of s.options)
        f.selected = f.value === u;
    });
    for (const c of this.data.options) {
      const u = document.createElement("option");
      u.textContent = c.displayValue, u.value = c.exportValue, i.value.includes(c.exportValue) && (u.setAttribute("selected", !0), r = !1), s.append(u);
    }
    let a = null;
    if (r) {
      const c = document.createElement("option");
      c.value = " ", c.setAttribute("hidden", !0), c.setAttribute("selected", !0), s.prepend(c), a = () => {
        c.remove(), s.removeEventListener("input", a), a = null;
      }, s.addEventListener("input", a);
    }
    const o = (c) => {
      const u = c ? "value" : "textContent", {
        options: f,
        multiple: m
      } = s;
      return m ? Array.prototype.filter.call(f, (A) => A.selected).map((A) => A[u]) : f.selectedIndex === -1 ? null : f[f.selectedIndex][u];
    };
    let l = o(!1);
    const h = (c) => {
      const u = c.target.options;
      return Array.prototype.map.call(u, (f) => ({
        displayValue: f.textContent,
        exportValue: f.value
      }));
    };
    return this.enableScripting && this.hasJSActions ? (s.addEventListener("updatefromsandbox", (c) => {
      const u = {
        value(f) {
          a == null || a();
          const m = f.detail.value, A = new Set(Array.isArray(m) ? m : [m]);
          for (const y of s.options)
            y.selected = A.has(y.value);
          t.setValue(e, {
            value: o(!0)
          }), l = o(!1);
        },
        multipleSelection(f) {
          s.multiple = !0;
        },
        remove(f) {
          const m = s.options, A = f.detail.remove;
          m[A].selected = !1, s.remove(A), m.length > 0 && Array.prototype.findIndex.call(m, (v) => v.selected) === -1 && (m[0].selected = !0), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        clear(f) {
          for (; s.length !== 0; )
            s.remove(0);
          t.setValue(e, {
            value: null,
            items: []
          }), l = o(!1);
        },
        insert(f) {
          const {
            index: m,
            displayValue: A,
            exportValue: y
          } = f.detail.insert, v = s.children[m], w = document.createElement("option");
          w.textContent = A, w.value = y, v ? v.before(w) : s.append(w), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        items(f) {
          const {
            items: m
          } = f.detail;
          for (; s.length !== 0; )
            s.remove(0);
          for (const A of m) {
            const {
              displayValue: y,
              exportValue: v
            } = A, w = document.createElement("option");
            w.textContent = y, w.value = v, s.append(w);
          }
          s.options.length > 0 && (s.options[0].selected = !0), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        indices(f) {
          const m = new Set(f.detail.indices);
          for (const A of f.target.options)
            A.selected = m.has(A.index);
          t.setValue(e, {
            value: o(!0)
          }), l = o(!1);
        },
        editable(f) {
          f.target.disabled = !f.detail.editable;
        }
      };
      this._dispatchEventFromSandbox(u, c);
    }), s.addEventListener("input", (c) => {
      var m;
      const u = o(!0), f = o(!1);
      t.setValue(e, {
        value: u
      }), c.preventDefault(), (m = this.linkService.eventBus) == null || m.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: e,
          name: "Keystroke",
          value: l,
          change: f,
          changeEx: u,
          willCommit: !1,
          commitKey: 1,
          keyDown: !1
        }
      });
    }), this._setEventListeners(s, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (c) => c.target.value)) : s.addEventListener("input", function(c) {
      t.setValue(e, {
        value: o(!0)
      });
    }), this.data.combo && this._setTextStyle(s), this._setBackgroundColor(s), this._setDefaultPropertiesFromJS(s), this.container.append(s), this.container;
  }
}
var nd, Pp;
class Tp extends Gt {
  constructor(e) {
    const {
      data: i,
      elements: s,
      parent: r
    } = e, a = !!r._commentManager;
    super(e, {
      isRenderable: !a && Gt._hasPopupData(i)
    });
    g(this, nd);
    if (this.elements = s, a && Gt._hasPopupData(i)) {
      const o = this.popup = b(this, nd, Pp).call(this);
      for (const l of s)
        l.popup = o;
    } else
      this.popup = null;
  }
  render() {
    const {
      container: e
    } = this;
    e.classList.add("popupAnnotation"), e.role = "comment";
    const i = this.popup = b(this, nd, Pp).call(this), s = [];
    for (const r of this.elements)
      r.popup = i, r.container.ariaHasPopup = "dialog", s.push(r.data.id), r.addHighlightArea();
    return this.container.setAttribute("aria-controls", s.map((r) => `${pg}${r}`).join(",")), this.container;
  }
}
nd = new WeakSet(), Pp = function() {
  return new RA({
    container: this.container,
    color: this.data.color,
    titleObj: this.data.titleObj,
    modificationDate: this.data.modificationDate || this.data.creationDate,
    contentsObj: this.data.contentsObj,
    richText: this.data.richText,
    rect: this.data.rect,
    parentRect: this.data.parentRect || null,
    parent: this.parent,
    elements: this.elements,
    open: this.data.open,
    commentManager: this.parent._commentManager
  });
};
var Ci, xr, rf, af, Nl, Ol, Yt, zs, Cr, ja, Bl, Hl, Gs, Ti, Rn, Mn, be, Dn, Tr, rd, In, Ul, qa, Pr, ze, Lr, rt, gu, Lp, kp, Rp, mu, Mp, Bb, Hb, Ub, $b, bu, yu, Dp;
class RA {
  constructor({
    container: t,
    color: e,
    elements: i,
    titleObj: s,
    modificationDate: r,
    contentsObj: a,
    richText: o,
    parent: l,
    rect: h,
    parentRect: c,
    open: u,
    commentManager: f = null
  }) {
    g(this, rt);
    g(this, Ci, null);
    g(this, xr, b(this, rt, Ub).bind(this));
    g(this, rf, b(this, rt, Dp).bind(this));
    g(this, af, b(this, rt, yu).bind(this));
    g(this, Nl, b(this, rt, bu).bind(this));
    g(this, Ol, null);
    g(this, Yt, null);
    g(this, zs, null);
    g(this, Cr, null);
    g(this, ja, null);
    g(this, Bl, null);
    g(this, Hl, null);
    g(this, Gs, !1);
    g(this, Ti, null);
    g(this, Rn, null);
    g(this, Mn, null);
    g(this, be, null);
    g(this, Dn, null);
    g(this, Tr, null);
    g(this, rd, null);
    g(this, In, null);
    g(this, Ul, null);
    g(this, qa, null);
    g(this, Pr, !1);
    g(this, ze, null);
    g(this, Lr, null);
    p(this, Yt, t), p(this, Ul, s), p(this, zs, a), p(this, In, o), p(this, Bl, l), p(this, Ol, e), p(this, rd, h), p(this, Hl, c), p(this, ja, i), p(this, Ci, f), p(this, ze, i[0]), p(this, Cr, qh.toDateObject(r)), this.trigger = i.flatMap((m) => m.getElementsToTriggerPopup()), f ? this.renderCommentButton() : (b(this, rt, gu).call(this), n(this, Yt).hidden = !0, u && b(this, rt, bu).call(this));
  }
  renderCommentButton() {
    if (n(this, be) || (n(this, Dn) || b(this, rt, Lp).call(this), !n(this, Dn)))
      return;
    const {
      signal: t
    } = p(this, Rn, new AbortController()), e = !!n(this, ze).extraPopupElement, i = () => {
      n(this, Ci).toggleCommentPopup(this, !0, void 0, !e);
    }, s = () => {
      n(this, Ci).toggleCommentPopup(this, !1, !0, !e);
    }, r = () => {
      n(this, Ci).toggleCommentPopup(this, !1, !1);
    };
    if (e) {
      p(this, be, n(this, ze).container);
      for (const a of this.trigger)
        a.ariaHasPopup = "dialog", a.ariaControls = "commentPopup", a.addEventListener("keydown", n(this, xr), {
          signal: t
        }), a.addEventListener("click", i, {
          signal: t
        }), a.addEventListener("pointerenter", s, {
          signal: t
        }), a.addEventListener("pointerleave", r, {
          signal: t
        }), a.classList.add("popupTriggerArea");
    } else {
      const a = p(this, be, document.createElement("button"));
      a.className = "annotationCommentButton";
      const o = n(this, ze).container;
      a.style.zIndex = o.style.zIndex + 1, a.tabIndex = 0, a.ariaHasPopup = "dialog", a.ariaControls = "commentPopup", a.setAttribute("data-l10n-id", "pdfjs-show-comment-button"), b(this, rt, Rp).call(this), b(this, rt, kp).call(this), a.addEventListener("keydown", n(this, xr), {
        signal: t
      }), a.addEventListener("click", i, {
        signal: t
      }), a.addEventListener("pointerenter", s, {
        signal: t
      }), a.addEventListener("pointerleave", r, {
        signal: t
      }), o.after(a);
    }
  }
  get commentButtonColor() {
    const {
      color: t,
      opacity: e
    } = n(this, ze).commentData;
    return t ? n(this, Bl)._commentManager.makeCommentColor(t, e) : null;
  }
  focusCommentButton() {
    setTimeout(() => {
      var t;
      (t = n(this, be)) == null || t.focus();
    }, 0);
  }
  getData() {
    const {
      richText: t,
      color: e,
      opacity: i,
      creationDate: s,
      modificationDate: r
    } = n(this, ze).commentData;
    return {
      contentsObj: {
        str: this.comment
      },
      richText: t,
      color: e,
      opacity: i,
      creationDate: s,
      modificationDate: r
    };
  }
  get elementBeforePopup() {
    return n(this, be);
  }
  get comment() {
    return n(this, Lr) || p(this, Lr, n(this, ze).commentText), n(this, Lr);
  }
  set comment(t) {
    t !== this.comment && (n(this, ze).commentText = p(this, Lr, t));
  }
  get parentBoundingClientRect() {
    return n(this, ze).layer.getBoundingClientRect();
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    n(this, be) && (n(this, be).classList.toggle("selected", t), n(this, be).ariaExpanded = e);
  }
  setSelectedCommentButton(t) {
    n(this, be).classList.toggle("selected", t);
  }
  get commentPopupPosition() {
    if (n(this, Tr))
      return n(this, Tr);
    const {
      x: t,
      y: e,
      height: i
    } = n(this, be).getBoundingClientRect(), {
      x: s,
      y: r,
      width: a,
      height: o
    } = n(this, ze).layer.getBoundingClientRect();
    return [(t - s) / a, (e + i - r) / o];
  }
  set commentPopupPosition(t) {
    p(this, Tr, t);
  }
  hasDefaultPopupPosition() {
    return n(this, Tr) === null;
  }
  get commentButtonPosition() {
    return n(this, Dn);
  }
  get commentButtonWidth() {
    return n(this, be).getBoundingClientRect().width / this.parentBoundingClientRect.width;
  }
  editComment(t) {
    const [e, i] = n(this, Tr) || this.commentButtonPosition.map((h) => h / 100), s = this.parentBoundingClientRect, {
      x: r,
      y: a,
      width: o,
      height: l
    } = s;
    n(this, Ci).showDialog(null, this, r + e * o, a + i * l, {
      ...t,
      parentDimensions: s
    });
  }
  render() {
    var i, s;
    if (n(this, Ti))
      return;
    const t = p(this, Ti, document.createElement("div"));
    if (t.className = "popup", n(this, Ol)) {
      const r = t.style.outlineColor = z.makeHexColor(...n(this, Ol));
      t.style.backgroundColor = `color-mix(in srgb, ${r} 30%, white)`;
    }
    const e = document.createElement("span");
    if (e.className = "header", (i = n(this, Ul)) != null && i.str) {
      const r = document.createElement("span");
      r.className = "title", e.append(r), {
        dir: r.dir,
        str: r.textContent
      } = n(this, Ul);
    }
    if (t.append(e), n(this, Cr)) {
      const r = document.createElement("time");
      r.className = "popupDate", r.setAttribute("data-l10n-id", "pdfjs-annotation-date-time-string"), r.setAttribute("data-l10n-args", JSON.stringify({
        dateObj: n(this, Cr).valueOf()
      })), r.dateTime = n(this, Cr).toISOString(), e.append(r);
    }
    mg({
      html: n(this, rt, mu) || n(this, zs).str,
      dir: (s = n(this, zs)) == null ? void 0 : s.dir,
      className: "popupContent"
    }, t), n(this, Yt).append(t);
  }
  updateEdited({
    rect: t,
    popup: e,
    deleted: i
  }) {
    var s;
    if (n(this, Ci)) {
      i ? (this.remove(), p(this, Lr, null)) : e && (e.deleted ? this.remove() : (b(this, rt, Rp).call(this), p(this, Lr, e.text))), t && (p(this, Dn, null), b(this, rt, Lp).call(this), b(this, rt, kp).call(this));
      return;
    }
    if (i || e != null && e.deleted) {
      this.remove();
      return;
    }
    b(this, rt, gu).call(this), n(this, qa) || p(this, qa, {
      contentsObj: n(this, zs),
      richText: n(this, In)
    }), t && p(this, Mn, null), e && e.text && (p(this, In, b(this, rt, Hb).call(this, e.text)), p(this, Cr, qh.toDateObject(e.date)), p(this, zs, null)), (s = n(this, Ti)) == null || s.remove(), p(this, Ti, null);
  }
  resetEdited() {
    var t;
    n(this, qa) && ({
      contentsObj: oe(this, zs)._,
      richText: oe(this, In)._
    } = n(this, qa), p(this, qa, null), (t = n(this, Ti)) == null || t.remove(), p(this, Ti, null), p(this, Mn, null));
  }
  remove() {
    var t, e, i;
    if ((t = n(this, Rn)) == null || t.abort(), p(this, Rn, null), (e = n(this, Ti)) == null || e.remove(), p(this, Ti, null), p(this, Pr, !1), p(this, Gs, !1), (i = n(this, be)) == null || i.remove(), p(this, be, null), this.trigger)
      for (const s of this.trigger)
        s.classList.remove("popupTriggerArea");
  }
  forceHide() {
    p(this, Pr, this.isVisible), n(this, Pr) && (n(this, Yt).hidden = !0);
  }
  maybeShow() {
    n(this, Ci) || (b(this, rt, gu).call(this), n(this, Pr) && (n(this, Ti) || b(this, rt, yu).call(this), p(this, Pr, !1), n(this, Yt).hidden = !1));
  }
  get isVisible() {
    return n(this, Ci) ? !1 : n(this, Yt).hidden === !1;
  }
}
Ci = new WeakMap(), xr = new WeakMap(), rf = new WeakMap(), af = new WeakMap(), Nl = new WeakMap(), Ol = new WeakMap(), Yt = new WeakMap(), zs = new WeakMap(), Cr = new WeakMap(), ja = new WeakMap(), Bl = new WeakMap(), Hl = new WeakMap(), Gs = new WeakMap(), Ti = new WeakMap(), Rn = new WeakMap(), Mn = new WeakMap(), be = new WeakMap(), Dn = new WeakMap(), Tr = new WeakMap(), rd = new WeakMap(), In = new WeakMap(), Ul = new WeakMap(), qa = new WeakMap(), Pr = new WeakMap(), ze = new WeakMap(), Lr = new WeakMap(), rt = new WeakSet(), gu = function() {
  var e;
  if (n(this, Rn))
    return;
  p(this, Rn, new AbortController());
  const {
    signal: t
  } = n(this, Rn);
  for (const i of this.trigger)
    i.addEventListener("click", n(this, Nl), {
      signal: t
    }), i.addEventListener("pointerenter", n(this, af), {
      signal: t
    }), i.addEventListener("pointerleave", n(this, rf), {
      signal: t
    }), i.classList.add("popupTriggerArea");
  for (const i of n(this, ja))
    (e = i.container) == null || e.addEventListener("keydown", n(this, xr), {
      signal: t
    });
}, Lp = function() {
  const t = n(this, ja).find((e) => e.hasCommentButton);
  t && p(this, Dn, t._normalizePoint(t.commentButtonPosition));
}, kp = function() {
  if (n(this, ze).extraPopupElement && !n(this, ze).editor)
    return;
  this.renderCommentButton();
  const [t, e] = n(this, Dn), {
    style: i
  } = n(this, be);
  i.left = `calc(${t}%)`, i.top = `calc(${e}% - var(--comment-button-dim))`;
}, Rp = function() {
  n(this, ze).extraPopupElement || (this.renderCommentButton(), n(this, be).style.backgroundColor = this.commentButtonColor || "");
}, mu = function() {
  const t = n(this, In), e = n(this, zs);
  return t != null && t.str && (!(e != null && e.str) || e.str === t.str) && n(this, In).html || null;
}, Mp = function() {
  var t, e, i;
  return ((i = (e = (t = n(this, rt, mu)) == null ? void 0 : t.attributes) == null ? void 0 : e.style) == null ? void 0 : i.fontSize) || 0;
}, Bb = function() {
  var t, e, i;
  return ((i = (e = (t = n(this, rt, mu)) == null ? void 0 : t.attributes) == null ? void 0 : e.style) == null ? void 0 : i.color) || null;
}, Hb = function(t) {
  const e = [], i = {
    str: t,
    html: {
      name: "div",
      attributes: {
        dir: "auto"
      },
      children: [{
        name: "p",
        children: e
      }]
    }
  }, s = {
    style: {
      color: n(this, rt, Bb),
      fontSize: n(this, rt, Mp) ? `calc(${n(this, rt, Mp)}px * var(--total-scale-factor))` : ""
    }
  };
  for (const r of t.split(`
`))
    e.push({
      name: "span",
      value: r,
      attributes: s
    });
  return i;
}, Ub = function(t) {
  t.altKey || t.shiftKey || t.ctrlKey || t.metaKey || (t.key === "Enter" || t.key === "Escape" && n(this, Gs)) && b(this, rt, bu).call(this);
}, $b = function() {
  if (n(this, Mn) !== null)
    return;
  const {
    page: {
      view: t
    },
    viewport: {
      rawDims: {
        pageWidth: e,
        pageHeight: i,
        pageX: s,
        pageY: r
      }
    }
  } = n(this, Bl);
  let a = !!n(this, Hl), o = a ? n(this, Hl) : n(this, rd);
  for (const A of n(this, ja))
    if (!o || z.intersect(A.data.rect, o) !== null) {
      o = A.data.rect, a = !0;
      break;
    }
  const l = z.normalizeRect([o[0], t[3] - o[1] + t[1], o[2], t[3] - o[3] + t[1]]), c = a ? o[2] - o[0] + 5 : 0, u = l[0] + c, f = l[1];
  p(this, Mn, [100 * (u - s) / e, 100 * (f - r) / i]);
  const {
    style: m
  } = n(this, Yt);
  m.left = `${n(this, Mn)[0]}%`, m.top = `${n(this, Mn)[1]}%`;
}, bu = function() {
  if (n(this, Ci)) {
    n(this, Ci).toggleCommentPopup(this, !1);
    return;
  }
  p(this, Gs, !n(this, Gs)), n(this, Gs) ? (b(this, rt, yu).call(this), n(this, Yt).addEventListener("click", n(this, Nl)), n(this, Yt).addEventListener("keydown", n(this, xr))) : (b(this, rt, Dp).call(this), n(this, Yt).removeEventListener("click", n(this, Nl)), n(this, Yt).removeEventListener("keydown", n(this, xr)));
}, yu = function() {
  n(this, Ti) || this.render(), this.isVisible ? n(this, Gs) && n(this, Yt).classList.add("focused") : (b(this, rt, $b).call(this), n(this, Yt).hidden = !1, n(this, Yt).style.zIndex = parseInt(n(this, Yt).style.zIndex) + 1e3);
}, Dp = function() {
  n(this, Yt).classList.remove("focused"), !(n(this, Gs) || !this.isVisible) && (n(this, Yt).hidden = !0, n(this, Yt).style.zIndex = parseInt(n(this, Yt).style.zIndex) - 1e3);
};
class Vb extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.textContent = t.data.textContent, this.textPosition = t.data.textPosition, this.annotationEditorType = Z.FREETEXT;
  }
  render() {
    if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
      const t = document.createElement("div");
      t.classList.add("annotationTextContent"), t.setAttribute("role", "comment");
      for (const e of this.textContent) {
        const i = document.createElement("span");
        i.textContent = e, t.append(i);
      }
      this.container.append(t);
    }
    return !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
  }
}
var ad;
class MA extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, ad, null);
  }
  render() {
    this.container.classList.add("lineAnnotation");
    const {
      data: e,
      width: i,
      height: s
    } = this, r = this.svgFactory.create(i, s, !0), a = p(this, ad, this.svgFactory.createElement("svg:line"));
    return a.setAttribute("x1", e.rect[2] - e.lineCoordinates[0]), a.setAttribute("y1", e.rect[3] - e.lineCoordinates[1]), a.setAttribute("x2", e.rect[2] - e.lineCoordinates[2]), a.setAttribute("y2", e.rect[3] - e.lineCoordinates[3]), a.setAttribute("stroke-width", e.borderStyle.width || 1), a.setAttribute("stroke", "transparent"), a.setAttribute("fill", "transparent"), r.append(a), this.container.append(r), !e.popupRef && this.hasPopupData && this._createPopup(), this.container;
  }
  getElementsToTriggerPopup() {
    return n(this, ad);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
ad = new WeakMap();
var od;
class DA extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, od, null);
  }
  render() {
    this.container.classList.add("squareAnnotation");
    const {
      data: e,
      width: i,
      height: s
    } = this, r = this.svgFactory.create(i, s, !0), a = e.borderStyle.width, o = p(this, od, this.svgFactory.createElement("svg:rect"));
    return o.setAttribute("x", a / 2), o.setAttribute("y", a / 2), o.setAttribute("width", i - a), o.setAttribute("height", s - a), o.setAttribute("stroke-width", a || 1), o.setAttribute("stroke", "transparent"), o.setAttribute("fill", "transparent"), r.append(o), this.container.append(r), !e.popupRef && this.hasPopupData && this._createPopup(), this.container;
  }
  getElementsToTriggerPopup() {
    return n(this, od);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
od = new WeakMap();
var ld;
class IA extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, ld, null);
  }
  render() {
    this.container.classList.add("circleAnnotation");
    const {
      data: e,
      width: i,
      height: s
    } = this, r = this.svgFactory.create(i, s, !0), a = e.borderStyle.width, o = p(this, ld, this.svgFactory.createElement("svg:ellipse"));
    return o.setAttribute("cx", i / 2), o.setAttribute("cy", s / 2), o.setAttribute("rx", i / 2 - a / 2), o.setAttribute("ry", s / 2 - a / 2), o.setAttribute("stroke-width", a || 1), o.setAttribute("stroke", "transparent"), o.setAttribute("fill", "transparent"), r.append(o), this.container.append(r), !e.popupRef && this.hasPopupData && this._createPopup(), this.container;
  }
  getElementsToTriggerPopup() {
    return n(this, ld);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
ld = new WeakMap();
var hd;
class zb extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, hd, null);
    this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: e,
        vertices: i,
        borderStyle: s,
        popupRef: r
      },
      width: a,
      height: o
    } = this;
    if (!i)
      return this.container;
    const l = this.svgFactory.create(a, o, !0);
    let h = [];
    for (let u = 0, f = i.length; u < f; u += 2) {
      const m = i[u] - e[0], A = e[3] - i[u + 1];
      h.push(`${m},${A}`);
    }
    h = h.join(" ");
    const c = p(this, hd, this.svgFactory.createElement(this.svgElementName));
    return c.setAttribute("points", h), c.setAttribute("stroke-width", s.width || 1), c.setAttribute("stroke", "transparent"), c.setAttribute("fill", "transparent"), l.append(c), this.container.append(l), !r && this.hasPopupData && this._createPopup(), this.container;
  }
  getElementsToTriggerPopup() {
    return n(this, hd);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
hd = new WeakMap();
class FA extends zb {
  constructor(t) {
    super(t), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
  }
}
class NA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
  }
}
var cd, Xa, dd, Ip;
class Sg extends Gt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, dd);
    g(this, cd, null);
    g(this, Xa, []);
    this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = this.data.it === "InkHighlight" ? Z.HIGHLIGHT : Z.INK;
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: e,
        rotation: i,
        inkLists: s,
        borderStyle: r,
        popupRef: a
      }
    } = this, {
      transform: o,
      width: l,
      height: h
    } = b(this, dd, Ip).call(this, i, e), c = this.svgFactory.create(l, h, !0), u = p(this, cd, this.svgFactory.createElement("svg:g"));
    c.append(u), u.setAttribute("stroke-width", r.width || 1), u.setAttribute("stroke-linecap", "round"), u.setAttribute("stroke-linejoin", "round"), u.setAttribute("stroke-miterlimit", 10), u.setAttribute("stroke", "transparent"), u.setAttribute("fill", "transparent"), u.setAttribute("transform", o);
    for (let f = 0, m = s.length; f < m; f++) {
      const A = this.svgFactory.createElement(this.svgElementName);
      n(this, Xa).push(A), A.setAttribute("points", s[f].join(",")), u.append(A);
    }
    return !a && this.hasPopupData && this._createPopup(), this.container.append(c), this._editOnDoubleClick(), this.container;
  }
  updateEdited(e) {
    super.updateEdited(e);
    const {
      thickness: i,
      points: s,
      rect: r
    } = e, a = n(this, cd);
    if (i >= 0 && a.setAttribute("stroke-width", i || 1), s)
      for (let o = 0, l = n(this, Xa).length; o < l; o++)
        n(this, Xa)[o].setAttribute("points", s[o].join(","));
    if (r) {
      const {
        transform: o,
        width: l,
        height: h
      } = b(this, dd, Ip).call(this, this.data.rotation, r);
      a.parentElement.setAttribute("viewBox", `0 0 ${l} ${h}`), a.setAttribute("transform", o);
    }
  }
  getElementsToTriggerPopup() {
    return n(this, Xa);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
cd = new WeakMap(), Xa = new WeakMap(), dd = new WeakSet(), Ip = function(e, i) {
  switch (e) {
    case 90:
      return {
        transform: `rotate(90) translate(${-i[0]},${i[1]}) scale(1,-1)`,
        width: i[3] - i[1],
        height: i[2] - i[0]
      };
    case 180:
      return {
        transform: `rotate(180) translate(${-i[2]},${i[1]}) scale(1,-1)`,
        width: i[2] - i[0],
        height: i[3] - i[1]
      };
    case 270:
      return {
        transform: `rotate(270) translate(${-i[2]},${i[3]}) scale(1,-1)`,
        width: i[3] - i[1],
        height: i[2] - i[0]
      };
    default:
      return {
        transform: `translate(${-i[0]},${i[3]}) scale(1,-1)`,
        width: i[2] - i[0],
        height: i[3] - i[1]
      };
  }
};
class Gb extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    }), this.annotationEditorType = Z.HIGHLIGHT;
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && this._createPopup(), this.container.classList.add("highlightAnnotation"), this._editOnDoubleClick(), t) {
      const i = document.createElement("mark");
      i.classList.add("overlaidText"), i.textContent = t, this.container.append(i);
    }
    return this.container;
  }
}
class OA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && this._createPopup(), this.container.classList.add("underlineAnnotation"), t) {
      const i = document.createElement("u");
      i.classList.add("overlaidText"), i.textContent = t, this.container.append(i);
    }
    return this.container;
  }
}
class BA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && this._createPopup(), this.container.classList.add("squigglyAnnotation"), t) {
      const i = document.createElement("u");
      i.classList.add("overlaidText"), i.textContent = t, this.container.append(i);
    }
    return this.container;
  }
}
class HA extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && this._createPopup(), this.container.classList.add("strikeoutAnnotation"), t) {
      const i = document.createElement("s");
      i.classList.add("overlaidText"), i.textContent = t, this.container.append(i);
    }
    return this.container;
  }
}
class Wb extends Gt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.annotationEditorType = Z.STAMP;
  }
  render() {
    return this.container.classList.add("stampAnnotation"), this.container.setAttribute("role", "img"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
  }
}
var ud, fd, Fp;
class UA extends Gt {
  constructor(e) {
    var s;
    super(e, {
      isRenderable: !0
    });
    g(this, fd);
    g(this, ud, null);
    const {
      file: i
    } = this.data;
    this.filename = i.filename, this.content = i.content, (s = this.linkService.eventBus) == null || s.dispatch("fileattachmentannotation", {
      source: this,
      ...i
    });
  }
  render() {
    this.container.classList.add("fileAttachmentAnnotation");
    const {
      container: e,
      data: i
    } = this;
    let s;
    i.hasAppearance || i.fillAlpha === 0 ? s = document.createElement("div") : (s = document.createElement("img"), s.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(i.name) ? "paperclip" : "pushpin"}.svg`, i.fillAlpha && i.fillAlpha < 1 && (s.style = `filter: opacity(${Math.round(i.fillAlpha * 100)}%);`)), s.addEventListener("dblclick", b(this, fd, Fp).bind(this)), p(this, ud, s);
    const {
      isMac: r
    } = _e.platform;
    return e.addEventListener("keydown", (a) => {
      a.key === "Enter" && (r ? a.metaKey : a.ctrlKey) && b(this, fd, Fp).call(this);
    }), !i.popupRef && this.hasPopupData ? this._createPopup() : s.classList.add("popupTriggerArea"), e.append(s), e;
  }
  getElementsToTriggerPopup() {
    return n(this, ud);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
ud = new WeakMap(), fd = new WeakSet(), Fp = function() {
  var e;
  (e = this.downloadManager) == null || e.openOrDownloadData(this.content, this.filename);
};
var $l, Ya, Vl, kr, pd, Ka, Xr, Np, Op, zl;
let _g = (zl = class {
  constructor({
    div: t,
    accessibilityManager: e,
    annotationCanvasMap: i,
    annotationEditorUIManager: s,
    page: r,
    viewport: a,
    structTreeLayer: o,
    commentManager: l,
    linkService: h,
    annotationStorage: c
  }) {
    g(this, Xr);
    g(this, $l, null);
    g(this, Ya, null);
    g(this, Vl, null);
    g(this, kr, /* @__PURE__ */ new Map());
    g(this, pd, null);
    g(this, Ka, null);
    this.div = t, p(this, $l, e), p(this, Ya, i), p(this, pd, o || null), p(this, Ka, h || null), p(this, Vl, c || new bg()), this.page = r, this.viewport = a, this.zIndex = 0, this._annotationEditorUIManager = s, this._commentManager = l || null;
  }
  hasEditableAnnotations() {
    return n(this, kr).size > 0;
  }
  async render(t) {
    var a, o, l;
    const {
      annotations: e
    } = t, i = this.div;
    Wr(i, this.viewport);
    const s = /* @__PURE__ */ new Map(), r = {
      data: null,
      layer: i,
      linkService: n(this, Ka),
      downloadManager: t.downloadManager,
      imageResourcesPath: t.imageResourcesPath || "",
      renderForms: t.renderForms !== !1,
      svgFactory: new Jh(),
      annotationStorage: n(this, Vl),
      enableComment: t.enableComment === !0,
      enableScripting: t.enableScripting === !0,
      hasJSActions: t.hasJSActions,
      fieldObjects: t.fieldObjects,
      parent: this,
      elements: null
    };
    for (const h of e) {
      if (h.noHTML)
        continue;
      const c = h.annotationType === te.POPUP;
      if (c) {
        const m = s.get(h.id);
        if (!m)
          continue;
        r.elements = m;
      } else if (h.rect[2] === h.rect[0] || h.rect[3] === h.rect[1])
        continue;
      r.data = h;
      const u = am.create(r);
      if (!u.isRenderable)
        continue;
      if (!c && h.popupRef) {
        const m = s.get(h.popupRef);
        m ? m.push(u) : s.set(h.popupRef, [u]);
      }
      const f = u.render();
      h.hidden && (f.style.visibility = "hidden"), await b(this, Xr, Np).call(this, f, h.id, r.elements), (o = (a = u.extraPopupElement) == null ? void 0 : a.popup) == null || o.renderCommentButton(), u._isEditable && (n(this, kr).set(u.data.id, u), (l = this._annotationEditorUIManager) == null || l.renderAnnotationElement(u));
    }
    b(this, Xr, Op).call(this);
  }
  async addLinkAnnotations(t) {
    const e = {
      data: null,
      layer: this.div,
      linkService: n(this, Ka),
      svgFactory: new Jh(),
      parent: this
    };
    for (const i of t) {
      i.borderStyle || (i.borderStyle = zl._defaultBorderStyle), e.data = i;
      const s = am.create(e);
      if (!s.isRenderable)
        continue;
      const r = s.render();
      await b(this, Xr, Np).call(this, r, i.id, null);
    }
  }
  update({
    viewport: t
  }) {
    const e = this.div;
    this.viewport = t, Wr(e, {
      rotation: t.rotation
    }), b(this, Xr, Op).call(this), e.hidden = !1;
  }
  getEditableAnnotations() {
    return Array.from(n(this, kr).values());
  }
  getEditableAnnotation(t) {
    return n(this, kr).get(t);
  }
  addFakeAnnotation(t) {
    var o;
    const {
      div: e
    } = this, {
      id: i,
      rotation: s
    } = t, r = new _A({
      data: {
        id: i,
        rect: t.getPDFRect(),
        rotation: s
      },
      editor: t,
      layer: e,
      parent: this,
      enableComment: !!this._commentManager,
      linkService: n(this, Ka),
      annotationStorage: n(this, Vl)
    }), a = r.render();
    return e.append(a), (o = n(this, $l)) == null || o.moveElementInDOM(e, a, a, !1), r.createOrUpdatePopup(), r;
  }
  static get _defaultBorderStyle() {
    return st(this, "_defaultBorderStyle", Object.freeze({
      width: 1,
      rawWidth: 1,
      style: So.SOLID,
      dashArray: [3],
      horizontalCornerRadius: 0,
      verticalCornerRadius: 0
    }));
  }
}, $l = new WeakMap(), Ya = new WeakMap(), Vl = new WeakMap(), kr = new WeakMap(), pd = new WeakMap(), Ka = new WeakMap(), Xr = new WeakSet(), Np = async function(t, e, i) {
  var o, l;
  const s = t.firstChild || t, r = s.id = `${pg}${e}`, a = await ((o = n(this, pd)) == null ? void 0 : o.getAriaAttributes(r));
  if (a)
    for (const [h, c] of a)
      s.setAttribute(h, c);
  i ? i.at(-1).container.after(t) : (this.div.append(t), (l = n(this, $l)) == null || l.moveElementInDOM(this.div, t, s, !1));
}, Op = function() {
  var e;
  if (!n(this, Ya))
    return;
  const t = this.div;
  for (const [i, s] of n(this, Ya)) {
    const r = t.querySelector(`[data-annotation-id="${i}"]`);
    if (!r)
      continue;
    s.className = "annotationContent";
    const {
      firstChild: a
    } = r;
    a ? a.nodeName === "CANVAS" ? a.replaceWith(s) : a.classList.contains("annotationContent") ? a.after(s) : a.before(s) : r.append(s);
    const o = n(this, kr).get(i);
    o && (o._hasNoCanvas ? ((e = this._annotationEditorUIManager) == null || e.setMissingCanvas(i, r.id, s), o._hasNoCanvas = !1) : o.canvas = s);
  }
  n(this, Ya).clear();
}, zl);
const tu = /\r\n?|\n/g;
var Pi, gd, Za, Li, ae, jb, qb, Xb, Au, zn, wu, vu, Yb, Hp, Kb;
const Ot = class Ot extends Ft {
  constructor(e) {
    super({
      ...e,
      name: "freeTextEditor"
    });
    g(this, ae);
    g(this, Pi, "");
    g(this, gd, `${this.id}-editor`);
    g(this, Za, null);
    g(this, Li);
    M(this, "_colorPicker", null);
    this.color = e.color || Ot._defaultColor || Ft._defaultLineColor, p(this, Li, e.fontSize || Ot._defaultFontSize), this.annotationElementId || this._uiManager.a11yAlert("pdfjs-editor-freetext-added-alert");
  }
  static get _keyboardManager() {
    const e = Ot.prototype, i = (a) => a.isEmpty(), s = jr.TRANSLATE_SMALL, r = jr.TRANSLATE_BIG;
    return st(this, "_keyboardManager", new Od([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], e.commitOrRemove, {
      bubbles: !0
    }], [["ctrl+Enter", "mac+meta+Enter", "Escape", "mac+Escape"], e.commitOrRemove], [["ArrowLeft", "mac+ArrowLeft"], e._translateEmpty, {
      args: [-s, 0],
      checker: i
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], e._translateEmpty, {
      args: [-r, 0],
      checker: i
    }], [["ArrowRight", "mac+ArrowRight"], e._translateEmpty, {
      args: [s, 0],
      checker: i
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], e._translateEmpty, {
      args: [r, 0],
      checker: i
    }], [["ArrowUp", "mac+ArrowUp"], e._translateEmpty, {
      args: [0, -s],
      checker: i
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], e._translateEmpty, {
      args: [0, -r],
      checker: i
    }], [["ArrowDown", "mac+ArrowDown"], e._translateEmpty, {
      args: [0, s],
      checker: i
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], e._translateEmpty, {
      args: [0, r],
      checker: i
    }]]));
  }
  static initialize(e, i) {
    Ft.initialize(e, i);
    const s = getComputedStyle(document.documentElement);
    this._internalPadding = parseFloat(s.getPropertyValue("--freetext-padding"));
  }
  static updateDefaultParams(e, i) {
    switch (e) {
      case ht.FREETEXT_SIZE:
        Ot._defaultFontSize = i;
        break;
      case ht.FREETEXT_COLOR:
        Ot._defaultColor = i;
        break;
    }
  }
  updateParams(e, i) {
    switch (e) {
      case ht.FREETEXT_SIZE:
        b(this, ae, jb).call(this, i);
        break;
      case ht.FREETEXT_COLOR:
        b(this, ae, qb).call(this, i);
        break;
    }
  }
  static get defaultPropertiesToUpdate() {
    return [[ht.FREETEXT_SIZE, Ot._defaultFontSize], [ht.FREETEXT_COLOR, Ot._defaultColor || Ft._defaultLineColor]];
  }
  get propertiesToUpdate() {
    return [[ht.FREETEXT_SIZE, n(this, Li)], [ht.FREETEXT_COLOR, this.color]];
  }
  get toolbarButtons() {
    return this._colorPicker || (this._colorPicker = new Uu(this)), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return ht.FREETEXT_COLOR;
  }
  onUpdatedColor() {
    var e;
    this.editorDiv.style.color = this.color, (e = this._colorPicker) == null || e.update(this.color), super.onUpdatedColor();
  }
  _translateEmpty(e, i) {
    this._uiManager.translateSelectedEditors(e, i, !0);
  }
  getInitialTranslation() {
    const e = this.parentScale;
    return [-Ot._internalPadding * e, -(Ot._internalPadding + n(this, Li)) * e];
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
  }
  enableEditMode() {
    if (!super.enableEditMode())
      return !1;
    this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), p(this, Za, new AbortController());
    const e = this._uiManager.combinedSignal(n(this, Za));
    return this.editorDiv.addEventListener("keydown", this.editorDivKeydown.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("focus", this.editorDivFocus.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("blur", this.editorDivBlur.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("input", this.editorDivInput.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("paste", this.editorDivPaste.bind(this), {
      signal: e
    }), !0;
  }
  disableEditMode() {
    var e;
    return super.disableEditMode() ? (this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", n(this, gd)), this._isDraggable = !0, (e = n(this, Za)) == null || e.abort(), p(this, Za, null), this.div.focus({
      preventScroll: !0
    }), this.isEditing = !1, this.parent.div.classList.add("freetextEditing"), !0) : !1;
  }
  focusin(e) {
    this._focusEventsAllowed && (super.focusin(e), e.target !== this.editorDiv && this.editorDiv.focus());
  }
  onceAdded(e) {
    var i;
    this.width || (this.enableEditMode(), e && this.editorDiv.focus(), (i = this._initialOptions) != null && i.isCentered && this.center(), this._initialOptions = null);
  }
  isEmpty() {
    return !this.editorDiv || this.editorDiv.innerText.trim() === "";
  }
  remove() {
    this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freetextEditing")), super.remove();
  }
  commit() {
    if (!this.isInEditMode())
      return;
    super.commit(), this.disableEditMode();
    const e = n(this, Pi), i = p(this, Pi, b(this, ae, Xb).call(this).trimEnd());
    if (e === i)
      return;
    const s = (r) => {
      if (p(this, Pi, r), !r) {
        this.remove();
        return;
      }
      b(this, ae, vu).call(this), this._uiManager.rebuild(this), b(this, ae, Au).call(this);
    };
    this.addCommands({
      cmd: () => {
        s(i);
      },
      undo: () => {
        s(e);
      },
      mustExec: !1
    }), b(this, ae, Au).call(this);
  }
  shouldGetKeyboardEvents() {
    return this.isInEditMode();
  }
  enterInEditMode() {
    this.enableEditMode(), this.editorDiv.focus();
  }
  keydown(e) {
    e.target === this.div && e.key === "Enter" && (this.enterInEditMode(), e.preventDefault());
  }
  editorDivKeydown(e) {
    Ot._keyboardManager.exec(this, e);
  }
  editorDivFocus(e) {
    this.isEditing = !0;
  }
  editorDivBlur(e) {
    this.isEditing = !1;
  }
  editorDivInput(e) {
    this.parent.div.classList.toggle("freetextEditing", this.isEmpty());
  }
  disableEditing() {
    this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
  }
  enableEditing() {
    this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
  }
  get canChangeContent() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let e, i;
    (this._isCopy || this.annotationElementId) && (e = this.x, i = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", n(this, gd)), this.editorDiv.setAttribute("data-l10n-id", "pdfjs-free-text2"), this.editorDiv.setAttribute("data-l10n-attrs", "default-content"), this.enableEditing(), this.editorDiv.contentEditable = !0;
    const {
      style: s
    } = this.editorDiv;
    if (s.fontSize = `calc(${n(this, Li)}px * var(--total-scale-factor))`, s.color = this.color, this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), this._isCopy || this.annotationElementId) {
      const [r, a] = this.parentDimensions;
      if (this.annotationElementId) {
        const {
          position: o
        } = this._initialData;
        let [l, h] = this.getInitialTranslation();
        [l, h] = this.pageTranslationToScreen(l, h);
        const [c, u] = this.pageDimensions, [f, m] = this.pageTranslation;
        let A, y;
        switch (this.rotation) {
          case 0:
            A = e + (o[0] - f) / c, y = i + this.height - (o[1] - m) / u;
            break;
          case 90:
            A = e + (o[0] - f) / c, y = i - (o[1] - m) / u, [l, h] = [h, -l];
            break;
          case 180:
            A = e - this.width + (o[0] - f) / c, y = i - (o[1] - m) / u, [l, h] = [-l, -h];
            break;
          case 270:
            A = e + (o[0] - f - this.height * u) / c, y = i + (o[1] - m - this.width * c) / u, [l, h] = [-h, l];
            break;
        }
        this.setAt(A * r, y * a, l, h);
      } else
        this._moveAfterPaste(e, i);
      b(this, ae, vu).call(this), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
    } else
      this._isDraggable = !1, this.editorDiv.contentEditable = !0;
    return this.div;
  }
  editorDivPaste(e) {
    var A, y, v;
    const i = e.clipboardData || window.clipboardData, {
      types: s
    } = i;
    if (s.length === 1 && s[0] === "text/plain")
      return;
    e.preventDefault();
    const r = b(A = Ot, zn, Hp).call(A, i.getData("text") || "").replaceAll(tu, `
`);
    if (!r)
      return;
    const a = window.getSelection();
    if (!a.rangeCount)
      return;
    this.editorDiv.normalize(), a.deleteFromDocument();
    const o = a.getRangeAt(0);
    if (!r.includes(`
`)) {
      o.insertNode(document.createTextNode(r)), this.editorDiv.normalize(), a.collapseToStart();
      return;
    }
    const {
      startContainer: l,
      startOffset: h
    } = o, c = [], u = [];
    if (l.nodeType === Node.TEXT_NODE) {
      const w = l.parentElement;
      if (u.push(l.nodeValue.slice(h).replaceAll(tu, "")), w !== this.editorDiv) {
        let S = c;
        for (const E of this.editorDiv.childNodes) {
          if (E === w) {
            S = u;
            continue;
          }
          S.push(b(y = Ot, zn, wu).call(y, E));
        }
      }
      c.push(l.nodeValue.slice(0, h).replaceAll(tu, ""));
    } else if (l === this.editorDiv) {
      let w = c, S = 0;
      for (const E of this.editorDiv.childNodes)
        S++ === h && (w = u), w.push(b(v = Ot, zn, wu).call(v, E));
    }
    p(this, Pi, `${c.join(`
`)}${r}${u.join(`
`)}`), b(this, ae, vu).call(this);
    const f = new Range();
    let m = Math.sumPrecise(c.map((w) => w.length));
    for (const {
      firstChild: w
    } of this.editorDiv.childNodes)
      if (w.nodeType === Node.TEXT_NODE) {
        const S = w.nodeValue.length;
        if (m <= S) {
          f.setStart(w, m), f.setEnd(w, m);
          break;
        }
        m -= S;
      }
    a.removeAllRanges(), a.addRange(f);
  }
  get contentDiv() {
    return this.editorDiv;
  }
  getPDFRect() {
    const e = Ot._internalPadding * this.parentScale;
    return this.getRect(e, e);
  }
  static async deserialize(e, i, s) {
    var o;
    let r = null;
    if (e instanceof Vb) {
      const {
        data: {
          defaultAppearanceData: {
            fontSize: l,
            fontColor: h
          },
          rect: c,
          rotation: u,
          id: f,
          popupRef: m,
          richText: A,
          contentsObj: y,
          creationDate: v,
          modificationDate: w
        },
        textContent: S,
        textPosition: E,
        parent: {
          page: {
            pageNumber: _
          }
        }
      } = e;
      if (!S || S.length === 0)
        return null;
      r = e = {
        annotationType: Z.FREETEXT,
        color: Array.from(h),
        fontSize: l,
        value: S.join(`
`),
        position: E,
        pageIndex: _ - 1,
        rect: c.slice(0),
        rotation: u,
        annotationElementId: f,
        id: f,
        deleted: !1,
        popupRef: m,
        comment: (y == null ? void 0 : y.str) || null,
        richText: A,
        creationDate: v,
        modificationDate: w
      };
    }
    const a = await super.deserialize(e, i, s);
    return p(a, Li, e.fontSize), a.color = z.makeHexColor(...e.color), p(a, Pi, b(o = Ot, zn, Hp).call(o, e.value)), a._initialData = r, e.comment && a.setCommentData(e), a;
  }
  serialize(e = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const i = Ft._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : this.color), s = Object.assign(super.serialize(e), {
      color: i,
      fontSize: n(this, Li),
      value: b(this, ae, Yb).call(this)
    });
    return this.addComment(s), e ? (s.isCopy = !0, s) : this.annotationElementId && !b(this, ae, Kb).call(this, s) ? null : (s.id = this.annotationElementId, s);
  }
  renderAnnotationElement(e) {
    const i = super.renderAnnotationElement(e);
    if (!i)
      return null;
    const {
      style: s
    } = i;
    s.fontSize = `calc(${n(this, Li)}px * var(--total-scale-factor))`, s.color = this.color, i.replaceChildren();
    for (const r of n(this, Pi).split(`
`)) {
      const a = document.createElement("div");
      a.append(r ? document.createTextNode(r) : document.createElement("br")), i.append(a);
    }
    return e.updateEdited({
      rect: this.getPDFRect(),
      popup: this._uiManager.hasCommentManager() || this.hasEditedComment ? this.comment : {
        text: n(this, Pi)
      }
    }), i;
  }
  resetAnnotationElement(e) {
    super.resetAnnotationElement(e), e.resetEdited();
  }
};
Pi = new WeakMap(), gd = new WeakMap(), Za = new WeakMap(), Li = new WeakMap(), ae = new WeakSet(), jb = function(e) {
  const i = (r) => {
    this.editorDiv.style.fontSize = `calc(${r}px * var(--total-scale-factor))`, this.translate(0, -(r - n(this, Li)) * this.parentScale), p(this, Li, r), b(this, ae, Au).call(this);
  }, s = n(this, Li);
  this.addCommands({
    cmd: i.bind(this, e),
    undo: i.bind(this, s),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: ht.FREETEXT_SIZE,
    overwriteIfSameType: !0,
    keepUndo: !0
  });
}, qb = function(e) {
  const i = (r) => {
    this.color = r, this.onUpdatedColor();
  }, s = this.color;
  this.addCommands({
    cmd: i.bind(this, e),
    undo: i.bind(this, s),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: ht.FREETEXT_COLOR,
    overwriteIfSameType: !0,
    keepUndo: !0
  });
}, Xb = function() {
  var s;
  const e = [];
  this.editorDiv.normalize();
  let i = null;
  for (const r of this.editorDiv.childNodes)
    (i == null ? void 0 : i.nodeType) === Node.TEXT_NODE && r.nodeName === "BR" || (e.push(b(s = Ot, zn, wu).call(s, r)), i = r);
  return e.join(`
`);
}, Au = function() {
  const [e, i] = this.parentDimensions;
  let s;
  if (this.isAttachedToDOM)
    s = this.div.getBoundingClientRect();
  else {
    const {
      currentLayer: r,
      div: a
    } = this, o = a.style.display, l = a.classList.contains("hidden");
    a.classList.remove("hidden"), a.style.display = "hidden", r.div.append(this.div), s = a.getBoundingClientRect(), a.remove(), a.style.display = o, a.classList.toggle("hidden", l);
  }
  this.rotation % 180 === this.parentRotation % 180 ? (this.width = s.width / e, this.height = s.height / i) : (this.width = s.height / e, this.height = s.width / i), this.fixAndSetPosition();
}, zn = new WeakSet(), wu = function(e) {
  return (e.nodeType === Node.TEXT_NODE ? e.nodeValue : e.innerText).replaceAll(tu, "");
}, vu = function() {
  if (this.editorDiv.replaceChildren(), !!n(this, Pi))
    for (const e of n(this, Pi).split(`
`)) {
      const i = document.createElement("div");
      i.append(e ? document.createTextNode(e) : document.createElement("br")), this.editorDiv.append(i);
    }
}, Yb = function() {
  return n(this, Pi).replaceAll(" ", " ");
}, Hp = function(e) {
  return e.replaceAll(" ", " ");
}, Kb = function(e) {
  const {
    value: i,
    fontSize: s,
    color: r,
    pageIndex: a
  } = this._initialData;
  return this.hasEditedComment || this._hasBeenMoved || e.value !== i || e.fontSize !== s || e.color.some((o, l) => o !== r[l]) || e.pageIndex !== a;
}, g(Ot, zn), M(Ot, "_freeTextDefaultContent", ""), M(Ot, "_internalPadding", 0), M(Ot, "_defaultColor", null), M(Ot, "_defaultFontSize", 10), M(Ot, "_type", "freetext"), M(Ot, "_editorType", Z.FREETEXT);
let Bp = Ot;
class V {
  toSVGPath() {
    Dt("Abstract method `toSVGPath` must be implemented.");
  }
  get box() {
    Dt("Abstract getter `box` must be implemented.");
  }
  serialize(t, e) {
    Dt("Abstract method `serialize` must be implemented.");
  }
  static _rescale(t, e, i, s, r, a) {
    a || (a = new Float32Array(t.length));
    for (let o = 0, l = t.length; o < l; o += 2)
      a[o] = e + t[o] * s, a[o + 1] = i + t[o + 1] * r;
    return a;
  }
  static _rescaleAndSwap(t, e, i, s, r, a) {
    a || (a = new Float32Array(t.length));
    for (let o = 0, l = t.length; o < l; o += 2)
      a[o] = e + t[o + 1] * s, a[o + 1] = i + t[o] * r;
    return a;
  }
  static _translate(t, e, i, s) {
    s || (s = new Float32Array(t.length));
    for (let r = 0, a = t.length; r < a; r += 2)
      s[r] = e + t[r], s[r + 1] = i + t[r + 1];
    return s;
  }
  static svgRound(t) {
    return Math.round(t * 1e4);
  }
  static _normalizePoint(t, e, i, s, r) {
    switch (r) {
      case 90:
        return [1 - e / i, t / s];
      case 180:
        return [1 - t / i, 1 - e / s];
      case 270:
        return [e / i, 1 - t / s];
      default:
        return [t / i, e / s];
    }
  }
  static _normalizePagePoint(t, e, i) {
    switch (i) {
      case 90:
        return [1 - e, t];
      case 180:
        return [1 - t, 1 - e];
      case 270:
        return [e, 1 - t];
      default:
        return [t, e];
    }
  }
  static createBezierPoints(t, e, i, s, r, a) {
    return [(t + 5 * i) / 6, (e + 5 * s) / 6, (5 * i + r) / 6, (5 * s + a) / 6, (i + r) / 2, (s + a) / 2];
  }
}
M(V, "PRECISION", 1e-4);
var ki, bs, Gl, Wl, Ws, ot, Ja, Qa, md, bd, jl, ql, Rr, yd, of, lf, ue, Bh, Zb, Jb, Qb, t0, e0, i0;
const on = class on {
  constructor({
    x: t,
    y: e
  }, i, s, r, a, o = 0) {
    g(this, ue);
    g(this, ki);
    g(this, bs, []);
    g(this, Gl);
    g(this, Wl);
    g(this, Ws, []);
    g(this, ot, new Float32Array(18));
    g(this, Ja);
    g(this, Qa);
    g(this, md);
    g(this, bd);
    g(this, jl);
    g(this, ql);
    g(this, Rr, []);
    p(this, ki, i), p(this, ql, r * s), p(this, Wl, a), n(this, ot).set([NaN, NaN, NaN, NaN, t, e], 6), p(this, Gl, o), p(this, bd, n(on, yd) * s), p(this, md, n(on, lf) * s), p(this, jl, s), n(this, Rr).push(t, e);
  }
  isEmpty() {
    return isNaN(n(this, ot)[8]);
  }
  add({
    x: t,
    y: e
  }) {
    var k;
    p(this, Ja, t), p(this, Qa, e);
    const [i, s, r, a] = n(this, ki);
    let [o, l, h, c] = n(this, ot).subarray(8, 12);
    const u = t - h, f = e - c, m = Math.hypot(u, f);
    if (m < n(this, md))
      return !1;
    const A = m - n(this, bd), y = A / m, v = y * u, w = y * f;
    let S = o, E = l;
    o = h, l = c, h += v, c += w, (k = n(this, Rr)) == null || k.push(t, e);
    const _ = -w / A, x = v / A, C = _ * n(this, ql), T = x * n(this, ql);
    return n(this, ot).set(n(this, ot).subarray(2, 8), 0), n(this, ot).set([h + C, c + T], 4), n(this, ot).set(n(this, ot).subarray(14, 18), 12), n(this, ot).set([h - C, c - T], 16), isNaN(n(this, ot)[6]) ? (n(this, Ws).length === 0 && (n(this, ot).set([o + C, l + T], 2), n(this, Ws).push(NaN, NaN, NaN, NaN, (o + C - i) / r, (l + T - s) / a), n(this, ot).set([o - C, l - T], 14), n(this, bs).push(NaN, NaN, NaN, NaN, (o - C - i) / r, (l - T - s) / a)), n(this, ot).set([S, E, o, l, h, c], 6), !this.isEmpty()) : (n(this, ot).set([S, E, o, l, h, c], 6), Math.abs(Math.atan2(E - l, S - o) - Math.atan2(w, v)) < Math.PI / 2 ? ([o, l, h, c] = n(this, ot).subarray(2, 6), n(this, Ws).push(NaN, NaN, NaN, NaN, ((o + h) / 2 - i) / r, ((l + c) / 2 - s) / a), [o, l, S, E] = n(this, ot).subarray(14, 18), n(this, bs).push(NaN, NaN, NaN, NaN, ((S + o) / 2 - i) / r, ((E + l) / 2 - s) / a), !0) : ([S, E, o, l, h, c] = n(this, ot).subarray(0, 6), n(this, Ws).push(((S + 5 * o) / 6 - i) / r, ((E + 5 * l) / 6 - s) / a, ((5 * o + h) / 6 - i) / r, ((5 * l + c) / 6 - s) / a, ((o + h) / 2 - i) / r, ((l + c) / 2 - s) / a), [h, c, o, l, S, E] = n(this, ot).subarray(12, 18), n(this, bs).push(((S + 5 * o) / 6 - i) / r, ((E + 5 * l) / 6 - s) / a, ((5 * o + h) / 6 - i) / r, ((5 * l + c) / 6 - s) / a, ((o + h) / 2 - i) / r, ((l + c) / 2 - s) / a), !0));
  }
  toSVGPath() {
    if (this.isEmpty())
      return "";
    const t = n(this, Ws), e = n(this, bs);
    if (isNaN(n(this, ot)[6]) && !this.isEmpty())
      return b(this, ue, Zb).call(this);
    const i = [];
    i.push(`M${t[4]} ${t[5]}`);
    for (let s = 6; s < t.length; s += 6)
      isNaN(t[s]) ? i.push(`L${t[s + 4]} ${t[s + 5]}`) : i.push(`C${t[s]} ${t[s + 1]} ${t[s + 2]} ${t[s + 3]} ${t[s + 4]} ${t[s + 5]}`);
    b(this, ue, Qb).call(this, i);
    for (let s = e.length - 6; s >= 6; s -= 6)
      isNaN(e[s]) ? i.push(`L${e[s + 4]} ${e[s + 5]}`) : i.push(`C${e[s]} ${e[s + 1]} ${e[s + 2]} ${e[s + 3]} ${e[s + 4]} ${e[s + 5]}`);
    return b(this, ue, Jb).call(this, i), i.join(" ");
  }
  newFreeDrawOutline(t, e, i, s, r, a) {
    return new s0(t, e, i, s, r, a);
  }
  getOutlines() {
    var u;
    const t = n(this, Ws), e = n(this, bs), i = n(this, ot), [s, r, a, o] = n(this, ki), l = new Float32Array((((u = n(this, Rr)) == null ? void 0 : u.length) ?? 0) + 2);
    for (let f = 0, m = l.length - 2; f < m; f += 2)
      l[f] = (n(this, Rr)[f] - s) / a, l[f + 1] = (n(this, Rr)[f + 1] - r) / o;
    if (l[l.length - 2] = (n(this, Ja) - s) / a, l[l.length - 1] = (n(this, Qa) - r) / o, isNaN(i[6]) && !this.isEmpty())
      return b(this, ue, t0).call(this, l);
    const h = new Float32Array(n(this, Ws).length + 24 + n(this, bs).length);
    let c = t.length;
    for (let f = 0; f < c; f += 2) {
      if (isNaN(t[f])) {
        h[f] = h[f + 1] = NaN;
        continue;
      }
      h[f] = t[f], h[f + 1] = t[f + 1];
    }
    c = b(this, ue, i0).call(this, h, c);
    for (let f = e.length - 6; f >= 6; f -= 6)
      for (let m = 0; m < 6; m += 2) {
        if (isNaN(e[f + m])) {
          h[c] = h[c + 1] = NaN, c += 2;
          continue;
        }
        h[c] = e[f + m], h[c + 1] = e[f + m + 1], c += 2;
      }
    return b(this, ue, e0).call(this, h, c), this.newFreeDrawOutline(h, l, n(this, ki), n(this, jl), n(this, Gl), n(this, Wl));
  }
};
ki = new WeakMap(), bs = new WeakMap(), Gl = new WeakMap(), Wl = new WeakMap(), Ws = new WeakMap(), ot = new WeakMap(), Ja = new WeakMap(), Qa = new WeakMap(), md = new WeakMap(), bd = new WeakMap(), jl = new WeakMap(), ql = new WeakMap(), Rr = new WeakMap(), yd = new WeakMap(), of = new WeakMap(), lf = new WeakMap(), ue = new WeakSet(), Bh = function() {
  const t = n(this, ot).subarray(4, 6), e = n(this, ot).subarray(16, 18), [i, s, r, a] = n(this, ki);
  return [(n(this, Ja) + (t[0] - e[0]) / 2 - i) / r, (n(this, Qa) + (t[1] - e[1]) / 2 - s) / a, (n(this, Ja) + (e[0] - t[0]) / 2 - i) / r, (n(this, Qa) + (e[1] - t[1]) / 2 - s) / a];
}, Zb = function() {
  const [t, e, i, s] = n(this, ki), [r, a, o, l] = b(this, ue, Bh).call(this);
  return `M${(n(this, ot)[2] - t) / i} ${(n(this, ot)[3] - e) / s} L${(n(this, ot)[4] - t) / i} ${(n(this, ot)[5] - e) / s} L${r} ${a} L${o} ${l} L${(n(this, ot)[16] - t) / i} ${(n(this, ot)[17] - e) / s} L${(n(this, ot)[14] - t) / i} ${(n(this, ot)[15] - e) / s} Z`;
}, Jb = function(t) {
  const e = n(this, bs);
  t.push(`L${e[4]} ${e[5]} Z`);
}, Qb = function(t) {
  const [e, i, s, r] = n(this, ki), a = n(this, ot).subarray(4, 6), o = n(this, ot).subarray(16, 18), [l, h, c, u] = b(this, ue, Bh).call(this);
  t.push(`L${(a[0] - e) / s} ${(a[1] - i) / r} L${l} ${h} L${c} ${u} L${(o[0] - e) / s} ${(o[1] - i) / r}`);
}, t0 = function(t) {
  const e = n(this, ot), [i, s, r, a] = n(this, ki), [o, l, h, c] = b(this, ue, Bh).call(this), u = new Float32Array(36);
  return u.set([NaN, NaN, NaN, NaN, (e[2] - i) / r, (e[3] - s) / a, NaN, NaN, NaN, NaN, (e[4] - i) / r, (e[5] - s) / a, NaN, NaN, NaN, NaN, o, l, NaN, NaN, NaN, NaN, h, c, NaN, NaN, NaN, NaN, (e[16] - i) / r, (e[17] - s) / a, NaN, NaN, NaN, NaN, (e[14] - i) / r, (e[15] - s) / a], 0), this.newFreeDrawOutline(u, t, n(this, ki), n(this, jl), n(this, Gl), n(this, Wl));
}, e0 = function(t, e) {
  const i = n(this, bs);
  return t.set([NaN, NaN, NaN, NaN, i[4], i[5]], e), e += 6;
}, i0 = function(t, e) {
  const i = n(this, ot).subarray(4, 6), s = n(this, ot).subarray(16, 18), [r, a, o, l] = n(this, ki), [h, c, u, f] = b(this, ue, Bh).call(this);
  return t.set([NaN, NaN, NaN, NaN, (i[0] - r) / o, (i[1] - a) / l, NaN, NaN, NaN, NaN, h, c, NaN, NaN, NaN, NaN, u, f, NaN, NaN, NaN, NaN, (s[0] - r) / o, (s[1] - a) / l], e), e += 24;
}, g(on, yd, 8), g(on, of, 2), g(on, lf, n(on, yd) + n(on, of));
let $u = on;
var Xl, to, Fn, Ad, Ri, wd, ie, hf, n0;
class s0 extends V {
  constructor(e, i, s, r, a, o) {
    super();
    g(this, hf);
    g(this, Xl);
    g(this, to, new Float32Array(4));
    g(this, Fn);
    g(this, Ad);
    g(this, Ri);
    g(this, wd);
    g(this, ie);
    p(this, ie, e), p(this, Ri, i), p(this, Xl, s), p(this, wd, r), p(this, Fn, a), p(this, Ad, o), this.firstPoint = [NaN, NaN], this.lastPoint = [NaN, NaN], b(this, hf, n0).call(this, o);
    const [l, h, c, u] = n(this, to);
    for (let f = 0, m = e.length; f < m; f += 2)
      e[f] = (e[f] - l) / c, e[f + 1] = (e[f + 1] - h) / u;
    for (let f = 0, m = i.length; f < m; f += 2)
      i[f] = (i[f] - l) / c, i[f + 1] = (i[f + 1] - h) / u;
  }
  toSVGPath() {
    const e = [`M${n(this, ie)[4]} ${n(this, ie)[5]}`];
    for (let i = 6, s = n(this, ie).length; i < s; i += 6) {
      if (isNaN(n(this, ie)[i])) {
        e.push(`L${n(this, ie)[i + 4]} ${n(this, ie)[i + 5]}`);
        continue;
      }
      e.push(`C${n(this, ie)[i]} ${n(this, ie)[i + 1]} ${n(this, ie)[i + 2]} ${n(this, ie)[i + 3]} ${n(this, ie)[i + 4]} ${n(this, ie)[i + 5]}`);
    }
    return e.push("Z"), e.join(" ");
  }
  serialize([e, i, s, r], a) {
    const o = s - e, l = r - i;
    let h, c;
    switch (a) {
      case 0:
        h = V._rescale(n(this, ie), e, r, o, -l), c = V._rescale(n(this, Ri), e, r, o, -l);
        break;
      case 90:
        h = V._rescaleAndSwap(n(this, ie), e, i, o, l), c = V._rescaleAndSwap(n(this, Ri), e, i, o, l);
        break;
      case 180:
        h = V._rescale(n(this, ie), s, i, -o, l), c = V._rescale(n(this, Ri), s, i, -o, l);
        break;
      case 270:
        h = V._rescaleAndSwap(n(this, ie), s, r, -o, -l), c = V._rescaleAndSwap(n(this, Ri), s, r, -o, -l);
        break;
    }
    return {
      outline: Array.from(h),
      points: [Array.from(c)]
    };
  }
  get box() {
    return n(this, to);
  }
  newOutliner(e, i, s, r, a, o = 0) {
    return new $u(e, i, s, r, a, o);
  }
  getNewOutline(e, i) {
    const [s, r, a, o] = n(this, to), [l, h, c, u] = n(this, Xl), f = a * c, m = o * u, A = s * c + l, y = r * u + h, v = this.newOutliner({
      x: n(this, Ri)[0] * f + A,
      y: n(this, Ri)[1] * m + y
    }, n(this, Xl), n(this, wd), e, n(this, Ad), i ?? n(this, Fn));
    for (let w = 2; w < n(this, Ri).length; w += 2)
      v.add({
        x: n(this, Ri)[w] * f + A,
        y: n(this, Ri)[w + 1] * m + y
      });
    return v.getOutlines();
  }
}
Xl = new WeakMap(), to = new WeakMap(), Fn = new WeakMap(), Ad = new WeakMap(), Ri = new WeakMap(), wd = new WeakMap(), ie = new WeakMap(), hf = new WeakSet(), n0 = function(e) {
  const i = n(this, ie);
  let s = i[4], r = i[5];
  const a = [s, r, s, r];
  let o = s, l = r, h = s, c = r;
  const u = e ? Math.max : Math.min, f = new Float32Array(4);
  for (let A = 6, y = i.length; A < y; A += 6) {
    const v = i[A + 4], w = i[A + 5];
    isNaN(i[A]) ? (z.pointBoundingBox(v, w, a), l > w ? (o = v, l = w) : l === w && (o = u(o, v)), c < w ? (h = v, c = w) : c === w && (h = u(h, v))) : (f[0] = f[1] = 1 / 0, f[2] = f[3] = -1 / 0, z.bezierBoundingBox(s, r, ...i.slice(A, A + 6), f), z.rectBoundingBox(f[0], f[1], f[2], f[3], a), l > f[1] ? (o = f[0], l = f[1]) : l === f[1] && (o = u(o, f[0])), c < f[3] ? (h = f[2], c = f[3]) : c === f[3] && (h = u(h, f[2]))), s = v, r = w;
  }
  const m = n(this, to);
  m[0] = a[0] - n(this, Fn), m[1] = a[1] - n(this, Fn), m[2] = a[2] - a[0] + 2 * n(this, Fn), m[3] = a[3] - a[1] + 2 * n(this, Fn), this.firstPoint = [o, l], this.lastPoint = [h, c];
};
var vd, Ed, Sd, Mr, ys, ni, r0, Eu, a0, o0, $p;
class Up {
  constructor(t, e = 0, i = 0, s = !0) {
    g(this, ni);
    g(this, vd);
    g(this, Ed);
    g(this, Sd);
    g(this, Mr, []);
    g(this, ys, []);
    const r = [1 / 0, 1 / 0, -1 / 0, -1 / 0], a = 10 ** -4;
    for (const {
      x: y,
      y: v,
      width: w,
      height: S
    } of t) {
      const E = Math.floor((y - e) / a) * a, _ = Math.ceil((y + w + e) / a) * a, x = Math.floor((v - e) / a) * a, C = Math.ceil((v + S + e) / a) * a, T = [E, x, C, !0], L = [_, x, C, !1];
      n(this, Mr).push(T, L), z.rectBoundingBox(E, x, _, C, r);
    }
    const o = r[2] - r[0] + 2 * i, l = r[3] - r[1] + 2 * i, h = r[0] - i, c = r[1] - i;
    let u = s ? -1 / 0 : 1 / 0, f = 1 / 0;
    const m = n(this, Mr).at(s ? -1 : -2), A = [m[0], m[2]];
    for (const y of n(this, Mr)) {
      const [v, w, S, E] = y;
      !E && s ? w < f ? (f = w, u = v) : w === f && (u = Math.max(u, v)) : E && !s && (w < f ? (f = w, u = v) : w === f && (u = Math.min(u, v))), y[0] = (v - h) / o, y[1] = (w - c) / l, y[2] = (S - c) / l;
    }
    p(this, vd, new Float32Array([h, c, o, l])), p(this, Ed, [u, f]), p(this, Sd, A);
  }
  getOutlines() {
    n(this, Mr).sort((e, i) => e[0] - i[0] || e[1] - i[1] || e[2] - i[2]);
    const t = [];
    for (const e of n(this, Mr))
      e[3] ? (t.push(...b(this, ni, $p).call(this, e)), b(this, ni, a0).call(this, e)) : (b(this, ni, o0).call(this, e), t.push(...b(this, ni, $p).call(this, e)));
    return b(this, ni, r0).call(this, t);
  }
}
vd = new WeakMap(), Ed = new WeakMap(), Sd = new WeakMap(), Mr = new WeakMap(), ys = new WeakMap(), ni = new WeakSet(), r0 = function(t) {
  const e = [], i = /* @__PURE__ */ new Set();
  for (const a of t) {
    const [o, l, h] = a;
    e.push([o, l, a], [o, h, a]);
  }
  e.sort((a, o) => a[1] - o[1] || a[0] - o[0]);
  for (let a = 0, o = e.length; a < o; a += 2) {
    const l = e[a][2], h = e[a + 1][2];
    l.push(h), h.push(l), i.add(l), i.add(h);
  }
  const s = [];
  let r;
  for (; i.size > 0; ) {
    const a = i.values().next().value;
    let [o, l, h, c, u] = a;
    i.delete(a);
    let f = o, m = l;
    for (r = [o, h], s.push(r); ; ) {
      let A;
      if (i.has(c))
        A = c;
      else if (i.has(u))
        A = u;
      else
        break;
      i.delete(A), [o, l, h, c, u] = A, f !== o && (r.push(f, m, o, m === l ? l : h), f = o), m = m === l ? h : l;
    }
    r.push(f, m);
  }
  return new $A(s, n(this, vd), n(this, Ed), n(this, Sd));
}, Eu = function(t) {
  const e = n(this, ys);
  let i = 0, s = e.length - 1;
  for (; i <= s; ) {
    const r = i + s >> 1, a = e[r][0];
    if (a === t)
      return r;
    a < t ? i = r + 1 : s = r - 1;
  }
  return s + 1;
}, a0 = function([, t, e]) {
  const i = b(this, ni, Eu).call(this, t);
  n(this, ys).splice(i, 0, [t, e]);
}, o0 = function([, t, e]) {
  const i = b(this, ni, Eu).call(this, t);
  for (let s = i; s < n(this, ys).length; s++) {
    const [r, a] = n(this, ys)[s];
    if (r !== t)
      break;
    if (r === t && a === e) {
      n(this, ys).splice(s, 1);
      return;
    }
  }
  for (let s = i - 1; s >= 0; s--) {
    const [r, a] = n(this, ys)[s];
    if (r !== t)
      break;
    if (r === t && a === e) {
      n(this, ys).splice(s, 1);
      return;
    }
  }
}, $p = function(t) {
  const [e, i, s] = t, r = [[e, i, s]], a = b(this, ni, Eu).call(this, s);
  for (let o = 0; o < a; o++) {
    const [l, h] = n(this, ys)[o];
    for (let c = 0, u = r.length; c < u; c++) {
      const [, f, m] = r[c];
      if (!(h <= f || m <= l)) {
        if (f >= l) {
          if (m > h)
            r[c][1] = h;
          else {
            if (u === 1)
              return [];
            r.splice(c, 1), c--, u--;
          }
          continue;
        }
        r[c][2] = l, m > h && r.push([e, h, m]);
      }
    }
  }
  return r;
};
var _d, Yl;
class $A extends V {
  constructor(e, i, s, r) {
    super();
    g(this, _d);
    g(this, Yl);
    p(this, Yl, e), p(this, _d, i), this.firstPoint = s, this.lastPoint = r;
  }
  toSVGPath() {
    const e = [];
    for (const i of n(this, Yl)) {
      let [s, r] = i;
      e.push(`M${s} ${r}`);
      for (let a = 2; a < i.length; a += 2) {
        const o = i[a], l = i[a + 1];
        o === s ? (e.push(`V${l}`), r = l) : l === r && (e.push(`H${o}`), s = o);
      }
      e.push("Z");
    }
    return e.join(" ");
  }
  serialize([e, i, s, r], a) {
    const o = [], l = s - e, h = r - i;
    for (const c of n(this, Yl)) {
      const u = new Array(c.length);
      for (let f = 0; f < c.length; f += 2)
        u[f] = e + c[f] * l, u[f + 1] = r - c[f + 1] * h;
      o.push(u);
    }
    return o;
  }
  get box() {
    return n(this, _d);
  }
  get classNamesForOutlining() {
    return ["highlightOutline"];
  }
}
_d = new WeakMap(), Yl = new WeakMap();
class Vp extends $u {
  newFreeDrawOutline(t, e, i, s, r, a) {
    return new VA(t, e, i, s, r, a);
  }
}
class VA extends s0 {
  newOutliner(t, e, i, s, r, a = 0) {
    return new Vp(t, e, i, s, r, a);
  }
}
var Kl, xd, Nn, eo, Cd, pi, Td, Pd, io, Mi, Di, Re, Zl, Jl, Ge, Ql, es, Ld, nt, zp, Su, l0, h0, c0, Gp, ea, rs, Lo, d0, _u, xu, u0, f0, p0, g0, m0;
const mt = class mt extends Ft {
  constructor(e) {
    super({
      ...e,
      name: "highlightEditor"
    });
    g(this, nt);
    g(this, Kl, null);
    g(this, xd, 0);
    g(this, Nn);
    g(this, eo, null);
    g(this, Cd, null);
    g(this, pi, null);
    g(this, Td, null);
    g(this, Pd, 0);
    g(this, io, null);
    g(this, Mi, null);
    g(this, Di, null);
    g(this, Re, !1);
    g(this, Zl, null);
    g(this, Jl, null);
    g(this, Ge, null);
    g(this, Ql, "");
    g(this, es);
    g(this, Ld, "");
    this.color = e.color || mt._defaultColor, p(this, es, e.thickness || mt._defaultThickness), this.opacity = e.opacity || mt._defaultOpacity, p(this, Nn, e.boxes || null), p(this, Ld, e.methodOfCreation || ""), p(this, Ql, e.text || ""), this._isDraggable = !1, this.defaultL10nId = "pdfjs-editor-highlight-editor", e.highlightId > -1 ? (p(this, Re, !0), b(this, nt, Su).call(this, e), b(this, nt, ea).call(this)) : n(this, Nn) && (p(this, Kl, e.anchorNode), p(this, xd, e.anchorOffset), p(this, Td, e.focusNode), p(this, Pd, e.focusOffset), b(this, nt, zp).call(this), b(this, nt, ea).call(this), this.rotate(this.rotation)), this.annotationElementId || this._uiManager.a11yAlert("pdfjs-editor-highlight-added-alert");
  }
  static get _keyboardManager() {
    const e = mt.prototype;
    return st(this, "_keyboardManager", new Od([[["ArrowLeft", "mac+ArrowLeft"], e._moveCaret, {
      args: [0]
    }], [["ArrowRight", "mac+ArrowRight"], e._moveCaret, {
      args: [1]
    }], [["ArrowUp", "mac+ArrowUp"], e._moveCaret, {
      args: [2]
    }], [["ArrowDown", "mac+ArrowDown"], e._moveCaret, {
      args: [3]
    }]]));
  }
  get telemetryInitialData() {
    return {
      action: "added",
      type: n(this, Re) ? "free_highlight" : "highlight",
      color: this._uiManager.getNonHCMColorName(this.color),
      thickness: n(this, es),
      methodOfCreation: n(this, Ld)
    };
  }
  get telemetryFinalData() {
    return {
      type: "highlight",
      color: this._uiManager.getNonHCMColorName(this.color)
    };
  }
  static computeTelemetryFinalData(e) {
    return {
      numberOfColors: e.get("color").size
    };
  }
  static initialize(e, i) {
    var s;
    Ft.initialize(e, i), mt._defaultColor || (mt._defaultColor = ((s = i.highlightColors) == null ? void 0 : s.values().next().value) || "#fff066");
  }
  static updateDefaultParams(e, i) {
    switch (e) {
      case ht.HIGHLIGHT_COLOR:
        mt._defaultColor = i;
        break;
      case ht.HIGHLIGHT_THICKNESS:
        mt._defaultThickness = i;
        break;
    }
  }
  translateInPage(e, i) {
  }
  get toolbarPosition() {
    return n(this, Jl);
  }
  get commentButtonPosition() {
    return n(this, Zl);
  }
  updateParams(e, i) {
    switch (e) {
      case ht.HIGHLIGHT_COLOR:
        b(this, nt, l0).call(this, i);
        break;
      case ht.HIGHLIGHT_THICKNESS:
        b(this, nt, h0).call(this, i);
        break;
    }
  }
  static get defaultPropertiesToUpdate() {
    return [[ht.HIGHLIGHT_COLOR, mt._defaultColor], [ht.HIGHLIGHT_THICKNESS, mt._defaultThickness]];
  }
  get propertiesToUpdate() {
    return [[ht.HIGHLIGHT_COLOR, this.color || mt._defaultColor], [ht.HIGHLIGHT_THICKNESS, n(this, es) || mt._defaultThickness], [ht.HIGHLIGHT_FREE, n(this, Re)]];
  }
  onUpdatedColor() {
    var e, i;
    (e = this.parent) == null || e.drawLayer.updateProperties(n(this, Di), {
      root: {
        fill: this.color,
        "fill-opacity": this.opacity
      }
    }), (i = n(this, Cd)) == null || i.updateColor(this.color), super.onUpdatedColor();
  }
  get toolbarButtons() {
    return this._uiManager.highlightColors ? [["colorPicker", p(this, Cd, new Zh({
      editor: this
    }))]] : super.toolbarButtons;
  }
  disableEditing() {
    super.disableEditing(), this.div.classList.toggle("disabled", !0);
  }
  enableEditing() {
    super.enableEditing(), this.div.classList.toggle("disabled", !1);
  }
  fixAndSetPosition() {
    return super.fixAndSetPosition(b(this, nt, xu).call(this));
  }
  getBaseTranslation() {
    return [0, 0];
  }
  getRect(e, i) {
    return super.getRect(e, i, b(this, nt, xu).call(this));
  }
  onceAdded(e) {
    this.annotationElementId || this.parent.addUndoableEditor(this), e && this.div.focus();
  }
  remove() {
    b(this, nt, Gp).call(this), this._reportTelemetry({
      action: "deleted"
    }), super.remove();
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (b(this, nt, ea).call(this), this.isAttachedToDOM || this.parent.add(this)));
  }
  setParent(e) {
    var s;
    let i = !1;
    this.parent && !e ? b(this, nt, Gp).call(this) : e && (b(this, nt, ea).call(this, e), i = !this.parent && ((s = this.div) == null ? void 0 : s.classList.contains("selectedEditor"))), super.setParent(e), this.show(this._isVisible), i && this.select();
  }
  rotate(e) {
    var r, a, o;
    const {
      drawLayer: i
    } = this.parent;
    let s;
    n(this, Re) ? (e = (e - this.rotation + 360) % 360, s = b(r = mt, rs, Lo).call(r, n(this, Mi).box, e)) : s = b(a = mt, rs, Lo).call(a, [this.x, this.y, this.width, this.height], e), i.updateProperties(n(this, Di), {
      bbox: s,
      root: {
        "data-main-rotation": e
      }
    }), i.updateProperties(n(this, Ge), {
      bbox: b(o = mt, rs, Lo).call(o, n(this, pi).box, e),
      root: {
        "data-main-rotation": e
      }
    });
  }
  render() {
    if (this.div)
      return this.div;
    const e = super.render();
    n(this, Ql) && (e.setAttribute("aria-label", n(this, Ql)), e.setAttribute("role", "mark")), n(this, Re) ? e.classList.add("free") : this.div.addEventListener("keydown", b(this, nt, d0).bind(this), {
      signal: this._uiManager._signal
    });
    const i = p(this, io, document.createElement("div"));
    return e.append(i), i.setAttribute("aria-hidden", "true"), i.className = "internal", i.style.clipPath = n(this, eo), this.setDims(this.width, this.height), Om(this, n(this, io), ["pointerover", "pointerleave"]), this.enableEditing(), e;
  }
  pointerover() {
    var e;
    this.isSelected || (e = this.parent) == null || e.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        hovered: !0
      }
    });
  }
  pointerleave() {
    var e;
    this.isSelected || (e = this.parent) == null || e.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        hovered: !1
      }
    });
  }
  _moveCaret(e) {
    switch (this.parent.unselect(this), e) {
      case 0:
      case 2:
        b(this, nt, _u).call(this, !0);
        break;
      case 1:
      case 3:
        b(this, nt, _u).call(this, !1);
        break;
    }
  }
  select() {
    var e;
    super.select(), n(this, Ge) && ((e = this.parent) == null || e.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        hovered: !1,
        selected: !0
      }
    }));
  }
  unselect() {
    var e;
    super.unselect(), n(this, Ge) && ((e = this.parent) == null || e.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        selected: !1
      }
    }), n(this, Re) || b(this, nt, _u).call(this, !1));
  }
  get _mustFixPosition() {
    return !n(this, Re);
  }
  show(e = this._isVisible) {
    super.show(e), this.parent && (this.parent.drawLayer.updateProperties(n(this, Di), {
      rootClass: {
        hidden: !e
      }
    }), this.parent.drawLayer.updateProperties(n(this, Ge), {
      rootClass: {
        hidden: !e
      }
    }));
  }
  static startHighlighting(e, i, {
    target: s,
    x: r,
    y: a
  }) {
    const {
      x: o,
      y: l,
      width: h,
      height: c
    } = s.getBoundingClientRect(), u = new AbortController(), f = e.combinedSignal(u), m = (A) => {
      u.abort(), b(this, rs, g0).call(this, e, A);
    };
    window.addEventListener("blur", m, {
      signal: f
    }), window.addEventListener("pointerup", m, {
      signal: f
    }), window.addEventListener("pointerdown", zt, {
      capture: !0,
      passive: !1,
      signal: f
    }), window.addEventListener("contextmenu", $i, {
      signal: f
    }), s.addEventListener("pointermove", b(this, rs, p0).bind(this, e), {
      signal: f
    }), this._freeHighlight = new Vp({
      x: r,
      y: a
    }, [o, l, h, c], e.scale, this._defaultThickness / 2, i, 1e-3), {
      id: this._freeHighlightId,
      clipPathId: this._freeHighlightClipId
    } = e.drawLayer.draw({
      bbox: [0, 0, 1, 1],
      root: {
        viewBox: "0 0 1 1",
        fill: this._defaultColor,
        "fill-opacity": this._defaultOpacity
      },
      rootClass: {
        highlight: !0,
        free: !0
      },
      path: {
        d: this._freeHighlight.toSVGPath()
      }
    }, !0, !0);
  }
  static async deserialize(e, i, s) {
    var y, v, w, S;
    let r = null;
    if (e instanceof Gb) {
      const {
        data: {
          quadPoints: E,
          rect: _,
          rotation: x,
          id: C,
          color: T,
          opacity: L,
          popupRef: k,
          richText: D,
          contentsObj: R,
          creationDate: N,
          modificationDate: q
        },
        parent: {
          page: {
            pageNumber: B
          }
        }
      } = e;
      r = e = {
        annotationType: Z.HIGHLIGHT,
        color: Array.from(T),
        opacity: L,
        quadPoints: E,
        boxes: null,
        pageIndex: B - 1,
        rect: _.slice(0),
        rotation: x,
        annotationElementId: C,
        id: C,
        deleted: !1,
        popupRef: k,
        richText: D,
        comment: (R == null ? void 0 : R.str) || null,
        creationDate: N,
        modificationDate: q
      };
    } else if (e instanceof Sg) {
      const {
        data: {
          inkLists: E,
          rect: _,
          rotation: x,
          id: C,
          color: T,
          borderStyle: {
            rawWidth: L
          },
          popupRef: k,
          richText: D,
          contentsObj: R,
          creationDate: N,
          modificationDate: q
        },
        parent: {
          page: {
            pageNumber: B
          }
        }
      } = e;
      r = e = {
        annotationType: Z.HIGHLIGHT,
        color: Array.from(T),
        thickness: L,
        inkLists: E,
        boxes: null,
        pageIndex: B - 1,
        rect: _.slice(0),
        rotation: x,
        annotationElementId: C,
        id: C,
        deleted: !1,
        popupRef: k,
        richText: D,
        comment: (R == null ? void 0 : R.str) || null,
        creationDate: N,
        modificationDate: q
      };
    }
    const {
      color: a,
      quadPoints: o,
      inkLists: l,
      opacity: h
    } = e, c = await super.deserialize(e, i, s);
    c.color = z.makeHexColor(...a), c.opacity = h || 1, l && p(c, es, e.thickness), c._initialData = r, e.comment && c.setCommentData(e);
    const [u, f] = c.pageDimensions, [m, A] = c.pageTranslation;
    if (o) {
      const E = p(c, Nn, []);
      for (let _ = 0; _ < o.length; _ += 8)
        E.push({
          x: (o[_] - m) / u,
          y: 1 - (o[_ + 1] - A) / f,
          width: (o[_ + 2] - o[_]) / u,
          height: (o[_ + 1] - o[_ + 5]) / f
        });
      b(y = c, nt, zp).call(y), b(v = c, nt, ea).call(v), c.rotate(c.rotation);
    } else if (l) {
      p(c, Re, !0);
      const E = l[0], _ = {
        x: E[0] - m,
        y: f - (E[1] - A)
      }, x = new Vp(_, [0, 0, u, f], 1, n(c, es) / 2, !0, 1e-3);
      for (let L = 0, k = E.length; L < k; L += 2)
        _.x = E[L] - m, _.y = f - (E[L + 1] - A), x.add(_);
      const {
        id: C,
        clipPathId: T
      } = i.drawLayer.draw({
        bbox: [0, 0, 1, 1],
        root: {
          viewBox: "0 0 1 1",
          fill: c.color,
          "fill-opacity": c._defaultOpacity
        },
        rootClass: {
          highlight: !0,
          free: !0
        },
        path: {
          d: x.toSVGPath()
        }
      }, !0, !0);
      b(w = c, nt, Su).call(w, {
        highlightOutlines: x.getOutlines(),
        highlightId: C,
        clipPathId: T
      }), b(S = c, nt, ea).call(S), c.rotate(c.parentRotation);
    }
    return c;
  }
  serialize(e = !1) {
    if (this.isEmpty() || e)
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const i = Ft._colorManager.convert(this._uiManager.getNonHCMColor(this.color)), s = super.serialize(e);
    return Object.assign(s, {
      color: i,
      opacity: this.opacity,
      thickness: n(this, es),
      quadPoints: b(this, nt, u0).call(this),
      outlines: b(this, nt, f0).call(this, s.rect)
    }), this.addComment(s), this.annotationElementId && !b(this, nt, m0).call(this, s) ? null : (s.id = this.annotationElementId, s);
  }
  renderAnnotationElement(e) {
    return this.deleted ? (e.hide(), null) : (e.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
  static canCreateNewEmptyEditor() {
    return !1;
  }
};
Kl = new WeakMap(), xd = new WeakMap(), Nn = new WeakMap(), eo = new WeakMap(), Cd = new WeakMap(), pi = new WeakMap(), Td = new WeakMap(), Pd = new WeakMap(), io = new WeakMap(), Mi = new WeakMap(), Di = new WeakMap(), Re = new WeakMap(), Zl = new WeakMap(), Jl = new WeakMap(), Ge = new WeakMap(), Ql = new WeakMap(), es = new WeakMap(), Ld = new WeakMap(), nt = new WeakSet(), zp = function() {
  const e = new Up(n(this, Nn), 1e-3);
  p(this, Mi, e.getOutlines()), [this.x, this.y, this.width, this.height] = n(this, Mi).box;
  const i = new Up(n(this, Nn), 25e-4, 1e-3, this._uiManager.direction === "ltr");
  p(this, pi, i.getOutlines());
  const {
    firstPoint: s
  } = n(this, Mi);
  p(this, Zl, [(s[0] - this.x) / this.width, (s[1] - this.y) / this.height]);
  const {
    lastPoint: r
  } = n(this, pi);
  p(this, Jl, [(r[0] - this.x) / this.width, (r[1] - this.y) / this.height]);
}, Su = function({
  highlightOutlines: e,
  highlightId: i,
  clipPathId: s
}) {
  var f, m;
  if (p(this, Mi, e), p(this, pi, e.getNewOutline(n(this, es) / 2 + 1.5, 25e-4)), i >= 0)
    p(this, Di, i), p(this, eo, s), this.parent.drawLayer.finalizeDraw(i, {
      bbox: e.box,
      path: {
        d: e.toSVGPath()
      }
    }), p(this, Ge, this.parent.drawLayer.drawOutline({
      rootClass: {
        highlightOutline: !0,
        free: !0
      },
      bbox: n(this, pi).box,
      path: {
        d: n(this, pi).toSVGPath()
      }
    }, !0));
  else if (this.parent) {
    const A = this.parent.viewport.rotation;
    this.parent.drawLayer.updateProperties(n(this, Di), {
      bbox: b(f = mt, rs, Lo).call(f, n(this, Mi).box, (A - this.rotation + 360) % 360),
      path: {
        d: e.toSVGPath()
      }
    }), this.parent.drawLayer.updateProperties(n(this, Ge), {
      bbox: b(m = mt, rs, Lo).call(m, n(this, pi).box, A),
      path: {
        d: n(this, pi).toSVGPath()
      }
    });
  }
  const [a, o, l, h] = e.box;
  switch (this.rotation) {
    case 0:
      this.x = a, this.y = o, this.width = l, this.height = h;
      break;
    case 90: {
      const [A, y] = this.parentDimensions;
      this.x = o, this.y = 1 - a, this.width = l * y / A, this.height = h * A / y;
      break;
    }
    case 180:
      this.x = 1 - a, this.y = 1 - o, this.width = l, this.height = h;
      break;
    case 270: {
      const [A, y] = this.parentDimensions;
      this.x = 1 - o, this.y = a, this.width = l * y / A, this.height = h * A / y;
      break;
    }
  }
  const {
    firstPoint: c
  } = e;
  p(this, Zl, [(c[0] - a) / l, (c[1] - o) / h]);
  const {
    lastPoint: u
  } = n(this, pi);
  p(this, Jl, [(u[0] - a) / l, (u[1] - o) / h]);
}, l0 = function(e) {
  const i = (a, o) => {
    this.color = a, this.opacity = o, this.onUpdatedColor();
  }, s = this.color, r = this.opacity;
  this.addCommands({
    cmd: i.bind(this, e, mt._defaultOpacity),
    undo: i.bind(this, s, r),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: ht.HIGHLIGHT_COLOR,
    overwriteIfSameType: !0,
    keepUndo: !0
  }), this._reportTelemetry({
    action: "color_changed",
    color: this._uiManager.getNonHCMColorName(e)
  }, !0);
}, h0 = function(e) {
  const i = n(this, es), s = (r) => {
    p(this, es, r), b(this, nt, c0).call(this, r);
  };
  this.addCommands({
    cmd: s.bind(this, e),
    undo: s.bind(this, i),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: ht.INK_THICKNESS,
    overwriteIfSameType: !0,
    keepUndo: !0
  }), this._reportTelemetry({
    action: "thickness_changed",
    thickness: e
  }, !0);
}, c0 = function(e) {
  n(this, Re) && (b(this, nt, Su).call(this, {
    highlightOutlines: n(this, Mi).getNewOutline(e / 2)
  }), this.fixAndSetPosition(), this.setDims(this.width, this.height));
}, Gp = function() {
  n(this, Di) === null || !this.parent || (this.parent.drawLayer.remove(n(this, Di)), p(this, Di, null), this.parent.drawLayer.remove(n(this, Ge)), p(this, Ge, null));
}, ea = function(e = this.parent) {
  n(this, Di) === null && ({
    id: oe(this, Di)._,
    clipPathId: oe(this, eo)._
  } = e.drawLayer.draw({
    bbox: n(this, Mi).box,
    root: {
      viewBox: "0 0 1 1",
      fill: this.color,
      "fill-opacity": this.opacity
    },
    rootClass: {
      highlight: !0,
      free: n(this, Re)
    },
    path: {
      d: n(this, Mi).toSVGPath()
    }
  }, !1, !0), p(this, Ge, e.drawLayer.drawOutline({
    rootClass: {
      highlightOutline: !0,
      free: n(this, Re)
    },
    bbox: n(this, pi).box,
    path: {
      d: n(this, pi).toSVGPath()
    }
  }, n(this, Re))), n(this, io) && (n(this, io).style.clipPath = n(this, eo)));
}, rs = new WeakSet(), Lo = function([e, i, s, r], a) {
  switch (a) {
    case 90:
      return [1 - i - r, e, r, s];
    case 180:
      return [1 - e - s, 1 - i - r, s, r];
    case 270:
      return [i, 1 - e - s, r, s];
  }
  return [e, i, s, r];
}, d0 = function(e) {
  mt._keyboardManager.exec(this, e);
}, _u = function(e) {
  if (!n(this, Kl))
    return;
  const i = window.getSelection();
  e ? i.setPosition(n(this, Kl), n(this, xd)) : i.setPosition(n(this, Td), n(this, Pd));
}, xu = function() {
  return n(this, Re) ? this.rotation : 0;
}, u0 = function() {
  if (n(this, Re))
    return null;
  const [e, i] = this.pageDimensions, [s, r] = this.pageTranslation, a = n(this, Nn), o = new Float32Array(a.length * 8);
  let l = 0;
  for (const {
    x: h,
    y: c,
    width: u,
    height: f
  } of a) {
    const m = h * e + s, A = (1 - c) * i + r;
    o[l] = o[l + 4] = m, o[l + 1] = o[l + 3] = A, o[l + 2] = o[l + 6] = m + u * e, o[l + 5] = o[l + 7] = A - f * i, l += 8;
  }
  return o;
}, f0 = function(e) {
  return n(this, Mi).serialize(e, b(this, nt, xu).call(this));
}, p0 = function(e, i) {
  this._freeHighlight.add(i) && e.drawLayer.updateProperties(this._freeHighlightId, {
    path: {
      d: this._freeHighlight.toSVGPath()
    }
  });
}, g0 = function(e, i) {
  this._freeHighlight.isEmpty() ? e.drawLayer.remove(this._freeHighlightId) : e.createAndAddNewEditor(i, !1, {
    highlightId: this._freeHighlightId,
    highlightOutlines: this._freeHighlight.getOutlines(),
    clipPathId: this._freeHighlightClipId,
    methodOfCreation: "main_toolbar"
  }), this._freeHighlightId = -1, this._freeHighlight = null, this._freeHighlightClipId = "";
}, m0 = function(e) {
  const {
    color: i
  } = this._initialData;
  return this.hasEditedComment || e.color.some((s, r) => s !== i[r]);
}, g(mt, rs), M(mt, "_defaultColor", null), M(mt, "_defaultOpacity", 1), M(mt, "_defaultThickness", 12), M(mt, "_type", "highlight"), M(mt, "_editorType", Z.HIGHLIGHT), M(mt, "_freeHighlightId", -1), M(mt, "_freeHighlight", null), M(mt, "_freeHighlightClipId", "");
let Vu = mt;
var so;
class b0 {
  constructor() {
    g(this, so, /* @__PURE__ */ Object.create(null));
  }
  updateProperty(t, e) {
    this[t] = e, this.updateSVGProperty(t, e);
  }
  updateProperties(t) {
    if (t)
      for (const [e, i] of Object.entries(t))
        e.startsWith("_") || this.updateProperty(e, i);
  }
  updateSVGProperty(t, e) {
    n(this, so)[t] = e;
  }
  toSVGProperties() {
    const t = n(this, so);
    return p(this, so, /* @__PURE__ */ Object.create(null)), {
      root: t
    };
  }
  reset() {
    p(this, so, /* @__PURE__ */ Object.create(null));
  }
  updateAll(t = this) {
    this.updateProperties(t);
  }
  clone() {
    Dt("Not implemented");
  }
}
so = new WeakMap();
var Ii, th, ye, no, ro, Dr, Ir, Fr, ao, pt, Wp, jp, qp, Hh, y0, Cu, Uh, ko;
const G = class G extends Ft {
  constructor(e) {
    super(e);
    g(this, pt);
    g(this, Ii, null);
    g(this, th);
    M(this, "_colorPicker", null);
    M(this, "_drawId", null);
    p(this, th, e.mustBeCommitted || !1), this._addOutlines(e);
  }
  onUpdatedColor() {
    var e;
    (e = this._colorPicker) == null || e.update(this.color), super.onUpdatedColor();
  }
  _addOutlines(e) {
    e.drawOutlines && (b(this, pt, Wp).call(this, e), b(this, pt, Hh).call(this));
  }
  static _mergeSVGProperties(e, i) {
    const s = new Set(Object.keys(e));
    for (const [r, a] of Object.entries(i))
      s.has(r) ? Object.assign(e[r], a) : e[r] = a;
    return e;
  }
  static getDefaultDrawingOptions(e) {
    Dt("Not implemented");
  }
  static get typesMap() {
    Dt("Not implemented");
  }
  static get isDrawer() {
    return !0;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  static updateDefaultParams(e, i) {
    const s = this.typesMap.get(e);
    s && this._defaultDrawingOptions.updateProperty(s, i), this._currentParent && (n(G, ye).updateProperty(s, i), this._currentParent.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  updateParams(e, i) {
    const s = this.constructor.typesMap.get(e);
    s && this._updateProperty(e, s, i);
  }
  static get defaultPropertiesToUpdate() {
    const e = [], i = this._defaultDrawingOptions;
    for (const [s, r] of this.typesMap)
      e.push([s, i[r]]);
    return e;
  }
  get propertiesToUpdate() {
    const e = [], {
      _drawingOptions: i
    } = this;
    for (const [s, r] of this.constructor.typesMap)
      e.push([s, i[r]]);
    return e;
  }
  _updateProperty(e, i, s) {
    const r = this._drawingOptions, a = r[i], o = (l) => {
      var c;
      r.updateProperty(i, l);
      const h = n(this, Ii).updateProperty(i, l);
      h && b(this, pt, Uh).call(this, h), (c = this.parent) == null || c.drawLayer.updateProperties(this._drawId, r.toSVGProperties()), e === this.colorType && this.onUpdatedColor();
    };
    this.addCommands({
      cmd: o.bind(this, s),
      undo: o.bind(this, a),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: e,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _onResizing() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, G._mergeSVGProperties(n(this, Ii).getPathResizingSVGProperties(b(this, pt, Cu).call(this)), {
      bbox: b(this, pt, ko).call(this)
    }));
  }
  _onResized() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, G._mergeSVGProperties(n(this, Ii).getPathResizedSVGProperties(b(this, pt, Cu).call(this)), {
      bbox: b(this, pt, ko).call(this)
    }));
  }
  _onTranslating(e, i) {
    var s;
    (s = this.parent) == null || s.drawLayer.updateProperties(this._drawId, {
      bbox: b(this, pt, ko).call(this)
    });
  }
  _onTranslated() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, G._mergeSVGProperties(n(this, Ii).getPathTranslatedSVGProperties(b(this, pt, Cu).call(this), this.parentDimensions), {
      bbox: b(this, pt, ko).call(this)
    }));
  }
  _onStartDragging() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !0
      }
    });
  }
  _onStopDragging() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !1
      }
    });
  }
  commit() {
    super.commit(), this.disableEditMode(), this.disableEditing();
  }
  disableEditing() {
    super.disableEditing(), this.div.classList.toggle("disabled", !0);
  }
  enableEditing() {
    super.enableEditing(), this.div.classList.toggle("disabled", !1);
  }
  getBaseTranslation() {
    return [0, 0];
  }
  get isResizable() {
    return !0;
  }
  onceAdded(e) {
    this.annotationElementId || this.parent.addUndoableEditor(this), this._isDraggable = !0, n(this, th) && (p(this, th, !1), this.commit(), this.parent.setSelected(this), e && this.isOnScreen && this.div.focus());
  }
  remove() {
    b(this, pt, qp).call(this), super.remove();
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (b(this, pt, Hh).call(this), b(this, pt, Uh).call(this, n(this, Ii).box), this.isAttachedToDOM || this.parent.add(this)));
  }
  setParent(e) {
    var s;
    let i = !1;
    this.parent && !e ? (this._uiManager.removeShouldRescale(this), b(this, pt, qp).call(this)) : e && (this._uiManager.addShouldRescale(this), b(this, pt, Hh).call(this, e), i = !this.parent && ((s = this.div) == null ? void 0 : s.classList.contains("selectedEditor"))), super.setParent(e), i && this.select();
  }
  rotate() {
    this.parent && this.parent.drawLayer.updateProperties(this._drawId, G._mergeSVGProperties({
      bbox: b(this, pt, ko).call(this)
    }, n(this, Ii).updateRotation((this.parentRotation - this.rotation + 360) % 360)));
  }
  onScaleChanging() {
    this.parent && b(this, pt, Uh).call(this, n(this, Ii).updateParentDimensions(this.parentDimensions, this.parent.scale));
  }
  static onScaleChangingWhenDrawing() {
  }
  render() {
    if (this.div)
      return this.div;
    let e, i;
    this._isCopy && (e = this.x, i = this.y);
    const s = super.render();
    s.classList.add("draw");
    const r = document.createElement("div");
    return s.append(r), r.setAttribute("aria-hidden", "true"), r.className = "internal", this.setDims(), this._uiManager.addShouldRescale(this), this.disableEditing(), this._isCopy && this._moveAfterPaste(e, i), s;
  }
  static createDrawerInstance(e, i, s, r, a) {
    Dt("Not implemented");
  }
  static startDrawing(e, i, s, r) {
    var v;
    const {
      target: a,
      offsetX: o,
      offsetY: l,
      pointerId: h,
      pointerType: c
    } = r;
    if (n(G, Ir) && n(G, Ir) !== c)
      return;
    const {
      viewport: {
        rotation: u
      }
    } = e, {
      width: f,
      height: m
    } = a.getBoundingClientRect(), A = p(G, no, new AbortController()), y = e.combinedSignal(A);
    if (n(G, Dr) || p(G, Dr, h), n(G, Ir) ?? p(G, Ir, c), window.addEventListener("pointerup", (w) => {
      var S;
      n(G, Dr) === w.pointerId ? this._endDraw(w) : (S = n(G, Fr)) == null || S.delete(w.pointerId);
    }, {
      signal: y
    }), window.addEventListener("pointercancel", (w) => {
      var S;
      n(G, Dr) === w.pointerId ? this._currentParent.endDrawingSession() : (S = n(G, Fr)) == null || S.delete(w.pointerId);
    }, {
      signal: y
    }), window.addEventListener("pointerdown", (w) => {
      n(G, Ir) === w.pointerType && ((n(G, Fr) || p(G, Fr, /* @__PURE__ */ new Set())).add(w.pointerId), n(G, ye).isCancellable() && (n(G, ye).removeLastElement(), n(G, ye).isEmpty() ? this._currentParent.endDrawingSession(!0) : this._endDraw(null)));
    }, {
      capture: !0,
      passive: !1,
      signal: y
    }), window.addEventListener("contextmenu", $i, {
      signal: y
    }), a.addEventListener("pointermove", this._drawMove.bind(this), {
      signal: y
    }), a.addEventListener("touchmove", (w) => {
      w.timeStamp === n(G, ao) && zt(w);
    }, {
      signal: y
    }), e.toggleDrawing(), (v = i._editorUndoBar) == null || v.hide(), n(G, ye)) {
      e.drawLayer.updateProperties(this._currentDrawId, n(G, ye).startNew(o, l, f, m, u));
      return;
    }
    i.updateUIForDefaultProperties(this), p(G, ye, this.createDrawerInstance(o, l, f, m, u)), p(G, ro, this.getDefaultDrawingOptions()), this._currentParent = e, {
      id: this._currentDrawId
    } = e.drawLayer.draw(this._mergeSVGProperties(n(G, ro).toSVGProperties(), n(G, ye).defaultSVGProperties), !0, !1);
  }
  static _drawMove(e) {
    var a;
    if (p(G, ao, -1), !n(G, ye))
      return;
    const {
      offsetX: i,
      offsetY: s,
      pointerId: r
    } = e;
    if (n(G, Dr) === r) {
      if (((a = n(G, Fr)) == null ? void 0 : a.size) >= 1) {
        this._endDraw(e);
        return;
      }
      this._currentParent.drawLayer.updateProperties(this._currentDrawId, n(G, ye).add(i, s)), p(G, ao, e.timeStamp), zt(e);
    }
  }
  static _cleanup(e) {
    e && (this._currentDrawId = -1, this._currentParent = null, p(G, ye, null), p(G, ro, null), p(G, Ir, null), p(G, ao, NaN)), n(G, no) && (n(G, no).abort(), p(G, no, null), p(G, Dr, NaN), p(G, Fr, null));
  }
  static _endDraw(e) {
    const i = this._currentParent;
    if (i) {
      if (i.toggleDrawing(!0), this._cleanup(!1), (e == null ? void 0 : e.target) === i.div && i.drawLayer.updateProperties(this._currentDrawId, n(G, ye).end(e.offsetX, e.offsetY)), this.supportMultipleDrawings) {
        const s = n(G, ye), r = this._currentDrawId, a = s.getLastElement();
        i.addCommands({
          cmd: () => {
            i.drawLayer.updateProperties(r, s.setLastElement(a));
          },
          undo: () => {
            i.drawLayer.updateProperties(r, s.removeLastElement());
          },
          mustExec: !1,
          type: ht.DRAW_STEP
        });
        return;
      }
      this.endDrawing(!1);
    }
  }
  static endDrawing(e) {
    const i = this._currentParent;
    if (!i)
      return null;
    if (i.toggleDrawing(!0), i.cleanUndoStack(ht.DRAW_STEP), !n(G, ye).isEmpty()) {
      const {
        pageDimensions: [s, r],
        scale: a
      } = i, o = i.createAndAddNewEditor({
        offsetX: 0,
        offsetY: 0
      }, !1, {
        drawId: this._currentDrawId,
        drawOutlines: n(G, ye).getOutlines(s * a, r * a, a, this._INNER_MARGIN),
        drawingOptions: n(G, ro),
        mustBeCommitted: !e
      });
      return this._cleanup(!0), o;
    }
    return i.drawLayer.remove(this._currentDrawId), this._cleanup(!0), null;
  }
  createDrawingOptions(e) {
  }
  static deserializeDraw(e, i, s, r, a, o) {
    Dt("Not implemented");
  }
  static async deserialize(e, i, s) {
    var u, f;
    const {
      rawDims: {
        pageWidth: r,
        pageHeight: a,
        pageX: o,
        pageY: l
      }
    } = i.viewport, h = this.deserializeDraw(o, l, r, a, this._INNER_MARGIN, e), c = await super.deserialize(e, i, s);
    return c.createDrawingOptions(e), b(u = c, pt, Wp).call(u, {
      drawOutlines: h
    }), b(f = c, pt, Hh).call(f), c.onScaleChanging(), c.rotate(), c;
  }
  serializeDraw(e) {
    const [i, s] = this.pageTranslation, [r, a] = this.pageDimensions;
    return n(this, Ii).serialize([i, s, r, a], e);
  }
  renderAnnotationElement(e) {
    return e.updateEdited({
      rect: this.getPDFRect()
    }), null;
  }
  static canCreateNewEmptyEditor() {
    return !1;
  }
};
Ii = new WeakMap(), th = new WeakMap(), ye = new WeakMap(), no = new WeakMap(), ro = new WeakMap(), Dr = new WeakMap(), Ir = new WeakMap(), Fr = new WeakMap(), ao = new WeakMap(), pt = new WeakSet(), Wp = function({
  drawOutlines: e,
  drawId: i,
  drawingOptions: s
}) {
  p(this, Ii, e), this._drawingOptions || (this._drawingOptions = s), this.annotationElementId || this._uiManager.a11yAlert(`pdfjs-editor-${this.editorType}-added-alert`), i >= 0 ? (this._drawId = i, this.parent.drawLayer.finalizeDraw(i, e.defaultProperties)) : this._drawId = b(this, pt, jp).call(this, e, this.parent), b(this, pt, Uh).call(this, e.box);
}, jp = function(e, i) {
  const {
    id: s
  } = i.drawLayer.draw(G._mergeSVGProperties(this._drawingOptions.toSVGProperties(), e.defaultSVGProperties), !1, !1);
  return s;
}, qp = function() {
  this._drawId === null || !this.parent || (this.parent.drawLayer.remove(this._drawId), this._drawId = null, this._drawingOptions.reset());
}, Hh = function(e = this.parent) {
  if (!(this._drawId !== null && this.parent === e)) {
    if (this._drawId !== null) {
      this.parent.drawLayer.updateParent(this._drawId, e.drawLayer);
      return;
    }
    this._drawingOptions.updateAll(), this._drawId = b(this, pt, jp).call(this, n(this, Ii), e);
  }
}, y0 = function([e, i, s, r]) {
  const {
    parentDimensions: [a, o],
    rotation: l
  } = this;
  switch (l) {
    case 90:
      return [i, 1 - e, s * (o / a), r * (a / o)];
    case 180:
      return [1 - e, 1 - i, s, r];
    case 270:
      return [1 - i, e, s * (o / a), r * (a / o)];
    default:
      return [e, i, s, r];
  }
}, Cu = function() {
  const {
    x: e,
    y: i,
    width: s,
    height: r,
    parentDimensions: [a, o],
    rotation: l
  } = this;
  switch (l) {
    case 90:
      return [1 - i, e, s * (a / o), r * (o / a)];
    case 180:
      return [1 - e, 1 - i, s, r];
    case 270:
      return [i, 1 - e, s * (a / o), r * (o / a)];
    default:
      return [e, i, s, r];
  }
}, Uh = function(e) {
  [this.x, this.y, this.width, this.height] = b(this, pt, y0).call(this, e), this.div && (this.fixAndSetPosition(), this.setDims()), this._onResized();
}, ko = function() {
  const {
    x: e,
    y: i,
    width: s,
    height: r,
    rotation: a,
    parentRotation: o,
    parentDimensions: [l, h]
  } = this;
  switch ((a * 4 + o) / 90) {
    case 1:
      return [1 - i - r, e, r, s];
    case 2:
      return [1 - e - s, 1 - i - r, s, r];
    case 3:
      return [i, 1 - e - s, r, s];
    case 4:
      return [e, i - s * (l / h), r * (h / l), s * (l / h)];
    case 5:
      return [1 - i, e, s * (l / h), r * (h / l)];
    case 6:
      return [1 - e - r * (h / l), 1 - i, r * (h / l), s * (l / h)];
    case 7:
      return [i - s * (l / h), 1 - e - r * (h / l), s * (l / h), r * (h / l)];
    case 8:
      return [e - s, i - r, s, r];
    case 9:
      return [1 - i, e - s, r, s];
    case 10:
      return [1 - e, 1 - i, s, r];
    case 11:
      return [i - r, 1 - e, r, s];
    case 12:
      return [e - r * (h / l), i, r * (h / l), s * (l / h)];
    case 13:
      return [1 - i - s * (l / h), e - r * (h / l), s * (l / h), r * (h / l)];
    case 14:
      return [1 - e, 1 - i - s * (l / h), r * (h / l), s * (l / h)];
    case 15:
      return [i, 1 - e, s * (l / h), r * (h / l)];
    default:
      return [e, i, s, r];
  }
}, M(G, "_currentDrawId", -1), M(G, "_currentParent", null), g(G, ye, null), g(G, no, null), g(G, ro, null), g(G, Dr, NaN), g(G, Ir, null), g(G, Fr, null), g(G, ao, NaN), M(G, "_INNER_MARGIN", 3);
let zu = G;
var js, Ae, we, oo, eh, Qe, Me, is, lo, ho, co, ih, Tu;
class zA {
  constructor(t, e, i, s, r, a) {
    g(this, ih);
    g(this, js, new Float64Array(6));
    g(this, Ae);
    g(this, we);
    g(this, oo);
    g(this, eh);
    g(this, Qe);
    g(this, Me, "");
    g(this, is, 0);
    g(this, lo, new Hd());
    g(this, ho);
    g(this, co);
    p(this, ho, i), p(this, co, s), p(this, oo, r), p(this, eh, a), [t, e] = b(this, ih, Tu).call(this, t, e);
    const o = p(this, Ae, [NaN, NaN, NaN, NaN, t, e]);
    p(this, Qe, [t, e]), p(this, we, [{
      line: o,
      points: n(this, Qe)
    }]), n(this, js).set(o, 0);
  }
  updateProperty(t, e) {
    t === "stroke-width" && p(this, eh, e);
  }
  isEmpty() {
    return !n(this, we) || n(this, we).length === 0;
  }
  isCancellable() {
    return n(this, Qe).length <= 10;
  }
  add(t, e) {
    [t, e] = b(this, ih, Tu).call(this, t, e);
    const [i, s, r, a] = n(this, js).subarray(2, 6), o = t - r, l = e - a;
    return Math.hypot(n(this, ho) * o, n(this, co) * l) <= 2 ? null : (n(this, Qe).push(t, e), isNaN(i) ? (n(this, js).set([r, a, t, e], 2), n(this, Ae).push(NaN, NaN, NaN, NaN, t, e), {
      path: {
        d: this.toSVGPath()
      }
    }) : (isNaN(n(this, js)[0]) && n(this, Ae).splice(6, 6), n(this, js).set([i, s, r, a, t, e], 0), n(this, Ae).push(...V.createBezierPoints(i, s, r, a, t, e)), {
      path: {
        d: this.toSVGPath()
      }
    }));
  }
  end(t, e) {
    const i = this.add(t, e);
    return i || (n(this, Qe).length === 2 ? {
      path: {
        d: this.toSVGPath()
      }
    } : null);
  }
  startNew(t, e, i, s, r) {
    p(this, ho, i), p(this, co, s), p(this, oo, r), [t, e] = b(this, ih, Tu).call(this, t, e);
    const a = p(this, Ae, [NaN, NaN, NaN, NaN, t, e]);
    p(this, Qe, [t, e]);
    const o = n(this, we).at(-1);
    return o && (o.line = new Float32Array(o.line), o.points = new Float32Array(o.points)), n(this, we).push({
      line: a,
      points: n(this, Qe)
    }), n(this, js).set(a, 0), p(this, is, 0), this.toSVGPath(), null;
  }
  getLastElement() {
    return n(this, we).at(-1);
  }
  setLastElement(t) {
    return n(this, we) ? (n(this, we).push(t), p(this, Ae, t.line), p(this, Qe, t.points), p(this, is, 0), {
      path: {
        d: this.toSVGPath()
      }
    }) : n(this, lo).setLastElement(t);
  }
  removeLastElement() {
    if (!n(this, we))
      return n(this, lo).removeLastElement();
    n(this, we).pop(), p(this, Me, "");
    for (let t = 0, e = n(this, we).length; t < e; t++) {
      const {
        line: i,
        points: s
      } = n(this, we)[t];
      p(this, Ae, i), p(this, Qe, s), p(this, is, 0), this.toSVGPath();
    }
    return {
      path: {
        d: n(this, Me)
      }
    };
  }
  toSVGPath() {
    const t = V.svgRound(n(this, Ae)[4]), e = V.svgRound(n(this, Ae)[5]);
    if (n(this, Qe).length === 2)
      return p(this, Me, `${n(this, Me)} M ${t} ${e} Z`), n(this, Me);
    if (n(this, Qe).length <= 6) {
      const s = n(this, Me).lastIndexOf("M");
      p(this, Me, `${n(this, Me).slice(0, s)} M ${t} ${e}`), p(this, is, 6);
    }
    if (n(this, Qe).length === 4) {
      const s = V.svgRound(n(this, Ae)[10]), r = V.svgRound(n(this, Ae)[11]);
      return p(this, Me, `${n(this, Me)} L ${s} ${r}`), p(this, is, 12), n(this, Me);
    }
    const i = [];
    n(this, is) === 0 && (i.push(`M ${t} ${e}`), p(this, is, 6));
    for (let s = n(this, is), r = n(this, Ae).length; s < r; s += 6) {
      const [a, o, l, h, c, u] = n(this, Ae).slice(s, s + 6).map(V.svgRound);
      i.push(`C${a} ${o} ${l} ${h} ${c} ${u}`);
    }
    return p(this, Me, n(this, Me) + i.join(" ")), p(this, is, n(this, Ae).length), n(this, Me);
  }
  getOutlines(t, e, i, s) {
    const r = n(this, we).at(-1);
    return r.line = new Float32Array(r.line), r.points = new Float32Array(r.points), n(this, lo).build(n(this, we), t, e, i, n(this, oo), n(this, eh), s), p(this, js, null), p(this, Ae, null), p(this, we, null), p(this, Me, null), n(this, lo);
  }
  get defaultSVGProperties() {
    return {
      root: {
        viewBox: "0 0 10000 10000"
      },
      rootClass: {
        draw: !0
      },
      bbox: [0, 0, 1, 1]
    };
  }
}
js = new WeakMap(), Ae = new WeakMap(), we = new WeakMap(), oo = new WeakMap(), eh = new WeakMap(), Qe = new WeakMap(), Me = new WeakMap(), is = new WeakMap(), lo = new WeakMap(), ho = new WeakMap(), co = new WeakMap(), ih = new WeakSet(), Tu = function(t, e) {
  return V._normalizePoint(t, e, n(this, ho), n(this, co), n(this, oo));
};
var ti, kd, Rd, Fi, qs, Xs, sh, nh, uo, Ie, rn, A0, w0, v0;
class Hd extends V {
  constructor() {
    super(...arguments);
    g(this, Ie);
    g(this, ti);
    g(this, kd, 0);
    g(this, Rd);
    g(this, Fi);
    g(this, qs);
    g(this, Xs);
    g(this, sh);
    g(this, nh);
    g(this, uo);
  }
  build(e, i, s, r, a, o, l) {
    p(this, qs, i), p(this, Xs, s), p(this, sh, r), p(this, nh, a), p(this, uo, o), p(this, Rd, l ?? 0), p(this, Fi, e), b(this, Ie, w0).call(this);
  }
  get thickness() {
    return n(this, uo);
  }
  setLastElement(e) {
    return n(this, Fi).push(e), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  removeLastElement() {
    return n(this, Fi).pop(), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  toSVGPath() {
    const e = [];
    for (const {
      line: i
    } of n(this, Fi)) {
      if (e.push(`M${V.svgRound(i[4])} ${V.svgRound(i[5])}`), i.length === 6) {
        e.push("Z");
        continue;
      }
      if (i.length === 12 && isNaN(i[6])) {
        e.push(`L${V.svgRound(i[10])} ${V.svgRound(i[11])}`);
        continue;
      }
      for (let s = 6, r = i.length; s < r; s += 6) {
        const [a, o, l, h, c, u] = i.subarray(s, s + 6).map(V.svgRound);
        e.push(`C${a} ${o} ${l} ${h} ${c} ${u}`);
      }
    }
    return e.join("");
  }
  serialize([e, i, s, r], a) {
    const o = [], l = [], [h, c, u, f] = b(this, Ie, A0).call(this);
    let m, A, y, v, w, S, E, _, x;
    switch (n(this, nh)) {
      case 0:
        x = V._rescale, m = e, A = i + r, y = s, v = -r, w = e + h * s, S = i + (1 - c - f) * r, E = e + (h + u) * s, _ = i + (1 - c) * r;
        break;
      case 90:
        x = V._rescaleAndSwap, m = e, A = i, y = s, v = r, w = e + c * s, S = i + h * r, E = e + (c + f) * s, _ = i + (h + u) * r;
        break;
      case 180:
        x = V._rescale, m = e + s, A = i, y = -s, v = r, w = e + (1 - h - u) * s, S = i + c * r, E = e + (1 - h) * s, _ = i + (c + f) * r;
        break;
      case 270:
        x = V._rescaleAndSwap, m = e + s, A = i + r, y = -s, v = -r, w = e + (1 - c - f) * s, S = i + (1 - h - u) * r, E = e + (1 - c) * s, _ = i + (1 - h) * r;
        break;
    }
    for (const {
      line: C,
      points: T
    } of n(this, Fi))
      o.push(x(C, m, A, y, v, a ? new Array(C.length) : null)), l.push(x(T, m, A, y, v, a ? new Array(T.length) : null));
    return {
      lines: o,
      points: l,
      rect: [w, S, E, _]
    };
  }
  static deserialize(e, i, s, r, a, {
    paths: {
      lines: o,
      points: l
    },
    rotation: h,
    thickness: c
  }) {
    const u = [];
    let f, m, A, y, v;
    switch (h) {
      case 0:
        v = V._rescale, f = -e / s, m = i / r + 1, A = 1 / s, y = -1 / r;
        break;
      case 90:
        v = V._rescaleAndSwap, f = -i / r, m = -e / s, A = 1 / r, y = 1 / s;
        break;
      case 180:
        v = V._rescale, f = e / s + 1, m = -i / r, A = -1 / s, y = 1 / r;
        break;
      case 270:
        v = V._rescaleAndSwap, f = i / r + 1, m = e / s + 1, A = -1 / r, y = -1 / s;
        break;
    }
    if (!o) {
      o = [];
      for (const S of l) {
        const E = S.length;
        if (E === 2) {
          o.push(new Float32Array([NaN, NaN, NaN, NaN, S[0], S[1]]));
          continue;
        }
        if (E === 4) {
          o.push(new Float32Array([NaN, NaN, NaN, NaN, S[0], S[1], NaN, NaN, NaN, NaN, S[2], S[3]]));
          continue;
        }
        const _ = new Float32Array(3 * (E - 2));
        o.push(_);
        let [x, C, T, L] = S.subarray(0, 4);
        _.set([NaN, NaN, NaN, NaN, x, C], 0);
        for (let k = 4; k < E; k += 2) {
          const D = S[k], R = S[k + 1];
          _.set(V.createBezierPoints(x, C, T, L, D, R), (k - 2) * 3), [x, C, T, L] = [T, L, D, R];
        }
      }
    }
    for (let S = 0, E = o.length; S < E; S++)
      u.push({
        line: v(o[S].map((_) => _ ?? NaN), f, m, A, y),
        points: v(l[S].map((_) => _ ?? NaN), f, m, A, y)
      });
    const w = new this.prototype.constructor();
    return w.build(u, s, r, 1, h, c, a), w;
  }
  get box() {
    return n(this, ti);
  }
  updateProperty(e, i) {
    return e === "stroke-width" ? b(this, Ie, v0).call(this, i) : null;
  }
  updateParentDimensions([e, i], s) {
    const [r, a] = b(this, Ie, rn).call(this);
    p(this, qs, e), p(this, Xs, i), p(this, sh, s);
    const [o, l] = b(this, Ie, rn).call(this), h = o - r, c = l - a, u = n(this, ti);
    return u[0] -= h, u[1] -= c, u[2] += 2 * h, u[3] += 2 * c, u;
  }
  updateRotation(e) {
    return p(this, kd, e), {
      path: {
        transform: this.rotationTransform
      }
    };
  }
  get viewBox() {
    return n(this, ti).map(V.svgRound).join(" ");
  }
  get defaultProperties() {
    const [e, i] = n(this, ti);
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${V.svgRound(e)} ${V.svgRound(i)}`
      }
    };
  }
  get rotationTransform() {
    const [, , e, i] = n(this, ti);
    let s = 0, r = 0, a = 0, o = 0, l = 0, h = 0;
    switch (n(this, kd)) {
      case 90:
        r = i / e, a = -e / i, l = e;
        break;
      case 180:
        s = -1, o = -1, l = e, h = i;
        break;
      case 270:
        r = -i / e, a = e / i, h = i;
        break;
      default:
        return "";
    }
    return `matrix(${s} ${r} ${a} ${o} ${V.svgRound(l)} ${V.svgRound(h)})`;
  }
  getPathResizingSVGProperties([e, i, s, r]) {
    const [a, o] = b(this, Ie, rn).call(this), [l, h, c, u] = n(this, ti);
    if (Math.abs(c - a) <= V.PRECISION || Math.abs(u - o) <= V.PRECISION) {
      const v = e + s / 2 - (l + c / 2), w = i + r / 2 - (h + u / 2);
      return {
        path: {
          "transform-origin": `${V.svgRound(e)} ${V.svgRound(i)}`,
          transform: `${this.rotationTransform} translate(${v} ${w})`
        }
      };
    }
    const f = (s - 2 * a) / (c - 2 * a), m = (r - 2 * o) / (u - 2 * o), A = c / s, y = u / r;
    return {
      path: {
        "transform-origin": `${V.svgRound(l)} ${V.svgRound(h)}`,
        transform: `${this.rotationTransform} scale(${A} ${y}) translate(${V.svgRound(a)} ${V.svgRound(o)}) scale(${f} ${m}) translate(${V.svgRound(-a)} ${V.svgRound(-o)})`
      }
    };
  }
  getPathResizedSVGProperties([e, i, s, r]) {
    const [a, o] = b(this, Ie, rn).call(this), l = n(this, ti), [h, c, u, f] = l;
    if (l[0] = e, l[1] = i, l[2] = s, l[3] = r, Math.abs(u - a) <= V.PRECISION || Math.abs(f - o) <= V.PRECISION) {
      const w = e + s / 2 - (h + u / 2), S = i + r / 2 - (c + f / 2);
      for (const {
        line: E,
        points: _
      } of n(this, Fi))
        V._translate(E, w, S, E), V._translate(_, w, S, _);
      return {
        root: {
          viewBox: this.viewBox
        },
        path: {
          "transform-origin": `${V.svgRound(e)} ${V.svgRound(i)}`,
          transform: this.rotationTransform || null,
          d: this.toSVGPath()
        }
      };
    }
    const m = (s - 2 * a) / (u - 2 * a), A = (r - 2 * o) / (f - 2 * o), y = -m * (h + a) + e + a, v = -A * (c + o) + i + o;
    if (m !== 1 || A !== 1 || y !== 0 || v !== 0)
      for (const {
        line: w,
        points: S
      } of n(this, Fi))
        V._rescale(w, y, v, m, A, w), V._rescale(S, y, v, m, A, S);
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${V.svgRound(e)} ${V.svgRound(i)}`,
        transform: this.rotationTransform || null,
        d: this.toSVGPath()
      }
    };
  }
  getPathTranslatedSVGProperties([e, i], s) {
    const [r, a] = s, o = n(this, ti), l = e - o[0], h = i - o[1];
    if (n(this, qs) === r && n(this, Xs) === a)
      for (const {
        line: c,
        points: u
      } of n(this, Fi))
        V._translate(c, l, h, c), V._translate(u, l, h, u);
    else {
      const c = n(this, qs) / r, u = n(this, Xs) / a;
      p(this, qs, r), p(this, Xs, a);
      for (const {
        line: f,
        points: m
      } of n(this, Fi))
        V._rescale(f, l, h, c, u, f), V._rescale(m, l, h, c, u, m);
      o[2] *= c, o[3] *= u;
    }
    return o[0] = e, o[1] = i, {
      root: {
        viewBox: this.viewBox
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${V.svgRound(e)} ${V.svgRound(i)}`
      }
    };
  }
  get defaultSVGProperties() {
    const e = n(this, ti);
    return {
      root: {
        viewBox: this.viewBox
      },
      rootClass: {
        draw: !0
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${V.svgRound(e[0])} ${V.svgRound(e[1])}`,
        transform: this.rotationTransform || null
      },
      bbox: e
    };
  }
}
ti = new WeakMap(), kd = new WeakMap(), Rd = new WeakMap(), Fi = new WeakMap(), qs = new WeakMap(), Xs = new WeakMap(), sh = new WeakMap(), nh = new WeakMap(), uo = new WeakMap(), Ie = new WeakSet(), rn = function(e = n(this, uo)) {
  const i = n(this, Rd) + e / 2 * n(this, sh);
  return n(this, nh) % 180 === 0 ? [i / n(this, qs), i / n(this, Xs)] : [i / n(this, Xs), i / n(this, qs)];
}, A0 = function() {
  const [e, i, s, r] = n(this, ti), [a, o] = b(this, Ie, rn).call(this, 0);
  return [e + a, i + o, s - 2 * a, r - 2 * o];
}, w0 = function() {
  const e = p(this, ti, new Float32Array([1 / 0, 1 / 0, -1 / 0, -1 / 0]));
  for (const {
    line: r
  } of n(this, Fi)) {
    if (r.length <= 12) {
      for (let l = 4, h = r.length; l < h; l += 6)
        z.pointBoundingBox(r[l], r[l + 1], e);
      continue;
    }
    let a = r[4], o = r[5];
    for (let l = 6, h = r.length; l < h; l += 6) {
      const [c, u, f, m, A, y] = r.subarray(l, l + 6);
      z.bezierBoundingBox(a, o, c, u, f, m, A, y, e), a = A, o = y;
    }
  }
  const [i, s] = b(this, Ie, rn).call(this);
  e[0] = We(e[0] - i, 0, 1), e[1] = We(e[1] - s, 0, 1), e[2] = We(e[2] + i, 0, 1), e[3] = We(e[3] + s, 0, 1), e[2] -= e[0], e[3] -= e[1];
}, v0 = function(e) {
  const [i, s] = b(this, Ie, rn).call(this);
  p(this, uo, e);
  const [r, a] = b(this, Ie, rn).call(this), [o, l] = [r - i, a - s], h = n(this, ti);
  return h[0] -= o, h[1] -= l, h[2] += 2 * o, h[3] += 2 * l, h;
};
class bf extends b0 {
  constructor(t) {
    super(), this._viewParameters = t, super.updateProperties({
      fill: "none",
      stroke: Ft._defaultLineColor,
      "stroke-opacity": 1,
      "stroke-width": 1,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-miterlimit": 10
    });
  }
  updateSVGProperty(t, e) {
    t === "stroke-width" && (e ?? (e = this["stroke-width"]), e *= this._viewParameters.realScale), super.updateSVGProperty(t, e);
  }
  clone() {
    const t = new bf(this._viewParameters);
    return t.updateAll(this), t;
  }
}
var cf, E0;
const Fo = class Fo extends zu {
  constructor(e) {
    super({
      ...e,
      name: "inkEditor"
    });
    g(this, cf);
    this._willKeepAspectRatio = !0, this.defaultL10nId = "pdfjs-editor-ink-editor";
  }
  static initialize(e, i) {
    Ft.initialize(e, i), this._defaultDrawingOptions = new bf(i.viewParameters);
  }
  static getDefaultDrawingOptions(e) {
    const i = this._defaultDrawingOptions.clone();
    return i.updateProperties(e), i;
  }
  static get supportMultipleDrawings() {
    return !0;
  }
  static get typesMap() {
    return st(this, "typesMap", /* @__PURE__ */ new Map([[ht.INK_THICKNESS, "stroke-width"], [ht.INK_COLOR, "stroke"], [ht.INK_OPACITY, "stroke-opacity"]]));
  }
  static createDrawerInstance(e, i, s, r, a) {
    return new zA(e, i, s, r, a, this._defaultDrawingOptions["stroke-width"]);
  }
  static deserializeDraw(e, i, s, r, a, o) {
    return Hd.deserialize(e, i, s, r, a, o);
  }
  static async deserialize(e, i, s) {
    let r = null;
    if (e instanceof Sg) {
      const {
        data: {
          inkLists: o,
          rect: l,
          rotation: h,
          id: c,
          color: u,
          opacity: f,
          borderStyle: {
            rawWidth: m
          },
          popupRef: A,
          richText: y,
          contentsObj: v,
          creationDate: w,
          modificationDate: S
        },
        parent: {
          page: {
            pageNumber: E
          }
        }
      } = e;
      r = e = {
        annotationType: Z.INK,
        color: Array.from(u),
        thickness: m,
        opacity: f,
        paths: {
          points: o
        },
        boxes: null,
        pageIndex: E - 1,
        rect: l.slice(0),
        rotation: h,
        annotationElementId: c,
        id: c,
        deleted: !1,
        popupRef: A,
        richText: y,
        comment: (v == null ? void 0 : v.str) || null,
        creationDate: w,
        modificationDate: S
      };
    }
    const a = await super.deserialize(e, i, s);
    return a._initialData = r, e.comment && a.setCommentData(e), a;
  }
  get toolbarButtons() {
    return this._colorPicker || (this._colorPicker = new Uu(this)), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return ht.INK_COLOR;
  }
  get color() {
    return this._drawingOptions.stroke;
  }
  get opacity() {
    return this._drawingOptions["stroke-opacity"];
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    super.onScaleChanging();
    const {
      _drawId: e,
      _drawingOptions: i,
      parent: s
    } = this;
    i.updateSVGProperty("stroke-width"), s.drawLayer.updateProperties(e, i.toSVGProperties());
  }
  static onScaleChangingWhenDrawing() {
    const e = this._currentParent;
    e && (super.onScaleChangingWhenDrawing(), this._defaultDrawingOptions.updateSVGProperty("stroke-width"), e.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  createDrawingOptions({
    color: e,
    thickness: i,
    opacity: s
  }) {
    this._drawingOptions = Fo.getDefaultDrawingOptions({
      stroke: z.makeHexColor(...e),
      "stroke-width": i,
      "stroke-opacity": s
    });
  }
  serialize(e = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const {
      lines: i,
      points: s
    } = this.serializeDraw(e), {
      _drawingOptions: {
        stroke: r,
        "stroke-opacity": a,
        "stroke-width": o
      }
    } = this, l = Object.assign(super.serialize(e), {
      color: Ft._colorManager.convert(r),
      opacity: a,
      thickness: o,
      paths: {
        lines: i,
        points: s
      }
    });
    return this.addComment(l), e ? (l.isCopy = !0, l) : this.annotationElementId && !b(this, cf, E0).call(this, l) ? null : (l.id = this.annotationElementId, l);
  }
  renderAnnotationElement(e) {
    if (this.deleted)
      return e.hide(), null;
    const {
      points: i,
      rect: s
    } = this.serializeDraw(!1);
    return e.updateEdited({
      rect: s,
      thickness: this._drawingOptions["stroke-width"],
      points: i,
      popup: this.comment
    }), null;
  }
};
cf = new WeakSet(), E0 = function(e) {
  const {
    color: i,
    thickness: s,
    opacity: r,
    pageIndex: a
  } = this._initialData;
  return this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized || e.color.some((o, l) => o !== i[l]) || e.thickness !== s || e.opacity !== r || e.pageIndex !== a;
}, M(Fo, "_type", "ink"), M(Fo, "_editorType", Z.INK), M(Fo, "_defaultDrawingOptions", null);
let Xp = Fo;
class Yp extends Hd {
  toSVGPath() {
    let t = super.toSVGPath();
    return t.endsWith("Z") || (t += "Z"), t;
  }
}
const eu = 8, vh = 3;
var fo, yt, Kp, As, S0, _0, Zp, Pu, x0, C0, T0, Jp, Qp, P0;
class Js {
  static extractContoursFromText(t, {
    fontFamily: e,
    fontStyle: i,
    fontWeight: s
  }, r, a, o, l) {
    let h = new OffscreenCanvas(1, 1), c = h.getContext("2d", {
      alpha: !1
    });
    const u = 200, f = c.font = `${i} ${s} ${u}px ${e}`, {
      actualBoundingBoxLeft: m,
      actualBoundingBoxRight: A,
      actualBoundingBoxAscent: y,
      actualBoundingBoxDescent: v,
      fontBoundingBoxAscent: w,
      fontBoundingBoxDescent: S,
      width: E
    } = c.measureText(t), _ = 1.5, x = Math.ceil(Math.max(Math.abs(m) + Math.abs(A) || 0, E) * _), C = Math.ceil(Math.max(Math.abs(y) + Math.abs(v) || u, Math.abs(w) + Math.abs(S) || u) * _);
    h = new OffscreenCanvas(x, C), c = h.getContext("2d", {
      alpha: !0,
      willReadFrequently: !0
    }), c.font = f, c.filter = "grayscale(1)", c.fillStyle = "white", c.fillRect(0, 0, x, C), c.fillStyle = "black", c.fillText(t, x * (_ - 1) / 2, C * (3 - _) / 2);
    const T = b(this, yt, Jp).call(this, c.getImageData(0, 0, x, C).data), L = b(this, yt, T0).call(this, T), k = b(this, yt, Qp).call(this, L), D = b(this, yt, Zp).call(this, T, x, C, k);
    return this.processDrawnLines({
      lines: {
        curves: D,
        width: x,
        height: C
      },
      pageWidth: r,
      pageHeight: a,
      rotation: o,
      innerMargin: l,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static process(t, e, i, s, r) {
    const [a, o, l] = b(this, yt, P0).call(this, t), [h, c] = b(this, yt, C0).call(this, a, o, l, Math.hypot(o, l) * n(this, fo).sigmaSFactor, n(this, fo).sigmaR, n(this, fo).kernelSize), u = b(this, yt, Qp).call(this, c), f = b(this, yt, Zp).call(this, h, o, l, u);
    return this.processDrawnLines({
      lines: {
        curves: f,
        width: o,
        height: l
      },
      pageWidth: e,
      pageHeight: i,
      rotation: s,
      innerMargin: r,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static processDrawnLines({
    lines: t,
    pageWidth: e,
    pageHeight: i,
    rotation: s,
    innerMargin: r,
    mustSmooth: a,
    areContours: o
  }) {
    s % 180 !== 0 && ([e, i] = [i, e]);
    const {
      curves: l,
      width: h,
      height: c
    } = t, u = t.thickness ?? 0, f = [], m = Math.min(e / h, i / c), A = m / e, y = m / i, v = [];
    for (const {
      points: S
    } of l) {
      const E = a ? b(this, yt, x0).call(this, S) : S;
      if (!E)
        continue;
      v.push(E);
      const _ = E.length, x = new Float32Array(_), C = new Float32Array(3 * (_ === 2 ? 2 : _ - 2));
      if (f.push({
        line: C,
        points: x
      }), _ === 2) {
        x[0] = E[0] * A, x[1] = E[1] * y, C.set([NaN, NaN, NaN, NaN, x[0], x[1]], 0);
        continue;
      }
      let [T, L, k, D] = E;
      T *= A, L *= y, k *= A, D *= y, x.set([T, L, k, D], 0), C.set([NaN, NaN, NaN, NaN, T, L], 0);
      for (let R = 4; R < _; R += 2) {
        const N = x[R] = E[R] * A, q = x[R + 1] = E[R + 1] * y;
        C.set(V.createBezierPoints(T, L, k, D, N, q), (R - 2) * 3), [T, L, k, D] = [k, D, N, q];
      }
    }
    if (f.length === 0)
      return null;
    const w = o ? new Yp() : new Hd();
    return w.build(f, e, i, 1, s, o ? 0 : u, r), {
      outline: w,
      newCurves: v,
      areContours: o,
      thickness: u,
      width: h,
      height: c
    };
  }
  static async compressSignature({
    outlines: t,
    areContours: e,
    thickness: i,
    width: s,
    height: r
  }) {
    let a = 1 / 0, o = -1 / 0, l = 0;
    for (const E of t) {
      l += E.length;
      for (let _ = 2, x = E.length; _ < x; _++) {
        const C = E[_] - E[_ - 2];
        a = Math.min(a, C), o = Math.max(o, C);
      }
    }
    let h;
    a >= -128 && o <= 127 ? h = Int8Array : a >= -32768 && o <= 32767 ? h = Int16Array : h = Int32Array;
    const c = t.length, u = eu + vh * c, f = new Uint32Array(u);
    let m = 0;
    f[m++] = u * Uint32Array.BYTES_PER_ELEMENT + (l - 2 * c) * h.BYTES_PER_ELEMENT, f[m++] = 0, f[m++] = s, f[m++] = r, f[m++] = e ? 0 : 1, f[m++] = Math.max(0, Math.floor(i ?? 0)), f[m++] = c, f[m++] = h.BYTES_PER_ELEMENT;
    for (const E of t)
      f[m++] = E.length - 2, f[m++] = E[0], f[m++] = E[1];
    const A = new CompressionStream("deflate-raw"), y = A.writable.getWriter();
    await y.ready, y.write(f);
    const v = h.prototype.constructor;
    for (const E of t) {
      const _ = new v(E.length - 2);
      for (let x = 2, C = E.length; x < C; x++)
        _[x - 2] = E[x] - E[x - 2];
      y.write(_);
    }
    y.close();
    const w = await new Response(A.readable).arrayBuffer(), S = new Uint8Array(w);
    return xm(S);
  }
  static async decompressSignature(t) {
    try {
      const e = py(t), {
        readable: i,
        writable: s
      } = new DecompressionStream("deflate-raw"), r = s.getWriter();
      await r.ready, r.write(e).then(async () => {
        await r.ready, await r.close();
      }).catch(() => {
      });
      let a = null, o = 0;
      for await (const E of i)
        a || (a = new Uint8Array(new Uint32Array(E.buffer, 0, 4)[0])), a.set(E, o), o += E.length;
      const l = new Uint32Array(a.buffer, 0, a.length >> 2), h = l[1];
      if (h !== 0)
        throw new Error(`Invalid version: ${h}`);
      const c = l[2], u = l[3], f = l[4] === 0, m = l[5], A = l[6], y = l[7], v = [], w = (eu + vh * A) * Uint32Array.BYTES_PER_ELEMENT;
      let S;
      switch (y) {
        case Int8Array.BYTES_PER_ELEMENT:
          S = new Int8Array(a.buffer, w);
          break;
        case Int16Array.BYTES_PER_ELEMENT:
          S = new Int16Array(a.buffer, w);
          break;
        case Int32Array.BYTES_PER_ELEMENT:
          S = new Int32Array(a.buffer, w);
          break;
      }
      o = 0;
      for (let E = 0; E < A; E++) {
        const _ = l[vh * E + eu], x = new Float32Array(_ + 2);
        v.push(x);
        for (let C = 0; C < vh - 1; C++)
          x[C] = l[vh * E + eu + C + 1];
        for (let C = 0; C < _; C++)
          x[C + 2] = x[C] + S[o++];
      }
      return {
        areContours: f,
        thickness: m,
        outlines: v,
        width: c,
        height: u
      };
    } catch (e) {
      return J(`decompressSignature: ${e}`), null;
    }
  }
}
fo = new WeakMap(), yt = new WeakSet(), Kp = function(t, e, i, s) {
  return i -= t, s -= e, i === 0 ? s > 0 ? 0 : 4 : i === 1 ? s + 6 : 2 - s;
}, As = new WeakMap(), S0 = function(t, e, i, s, r, a, o) {
  const l = b(this, yt, Kp).call(this, i, s, r, a);
  for (let h = 0; h < 8; h++) {
    const c = (-h + l - o + 16) % 8, u = n(this, As)[2 * c], f = n(this, As)[2 * c + 1];
    if (t[(i + u) * e + (s + f)] !== 0)
      return c;
  }
  return -1;
}, _0 = function(t, e, i, s, r, a, o) {
  const l = b(this, yt, Kp).call(this, i, s, r, a);
  for (let h = 0; h < 8; h++) {
    const c = (h + l + o + 16) % 8, u = n(this, As)[2 * c], f = n(this, As)[2 * c + 1];
    if (t[(i + u) * e + (s + f)] !== 0)
      return c;
  }
  return -1;
}, Zp = function(t, e, i, s) {
  const r = t.length, a = new Int32Array(r);
  for (let c = 0; c < r; c++)
    a[c] = t[c] <= s ? 1 : 0;
  for (let c = 1; c < i - 1; c++)
    a[c * e] = a[c * e + e - 1] = 0;
  for (let c = 0; c < e; c++)
    a[c] = a[e * i - 1 - c] = 0;
  let o = 1, l;
  const h = [];
  for (let c = 1; c < i - 1; c++) {
    l = 1;
    for (let u = 1; u < e - 1; u++) {
      const f = c * e + u, m = a[f];
      if (m === 0)
        continue;
      let A = c, y = u;
      if (m === 1 && a[f - 1] === 0)
        o += 1, y -= 1;
      else if (m >= 1 && a[f + 1] === 0)
        o += 1, y += 1, m > 1 && (l = m);
      else {
        m !== 1 && (l = Math.abs(m));
        continue;
      }
      const v = [u, c], w = y === u + 1, S = {
        isHole: w,
        points: v,
        id: o,
        parent: 0
      };
      h.push(S);
      let E;
      for (const R of h)
        if (R.id === l) {
          E = R;
          break;
        }
      E ? E.isHole ? S.parent = w ? E.parent : l : S.parent = w ? l : E.parent : S.parent = w ? l : 0;
      const _ = b(this, yt, S0).call(this, a, e, c, u, A, y, 0);
      if (_ === -1) {
        a[f] = -o, a[f] !== 1 && (l = Math.abs(a[f]));
        continue;
      }
      let x = n(this, As)[2 * _], C = n(this, As)[2 * _ + 1];
      const T = c + x, L = u + C;
      A = T, y = L;
      let k = c, D = u;
      for (; ; ) {
        const R = b(this, yt, _0).call(this, a, e, k, D, A, y, 1);
        x = n(this, As)[2 * R], C = n(this, As)[2 * R + 1];
        const N = k + x, q = D + C;
        v.push(q, N);
        const B = k * e + D;
        if (a[B + 1] === 0 ? a[B] = -o : a[B] === 1 && (a[B] = o), N === c && q === u && k === T && D === L) {
          a[f] !== 1 && (l = Math.abs(a[f]));
          break;
        } else
          A = k, y = D, k = N, D = q;
      }
    }
  }
  return h;
}, Pu = function(t, e, i, s) {
  if (i - e <= 4) {
    for (let T = e; T < i - 2; T += 2)
      s.push(t[T], t[T + 1]);
    return;
  }
  const r = t[e], a = t[e + 1], o = t[i - 4] - r, l = t[i - 3] - a, h = Math.hypot(o, l), c = o / h, u = l / h, f = c * a - u * r, m = l / o, A = 1 / h, y = Math.atan(m), v = Math.cos(y), w = Math.sin(y), S = A * (Math.abs(v) + Math.abs(w)), E = A * (1 - S + S ** 2), _ = Math.max(Math.atan(Math.abs(w + v) * E), Math.atan(Math.abs(w - v) * E));
  let x = 0, C = e;
  for (let T = e + 2; T < i - 2; T += 2) {
    const L = Math.abs(f - c * t[T + 1] + u * t[T]);
    L > x && (C = T, x = L);
  }
  x > (h * _) ** 2 ? (b(this, yt, Pu).call(this, t, e, C + 2, s), b(this, yt, Pu).call(this, t, C, i, s)) : s.push(r, a);
}, x0 = function(t) {
  const e = [], i = t.length;
  return b(this, yt, Pu).call(this, t, 0, i, e), e.push(t[i - 2], t[i - 1]), e.length <= 4 ? null : e;
}, C0 = function(t, e, i, s, r, a) {
  const o = new Float32Array(a ** 2), l = -2 * s ** 2, h = a >> 1;
  for (let y = 0; y < a; y++) {
    const v = (y - h) ** 2;
    for (let w = 0; w < a; w++)
      o[y * a + w] = Math.exp((v + (w - h) ** 2) / l);
  }
  const c = new Float32Array(256), u = -2 * r ** 2;
  for (let y = 0; y < 256; y++)
    c[y] = Math.exp(y ** 2 / u);
  const f = t.length, m = new Uint8Array(f), A = new Uint32Array(256);
  for (let y = 0; y < i; y++)
    for (let v = 0; v < e; v++) {
      const w = y * e + v, S = t[w];
      let E = 0, _ = 0;
      for (let C = 0; C < a; C++) {
        const T = y + C - h;
        if (!(T < 0 || T >= i))
          for (let L = 0; L < a; L++) {
            const k = v + L - h;
            if (k < 0 || k >= e)
              continue;
            const D = t[T * e + k], R = o[C * a + L] * c[Math.abs(D - S)];
            E += D * R, _ += R;
          }
      }
      const x = m[w] = Math.round(E / _);
      A[x]++;
    }
  return [m, A];
}, T0 = function(t) {
  const e = new Uint32Array(256);
  for (const i of t)
    e[i]++;
  return e;
}, Jp = function(t) {
  const e = t.length, i = new Uint8ClampedArray(e >> 2);
  let s = -1 / 0, r = 1 / 0;
  for (let o = 0, l = i.length; o < l; o++) {
    const h = i[o] = t[o << 2];
    s = Math.max(s, h), r = Math.min(r, h);
  }
  const a = 255 / (s - r);
  for (let o = 0, l = i.length; o < l; o++)
    i[o] = (i[o] - r) * a;
  return i;
}, Qp = function(t) {
  let e, i = -1 / 0, s = -1 / 0;
  const r = t.findIndex((l) => l !== 0);
  let a = r, o = r;
  for (e = r; e < 256; e++) {
    const l = t[e];
    l > i && (e - a > s && (s = e - a, o = e - 1), i = l, a = e);
  }
  for (e = o - 1; e >= 0 && !(t[e] > t[e + 1]); e--)
    ;
  return e;
}, P0 = function(t) {
  const e = t, {
    width: i,
    height: s
  } = t, {
    maxDim: r
  } = n(this, fo);
  let a = i, o = s;
  if (i > r || s > r) {
    let f = i, m = s, A = Math.log2(Math.max(i, s) / r);
    const y = Math.floor(A);
    A = A === y ? y - 1 : y;
    for (let w = 0; w < A; w++) {
      a = Math.ceil(f / 2), o = Math.ceil(m / 2);
      const S = new OffscreenCanvas(a, o);
      S.getContext("2d").drawImage(t, 0, 0, f, m, 0, 0, a, o), f = a, m = o, t !== e && t.close(), t = S.transferToImageBitmap();
    }
    const v = Math.min(r / a, r / o);
    a = Math.round(a * v), o = Math.round(o * v);
  }
  const h = new OffscreenCanvas(a, o).getContext("2d", {
    willReadFrequently: !0
  });
  h.fillStyle = "white", h.fillRect(0, 0, a, o), h.filter = "grayscale(1)", h.drawImage(t, 0, 0, t.width, t.height, 0, 0, a, o);
  const c = h.getImageData(0, 0, a, o).data;
  return [b(this, yt, Jp).call(this, c), a, o];
}, g(Js, yt), g(Js, fo, {
  maxDim: 512,
  sigmaSFactor: 0.02,
  sigmaR: 25,
  kernelSize: 16
}), g(Js, As, new Int32Array([0, 1, -1, 1, -1, 0, -1, -1, 0, -1, 1, -1, 1, 0, 1, 1]));
class xg extends b0 {
  constructor() {
    super(), super.updateProperties({
      fill: Ft._defaultLineColor,
      "stroke-width": 0
    });
  }
  clone() {
    const t = new xg();
    return t.updateAll(this), t;
  }
}
class Cg extends bf {
  constructor(t) {
    super(t), super.updateProperties({
      stroke: Ft._defaultLineColor,
      "stroke-width": 1
    });
  }
  clone() {
    const t = new Cg(this._viewParameters);
    return t.updateAll(this), t;
  }
}
var Nr, Ys, Or, po;
const Ai = class Ai extends zu {
  constructor(e) {
    super({
      ...e,
      mustBeCommitted: !0,
      name: "signatureEditor"
    });
    g(this, Nr, !1);
    g(this, Ys, null);
    g(this, Or, null);
    g(this, po, null);
    this._willKeepAspectRatio = !0, p(this, Or, e.signatureData || null), p(this, Ys, null), this.defaultL10nId = "pdfjs-editor-signature-editor1";
  }
  static initialize(e, i) {
    Ft.initialize(e, i), this._defaultDrawingOptions = new xg(), this._defaultDrawnSignatureOptions = new Cg(i.viewParameters);
  }
  static getDefaultDrawingOptions(e) {
    const i = this._defaultDrawingOptions.clone();
    return i.updateProperties(e), i;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  static get typesMap() {
    return st(this, "typesMap", /* @__PURE__ */ new Map());
  }
  static get isDrawer() {
    return !1;
  }
  get telemetryFinalData() {
    return {
      type: "signature",
      hasDescription: !!n(this, Ys)
    };
  }
  static computeTelemetryFinalData(e) {
    const i = e.get("hasDescription");
    return {
      hasAltText: i.get(!0) ?? 0,
      hasNoAltText: i.get(!1) ?? 0
    };
  }
  get isResizable() {
    return !0;
  }
  onScaleChanging() {
    this._drawId !== null && super.onScaleChanging();
  }
  render() {
    if (this.div)
      return this.div;
    let e, i;
    const {
      _isCopy: s
    } = this;
    if (s && (this._isCopy = !1, e = this.x, i = this.y), super.render(), this._drawId === null)
      if (n(this, Or)) {
        const {
          lines: r,
          mustSmooth: a,
          areContours: o,
          description: l,
          uuid: h,
          heightInPage: c
        } = n(this, Or), {
          rawDims: {
            pageWidth: u,
            pageHeight: f
          },
          rotation: m
        } = this.parent.viewport, A = Js.processDrawnLines({
          lines: r,
          pageWidth: u,
          pageHeight: f,
          rotation: m,
          innerMargin: Ai._INNER_MARGIN,
          mustSmooth: a,
          areContours: o
        });
        this.addSignature(A, c, l, h);
      } else
        this.div.setAttribute("data-l10n-args", JSON.stringify({
          description: ""
        })), this.div.hidden = !0, this._uiManager.getSignature(this);
    else
      this.div.setAttribute("data-l10n-args", JSON.stringify({
        description: n(this, Ys) || ""
      }));
    return s && (this._isCopy = !0, this._moveAfterPaste(e, i)), this.div;
  }
  setUuid(e) {
    p(this, po, e), this.addEditToolbar();
  }
  getUuid() {
    return n(this, po);
  }
  get description() {
    return n(this, Ys);
  }
  set description(e) {
    p(this, Ys, e), this.div && (this.div.setAttribute("data-l10n-args", JSON.stringify({
      description: e
    })), super.addEditToolbar().then((i) => {
      i == null || i.updateEditSignatureButton(e);
    }));
  }
  getSignaturePreview() {
    const {
      newCurves: e,
      areContours: i,
      thickness: s,
      width: r,
      height: a
    } = n(this, Or), o = Math.max(r, a), l = Js.processDrawnLines({
      lines: {
        curves: e.map((h) => ({
          points: h
        })),
        thickness: s,
        width: r,
        height: a
      },
      pageWidth: o,
      pageHeight: o,
      rotation: 0,
      innerMargin: 0,
      mustSmooth: !1,
      areContours: i
    });
    return {
      areContours: i,
      outline: l.outline
    };
  }
  get toolbarButtons() {
    return this._uiManager.signatureManager ? [["editSignature", this._uiManager.signatureManager]] : super.toolbarButtons;
  }
  addSignature(e, i, s, r) {
    const {
      x: a,
      y: o
    } = this, {
      outline: l
    } = p(this, Or, e);
    p(this, Nr, l instanceof Yp), this.description = s;
    let h;
    n(this, Nr) ? h = Ai.getDefaultDrawingOptions() : (h = Ai._defaultDrawnSignatureOptions.clone(), h.updateProperties({
      "stroke-width": l.thickness
    })), this._addOutlines({
      drawOutlines: l,
      drawingOptions: h
    });
    const [, c] = this.pageDimensions;
    let u = i / c;
    u = u >= 1 ? 0.5 : u, this.width *= u / this.height, this.width >= 1 && (u *= 0.9 / this.width, this.width = 0.9), this.height = u, this.setDims(), this.x = a, this.y = o, this.center(), this._onResized(), this.onScaleChanging(), this.rotate(), this._uiManager.addToAnnotationStorage(this), this.setUuid(r), this._reportTelemetry({
      action: "pdfjs.signature.inserted",
      data: {
        hasBeenSaved: !!r,
        hasDescription: !!s
      }
    }), this.div.hidden = !1;
  }
  getFromImage(e) {
    const {
      rawDims: {
        pageWidth: i,
        pageHeight: s
      },
      rotation: r
    } = this.parent.viewport;
    return Js.process(e, i, s, r, Ai._INNER_MARGIN);
  }
  getFromText(e, i) {
    const {
      rawDims: {
        pageWidth: s,
        pageHeight: r
      },
      rotation: a
    } = this.parent.viewport;
    return Js.extractContoursFromText(e, i, s, r, a, Ai._INNER_MARGIN);
  }
  getDrawnSignature(e) {
    const {
      rawDims: {
        pageWidth: i,
        pageHeight: s
      },
      rotation: r
    } = this.parent.viewport;
    return Js.processDrawnLines({
      lines: e,
      pageWidth: i,
      pageHeight: s,
      rotation: r,
      innerMargin: Ai._INNER_MARGIN,
      mustSmooth: !1,
      areContours: !1
    });
  }
  createDrawingOptions({
    areContours: e,
    thickness: i
  }) {
    e ? this._drawingOptions = Ai.getDefaultDrawingOptions() : (this._drawingOptions = Ai._defaultDrawnSignatureOptions.clone(), this._drawingOptions.updateProperties({
      "stroke-width": i
    }));
  }
  serialize(e = !1) {
    if (this.isEmpty())
      return null;
    const {
      lines: i,
      points: s
    } = this.serializeDraw(e), {
      _drawingOptions: {
        "stroke-width": r
      }
    } = this, a = Object.assign(super.serialize(e), {
      isSignature: !0,
      areContours: n(this, Nr),
      color: [0, 0, 0],
      thickness: n(this, Nr) ? 0 : r
    });
    return this.addComment(a), e ? (a.paths = {
      lines: i,
      points: s
    }, a.uuid = n(this, po), a.isCopy = !0) : a.lines = i, n(this, Ys) && (a.accessibilityData = {
      type: "Figure",
      alt: n(this, Ys)
    }), a;
  }
  static deserializeDraw(e, i, s, r, a, o) {
    return o.areContours ? Yp.deserialize(e, i, s, r, a, o) : Hd.deserialize(e, i, s, r, a, o);
  }
  static async deserialize(e, i, s) {
    var a;
    const r = await super.deserialize(e, i, s);
    return p(r, Nr, e.areContours), r.description = ((a = e.accessibilityData) == null ? void 0 : a.alt) || "", p(r, po, e.uuid), r;
  }
};
Nr = new WeakMap(), Ys = new WeakMap(), Or = new WeakMap(), po = new WeakMap(), M(Ai, "_type", "signature"), M(Ai, "_editorType", Z.SIGNATURE), M(Ai, "_defaultDrawingOptions", null);
let tg = Ai;
var Ut, ve, Br, On, Hr, rh, Bn, go, Ks, Ni, ah, gt, $h, Vh, Lu, ku, Ru, ig, Mu, L0;
class eg extends Ft {
  constructor(e) {
    super({
      ...e,
      name: "stampEditor"
    });
    g(this, gt);
    g(this, Ut, null);
    g(this, ve, null);
    g(this, Br, null);
    g(this, On, null);
    g(this, Hr, null);
    g(this, rh, "");
    g(this, Bn, null);
    g(this, go, !1);
    g(this, Ks, null);
    g(this, Ni, !1);
    g(this, ah, !1);
    p(this, On, e.bitmapUrl), p(this, Hr, e.bitmapFile), this.defaultL10nId = "pdfjs-editor-stamp-editor";
  }
  static initialize(e, i) {
    Ft.initialize(e, i);
  }
  static isHandlingMimeForPasting(e) {
    return Fu.includes(e);
  }
  static paste(e, i) {
    i.pasteEditor({
      mode: Z.STAMP
    }, {
      bitmapFile: e.getAsFile()
    });
  }
  altTextFinish() {
    this._uiManager.useNewAltTextFlow && (this.div.hidden = !1), super.altTextFinish();
  }
  get telemetryFinalData() {
    var e;
    return {
      type: "stamp",
      hasAltText: !!((e = this.altTextData) != null && e.altText)
    };
  }
  static computeTelemetryFinalData(e) {
    const i = e.get("hasAltText");
    return {
      hasAltText: i.get(!0) ?? 0,
      hasNoAltText: i.get(!1) ?? 0
    };
  }
  async mlGuessAltText(e = null, i = !0) {
    if (this.hasAltTextData())
      return null;
    const {
      mlManager: s
    } = this._uiManager;
    if (!s)
      throw new Error("No ML.");
    if (!await s.isEnabledFor("altText"))
      throw new Error("ML isn't enabled for alt text.");
    const {
      data: r,
      width: a,
      height: o
    } = e || this.copyCanvas(null, null, !0).imageData, l = await s.guess({
      name: "altText",
      request: {
        data: r,
        width: a,
        height: o,
        channels: r.length / (a * o)
      }
    });
    if (!l)
      throw new Error("No response from the AI service.");
    if (l.error)
      throw new Error("Error from the AI service.");
    if (l.cancel)
      return null;
    if (!l.output)
      throw new Error("No valid response from the AI service.");
    const h = l.output;
    return await this.setGuessedAltText(h), i && !this.hasAltTextData() && (this.altTextData = {
      alt: h,
      decorative: !1
    }), h;
  }
  remove() {
    var e;
    n(this, ve) && (p(this, Ut, null), this._uiManager.imageManager.deleteId(n(this, ve)), (e = n(this, Bn)) == null || e.remove(), p(this, Bn, null), n(this, Ks) && (clearTimeout(n(this, Ks)), p(this, Ks, null))), super.remove();
  }
  rebuild() {
    if (!this.parent) {
      n(this, ve) && b(this, gt, Lu).call(this);
      return;
    }
    super.rebuild(), this.div !== null && (n(this, ve) && n(this, Bn) === null && b(this, gt, Lu).call(this), this.isAttachedToDOM || this.parent.add(this));
  }
  onceAdded(e) {
    this._isDraggable = !0, e && this.div.focus();
  }
  isEmpty() {
    return !(n(this, Br) || n(this, Ut) || n(this, On) || n(this, Hr) || n(this, ve) || n(this, go));
  }
  get toolbarButtons() {
    return [["altText", this.createAltText()]];
  }
  get isResizable() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let e, i;
    return this._isCopy && (e = this.x, i = this.y), super.render(), this.div.hidden = !0, this.createAltText(), n(this, go) || (n(this, Ut) ? b(this, gt, ku).call(this) : b(this, gt, Lu).call(this)), this._isCopy && this._moveAfterPaste(e, i), this._uiManager.addShouldRescale(this), this.div;
  }
  setCanvas(e, i) {
    const {
      id: s,
      bitmap: r
    } = this._uiManager.imageManager.getFromCanvas(e, i);
    i.remove(), s && this._uiManager.imageManager.isValidId(s) && (p(this, ve, s), r && p(this, Ut, r), p(this, go, !1), b(this, gt, ku).call(this));
  }
  _onResized() {
    this.onScaleChanging();
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    n(this, Ks) !== null && clearTimeout(n(this, Ks)), p(this, Ks, setTimeout(() => {
      p(this, Ks, null), b(this, gt, ig).call(this);
    }, 200));
  }
  copyCanvas(e, i, s = !1) {
    e || (e = 224);
    const {
      width: r,
      height: a
    } = n(this, Ut), o = new Ss();
    let l = n(this, Ut), h = r, c = a, u = null;
    if (i) {
      if (r > i || a > i) {
        const T = Math.min(i / r, i / a);
        h = Math.floor(r * T), c = Math.floor(a * T);
      }
      u = document.createElement("canvas");
      const m = u.width = Math.ceil(h * o.sx), A = u.height = Math.ceil(c * o.sy);
      n(this, Ni) || (l = b(this, gt, Ru).call(this, m, A));
      const y = u.getContext("2d");
      y.filter = this._uiManager.hcmFilter;
      let v = "white", w = "#cfcfd8";
      this._uiManager.hcmFilter !== "none" ? w = "black" : by.isDarkMode && (v = "#8f8f9d", w = "#42414d");
      const S = 15, E = S * o.sx, _ = S * o.sy, x = new OffscreenCanvas(E * 2, _ * 2), C = x.getContext("2d");
      C.fillStyle = v, C.fillRect(0, 0, E * 2, _ * 2), C.fillStyle = w, C.fillRect(0, 0, E, _), C.fillRect(E, _, E, _), y.fillStyle = y.createPattern(x, "repeat"), y.fillRect(0, 0, m, A), y.drawImage(l, 0, 0, l.width, l.height, 0, 0, m, A);
    }
    let f = null;
    if (s) {
      let m, A;
      if (o.symmetric && l.width < e && l.height < e)
        m = l.width, A = l.height;
      else if (l = n(this, Ut), r > e || a > e) {
        const w = Math.min(e / r, e / a);
        m = Math.floor(r * w), A = Math.floor(a * w), n(this, Ni) || (l = b(this, gt, Ru).call(this, m, A));
      }
      const v = new OffscreenCanvas(m, A).getContext("2d", {
        willReadFrequently: !0
      });
      v.drawImage(l, 0, 0, l.width, l.height, 0, 0, m, A), f = {
        width: m,
        height: A,
        data: v.getImageData(0, 0, m, A).data
      };
    }
    return {
      canvas: u,
      width: h,
      height: c,
      imageData: f
    };
  }
  static async deserialize(e, i, s) {
    var v;
    let r = null, a = !1;
    if (e instanceof Wb) {
      const {
        data: {
          rect: w,
          rotation: S,
          id: E,
          structParent: _,
          popupRef: x,
          richText: C,
          contentsObj: T,
          creationDate: L,
          modificationDate: k
        },
        container: D,
        parent: {
          page: {
            pageNumber: R
          }
        },
        canvas: N
      } = e;
      let q, B;
      N ? (delete e.canvas, {
        id: q,
        bitmap: B
      } = s.imageManager.getFromCanvas(D.id, N), N.remove()) : (a = !0, e._hasNoCanvas = !0);
      const Y = ((v = await i._structTree.getAriaAttributes(`${pg}${E}`)) == null ? void 0 : v.get("aria-label")) || "";
      r = e = {
        annotationType: Z.STAMP,
        bitmapId: q,
        bitmap: B,
        pageIndex: R - 1,
        rect: w.slice(0),
        rotation: S,
        annotationElementId: E,
        id: E,
        deleted: !1,
        accessibilityData: {
          decorative: !1,
          altText: Y
        },
        isSvg: !1,
        structParent: _,
        popupRef: x,
        richText: C,
        comment: (T == null ? void 0 : T.str) || null,
        creationDate: L,
        modificationDate: k
      };
    }
    const o = await super.deserialize(e, i, s), {
      rect: l,
      bitmap: h,
      bitmapUrl: c,
      bitmapId: u,
      isSvg: f,
      accessibilityData: m
    } = e;
    a ? (s.addMissingCanvas(e.id, o), p(o, go, !0)) : u && s.imageManager.isValidId(u) ? (p(o, ve, u), h && p(o, Ut, h)) : p(o, On, c), p(o, Ni, f);
    const [A, y] = o.pageDimensions;
    return o.width = (l[2] - l[0]) / A, o.height = (l[3] - l[1]) / y, m && (o.altTextData = m), o._initialData = r, e.comment && o.setCommentData(e), p(o, ah, !!r), o;
  }
  serialize(e = !1, i = null) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const s = Object.assign(super.serialize(e), {
      bitmapId: n(this, ve),
      isSvg: n(this, Ni)
    });
    if (this.addComment(s), e)
      return s.bitmapUrl = b(this, gt, Mu).call(this, !0), s.accessibilityData = this.serializeAltText(!0), s.isCopy = !0, s;
    const {
      decorative: r,
      altText: a
    } = this.serializeAltText(!1);
    if (!r && a && (s.accessibilityData = {
      type: "Figure",
      alt: a
    }), this.annotationElementId) {
      const l = b(this, gt, L0).call(this, s);
      return l.isSame ? null : (l.isSameAltText ? delete s.accessibilityData : s.accessibilityData.structParent = this._initialData.structParent ?? -1, s.id = this.annotationElementId, delete s.bitmapId, s);
    }
    if (i === null)
      return s;
    i.stamps || (i.stamps = /* @__PURE__ */ new Map());
    const o = n(this, Ni) ? (s.rect[2] - s.rect[0]) * (s.rect[3] - s.rect[1]) : null;
    if (!i.stamps.has(n(this, ve)))
      i.stamps.set(n(this, ve), {
        area: o,
        serialized: s
      }), s.bitmap = b(this, gt, Mu).call(this, !1);
    else if (n(this, Ni)) {
      const l = i.stamps.get(n(this, ve));
      o > l.area && (l.area = o, l.serialized.bitmap.close(), l.serialized.bitmap = b(this, gt, Mu).call(this, !1));
    }
    return s;
  }
  renderAnnotationElement(e) {
    return this.deleted ? (e.hide(), null) : (e.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
}
Ut = new WeakMap(), ve = new WeakMap(), Br = new WeakMap(), On = new WeakMap(), Hr = new WeakMap(), rh = new WeakMap(), Bn = new WeakMap(), go = new WeakMap(), Ks = new WeakMap(), Ni = new WeakMap(), ah = new WeakMap(), gt = new WeakSet(), $h = function(e, i = !1) {
  if (!e) {
    this.remove();
    return;
  }
  p(this, Ut, e.bitmap), i || (p(this, ve, e.id), p(this, Ni, e.isSvg)), e.file && p(this, rh, e.file.name), b(this, gt, ku).call(this);
}, Vh = function() {
  if (p(this, Br, null), this._uiManager.enableWaiting(!1), !!n(this, Bn)) {
    if (this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && n(this, Ut)) {
      this.addEditToolbar().then(() => {
        this._editToolbar.hide(), this._uiManager.editAltText(this, !0);
      });
      return;
    }
    if (!this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && n(this, Ut)) {
      this._reportTelemetry({
        action: "pdfjs.image.image_added",
        data: {
          alt_text_modal: !1,
          alt_text_type: "empty"
        }
      });
      try {
        this.mlGuessAltText();
      } catch {
      }
    }
    this.div.focus();
  }
}, Lu = function() {
  if (n(this, ve)) {
    this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(n(this, ve)).then((s) => b(this, gt, $h).call(this, s, !0)).finally(() => b(this, gt, Vh).call(this));
    return;
  }
  if (n(this, On)) {
    const s = n(this, On);
    p(this, On, null), this._uiManager.enableWaiting(!0), p(this, Br, this._uiManager.imageManager.getFromUrl(s).then((r) => b(this, gt, $h).call(this, r)).finally(() => b(this, gt, Vh).call(this)));
    return;
  }
  if (n(this, Hr)) {
    const s = n(this, Hr);
    p(this, Hr, null), this._uiManager.enableWaiting(!0), p(this, Br, this._uiManager.imageManager.getFromFile(s).then((r) => b(this, gt, $h).call(this, r)).finally(() => b(this, gt, Vh).call(this)));
    return;
  }
  const e = document.createElement("input");
  e.type = "file", e.accept = Fu.join(",");
  const i = this._uiManager._signal;
  p(this, Br, new Promise((s) => {
    e.addEventListener("change", async () => {
      if (!e.files || e.files.length === 0)
        this.remove();
      else {
        this._uiManager.enableWaiting(!0);
        const r = await this._uiManager.imageManager.getFromFile(e.files[0]);
        this._reportTelemetry({
          action: "pdfjs.image.image_selected",
          data: {
            alt_text_modal: this._uiManager.useNewAltTextFlow
          }
        }), b(this, gt, $h).call(this, r);
      }
      s();
    }, {
      signal: i
    }), e.addEventListener("cancel", () => {
      this.remove(), s();
    }, {
      signal: i
    });
  }).finally(() => b(this, gt, Vh).call(this))), e.click();
}, ku = function() {
  var h;
  const {
    div: e
  } = this;
  let {
    width: i,
    height: s
  } = n(this, Ut);
  const [r, a] = this.pageDimensions, o = 0.75;
  if (this.width)
    i = this.width * r, s = this.height * a;
  else if (i > o * r || s > o * a) {
    const c = Math.min(o * r / i, o * a / s);
    i *= c, s *= c;
  }
  this._uiManager.enableWaiting(!1);
  const l = p(this, Bn, document.createElement("canvas"));
  l.setAttribute("role", "img"), this.addContainer(l), this.width = i / r, this.height = s / a, this.setDims(), (h = this._initialOptions) != null && h.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, (!this._uiManager.useNewAltTextWhenAddingImage || !this._uiManager.useNewAltTextFlow || this.annotationElementId) && (e.hidden = !1), b(this, gt, ig).call(this), n(this, ah) || (this.parent.addUndoableEditor(this), p(this, ah, !0)), this._reportTelemetry({
    action: "inserted_image"
  }), n(this, rh) && this.div.setAttribute("aria-description", n(this, rh)), this.annotationElementId || this._uiManager.a11yAlert("pdfjs-editor-stamp-added-alert");
}, Ru = function(e, i) {
  const {
    width: s,
    height: r
  } = n(this, Ut);
  let a = s, o = r, l = n(this, Ut);
  for (; a > 2 * e || o > 2 * i; ) {
    const h = a, c = o;
    a > 2 * e && (a = a >= 16384 ? Math.floor(a / 2) - 1 : Math.ceil(a / 2)), o > 2 * i && (o = o >= 16384 ? Math.floor(o / 2) - 1 : Math.ceil(o / 2));
    const u = new OffscreenCanvas(a, o);
    u.getContext("2d").drawImage(l, 0, 0, h, c, 0, 0, a, o), l = u.transferToImageBitmap();
  }
  return l;
}, ig = function() {
  const [e, i] = this.parentDimensions, {
    width: s,
    height: r
  } = this, a = new Ss(), o = Math.ceil(s * e * a.sx), l = Math.ceil(r * i * a.sy), h = n(this, Bn);
  if (!h || h.width === o && h.height === l)
    return;
  h.width = o, h.height = l;
  const c = n(this, Ni) ? n(this, Ut) : b(this, gt, Ru).call(this, o, l), u = h.getContext("2d");
  u.filter = this._uiManager.hcmFilter, u.drawImage(c, 0, 0, c.width, c.height, 0, 0, o, l);
}, Mu = function(e) {
  if (e) {
    if (n(this, Ni)) {
      const r = this._uiManager.imageManager.getSvgUrl(n(this, ve));
      if (r)
        return r;
    }
    const i = document.createElement("canvas");
    return {
      width: i.width,
      height: i.height
    } = n(this, Ut), i.getContext("2d").drawImage(n(this, Ut), 0, 0), i.toDataURL();
  }
  if (n(this, Ni)) {
    const [i, s] = this.pageDimensions, r = Math.round(this.width * i * Wn.PDF_TO_CSS_UNITS), a = Math.round(this.height * s * Wn.PDF_TO_CSS_UNITS), o = new OffscreenCanvas(r, a);
    return o.getContext("2d").drawImage(n(this, Ut), 0, 0, n(this, Ut).width, n(this, Ut).height, 0, 0, r, a), o.transferToImageBitmap();
  }
  return structuredClone(n(this, Ut));
}, L0 = function(e) {
  var o;
  const {
    pageIndex: i,
    accessibilityData: {
      altText: s
    }
  } = this._initialData, r = e.pageIndex === i, a = (((o = e.accessibilityData) == null ? void 0 : o.alt) || "") === s;
  return {
    isSame: !this.hasEditedComment && !this._hasBeenMoved && !this._hasBeenResized && r && a,
    isSameAltText: a
  };
}, M(eg, "_type", "stamp"), M(eg, "_editorType", Z.STAMP);
var mo, oh, Ur, $r, Hn, gi, Vr, lh, hh, ws, Un, Ee, $n, zr, ch, j, Gr, Mt, sg, k0, Ts, ng, rg, Du;
const hs = class hs {
  constructor({
    uiManager: t,
    pageIndex: e,
    div: i,
    structTreeLayer: s,
    accessibilityManager: r,
    annotationLayer: a,
    drawLayer: o,
    textLayer: l,
    viewport: h,
    l10n: c
  }) {
    g(this, Mt);
    g(this, mo);
    g(this, oh, !1);
    g(this, Ur, null);
    g(this, $r, null);
    g(this, Hn, null);
    g(this, gi, /* @__PURE__ */ new Map());
    g(this, Vr, !1);
    g(this, lh, !1);
    g(this, hh, !1);
    g(this, ws, null);
    g(this, Un, null);
    g(this, Ee, null);
    g(this, $n, null);
    g(this, zr, null);
    g(this, ch, -1);
    g(this, j);
    const u = [...n(hs, Gr).values()];
    if (!hs._initialized) {
      hs._initialized = !0;
      for (const f of u)
        f.initialize(c, t);
    }
    t.registerEditorTypes(u), p(this, j, t), this.pageIndex = e, this.div = i, p(this, mo, r), p(this, Ur, a), this.viewport = h, p(this, Ee, l), this.drawLayer = o, this._structTree = s, n(this, j).addLayer(this);
  }
  get isEmpty() {
    return n(this, gi).size === 0;
  }
  get isInvisible() {
    return this.isEmpty && n(this, j).getMode() === Z.NONE;
  }
  updateToolbar(t) {
    n(this, j).updateToolbar(t);
  }
  updateMode(t = n(this, j).getMode()) {
    switch (b(this, Mt, Du).call(this), t) {
      case Z.NONE:
        this.div.classList.toggle("nonEditing", !0), this.disableTextSelection(), this.togglePointerEvents(!1), this.toggleAnnotationLayerPointerEvents(!0), this.disableClick();
        return;
      case Z.INK:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
        break;
      case Z.HIGHLIGHT:
        this.enableTextSelection(), this.togglePointerEvents(!1), this.disableClick();
        break;
      default:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
    }
    this.toggleAnnotationLayerPointerEvents(!1);
    const {
      classList: e
    } = this.div;
    if (e.toggle("nonEditing", !1), t === Z.POPUP)
      e.toggle("commentEditing", !0);
    else {
      e.toggle("commentEditing", !1);
      for (const i of n(hs, Gr).values())
        e.toggle(`${i._type}Editing`, t === i._editorType);
    }
    this.div.hidden = !1;
  }
  hasTextLayer(t) {
    var e;
    return t === ((e = n(this, Ee)) == null ? void 0 : e.div);
  }
  setEditingState(t) {
    n(this, j).setEditingState(t);
  }
  addCommands(t) {
    n(this, j).addCommands(t);
  }
  cleanUndoStack(t) {
    n(this, j).cleanUndoStack(t);
  }
  toggleDrawing(t = !1) {
    this.div.classList.toggle("drawing", !t);
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  toggleAnnotationLayerPointerEvents(t = !1) {
    var e;
    (e = n(this, Ur)) == null || e.div.classList.toggle("disabled", !t);
  }
  async enable() {
    var i;
    p(this, hh, !0), this.div.tabIndex = 0, this.togglePointerEvents(!0), this.div.classList.toggle("nonEditing", !1), (i = n(this, zr)) == null || i.abort(), p(this, zr, null);
    const t = /* @__PURE__ */ new Set();
    for (const s of n(this, Mt, sg))
      s.enableEditing(), s.show(!0), s.annotationElementId && (n(this, j).removeChangedExistingAnnotation(s), t.add(s.annotationElementId));
    const e = n(this, Ur);
    if (e)
      for (const s of e.getEditableAnnotations()) {
        if (s.hide(), n(this, j).isDeletedAnnotationElement(s.data.id) || t.has(s.data.id))
          continue;
        const r = await this.deserialize(s);
        r && (this.addOrRebuild(r), r.enableEditing());
      }
    p(this, hh, !1), n(this, j)._eventBus.dispatch("editorsrendered", {
      source: this,
      pageNumber: this.pageIndex + 1
    });
  }
  disable() {
    var i;
    if (p(this, lh, !0), this.div.tabIndex = -1, this.togglePointerEvents(!1), this.div.classList.toggle("nonEditing", !0), n(this, Ee) && !n(this, zr)) {
      p(this, zr, new AbortController());
      const s = n(this, j).combinedSignal(n(this, zr));
      n(this, Ee).div.addEventListener("pointerdown", (r) => {
        const {
          clientX: o,
          clientY: l,
          timeStamp: h
        } = r, c = n(this, ch);
        if (h - c > 500) {
          p(this, ch, h);
          return;
        }
        p(this, ch, -1);
        const {
          classList: u
        } = this.div;
        u.toggle("getElements", !0);
        const f = document.elementsFromPoint(o, l);
        if (u.toggle("getElements", !1), !this.div.contains(f[0]))
          return;
        let m;
        const A = new RegExp(`^${Gh}[0-9]+$`);
        for (const v of f)
          if (A.test(v.id)) {
            m = v.id;
            break;
          }
        if (!m)
          return;
        const y = n(this, gi).get(m);
        (y == null ? void 0 : y.annotationElementId) === null && (r.stopPropagation(), r.preventDefault(), y.dblclick(r));
      }, {
        signal: s,
        capture: !0
      });
    }
    const t = n(this, Ur);
    if (t) {
      const s = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
      for (const o of n(this, Mt, sg)) {
        if (o.disableEditing(), !o.annotationElementId) {
          o.updateFakeAnnotationElement(t);
          continue;
        }
        if (o.serialize() !== null) {
          s.set(o.annotationElementId, o);
          continue;
        } else
          r.set(o.annotationElementId, o);
        (i = this.getEditableAnnotation(o.annotationElementId)) == null || i.show(), o.remove();
      }
      const a = t.getEditableAnnotations();
      for (const o of a) {
        const {
          id: l
        } = o.data;
        if (n(this, j).isDeletedAnnotationElement(l)) {
          o.updateEdited({
            deleted: !0
          });
          continue;
        }
        let h = r.get(l);
        if (h) {
          h.resetAnnotationElement(o), h.show(!1), o.show();
          continue;
        }
        h = s.get(l), h && (n(this, j).addChangedExistingAnnotation(h), h.renderAnnotationElement(o) && h.show(!1)), o.show();
      }
    }
    b(this, Mt, Du).call(this), this.isEmpty && (this.div.hidden = !0);
    const {
      classList: e
    } = this.div;
    for (const s of n(hs, Gr).values())
      e.remove(`${s._type}Editing`);
    this.disableTextSelection(), this.toggleAnnotationLayerPointerEvents(!0), p(this, lh, !1);
  }
  getEditableAnnotation(t) {
    var e;
    return ((e = n(this, Ur)) == null ? void 0 : e.getEditableAnnotation(t)) || null;
  }
  setActiveEditor(t) {
    n(this, j).getActive() !== t && n(this, j).setActiveEditor(t);
  }
  enableTextSelection() {
    var t;
    if (this.div.tabIndex = -1, (t = n(this, Ee)) != null && t.div && !n(this, $n)) {
      p(this, $n, new AbortController());
      const e = n(this, j).combinedSignal(n(this, $n));
      n(this, Ee).div.addEventListener("pointerdown", b(this, Mt, k0).bind(this), {
        signal: e
      }), n(this, Ee).div.classList.add("highlighting");
    }
  }
  disableTextSelection() {
    var t;
    this.div.tabIndex = 0, (t = n(this, Ee)) != null && t.div && n(this, $n) && (n(this, $n).abort(), p(this, $n, null), n(this, Ee).div.classList.remove("highlighting"));
  }
  enableClick() {
    if (n(this, $r))
      return;
    p(this, $r, new AbortController());
    const t = n(this, j).combinedSignal(n(this, $r));
    this.div.addEventListener("pointerdown", this.pointerdown.bind(this), {
      signal: t
    });
    const e = this.pointerup.bind(this);
    this.div.addEventListener("pointerup", e, {
      signal: t
    }), this.div.addEventListener("pointercancel", e, {
      signal: t
    });
  }
  disableClick() {
    var t;
    (t = n(this, $r)) == null || t.abort(), p(this, $r, null);
  }
  attach(t) {
    n(this, gi).set(t.id, t);
    const {
      annotationElementId: e
    } = t;
    e && n(this, j).isDeletedAnnotationElement(e) && n(this, j).removeDeletedAnnotationElement(t);
  }
  detach(t) {
    var e;
    n(this, gi).delete(t.id), (e = n(this, mo)) == null || e.removePointerInTextLayer(t.contentDiv), !n(this, lh) && t.annotationElementId && n(this, j).addDeletedAnnotationElement(t);
  }
  remove(t) {
    this.detach(t), n(this, j).removeEditor(t), t.div.remove(), t.isAttachedToDOM = !1;
  }
  changeParent(t) {
    var e;
    t.parent !== this && (t.parent && t.annotationElementId && (n(this, j).addDeletedAnnotationElement(t.annotationElementId), Ft.deleteAnnotationElement(t), t.annotationElementId = null), this.attach(t), (e = t.parent) == null || e.detach(t), t.setParent(this), t.div && t.isAttachedToDOM && (t.div.remove(), this.div.append(t.div)));
  }
  add(t) {
    if (!(t.parent === this && t.isAttachedToDOM)) {
      if (this.changeParent(t), n(this, j).addEditor(t), this.attach(t), !t.isAttachedToDOM) {
        const e = t.render();
        this.div.append(e), t.isAttachedToDOM = !0;
      }
      t.fixAndSetPosition(), t.onceAdded(!n(this, hh)), n(this, j).addToAnnotationStorage(t), t._reportTelemetry(t.telemetryInitialData);
    }
  }
  moveEditorInDOM(t) {
    var i;
    if (!t.isAttachedToDOM)
      return;
    const {
      activeElement: e
    } = document;
    t.div.contains(e) && !n(this, Hn) && (t._focusEventsAllowed = !1, p(this, Hn, setTimeout(() => {
      p(this, Hn, null), t.div.contains(document.activeElement) ? t._focusEventsAllowed = !0 : (t.div.addEventListener("focusin", () => {
        t._focusEventsAllowed = !0;
      }, {
        once: !0,
        signal: n(this, j)._signal
      }), e.focus());
    }, 0))), t._structTreeParentId = (i = n(this, mo)) == null ? void 0 : i.moveElementInDOM(this.div, t.div, t.contentDiv, !0);
  }
  addOrRebuild(t) {
    t.needsToBeRebuilt() ? (t.parent || (t.parent = this), t.rebuild(), t.show()) : this.add(t);
  }
  addUndoableEditor(t) {
    const e = () => t._uiManager.rebuild(t), i = () => {
      t.remove();
    };
    this.addCommands({
      cmd: e,
      undo: i,
      mustExec: !1
    });
  }
  getEditorByUID(t) {
    for (const e of n(this, gi).values())
      if (e.uid === t)
        return e;
    return null;
  }
  getNextId() {
    return n(this, j).getId();
  }
  combinedSignal(t) {
    return n(this, j).combinedSignal(t);
  }
  canCreateNewEmptyEditor() {
    var t;
    return (t = n(this, Mt, Ts)) == null ? void 0 : t.canCreateNewEmptyEditor();
  }
  async pasteEditor(t, e) {
    this.updateToolbar(t), await n(this, j).updateMode(t.mode);
    const {
      offsetX: i,
      offsetY: s
    } = b(this, Mt, rg).call(this), r = this.getNextId(), a = b(this, Mt, ng).call(this, {
      parent: this,
      id: r,
      x: i,
      y: s,
      uiManager: n(this, j),
      isCentered: !0,
      ...e
    });
    a && this.add(a);
  }
  async deserialize(t) {
    var e;
    return await ((e = n(hs, Gr).get(t.annotationType ?? t.annotationEditorType)) == null ? void 0 : e.deserialize(t, this, n(this, j))) || null;
  }
  createAndAddNewEditor(t, e, i = {}) {
    const s = this.getNextId(), r = b(this, Mt, ng).call(this, {
      parent: this,
      id: s,
      x: t.offsetX,
      y: t.offsetY,
      uiManager: n(this, j),
      isCentered: e,
      ...i
    });
    return r && this.add(r), r;
  }
  get boundingClientRect() {
    return this.div.getBoundingClientRect();
  }
  addNewEditor(t = {}) {
    this.createAndAddNewEditor(b(this, Mt, rg).call(this), !0, t);
  }
  setSelected(t) {
    n(this, j).setSelected(t);
  }
  toggleSelected(t) {
    n(this, j).toggleSelected(t);
  }
  unselect(t) {
    n(this, j).unselect(t);
  }
  pointerup(t) {
    var s;
    const {
      isMac: e
    } = _e.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div || !n(this, Vr) || (p(this, Vr, !1), (s = n(this, Mt, Ts)) != null && s.isDrawer && n(this, Mt, Ts).supportMultipleDrawings))
      return;
    if (!n(this, oh)) {
      p(this, oh, !0);
      return;
    }
    const i = n(this, j).getMode();
    if (i === Z.STAMP || i === Z.SIGNATURE) {
      n(this, j).unselectAll();
      return;
    }
    this.createAndAddNewEditor(t, !1);
  }
  pointerdown(t) {
    var s;
    if (n(this, j).getMode() === Z.HIGHLIGHT && this.enableTextSelection(), n(this, Vr)) {
      p(this, Vr, !1);
      return;
    }
    const {
      isMac: e
    } = _e.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div)
      return;
    if (p(this, Vr, !0), (s = n(this, Mt, Ts)) != null && s.isDrawer) {
      this.startDrawingSession(t);
      return;
    }
    const i = n(this, j).getActive();
    p(this, oh, !i || i.isEmpty());
  }
  startDrawingSession(t) {
    if (this.div.focus({
      preventScroll: !0
    }), n(this, ws)) {
      n(this, Mt, Ts).startDrawing(this, n(this, j), !1, t);
      return;
    }
    n(this, j).setCurrentDrawingSession(this), p(this, ws, new AbortController());
    const e = n(this, j).combinedSignal(n(this, ws));
    this.div.addEventListener("blur", ({
      relatedTarget: i
    }) => {
      i && !this.div.contains(i) && (p(this, Un, null), this.commitOrRemove());
    }, {
      signal: e
    }), n(this, Mt, Ts).startDrawing(this, n(this, j), !1, t);
  }
  pause(t) {
    if (t) {
      const {
        activeElement: e
      } = document;
      this.div.contains(e) && p(this, Un, e);
      return;
    }
    n(this, Un) && setTimeout(() => {
      var e;
      (e = n(this, Un)) == null || e.focus(), p(this, Un, null);
    }, 0);
  }
  endDrawingSession(t = !1) {
    return n(this, ws) ? (n(this, j).setCurrentDrawingSession(null), n(this, ws).abort(), p(this, ws, null), p(this, Un, null), n(this, Mt, Ts).endDrawing(t)) : null;
  }
  findNewParent(t, e, i) {
    const s = n(this, j).findParent(e, i);
    return s === null || s === this ? !1 : (s.changeParent(t), !0);
  }
  commitOrRemove() {
    return n(this, ws) ? (this.endDrawingSession(), !0) : !1;
  }
  onScaleChanging() {
    n(this, ws) && n(this, Mt, Ts).onScaleChangingWhenDrawing(this);
  }
  destroy() {
    var t, e;
    this.commitOrRemove(), ((t = n(this, j).getActive()) == null ? void 0 : t.parent) === this && (n(this, j).commitOrRemove(), n(this, j).setActiveEditor(null)), n(this, Hn) && (clearTimeout(n(this, Hn)), p(this, Hn, null));
    for (const i of n(this, gi).values())
      (e = n(this, mo)) == null || e.removePointerInTextLayer(i.contentDiv), i.setParent(null), i.isAttachedToDOM = !1, i.div.remove();
    this.div = null, n(this, gi).clear(), n(this, j).removeLayer(this);
  }
  render({
    viewport: t
  }) {
    this.viewport = t, Wr(this.div, t);
    for (const e of n(this, j).getEditors(this.pageIndex))
      this.add(e), e.rebuild();
    this.updateMode();
  }
  update({
    viewport: t
  }) {
    n(this, j).commitOrRemove(), b(this, Mt, Du).call(this);
    const e = this.viewport.rotation, i = t.rotation;
    if (this.viewport = t, Wr(this.div, {
      rotation: i
    }), e !== i)
      for (const s of n(this, gi).values())
        s.rotate(i);
  }
  get pageDimensions() {
    const {
      pageWidth: t,
      pageHeight: e
    } = this.viewport.rawDims;
    return [t, e];
  }
  get scale() {
    return n(this, j).viewParameters.realScale;
  }
};
mo = new WeakMap(), oh = new WeakMap(), Ur = new WeakMap(), $r = new WeakMap(), Hn = new WeakMap(), gi = new WeakMap(), Vr = new WeakMap(), lh = new WeakMap(), hh = new WeakMap(), ws = new WeakMap(), Un = new WeakMap(), Ee = new WeakMap(), $n = new WeakMap(), zr = new WeakMap(), ch = new WeakMap(), j = new WeakMap(), Gr = new WeakMap(), Mt = new WeakSet(), sg = function() {
  return n(this, gi).size !== 0 ? n(this, gi).values() : n(this, j).getEditors(this.pageIndex);
}, k0 = function(t) {
  n(this, j).unselectAll();
  const {
    target: e
  } = t;
  if (e === n(this, Ee).div || (e.getAttribute("role") === "img" || e.classList.contains("endOfContent")) && n(this, Ee).div.contains(e)) {
    const {
      isMac: i
    } = _e.platform;
    if (t.button !== 0 || t.ctrlKey && i)
      return;
    n(this, j).showAllEditors("highlight", !0, !0), n(this, Ee).div.classList.add("free"), this.toggleDrawing(), Vu.startHighlighting(this, n(this, j).direction === "ltr", {
      target: n(this, Ee).div,
      x: t.x,
      y: t.y
    }), n(this, Ee).div.addEventListener("pointerup", () => {
      n(this, Ee).div.classList.remove("free"), this.toggleDrawing(!0);
    }, {
      once: !0,
      signal: n(this, j)._signal
    }), t.preventDefault();
  }
}, Ts = function() {
  return n(hs, Gr).get(n(this, j).getMode());
}, ng = function(t) {
  const e = n(this, Mt, Ts);
  return e ? new e.prototype.constructor(t) : null;
}, rg = function() {
  const {
    x: t,
    y: e,
    width: i,
    height: s
  } = this.boundingClientRect, r = Math.max(0, t), a = Math.max(0, e), o = Math.min(window.innerWidth, t + i), l = Math.min(window.innerHeight, e + s), h = (r + o) / 2 - t, c = (a + l) / 2 - e, [u, f] = this.viewport.rotation % 180 === 0 ? [h, c] : [c, h];
  return {
    offsetX: u,
    offsetY: f
  };
}, Du = function() {
  for (const t of n(this, gi).values())
    t.isEmpty() && t.remove();
}, M(hs, "_initialized", !1), g(hs, Gr, new Map([Bp, Xp, eg, Vu, tg].map((t) => [t._editorType, t])));
let Gu = hs;
var vs, ei, bo, Md, df, R0, Qs, ag, M0, og;
const he = class he {
  constructor({
    pageIndex: t
  }) {
    g(this, Qs);
    g(this, vs, null);
    g(this, ei, /* @__PURE__ */ new Map());
    g(this, bo, /* @__PURE__ */ new Map());
    this.pageIndex = t;
  }
  setParent(t) {
    if (!n(this, vs)) {
      p(this, vs, t);
      return;
    }
    if (n(this, vs) !== t) {
      if (n(this, ei).size > 0)
        for (const e of n(this, ei).values())
          e.remove(), t.append(e);
      p(this, vs, t);
    }
  }
  static get _svgFactory() {
    return st(this, "_svgFactory", new Jh());
  }
  draw(t, e = !1, i = !1) {
    const s = oe(he, Md)._++, r = b(this, Qs, ag).call(this), a = he._svgFactory.createElement("defs");
    r.append(a);
    const o = he._svgFactory.createElement("path");
    a.append(o);
    const l = `path_p${this.pageIndex}_${s}`;
    o.setAttribute("id", l), o.setAttribute("vector-effect", "non-scaling-stroke"), e && n(this, bo).set(s, o);
    const h = i ? b(this, Qs, M0).call(this, a, l) : null, c = he._svgFactory.createElement("use");
    return r.append(c), c.setAttribute("href", `#${l}`), this.updateProperties(r, t), n(this, ei).set(s, r), {
      id: s,
      clipPathId: `url(#${h})`
    };
  }
  drawOutline(t, e) {
    const i = oe(he, Md)._++, s = b(this, Qs, ag).call(this), r = he._svgFactory.createElement("defs");
    s.append(r);
    const a = he._svgFactory.createElement("path");
    r.append(a);
    const o = `path_p${this.pageIndex}_${i}`;
    a.setAttribute("id", o), a.setAttribute("vector-effect", "non-scaling-stroke");
    let l;
    if (e) {
      const u = he._svgFactory.createElement("mask");
      r.append(u), l = `mask_p${this.pageIndex}_${i}`, u.setAttribute("id", l), u.setAttribute("maskUnits", "objectBoundingBox");
      const f = he._svgFactory.createElement("rect");
      u.append(f), f.setAttribute("width", "1"), f.setAttribute("height", "1"), f.setAttribute("fill", "white");
      const m = he._svgFactory.createElement("use");
      u.append(m), m.setAttribute("href", `#${o}`), m.setAttribute("stroke", "none"), m.setAttribute("fill", "black"), m.setAttribute("fill-rule", "nonzero"), m.classList.add("mask");
    }
    const h = he._svgFactory.createElement("use");
    s.append(h), h.setAttribute("href", `#${o}`), l && h.setAttribute("mask", `url(#${l})`);
    const c = h.cloneNode();
    return s.append(c), h.classList.add("mainOutline"), c.classList.add("secondaryOutline"), this.updateProperties(s, t), n(this, ei).set(i, s), i;
  }
  finalizeDraw(t, e) {
    n(this, bo).delete(t), this.updateProperties(t, e);
  }
  updateProperties(t, e) {
    var l;
    if (!e)
      return;
    const {
      root: i,
      bbox: s,
      rootClass: r,
      path: a
    } = e, o = typeof t == "number" ? n(this, ei).get(t) : t;
    if (o) {
      if (i && b(this, Qs, og).call(this, o, i), s && b(l = he, df, R0).call(l, o, s), r) {
        const {
          classList: h
        } = o;
        for (const [c, u] of Object.entries(r))
          h.toggle(c, u);
      }
      if (a) {
        const c = o.firstChild.firstChild;
        b(this, Qs, og).call(this, c, a);
      }
    }
  }
  updateParent(t, e) {
    if (e === this)
      return;
    const i = n(this, ei).get(t);
    i && (n(e, vs).append(i), n(this, ei).delete(t), n(e, ei).set(t, i));
  }
  remove(t) {
    n(this, bo).delete(t), n(this, vs) !== null && (n(this, ei).get(t).remove(), n(this, ei).delete(t));
  }
  destroy() {
    p(this, vs, null);
    for (const t of n(this, ei).values())
      t.remove();
    n(this, ei).clear(), n(this, bo).clear();
  }
};
vs = new WeakMap(), ei = new WeakMap(), bo = new WeakMap(), Md = new WeakMap(), df = new WeakSet(), R0 = function(t, [e, i, s, r]) {
  const {
    style: a
  } = t;
  a.top = `${100 * i}%`, a.left = `${100 * e}%`, a.width = `${100 * s}%`, a.height = `${100 * r}%`;
}, Qs = new WeakSet(), ag = function() {
  const t = he._svgFactory.create(1, 1, !0);
  return n(this, vs).append(t), t.setAttribute("aria-hidden", !0), t;
}, M0 = function(t, e) {
  const i = he._svgFactory.createElement("clipPath");
  t.append(i);
  const s = `clip_${e}`;
  i.setAttribute("id", s), i.setAttribute("clipPathUnits", "objectBoundingBox");
  const r = he._svgFactory.createElement("use");
  return i.append(r), r.setAttribute("href", `#${e}`), r.classList.add("clip"), s;
}, og = function(t, e) {
  for (const [i, s] of Object.entries(e))
    s === null ? t.removeAttribute(i) : t.setAttribute(i, s);
}, g(he, df), g(he, Md, 0);
let Wu = he;
globalThis._pdfjsTestingUtils = {
  HighlightOutliner: Up
};
globalThis.pdfjsLib = {
  AbortException: Gn,
  AnnotationEditorLayer: Gu,
  AnnotationEditorParamsType: ht,
  AnnotationEditorType: Z,
  AnnotationEditorUIManager: jr,
  AnnotationLayer: _g,
  AnnotationMode: Zs,
  AnnotationType: te,
  applyOpacity: km,
  build: Db,
  ColorPicker: Zh,
  createValidAbsoluteUrl: dg,
  CSSConstants: Lm,
  DOMSVGFactory: Jh,
  DrawLayer: Wu,
  FeatureTest: _e,
  fetchData: ph,
  findContrastColor: Rm,
  getDocument: wg,
  getFilenameFromUrl: Cm,
  getPdfFilenameFromUrl: Tm,
  getRGB: gh,
  getUuid: fg,
  getXfaPageViewport: Pm,
  GlobalWorkerOptions: ns,
  ImageKind: zh,
  InvalidPDFException: Iu,
  isDataScheme: Nd,
  isPdfFile: gf,
  isValidExplicitDest: cb,
  MathClamp: We,
  noContextMenu: $i,
  normalizeUnicode: _m,
  OPS: dh,
  OutputScale: Ss,
  PasswordResponses: Em,
  PDFDataRangeTransport: vg,
  PDFDateString: qh,
  PDFWorker: uh,
  PermissionFlag: vm,
  PixelsPerInch: Wn,
  RenderingCancelledException: pf,
  renderRichText: mg,
  ResponseException: Wh,
  setLayerDimensions: Wr,
  shadow: st,
  SignatureExtractor: Js,
  stopEvent: zt,
  SupportedImageMimeTypes: Fu,
  TextLayer: Yh,
  TouchManager: Xh,
  updateUrlHash: ug,
  Util: z,
  VerbosityLevel: Dd,
  version: Kh,
  XfaLayer: gg
};
const GA = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AbortException: Gn,
  AnnotationEditorLayer: Gu,
  AnnotationEditorParamsType: ht,
  AnnotationEditorType: Z,
  AnnotationEditorUIManager: jr,
  AnnotationLayer: _g,
  AnnotationMode: Zs,
  AnnotationType: te,
  CSSConstants: Lm,
  ColorPicker: Zh,
  DOMSVGFactory: Jh,
  DrawLayer: Wu,
  FeatureTest: _e,
  GlobalWorkerOptions: ns,
  ImageKind: zh,
  InvalidPDFException: Iu,
  MathClamp: We,
  OPS: dh,
  OutputScale: Ss,
  PDFDataRangeTransport: vg,
  PDFDateString: qh,
  PDFWorker: uh,
  PasswordResponses: Em,
  PermissionFlag: vm,
  PixelsPerInch: Wn,
  RenderingCancelledException: pf,
  ResponseException: Wh,
  SignatureExtractor: Js,
  SupportedImageMimeTypes: Fu,
  TextLayer: Yh,
  TouchManager: Xh,
  Util: z,
  VerbosityLevel: Dd,
  XfaLayer: gg,
  applyOpacity: km,
  build: Db,
  createValidAbsoluteUrl: dg,
  fetchData: ph,
  findContrastColor: Rm,
  getDocument: wg,
  getFilenameFromUrl: Cm,
  getPdfFilenameFromUrl: Tm,
  getRGB: gh,
  getUuid: fg,
  getXfaPageViewport: Pm,
  isDataScheme: Nd,
  isPdfFile: gf,
  isValidExplicitDest: cb,
  noContextMenu: $i,
  normalizeUnicode: _m,
  renderRichText: mg,
  setLayerDimensions: Wr,
  shadow: st,
  stopEvent: zt,
  updateUrlHash: ug,
  version: Kh
}, Symbol.toStringTag, { value: "Module" }));
function D0(d) {
  var t, e, i = "";
  if (typeof d == "string" || typeof d == "number") i += d;
  else if (typeof d == "object") if (Array.isArray(d)) {
    var s = d.length;
    for (t = 0; t < s; t++) d[t] && (e = D0(d[t])) && (i && (i += " "), i += e);
  } else for (e in d) d[e] && (i && (i += " "), i += e);
  return i;
}
function yf() {
  for (var d, t, e = 0, i = "", s = arguments.length; e < s; e++) (d = arguments[e]) && (t = D0(d)) && (i && (i += " "), i += t);
  return i;
}
var om = Object.prototype.hasOwnProperty;
function lm(d, t, e) {
  for (e of d.keys())
    if (Oo(e, t)) return e;
}
function Oo(d, t) {
  var e, i, s;
  if (d === t) return !0;
  if (d && t && (e = d.constructor) === t.constructor) {
    if (e === Date) return d.getTime() === t.getTime();
    if (e === RegExp) return d.toString() === t.toString();
    if (e === Array) {
      if ((i = d.length) === t.length)
        for (; i-- && Oo(d[i], t[i]); ) ;
      return i === -1;
    }
    if (e === Set) {
      if (d.size !== t.size)
        return !1;
      for (i of d)
        if (s = i, s && typeof s == "object" && (s = lm(t, s), !s) || !t.has(s)) return !1;
      return !0;
    }
    if (e === Map) {
      if (d.size !== t.size)
        return !1;
      for (i of d)
        if (s = i[0], s && typeof s == "object" && (s = lm(t, s), !s) || !Oo(i[1], t.get(s)))
          return !1;
      return !0;
    }
    if (e === ArrayBuffer)
      d = new Uint8Array(d), t = new Uint8Array(t);
    else if (e === DataView) {
      if ((i = d.byteLength) === t.byteLength)
        for (; i-- && d.getInt8(i) === t.getInt8(i); ) ;
      return i === -1;
    }
    if (ArrayBuffer.isView(d)) {
      if ((i = d.byteLength) === t.byteLength)
        for (; i-- && d[i] === t[i]; ) ;
      return i === -1;
    }
    if (!e || typeof d == "object") {
      i = 0;
      for (e in d)
        if (om.call(d, e) && ++i && !om.call(t, e) || !(e in t) || !Oo(d[e], t[e])) return !1;
      return Object.keys(t).length === i;
    }
  }
  return d !== d && t !== t;
}
function Ud(d) {
  let t = !1;
  return {
    promise: new Promise((i, s) => {
      d.then((r) => !t && i(r)).catch((r) => !t && s(r));
    }),
    cancel() {
      t = !0;
    }
  };
}
const WA = ["onCopy", "onCut", "onPaste"], jA = [
  "onCompositionEnd",
  "onCompositionStart",
  "onCompositionUpdate"
], qA = ["onFocus", "onBlur"], XA = ["onInput", "onInvalid", "onReset", "onSubmit"], YA = ["onLoad", "onError"], KA = ["onKeyDown", "onKeyPress", "onKeyUp"], ZA = [
  "onAbort",
  "onCanPlay",
  "onCanPlayThrough",
  "onDurationChange",
  "onEmptied",
  "onEncrypted",
  "onEnded",
  "onError",
  "onLoadedData",
  "onLoadedMetadata",
  "onLoadStart",
  "onPause",
  "onPlay",
  "onPlaying",
  "onProgress",
  "onRateChange",
  "onSeeked",
  "onSeeking",
  "onStalled",
  "onSuspend",
  "onTimeUpdate",
  "onVolumeChange",
  "onWaiting"
], JA = [
  "onClick",
  "onContextMenu",
  "onDoubleClick",
  "onMouseDown",
  "onMouseEnter",
  "onMouseLeave",
  "onMouseMove",
  "onMouseOut",
  "onMouseOver",
  "onMouseUp"
], QA = [
  "onDrag",
  "onDragEnd",
  "onDragEnter",
  "onDragExit",
  "onDragLeave",
  "onDragOver",
  "onDragStart",
  "onDrop"
], t1 = ["onSelect"], e1 = ["onTouchCancel", "onTouchEnd", "onTouchMove", "onTouchStart"], i1 = [
  "onPointerDown",
  "onPointerMove",
  "onPointerUp",
  "onPointerCancel",
  "onGotPointerCapture",
  "onLostPointerCapture",
  "onPointerEnter",
  "onPointerLeave",
  "onPointerOver",
  "onPointerOut"
], s1 = ["onScroll"], n1 = ["onWheel"], r1 = [
  "onAnimationStart",
  "onAnimationEnd",
  "onAnimationIteration"
], a1 = ["onTransitionEnd"], o1 = ["onToggle"], l1 = ["onChange"], h1 = [
  ...WA,
  ...jA,
  ...qA,
  ...XA,
  ...YA,
  ...KA,
  ...ZA,
  ...JA,
  ...QA,
  ...t1,
  ...e1,
  ...i1,
  ...s1,
  ...n1,
  ...r1,
  ...a1,
  ...l1,
  ...o1
];
function I0(d, t) {
  const e = {};
  for (const i of h1) {
    const s = d[i];
    s && (t ? e[i] = ((r) => s(r, t(i))) : e[i] = s);
  }
  return e;
}
var c1 = "Invariant failed";
function Rt(d, t) {
  if (!d)
    throw new Error(c1);
}
function d1(d) {
  return d && d.__esModule && Object.prototype.hasOwnProperty.call(d, "default") ? d.default : d;
}
var Ff, hm;
function u1() {
  if (hm) return Ff;
  hm = 1;
  var d = function() {
  };
  return Ff = d, Ff;
}
var f1 = u1();
const qe = /* @__PURE__ */ d1(f1), F0 = cg(null), p1 = "noopener noreferrer nofollow";
class g1 {
  constructor() {
    this.externalLinkEnabled = !0, this.externalLinkRel = void 0, this.externalLinkTarget = void 0, this.isInPresentationMode = !1, this.pdfDocument = void 0, this.pdfViewer = void 0;
  }
  setDocument(t) {
    this.pdfDocument = t;
  }
  setViewer(t) {
    this.pdfViewer = t;
  }
  setExternalLinkRel(t) {
    this.externalLinkRel = t;
  }
  setExternalLinkTarget(t) {
    this.externalLinkTarget = t;
  }
  setHash() {
  }
  setHistory() {
  }
  get pagesCount() {
    return this.pdfDocument ? this.pdfDocument.numPages : 0;
  }
  get page() {
    return Rt(this.pdfViewer), this.pdfViewer.currentPageNumber || 0;
  }
  set page(t) {
    Rt(this.pdfViewer), this.pdfViewer.currentPageNumber = t;
  }
  get rotation() {
    return 0;
  }
  set rotation(t) {
  }
  addLinkAttributes(t, e, i) {
    t.href = e, t.rel = this.externalLinkRel || p1, t.target = i ? "_blank" : this.externalLinkTarget || "";
  }
  goToDestination(t) {
    return new Promise((e) => {
      Rt(this.pdfDocument), Rt(t), typeof t == "string" ? this.pdfDocument.getDestination(t).then(e) : Array.isArray(t) ? e(t) : t.then(e);
    }).then((e) => {
      Rt(Array.isArray(e));
      const i = e[0];
      new Promise((s) => {
        Rt(this.pdfDocument), i instanceof Object ? this.pdfDocument.getPageIndex(i).then((r) => {
          s(r);
        }).catch(() => {
          Rt(!1);
        }) : typeof i == "number" ? s(i) : Rt(!1);
      }).then((s) => {
        const r = s + 1;
        Rt(this.pdfViewer), Rt(r >= 1 && r <= this.pagesCount), this.pdfViewer.scrollPageIntoView({
          dest: e,
          pageIndex: s,
          pageNumber: r
        });
      });
    });
  }
  goToPage(t) {
    const e = t - 1;
    Rt(this.pdfViewer), Rt(t >= 1 && t <= this.pagesCount), this.pdfViewer.scrollPageIntoView({
      pageIndex: e,
      pageNumber: t
    });
  }
  goToXY() {
  }
  cachePageRef() {
  }
  getDestinationHash() {
    return "#";
  }
  getAnchorUrl() {
    return "#";
  }
  executeNamedAction() {
  }
  executeSetOCGState() {
  }
  isPageVisible() {
    return !0;
  }
  isPageCached() {
    return !0;
  }
  navigateTo(t) {
    this.goToDestination(t);
  }
}
function Bo({ children: d, type: t }) {
  return K("div", { className: `react-pdf__message react-pdf__message--${t}`, children: d });
}
const cm = {
  NEED_PASSWORD: 1,
  INCORRECT_PASSWORD: 2
};
function m1(d, t) {
  switch (t.type) {
    case "RESOLVE":
      return { value: t.value, error: void 0 };
    case "REJECT":
      return { value: !1, error: t.error };
    case "RESET":
      return { value: void 0, error: void 0 };
    default:
      return d;
  }
}
function fh() {
  return ey(m1, { value: void 0, error: void 0 });
}
const Af = typeof window < "u", N0 = Af && window.location.protocol === "file:";
function b1(d) {
  return typeof d < "u";
}
function Jr(d) {
  return b1(d) && d !== null;
}
function y1(d) {
  return typeof d == "string";
}
function A1(d) {
  return d instanceof ArrayBuffer;
}
function w1(d) {
  return Rt(Af), d instanceof Blob;
}
function lg(d) {
  return y1(d) && /^data:/.test(d);
}
function dm(d) {
  Rt(lg(d));
  const [t = "", e = ""] = d.split(",");
  return t.split(";").indexOf("base64") !== -1 ? atob(e) : unescape(e);
}
function v1() {
  return Af && window.devicePixelRatio || 1;
}
const O0 = "On Chromium based browsers, you can use --allow-file-access-from-files flag for debugging purposes.";
function um() {
  qe(!N0, `Loading PDF as base64 strings/URLs may not work on protocols other than HTTP/HTTPS. ${O0}`);
}
function E1() {
  qe(!N0, `Loading PDF.js worker may not work on protocols other than HTTP/HTTPS. ${O0}`);
}
function Ao(d) {
  d != null && d.cancel && d.cancel();
}
function hg(d, t) {
  return Object.defineProperty(d, "width", {
    get() {
      return this.getViewport({ scale: t }).width;
    },
    configurable: !0
  }), Object.defineProperty(d, "height", {
    get() {
      return this.getViewport({ scale: t }).height;
    },
    configurable: !0
  }), Object.defineProperty(d, "originalWidth", {
    get() {
      return this.getViewport({ scale: 1 }).width;
    },
    configurable: !0
  }), Object.defineProperty(d, "originalHeight", {
    get() {
      return this.getViewport({ scale: 1 }).height;
    },
    configurable: !0
  }), d;
}
function B0(d) {
  return d.name === "AbortException" || d.name === "RenderingCancelledException";
}
function S1(d) {
  return new Promise((t, e) => {
    const i = new FileReader();
    i.onload = () => {
      if (!i.result)
        return e(new Error("Error while reading a file."));
      t(i.result);
    }, i.onerror = (s) => {
      if (!s.target)
        return e(new Error("Error while reading a file."));
      const { error: r } = s.target;
      if (!r)
        return e(new Error("Error while reading a file."));
      switch (r.code) {
        case r.NOT_FOUND_ERR:
          return e(new Error("Error while reading a file: File not found."));
        case r.SECURITY_ERR:
          return e(new Error("Error while reading a file: Security error."));
        case r.ABORT_ERR:
          return e(new Error("Error while reading a file: Aborted."));
        default:
          return e(new Error("Error while reading a file."));
      }
    }, i.readAsArrayBuffer(d);
  });
}
const { PDFDataRangeTransport: _1 } = GA, x1 = (d, t) => {
  switch (t) {
    case cm.NEED_PASSWORD: {
      const e = prompt("Enter the password to open this PDF file.");
      d(e);
      break;
    }
    case cm.INCORRECT_PASSWORD: {
      const e = prompt("Invalid password. Please try again.");
      d(e);
      break;
    }
  }
};
function fm(d) {
  return typeof d == "object" && d !== null && ("data" in d || "range" in d || "url" in d);
}
const C1 = iy(function({ children: t, className: e, error: i = "Failed to load PDF file.", externalLinkRel: s, externalLinkTarget: r, file: a, inputRef: o, imageResourcesPath: l, loading: h = "Loading PDF…", noData: c = "No PDF file specified.", onItemClick: u, onLoadError: f, onLoadProgress: m, onLoadSuccess: A, onPassword: y = x1, onSourceError: v, onSourceSuccess: w, options: S, renderMode: E, rotate: _, scale: x, ...C }, T) {
  const [L, k] = fh(), { value: D, error: R } = L, [N, q] = fh(), { value: B, error: Y } = N, O = ss(new g1()), H = ss([]), it = ss(void 0), at = ss(void 0);
  a && a !== it.current && fm(a) && (qe(!Oo(a, it.current), `File prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to "file" prop.`), it.current = a), S && S !== at.current && (qe(!Oo(S, at.current), `Options prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to "options" prop.`), at.current = S);
  const Jt = ss({
    // Handling jumping to internal links target
    scrollPageIntoView: (Pt) => {
      const { dest: Wt, pageNumber: Nt, pageIndex: pe = Nt - 1 } = Pt;
      if (u) {
        u({ dest: Wt, pageIndex: pe, pageNumber: Nt });
        return;
      }
      const Ne = H.current[pe];
      if (Ne) {
        Ne.scrollIntoView();
        return;
      }
      qe(!1, `An internal link leading to page ${Nt} was clicked, but neither <Document> was provided with onItemClick nor it was able to find the page within itself. Either provide onItemClick to <Document> and handle navigating by yourself or ensure that all pages are rendered within <Document>.`);
    }
  });
  sy(T, () => ({
    linkService: O,
    pages: H,
    viewer: Jt
  }), []);
  function Xe() {
    w && w();
  }
  function lt() {
    R && (qe(!1, R.toString()), v && v(R));
  }
  function tt() {
    k({ type: "RESET" });
  }
  bt(tt, [a, k]);
  const vt = Se(async () => {
    if (!a)
      return null;
    if (typeof a == "string")
      return lg(a) ? { data: dm(a) } : (um(), { url: a });
    if (a instanceof _1)
      return { range: a };
    if (A1(a))
      return { data: a };
    if (Af && w1(a))
      return { data: await S1(a) };
    if (Rt(typeof a == "object"), Rt(fm(a)), "url" in a && typeof a.url == "string") {
      if (lg(a.url)) {
        const { url: Pt, ...Wt } = a;
        return { data: dm(Pt), ...Wt };
      }
      um();
    }
    return a;
  }, [a]);
  bt(() => {
    const Pt = Ud(vt());
    return Pt.promise.then((Wt) => {
      k({ type: "RESOLVE", value: Wt });
    }).catch((Wt) => {
      k({ type: "REJECT", error: Wt });
    }), () => {
      Ao(Pt);
    };
  }, [vt, k]), bt(() => {
    if (!(typeof D > "u")) {
      if (D === !1) {
        lt();
        return;
      }
      Xe();
    }
  }, [D]);
  function se() {
    B && (A && A(B), H.current = new Array(B.numPages), O.current.setDocument(B));
  }
  function fe() {
    Y && (qe(!1, Y.toString()), f && f(Y));
  }
  bt(function() {
    q({ type: "RESET" });
  }, [q, D]), bt(function() {
    if (!D)
      return;
    const Wt = S ? { ...D, ...S } : D, Nt = wg(Wt);
    m && (Nt.onProgress = m), y && (Nt.onPassword = y);
    const pe = Nt;
    return pe.promise.then((Ne) => {
      pe.destroyed || q({ type: "RESOLVE", value: Ne });
    }).catch((Ne) => {
      pe.destroyed || q({ type: "REJECT", error: Ne });
    }), () => {
      pe.destroy();
    };
  }, [S, q, D]), bt(() => {
    if (!(typeof B > "u")) {
      if (B === !1) {
        fe();
        return;
      }
      se();
    }
  }, [B]), bt(function() {
    O.current.setViewer(Jt.current), O.current.setExternalLinkRel(s), O.current.setExternalLinkTarget(r);
  }, [s, r]);
  const ct = Se((Pt, Wt) => {
    H.current[Pt] = Wt;
  }, []), bi = Se((Pt) => {
    delete H.current[Pt];
  }, []), Ye = je(() => ({
    imageResourcesPath: l,
    linkService: O.current,
    onItemClick: u,
    pdf: B,
    registerPage: ct,
    renderMode: E,
    rotate: _,
    scale: x,
    unregisterPage: bi
  }), [l, u, B, ct, E, _, x, bi]), Vi = je(
    () => I0(C, () => B),
    // biome-ignore lint/correctness/useExhaustiveDependencies: FIXME
    [C, B]
  );
  function xe() {
    function Pt(Nt) {
      return !!(Nt != null && Nt.pdf);
    }
    if (!Pt(Ye))
      throw new Error("pdf is undefined");
    const Wt = typeof t == "function" ? t(Ye) : t;
    return K(F0.Provider, { value: Ye, children: Wt });
  }
  function Tt() {
    return a ? B == null ? K(Bo, { type: "loading", children: typeof h == "function" ? h() : h }) : B === !1 ? K(Bo, { type: "error", children: typeof i == "function" ? i() : i }) : xe() : K(Bo, { type: "no-data", children: typeof c == "function" ? c() : c });
  }
  return K("div", {
    className: yf("react-pdf__Document", e),
    // Assertion is needed for React 18 compatibility
    ref: o,
    ...Vi,
    children: Tt()
  });
});
function H0() {
  return wm(F0);
}
function U0() {
  for (var d = [], t = 0; t < arguments.length; t++)
    d[t] = arguments[t];
  var e = d.filter(Boolean);
  if (e.length <= 1) {
    var i = e[0];
    return i || null;
  }
  return function(r) {
    for (var a = 0, o = e; a < o.length; a++) {
      var l = o[a];
      typeof l == "function" ? l(r) : l && (l.current = r);
    }
  };
}
const $0 = cg(null);
function wf() {
  return wm($0);
}
function T1() {
  const d = H0(), t = wf();
  Rt(t);
  const e = { ...d, ...t }, { filterAnnotations: i, imageResourcesPath: s, linkService: r, onGetAnnotationsError: a, onGetAnnotationsSuccess: o, onRenderAnnotationLayerError: l, onRenderAnnotationLayerSuccess: h, page: c, pdf: u, renderForms: f, rotate: m, scale: A = 1 } = e;
  Rt(u), Rt(c), Rt(r);
  const [y, v] = fh(), { value: w, error: S } = y, E = ss(null);
  qe(Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--react-pdf-annotation-layer"), 10) === 1, "AnnotationLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-annotations");
  function _() {
    w && o && o(w);
  }
  function x() {
    S && (qe(!1, S.toString()), a && a(S));
  }
  bt(function() {
    v({ type: "RESET" });
  }, [v, c]), bt(function() {
    if (!c)
      return;
    const D = Ud(c.getAnnotations()), R = D;
    return D.promise.then((N) => {
      v({ type: "RESOLVE", value: N });
    }).catch((N) => {
      v({ type: "REJECT", error: N });
    }), () => {
      Ao(R);
    };
  }, [v, c]), bt(() => {
    if (w !== void 0) {
      if (w === !1) {
        x();
        return;
      }
      _();
    }
  }, [w]);
  function C() {
    h && h();
  }
  function T(k) {
    qe(!1, `${k}`), l && l(k);
  }
  const L = je(() => c.getViewport({ scale: A, rotation: m }), [c, m, A]);
  return bt(function() {
    if (!u || !c || !r || !w)
      return;
    const { current: D } = E;
    if (!D)
      return;
    const R = L.clone({ dontFlip: !0 }), N = {
      accessibilityManager: null,
      // TODO: Implement this
      annotationCanvasMap: null,
      // TODO: Implement this
      annotationEditorUIManager: null,
      // TODO: Implement this
      annotationStorage: u.annotationStorage,
      commentManager: null,
      // TODO: Implement this
      div: D,
      l10n: null,
      // TODO: Implement this
      linkService: r,
      page: c,
      structTreeLayer: null,
      // TODO: Implement this
      viewport: R
    }, q = {
      annotations: i ? i({ annotations: w }) : w,
      annotationStorage: u.annotationStorage,
      div: D,
      imageResourcesPath: s,
      linkService: r,
      page: c,
      renderForms: f,
      viewport: R
    };
    D.innerHTML = "";
    try {
      new _g(N).render(q), C();
    } catch (B) {
      T(B);
    }
    return () => {
    };
  }, [
    w,
    i,
    s,
    r,
    c,
    u,
    f,
    L
  ]), K("div", { className: yf("react-pdf__Page__annotations", "annotationLayer"), ref: E });
}
const V0 = {
  // Document level structure types
  Document: null,
  // There's a "document" role, but it doesn't make sense here.
  DocumentFragment: null,
  // Grouping level structure types
  Part: "group",
  Sect: "group",
  // XXX: There's a "section" role, but it's abstract.
  Div: "group",
  Aside: "note",
  NonStruct: "none",
  // Block level structure types
  P: null,
  // H<n>,
  H: "heading",
  Title: null,
  FENote: "note",
  // Sub-block level structure type
  Sub: "group",
  // General inline level structure types
  Lbl: null,
  Span: null,
  Em: null,
  Strong: null,
  Link: "link",
  Annot: "note",
  Form: "form",
  // Ruby and Warichu structure types
  Ruby: null,
  RB: null,
  RT: null,
  RP: null,
  Warichu: null,
  WT: null,
  WP: null,
  // List standard structure types
  L: "list",
  LI: "listitem",
  LBody: null,
  // Table standard structure types
  Table: "table",
  TR: "row",
  TH: "columnheader",
  TD: "cell",
  THead: "columnheader",
  TBody: null,
  TFoot: null,
  // Standard structure type Caption
  Caption: null,
  // Standard structure type Figure
  Figure: "figure",
  // Standard structure type Formula
  Formula: null,
  // standard structure type Artifact
  Artifact: null
}, P1 = /^H(\d+)$/;
function L1(d) {
  return d in V0;
}
function vf(d) {
  return "children" in d;
}
function z0(d) {
  return vf(d) ? d.children.length === 1 && 0 in d.children && "id" in d.children[0] : !1;
}
function k1(d) {
  const t = {};
  if (vf(d)) {
    const { role: e } = d, i = e.match(P1);
    if (i)
      t.role = "heading", t["aria-level"] = Number(i[1]);
    else if (L1(e)) {
      const s = V0[e];
      s && (t.role = s);
    }
  }
  return t;
}
function G0(d) {
  const t = {};
  if (vf(d)) {
    if (d.alt !== void 0 && (t["aria-label"] = d.alt), d.lang !== void 0 && (t.lang = d.lang), z0(d)) {
      const [e] = d.children;
      if (e) {
        const i = G0(e);
        return {
          ...t,
          ...i
        };
      }
    }
  } else "id" in d && (t["aria-owns"] = d.id);
  return t;
}
function R1(d) {
  return d ? {
    ...k1(d),
    ...G0(d)
  } : null;
}
function W0({ className: d, node: t }) {
  const e = je(() => R1(t), [t]), i = je(() => !vf(t) || z0(t) ? null : t.children.map((s, r) => (
    // biome-ignore lint/suspicious/noArrayIndexKey: index is stable here
    K(W0, { node: s }, r)
  )), [t]);
  return K("span", { className: d, ...e, children: i });
}
function M1() {
  const d = wf();
  Rt(d);
  const { onGetStructTreeError: t, onGetStructTreeSuccess: e } = d, [i, s] = fh(), { value: r, error: a } = i, { customTextRenderer: o, page: l } = d;
  function h() {
    r && e && e(r);
  }
  function c() {
    a && (qe(!1, a.toString()), t && t(a));
  }
  return bt(function() {
    s({ type: "RESET" });
  }, [s, l]), bt(function() {
    if (o || !l)
      return;
    const f = Ud(l.getStructTree()), m = f;
    return f.promise.then((A) => {
      s({ type: "RESOLVE", value: A });
    }).catch((A) => {
      s({ type: "REJECT", error: A });
    }), () => Ao(m);
  }, [o, l, s]), bt(() => {
    if (r !== void 0) {
      if (r === !1) {
        c();
        return;
      }
      h();
    }
  }, [r]), r ? K(W0, { className: "react-pdf__Page__structTree structTree", node: r }) : null;
}
const pm = Zs;
function D1(d) {
  const t = wf();
  Rt(t);
  const e = { ...t, ...d }, { _className: i, canvasBackground: s, devicePixelRatio: r = v1(), onRenderError: a, onRenderSuccess: o, page: l, renderForms: h, renderTextLayer: c, pageColors: u, rotate: f, scale: m } = e, { canvasRef: A } = d;
  Rt(l);
  const y = ss(null);
  function v() {
    l && o && o(hg(l, m));
  }
  function w(x) {
    B0(x) || (qe(!1, x.toString()), a && a(x));
  }
  const S = je(() => l.getViewport({ scale: m * r, rotation: f }), [r, l, f, m]), E = je(() => l.getViewport({ scale: m, rotation: f }), [l, f, m]);
  bt(function() {
    if (!l)
      return;
    l.cleanup();
    const { current: C } = y;
    if (!C)
      return;
    C.width = S.width, C.height = S.height, C.style.width = `${Math.floor(E.width)}px`, C.style.height = `${Math.floor(E.height)}px`, C.style.visibility = "hidden";
    const T = {
      annotationMode: h ? pm.ENABLE_FORMS : pm.ENABLE,
      canvas: C,
      canvasContext: C.getContext("2d", { alpha: !1 }),
      pageColors: u,
      viewport: S
    };
    s && (T.background = s);
    const L = l.render(T), k = L;
    return L.promise.then(() => {
      C.style.visibility = "", v();
    }).catch(w), () => Ao(k);
  }, [s, l, u, h, S, E]);
  const _ = Se(() => {
    const { current: x } = y;
    x && (x.width = 0, x.height = 0);
  }, []);
  return bt(() => _, [_]), K("canvas", { className: `${i}__canvas`, dir: "ltr", ref: U0(A, y), style: {
    display: "block",
    userSelect: "none"
  }, children: c ? K(M1, {}) : null });
}
function I1(d) {
  return "str" in d;
}
const F1 = /* @__PURE__ */ new Set([
  "base",
  "embed",
  "iframe",
  "link",
  "meta",
  "object",
  "script",
  "style",
  "template"
]), N1 = /* @__PURE__ */ new Set(["action", "formaction", "href", "poster", "src", "xlink:href"]);
function O1(d) {
  let t = "";
  for (const e of d) {
    const i = e.charCodeAt(0);
    i <= 32 || i === 127 || (t += e.toLowerCase());
  }
  return t.startsWith("javascript:") || t.startsWith("vbscript:");
}
function B1(d) {
  return d.nodeType === Node.ELEMENT_NODE;
}
function j0(d) {
  return B1(d) && d instanceof HTMLElement;
}
function H1(d) {
  return j0(d) && F1.has(d.tagName.toLowerCase());
}
function U1(d) {
  const t = document.createElement(d.tagName.toLowerCase());
  return Array.from(d.attributes).forEach((e) => {
    const i = e.name.toLowerCase();
    i.startsWith("on") || i === "srcdoc" || N1.has(i) && O1(e.value) || t.setAttribute(e.name, e.value);
  }), Array.from(d.childNodes).forEach((e) => {
    t.append(q0(e));
  }), t;
}
function q0(d) {
  var t;
  return j0(d) && !H1(d) ? U1(d) : document.createTextNode((t = d.textContent) !== null && t !== void 0 ? t : "");
}
function $1(d, t) {
  const e = document.createElement("template");
  e.innerHTML = t;
  const i = document.createDocumentFragment();
  Array.from(e.content.childNodes).forEach((s) => {
    i.append(q0(s));
  }), d.replaceChildren(i);
}
function V1() {
  const d = wf();
  Rt(d);
  const { customTextRenderer: t, onGetTextError: e, onGetTextSuccess: i, onRenderTextLayerError: s, onRenderTextLayerSuccess: r, page: a, pageIndex: o, pageNumber: l, rotate: h, scale: c } = d;
  Rt(a);
  const [u, f] = fh(), { value: m, error: A } = u, y = ss(null);
  qe(Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--react-pdf-text-layer"), 10) === 1, "TextLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-text-layer");
  function v() {
    m && i && i(m);
  }
  function w() {
    A && (qe(!1, A.toString()), e && e(A));
  }
  bt(function() {
    f({ type: "RESET" });
  }, [a, f]), bt(function() {
    if (!a)
      return;
    const L = Ud(a.getTextContent()), k = L;
    return L.promise.then((D) => {
      f({ type: "RESOLVE", value: D });
    }).catch((D) => {
      f({ type: "REJECT", error: D });
    }), () => Ao(k);
  }, [a, f]), bt(() => {
    if (m !== void 0) {
      if (m === !1) {
        w();
        return;
      }
      v();
    }
  }, [m]);
  const S = Se(() => {
    r && r();
  }, [r]), E = Se((T) => {
    B0(T) || (qe(!1, T.toString()), s && s(T));
  }, [s]);
  function _() {
    const T = y.current;
    T && T.classList.add("selecting");
  }
  function x() {
    const T = y.current;
    T && T.classList.remove("selecting");
  }
  const C = je(() => a.getViewport({ scale: c, rotation: h }), [a, h, c]);
  return ny(function() {
    if (!a || !m)
      return;
    const { current: L } = y;
    if (!L)
      return;
    L.innerHTML = "";
    const k = a.streamTextContent({ includeMarkedContent: !0 }), D = {
      container: L,
      textContentSource: k,
      viewport: C
    }, R = new Yh(D), N = R;
    return R.render().then(() => {
      const q = document.createElement("div");
      q.className = "endOfContent", L.append(q);
      const B = L.querySelectorAll('[role="presentation"]');
      if (t) {
        let Y = 0;
        m.items.forEach((O, H) => {
          if (!I1(O))
            return;
          const it = B[Y];
          if (!it)
            return;
          const at = t({
            pageIndex: o,
            pageNumber: l,
            itemIndex: H,
            ...O
          });
          $1(it, at), Y += O.str && O.hasEOL ? 2 : 1;
        });
      }
      S();
    }).catch(E), () => Ao(N);
  }, [
    t,
    E,
    S,
    a,
    o,
    l,
    m,
    C
  ]), // biome-ignore lint/a11y/noStaticElementInteractions: False positive caused by non interactive wrapper listening for bubbling events
  K("div", { className: yf("react-pdf__Page__textContent", "textLayer"), onMouseUp: x, onMouseDown: _, ref: y });
}
const gm = 1;
function z1(d) {
  const e = { ...H0(), ...d }, { _className: i = "react-pdf__Page", _enableRegisterUnregisterPage: s = !0, canvasBackground: r, canvasRef: a, children: o, className: l, customRenderer: h, customTextRenderer: c, devicePixelRatio: u, error: f = "Failed to load the page.", filterAnnotations: m, height: A, inputRef: y, loading: v = "Loading page…", noData: w = "No page specified.", onGetAnnotationsError: S, onGetAnnotationsSuccess: E, onGetStructTreeError: _, onGetStructTreeSuccess: x, onGetTextError: C, onGetTextSuccess: T, onLoadError: L, onLoadSuccess: k, onRenderAnnotationLayerError: D, onRenderAnnotationLayerSuccess: R, onRenderError: N, onRenderSuccess: q, onRenderTextLayerError: B, onRenderTextLayerSuccess: Y, pageColors: O, pageIndex: H, pageNumber: it, pdf: at, registerPage: Jt, renderAnnotationLayer: Xe = !0, renderForms: lt = !1, renderMode: tt = "canvas", renderTextLayer: vt = !0, rotate: se, scale: fe = gm, unregisterPage: ct, width: bi, ...Ye } = e, [Vi, xe] = fh(), { value: Tt, error: Pt } = Vi, Wt = ss(null);
  Rt(at);
  const Nt = Jr(it) ? it - 1 : H ?? null, pe = it ?? (Jr(H) ? H + 1 : null), Ne = se ?? (Tt ? Tt.rotate : null), ri = je(() => {
    if (!Tt)
      return null;
    let jt = 1;
    const ge = fe ?? gm;
    if (bi || A) {
      const ai = Tt.getViewport({ scale: 1, rotation: Ne });
      bi ? jt = bi / ai.width : A && (jt = A / ai.height);
    }
    return ge * jt;
  }, [A, Tt, Ne, fe, bi]);
  bt(function() {
    return () => {
      Jr(Nt) && s && ct && ct(Nt);
    };
  }, [s, at, Nt, ct]);
  function Ef() {
    if (k) {
      if (!Tt || !ri)
        return;
      k(hg(Tt, ri));
    }
    if (s && Jt) {
      if (!Jr(Nt) || !Wt.current)
        return;
      Jt(Nt, Wt.current);
    }
  }
  function Sf() {
    Pt && (qe(!1, Pt.toString()), L && L(Pt));
  }
  bt(function() {
    xe({ type: "RESET" });
  }, [xe, at, Nt]), bt(function() {
    if (!at || !pe)
      return;
    const ge = Ud(at.getPage(pe)), ai = ge;
    return ge.promise.then((zi) => {
      xe({ type: "RESOLVE", value: zi });
    }).catch((zi) => {
      xe({ type: "REJECT", error: zi });
    }), () => Ao(ai);
  }, [xe, at, pe]), bt(() => {
    if (Tt !== void 0) {
      if (Tt === !1) {
        Sf();
        return;
      }
      Ef();
    }
  }, [Tt, ri]);
  const mh = je(() => (
    // Technically there cannot be page without pageIndex, pageNumber, rotate and scale, but TypeScript doesn't know that
    Jr(Nt) && pe && Jr(Ne) && Jr(ri) ? {
      _className: i,
      canvasBackground: r,
      customTextRenderer: c,
      devicePixelRatio: u,
      filterAnnotations: m,
      onGetAnnotationsError: S,
      onGetAnnotationsSuccess: E,
      onGetStructTreeError: _,
      onGetStructTreeSuccess: x,
      onGetTextError: C,
      onGetTextSuccess: T,
      onRenderAnnotationLayerError: D,
      onRenderAnnotationLayerSuccess: R,
      onRenderError: N,
      onRenderSuccess: q,
      onRenderTextLayerError: B,
      onRenderTextLayerSuccess: Y,
      page: Tt,
      pageColors: O,
      pageIndex: Nt,
      pageNumber: pe,
      renderForms: lt,
      renderTextLayer: vt,
      rotate: Ne,
      scale: ri
    } : null
  ), [
    i,
    r,
    c,
    u,
    m,
    S,
    E,
    _,
    x,
    C,
    T,
    D,
    R,
    N,
    q,
    B,
    Y,
    Tt,
    O,
    Nt,
    pe,
    lt,
    vt,
    Ne,
    ri
  ]), P = je(
    () => I0(Ye, () => Tt && (ri ? hg(Tt, ri) : void 0)),
    // biome-ignore lint/correctness/useExhaustiveDependencies: FIXME
    [Ye, Tt, ri]
  ), W = `${Nt}@${ri}/${Ne}`;
  function U() {
    switch (tt) {
      case "custom":
        return Rt(h), K(h, {}, `${W}_custom`);
      case "none":
        return null;
      case "canvas":
      default:
        return K(D1, { canvasRef: a }, `${W}_canvas`);
    }
  }
  function ut() {
    return vt ? K(V1, {}, `${W}_text`) : null;
  }
  function ft() {
    return Xe ? K(T1, {}, `${W}_annotations`) : null;
  }
  function Qt() {
    function jt(ai) {
      return !!(ai != null && ai.page);
    }
    if (!jt(mh))
      throw new Error("page is undefined");
    const ge = typeof o == "function" ? o(mh) : o;
    return le($0.Provider, { value: mh, children: [U(), ut(), ft(), ge] });
  }
  function Ke() {
    return pe ? at === null || Tt === void 0 || Tt === null ? K(Bo, { type: "loading", children: typeof v == "function" ? v() : v }) : at === !1 || Tt === !1 ? K(Bo, { type: "error", children: typeof f == "function" ? f() : f }) : Qt() : K(Bo, { type: "no-data", children: typeof w == "function" ? w() : w });
  }
  return K("div", {
    className: yf(i, l),
    "data-page-number": pe,
    // Assertion is needed for React 18 compatibility
    ref: U0(y, Wt),
    style: {
      "--scale-round-x": "1px",
      "--scale-round-y": "1px",
      "--scale-factor": "1",
      "--user-unit": `${ri}`,
      "--total-scale-factor": "calc(var(--scale-factor) * var(--user-unit))",
      backgroundColor: r || "white",
      position: "relative",
      minWidth: "min-content",
      minHeight: "min-content"
    },
    ...P,
    children: Ke()
  });
}
E1();
ns.workerSrc = "pdf.worker.mjs";
const G1 = /* @__PURE__ */ new Map([
  [
    "bold",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,44H40A20,20,0,0,0,20,64V224A19.82,19.82,0,0,0,31.56,242.1a20.14,20.14,0,0,0,8.49,1.9,19.91,19.91,0,0,0,12.82-4.72l.12-.11L84.47,212H216a20,20,0,0,0,20-20V64A20,20,0,0,0,216,44Zm-4,144H80a11.93,11.93,0,0,0-7.84,2.92L44,215.23V68H212ZM84,108A12,12,0,0,1,96,96h64a12,12,0,1,1,0,24H96A12,12,0,0,1,84,108Zm0,40a12,12,0,0,1,12-12h64a12,12,0,0,1,0,24H96A12,12,0,0,1,84,148Z" }))
  ],
  [
    "duotone",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement(
      "path",
      {
        d: "M224,64V192a8,8,0,0,1-8,8H80L45.15,230.11A8,8,0,0,1,32,224V64a8,8,0,0,1,8-8H216A8,8,0,0,1,224,64Z",
        opacity: "0.2"
      }
    ), /* @__PURE__ */ I.createElement("path", { d: "M216,48H40A16,16,0,0,0,24,64V224a15.85,15.85,0,0,0,9.24,14.5A16.13,16.13,0,0,0,40,240a15.89,15.89,0,0,0,10.25-3.78l.09-.07L83,208H216a16,16,0,0,0,16-16V64A16,16,0,0,0,216,48ZM40,224h0ZM216,192H80a8,8,0,0,0-5.23,1.95L40,224V64H216ZM88,112a8,8,0,0,1,8-8h64a8,8,0,0,1,0,16H96A8,8,0,0,1,88,112Zm0,32a8,8,0,0,1,8-8h64a8,8,0,1,1,0,16H96A8,8,0,0,1,88,144Z" }))
  ],
  [
    "fill",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,48H40A16,16,0,0,0,24,64V224a15.84,15.84,0,0,0,9.25,14.5A16.05,16.05,0,0,0,40,240a15.89,15.89,0,0,0,10.25-3.78l.09-.07L83,208H216a16,16,0,0,0,16-16V64A16,16,0,0,0,216,48ZM160,152H96a8,8,0,0,1,0-16h64a8,8,0,0,1,0,16Zm0-32H96a8,8,0,0,1,0-16h64a8,8,0,0,1,0,16Z" }))
  ],
  [
    "light",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,50H40A14,14,0,0,0,26,64V224a13.88,13.88,0,0,0,8.09,12.69A14.11,14.11,0,0,0,40,238a13.87,13.87,0,0,0,9-3.31l.06-.05L82.23,206H216a14,14,0,0,0,14-14V64A14,14,0,0,0,216,50Zm2,142a2,2,0,0,1-2,2H80a6,6,0,0,0-3.92,1.46L41.26,225.53A2,2,0,0,1,38,224V64a2,2,0,0,1,2-2H216a2,2,0,0,1,2,2Zm-52-80a6,6,0,0,1-6,6H96a6,6,0,0,1,0-12h64A6,6,0,0,1,166,112Zm0,32a6,6,0,0,1-6,6H96a6,6,0,0,1,0-12h64A6,6,0,0,1,166,144Z" }))
  ],
  [
    "regular",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,48H40A16,16,0,0,0,24,64V224a15.85,15.85,0,0,0,9.24,14.5A16.13,16.13,0,0,0,40,240a15.89,15.89,0,0,0,10.25-3.78l.09-.07L83,208H216a16,16,0,0,0,16-16V64A16,16,0,0,0,216,48ZM40,224h0ZM216,192H80a8,8,0,0,0-5.23,1.95L40,224V64H216ZM88,112a8,8,0,0,1,8-8h64a8,8,0,0,1,0,16H96A8,8,0,0,1,88,112Zm0,32a8,8,0,0,1,8-8h64a8,8,0,1,1,0,16H96A8,8,0,0,1,88,144Z" }))
  ],
  [
    "thin",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M216,52H40A12,12,0,0,0,28,64V224a11.89,11.89,0,0,0,6.93,10.88A12.17,12.17,0,0,0,40,236a11.89,11.89,0,0,0,7.69-2.83l0,0L81.49,204H216a12,12,0,0,0,12-12V64A12,12,0,0,0,216,52Zm4,140a4,4,0,0,1-4,4H80a4,4,0,0,0-2.62,1L42.56,227.06A4,4,0,0,1,36,224V64a4,4,0,0,1,4-4H216a4,4,0,0,1,4,4Zm-56-80a4,4,0,0,1-4,4H96a4,4,0,0,1,0-8h64A4,4,0,0,1,164,112Zm0,32a4,4,0,0,1-4,4H96a4,4,0,0,1,0-8h64A4,4,0,0,1,164,144Z" }))
  ]
]), W1 = /* @__PURE__ */ new Map([
  [
    "bold",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M156,112a12,12,0,0,1-12,12H80a12,12,0,0,1,0-24h64A12,12,0,0,1,156,112Zm76.49,120.49a12,12,0,0,1-17,0L168,185a92.12,92.12,0,1,1,17-17l47.54,47.53A12,12,0,0,1,232.49,232.49ZM112,180a68,68,0,1,0-68-68A68.08,68.08,0,0,0,112,180Z" }))
  ],
  [
    "duotone",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M192,112a80,80,0,1,1-80-80A80,80,0,0,1,192,112Z", opacity: "0.2" }), /* @__PURE__ */ I.createElement("path", { d: "M229.66,218.34,179.6,168.28a88.21,88.21,0,1,0-11.32,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Zm112,0a8,8,0,0,1-8,8H80a8,8,0,0,1,0-16h64A8,8,0,0,1,152,112Z" }))
  ],
  [
    "fill",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M229.66,218.34,179.6,168.28a88.21,88.21,0,1,0-11.32,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM144,120H80a8,8,0,0,1,0-16h64a8,8,0,0,1,0,16Z" }))
  ],
  [
    "light",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M150,112a6,6,0,0,1-6,6H80a6,6,0,0,1,0-12h64A6,6,0,0,1,150,112Zm78.24,116.24a6,6,0,0,1-8.48,0l-51.38-51.38a86.15,86.15,0,1,1,8.48-8.48l51.38,51.38A6,6,0,0,1,228.24,228.24ZM112,186a74,74,0,1,0-74-74A74.09,74.09,0,0,0,112,186Z" }))
  ],
  [
    "regular",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M152,112a8,8,0,0,1-8,8H80a8,8,0,0,1,0-16h64A8,8,0,0,1,152,112Zm77.66,117.66a8,8,0,0,1-11.32,0l-50.06-50.07a88.11,88.11,0,1,1,11.31-11.31l50.07,50.06A8,8,0,0,1,229.66,229.66ZM112,184a72,72,0,1,0-72-72A72.08,72.08,0,0,0,112,184Z" }))
  ],
  [
    "thin",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M148,112a4,4,0,0,1-4,4H80a4,4,0,0,1,0-8h64A4,4,0,0,1,148,112Zm78.83,114.83a4,4,0,0,1-5.66,0l-52.7-52.7a84.1,84.1,0,1,1,5.66-5.66l52.7,52.7A4,4,0,0,1,226.83,226.83ZM112,188a76,76,0,1,0-76-76A76.08,76.08,0,0,0,112,188Z" }))
  ]
]), j1 = /* @__PURE__ */ new Map([
  [
    "bold",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M156,112a12,12,0,0,1-12,12H124v20a12,12,0,0,1-24,0V124H80a12,12,0,0,1,0-24h20V80a12,12,0,0,1,24,0v20h20A12,12,0,0,1,156,112Zm76.49,120.49a12,12,0,0,1-17,0L168,185a92.12,92.12,0,1,1,17-17l47.54,47.53A12,12,0,0,1,232.49,232.49ZM112,180a68,68,0,1,0-68-68A68.08,68.08,0,0,0,112,180Z" }))
  ],
  [
    "duotone",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M192,112a80,80,0,1,1-80-80A80,80,0,0,1,192,112Z", opacity: "0.2" }), /* @__PURE__ */ I.createElement("path", { d: "M229.66,218.34,179.6,168.28a88.21,88.21,0,1,0-11.32,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Zm112,0a8,8,0,0,1-8,8H120v24a8,8,0,0,1-16,0V120H80a8,8,0,0,1,0-16h24V80a8,8,0,0,1,16,0v24h24A8,8,0,0,1,152,112Z" }))
  ],
  [
    "fill",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M229.66,218.34,179.6,168.28a88.21,88.21,0,1,0-11.32,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM144,120H120v24a8,8,0,0,1-16,0V120H80a8,8,0,0,1,0-16h24V80a8,8,0,0,1,16,0v24h24a8,8,0,0,1,0,16Z" }))
  ],
  [
    "light",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M150,112a6,6,0,0,1-6,6H118v26a6,6,0,0,1-12,0V118H80a6,6,0,0,1,0-12h26V80a6,6,0,0,1,12,0v26h26A6,6,0,0,1,150,112Zm78.24,116.24a6,6,0,0,1-8.48,0l-51.38-51.38a86.15,86.15,0,1,1,8.48-8.48l51.38,51.38A6,6,0,0,1,228.24,228.24ZM112,186a74,74,0,1,0-74-74A74.09,74.09,0,0,0,112,186Z" }))
  ],
  [
    "regular",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M152,112a8,8,0,0,1-8,8H120v24a8,8,0,0,1-16,0V120H80a8,8,0,0,1,0-16h24V80a8,8,0,0,1,16,0v24h24A8,8,0,0,1,152,112Zm77.66,117.66a8,8,0,0,1-11.32,0l-50.06-50.07a88.11,88.11,0,1,1,11.31-11.31l50.07,50.06A8,8,0,0,1,229.66,229.66ZM112,184a72,72,0,1,0-72-72A72.08,72.08,0,0,0,112,184Z" }))
  ],
  [
    "thin",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M148,112a4,4,0,0,1-4,4H116v28a4,4,0,0,1-8,0V116H80a4,4,0,0,1,0-8h28V80a4,4,0,0,1,8,0v28h28A4,4,0,0,1,148,112Zm78.83,114.83a4,4,0,0,1-5.66,0l-52.7-52.7a84.1,84.1,0,1,1,5.66-5.66l52.7,52.7A4,4,0,0,1,226.83,226.83ZM112,188a76,76,0,1,0-76-76A76.08,76.08,0,0,0,112,188Z" }))
  ]
]), q1 = /* @__PURE__ */ new Map([
  [
    "bold",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M208.49,191.51a12,12,0,0,1-17,17L128,145,64.49,208.49a12,12,0,0,1-17-17L111,128,47.51,64.49a12,12,0,0,1,17-17L128,111l63.51-63.52a12,12,0,0,1,17,17L145,128Z" }))
  ],
  [
    "duotone",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement(
      "path",
      {
        d: "M216,56V200a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V56A16,16,0,0,1,56,40H200A16,16,0,0,1,216,56Z",
        opacity: "0.2"
      }
    ), /* @__PURE__ */ I.createElement("path", { d: "M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z" }))
  ],
  [
    "fill",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM181.66,170.34a8,8,0,0,1-11.32,11.32L128,139.31,85.66,181.66a8,8,0,0,1-11.32-11.32L116.69,128,74.34,85.66A8,8,0,0,1,85.66,74.34L128,116.69l42.34-42.35a8,8,0,0,1,11.32,11.32L139.31,128Z" }))
  ],
  [
    "light",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M204.24,195.76a6,6,0,1,1-8.48,8.48L128,136.49,60.24,204.24a6,6,0,0,1-8.48-8.48L119.51,128,51.76,60.24a6,6,0,0,1,8.48-8.48L128,119.51l67.76-67.75a6,6,0,0,1,8.48,8.48L136.49,128Z" }))
  ],
  [
    "regular",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z" }))
  ],
  [
    "thin",
    /* @__PURE__ */ I.createElement(I.Fragment, null, /* @__PURE__ */ I.createElement("path", { d: "M202.83,197.17a4,4,0,0,1-5.66,5.66L128,133.66,58.83,202.83a4,4,0,0,1-5.66-5.66L122.34,128,53.17,58.83a4,4,0,0,1,5.66-5.66L128,122.34l69.17-69.17a4,4,0,1,1,5.66,5.66L133.66,128Z" }))
  ]
]), X1 = cg({
  color: "currentColor",
  size: "1em",
  weight: "regular",
  mirrored: !1
}), $d = I.forwardRef(
  (d, t) => {
    const {
      alt: e,
      color: i,
      size: s,
      weight: r,
      mirrored: a,
      children: o,
      weights: l,
      ...h
    } = d, {
      color: c = "currentColor",
      size: u,
      weight: f = "regular",
      mirrored: m = !1,
      ...A
    } = I.useContext(X1);
    return /* @__PURE__ */ I.createElement(
      "svg",
      {
        ref: t,
        xmlns: "http://www.w3.org/2000/svg",
        width: s ?? u,
        height: s ?? u,
        fill: i ?? c,
        viewBox: "0 0 256 256",
        transform: a || m ? "scale(-1, 1)" : void 0,
        ...A,
        ...h
      },
      !!e && /* @__PURE__ */ I.createElement("title", null, e),
      o,
      l.get(r ?? f)
    );
  }
);
$d.displayName = "IconBase";
const X0 = I.forwardRef((d, t) => /* @__PURE__ */ I.createElement($d, { ref: t, ...d, weights: G1 }));
X0.displayName = "ChatTextIcon";
const Y0 = I.forwardRef((d, t) => /* @__PURE__ */ I.createElement($d, { ref: t, ...d, weights: W1 }));
Y0.displayName = "MagnifyingGlassMinusIcon";
const K0 = I.forwardRef((d, t) => /* @__PURE__ */ I.createElement($d, { ref: t, ...d, weights: j1 }));
K0.displayName = "MagnifyingGlassPlusIcon";
const Z0 = I.forwardRef((d, t) => /* @__PURE__ */ I.createElement($d, { ref: t, ...d, weights: q1 }));
Z0.displayName = "XIcon";
const Y1 = `:root{--react-pdf-annotation-layer: 1;--annotation-unfocused-field-background: url("data:image/svg+xml;charset=UTF-8,<svg width='1px' height='1px' xmlns='http://www.w3.org/2000/svg'><rect width='100%' height='100%' style='fill:rgba(0, 54, 255, 0.13);'/></svg>");--input-focus-border-color: Highlight;--input-focus-outline: 1px solid Canvas;--input-unfocused-border-color: transparent;--input-disabled-border-color: transparent;--input-hover-border-color: black;--link-outline: none}@media screen and (forced-colors:active){:root{--input-focus-border-color: CanvasText;--input-unfocused-border-color: ActiveText;--input-disabled-border-color: GrayText;--input-hover-border-color: Highlight;--link-outline: 1.5px solid LinkText}.annotationLayer .textWidgetAnnotation :is(input,textarea):required,.annotationLayer .choiceWidgetAnnotation select:required,.annotationLayer .buttonWidgetAnnotation:is(.checkBox,.radioButton) input:required{outline:1.5px solid selectedItem}.annotationLayer .linkAnnotation:hover{-webkit-backdrop-filter:invert(100%);backdrop-filter:invert(100%)}}.annotationLayer{position:absolute;top:0;left:0;pointer-events:none;transform-origin:0 0;z-index:3}.annotationLayer[data-main-rotation="90"] .norotate{transform:rotate(270deg) translate(-100%)}.annotationLayer[data-main-rotation="180"] .norotate{transform:rotate(180deg) translate(-100%,-100%)}.annotationLayer[data-main-rotation="270"] .norotate{transform:rotate(90deg) translateY(-100%)}.annotationLayer canvas{position:absolute;width:100%;height:100%}.annotationLayer section{position:absolute;text-align:initial;pointer-events:auto;box-sizing:border-box;margin:0;transform-origin:0 0}.annotationLayer .linkAnnotation{outline:var(--link-outline)}.textLayer.selecting~.annotationLayer section{pointer-events:none}.annotationLayer :is(.linkAnnotation,.buttonWidgetAnnotation.pushButton)>a{position:absolute;font-size:1em;top:0;left:0;width:100%;height:100%}.annotationLayer :is(.linkAnnotation,.buttonWidgetAnnotation.pushButton)>a:hover{opacity:.2;background:#ff0;box-shadow:0 2px 10px #ff0}.annotationLayer .textAnnotation img{position:absolute;cursor:pointer;width:100%;height:100%;top:0;left:0}.annotationLayer .textWidgetAnnotation :is(input,textarea),.annotationLayer .choiceWidgetAnnotation select,.annotationLayer .buttonWidgetAnnotation:is(.checkBox,.radioButton) input{background-image:var(--annotation-unfocused-field-background);border:2px solid var(--input-unfocused-border-color);box-sizing:border-box;font:calc(9px * var(--total-scale-factor)) sans-serif;height:100%;margin:0;vertical-align:top;width:100%}.annotationLayer .textWidgetAnnotation :is(input,textarea):required,.annotationLayer .choiceWidgetAnnotation select:required,.annotationLayer .buttonWidgetAnnotation:is(.checkBox,.radioButton) input:required{outline:1.5px solid red}.annotationLayer .choiceWidgetAnnotation select option{padding:0}.annotationLayer .buttonWidgetAnnotation.radioButton input{border-radius:50%}.annotationLayer .textWidgetAnnotation textarea{resize:none}.annotationLayer .textWidgetAnnotation :is(input,textarea)[disabled],.annotationLayer .choiceWidgetAnnotation select[disabled],.annotationLayer .buttonWidgetAnnotation:is(.checkBox,.radioButton) input[disabled]{background:none;border:2px solid var(--input-disabled-border-color);cursor:not-allowed}.annotationLayer .textWidgetAnnotation :is(input,textarea):hover,.annotationLayer .choiceWidgetAnnotation select:hover,.annotationLayer .buttonWidgetAnnotation:is(.checkBox,.radioButton) input:hover{border:2px solid var(--input-hover-border-color)}.annotationLayer .textWidgetAnnotation :is(input,textarea):hover,.annotationLayer .choiceWidgetAnnotation select:hover,.annotationLayer .buttonWidgetAnnotation.checkBox input:hover{border-radius:2px}.annotationLayer .textWidgetAnnotation :is(input,textarea):focus,.annotationLayer .choiceWidgetAnnotation select:focus{background:none;border:2px solid var(--input-focus-border-color);border-radius:2px;outline:var(--input-focus-outline)}.annotationLayer .buttonWidgetAnnotation:is(.checkBox,.radioButton) :focus{background-image:none;background-color:transparent}.annotationLayer .buttonWidgetAnnotation.checkBox :focus{border:2px solid var(--input-focus-border-color);border-radius:2px;outline:var(--input-focus-outline)}.annotationLayer .buttonWidgetAnnotation.radioButton :focus{border:2px solid var(--input-focus-border-color);outline:var(--input-focus-outline)}.annotationLayer .buttonWidgetAnnotation.checkBox input:checked:before,.annotationLayer .buttonWidgetAnnotation.checkBox input:checked:after,.annotationLayer .buttonWidgetAnnotation.radioButton input:checked:before{background-color:CanvasText;content:"";display:block;position:absolute}.annotationLayer .buttonWidgetAnnotation.checkBox input:checked:before,.annotationLayer .buttonWidgetAnnotation.checkBox input:checked:after{height:80%;left:45%;width:1px}.annotationLayer .buttonWidgetAnnotation.checkBox input:checked:before{transform:rotate(45deg)}.annotationLayer .buttonWidgetAnnotation.checkBox input:checked:after{transform:rotate(-45deg)}.annotationLayer .buttonWidgetAnnotation.radioButton input:checked:before{border-radius:50%;height:50%;left:30%;top:20%;width:50%}.annotationLayer .textWidgetAnnotation input.comb{font-family:monospace;padding-left:2px;padding-right:0}.annotationLayer .textWidgetAnnotation input.comb:focus{width:103%}.annotationLayer .buttonWidgetAnnotation:is(.checkBox,.radioButton) input{-webkit-appearance:none;-moz-appearance:none;appearance:none}.annotationLayer .popupTriggerArea{height:100%;width:100%}.annotationLayer .fileAttachmentAnnotation .popupTriggerArea{position:absolute}.annotationLayer .popupWrapper{position:absolute;font-size:calc(9px * var(--total-scale-factor));width:100%;min-width:calc(180px * var(--total-scale-factor));pointer-events:none}.annotationLayer .popup{position:absolute;max-width:calc(180px * var(--total-scale-factor));background-color:#ff9;box-shadow:0 calc(2px * var(--total-scale-factor)) calc(5px * var(--total-scale-factor)) #888;border-radius:calc(2px * var(--total-scale-factor));padding:calc(6px * var(--total-scale-factor));margin-left:calc(5px * var(--total-scale-factor));cursor:pointer;font:message-box;white-space:normal;word-wrap:break-word;pointer-events:auto}.annotationLayer .popup>*{font-size:calc(9px * var(--total-scale-factor))}.annotationLayer .popup h1{display:inline-block}.annotationLayer .popupDate{display:inline-block;margin-left:calc(5px * var(--total-scale-factor))}.annotationLayer .popupContent{border-top:1px solid rgba(51,51,51,1);margin-top:calc(2px * var(--total-scale-factor));padding-top:calc(2px * var(--total-scale-factor))}.annotationLayer .richText>*{white-space:pre-wrap;font-size:calc(9px * var(--total-scale-factor))}.annotationLayer .highlightAnnotation,.annotationLayer .underlineAnnotation,.annotationLayer .squigglyAnnotation,.annotationLayer .strikeoutAnnotation,.annotationLayer .freeTextAnnotation,.annotationLayer .lineAnnotation svg line,.annotationLayer .squareAnnotation svg rect,.annotationLayer .circleAnnotation svg ellipse,.annotationLayer .polylineAnnotation svg polyline,.annotationLayer .polygonAnnotation svg polygon,.annotationLayer .caretAnnotation,.annotationLayer .inkAnnotation svg polyline,.annotationLayer .stampAnnotation,.annotationLayer .fileAttachmentAnnotation{cursor:pointer}.annotationLayer section svg{position:absolute;width:100%;height:100%;top:0;left:0}.annotationLayer .annotationTextContent{position:absolute;width:100%;height:100%;opacity:0;color:transparent;-webkit-user-select:none;user-select:none;pointer-events:none}.annotationLayer .annotationTextContent span{width:100%;display:inline-block}`, K1 = ':root{--react-pdf-text-layer: 1;--highlight-bg-color: rgba(180, 0, 170, 1);--highlight-selected-bg-color: rgba(0, 100, 0, 1)}@media screen and (forced-colors:active){:root{--highlight-bg-color: Highlight;--highlight-selected-bg-color: ButtonText}}[data-main-rotation="90"]{transform:rotate(90deg) translateY(-100%)}[data-main-rotation="180"]{transform:rotate(180deg) translate(-100%,-100%)}[data-main-rotation="270"]{transform:rotate(270deg) translate(-100%)}.textLayer{position:absolute;text-align:initial;top:0;right:0;bottom:0;left:0;overflow:hidden;line-height:1;text-size-adjust:none;forced-color-adjust:none;transform-origin:0 0;z-index:2}.textLayer :is(span,br){color:transparent;position:absolute;white-space:pre;cursor:text;margin:0;transform-origin:0 0}.textLayer span.markedContent{top:0;height:0}.textLayer .highlight{margin:-1px;padding:1px;background-color:var(--highlight-bg-color);border-radius:4px}.textLayer .highlight.appended{position:initial}.textLayer .highlight.begin{border-radius:4px 0 0 4px}.textLayer .highlight.end{border-radius:0 4px 4px 0}.textLayer .highlight.middle{border-radius:0}.textLayer .highlight.selected{background-color:var(--highlight-selected-bg-color)}.textLayer br::selection{background:transparent}.textLayer .endOfContent{display:block;position:absolute;top:100%;right:0;bottom:0;left:0;z-index:-1;cursor:default;-webkit-user-select:none;user-select:none}.textLayer.selecting .endOfContent{top:0}.hiddenCanvasElement{position:absolute;top:0;left:0;width:0;height:0;display:none}';
ns.workerSrc = `https://unpkg.com/pdfjs-dist@${Kh}/build/pdf.worker.min.mjs`;
function Z1(d) {
  function t(l, h) {
    const c = h.startsWith(l + "/") ? h.slice(l.length + 1) : h;
    return `${l}/.quipu/meta/${c}.frame.json`;
  }
  function e(l, h) {
    const c = h.startsWith(l + "/") ? h.slice(l.length + 1) : h;
    return {
      version: 1,
      type: "frame",
      id: crypto.randomUUID(),
      filePath: c,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      annotations: [],
      instructions: "",
      history: []
    };
  }
  async function i(l, h) {
    try {
      const c = await d.readFile(t(l, h));
      return c ? JSON.parse(c) : null;
    } catch {
      return null;
    }
  }
  async function s(l, h, c) {
    const u = t(l, h);
    try {
      await d.createFolder(u.substring(0, u.lastIndexOf("/")));
    } catch {
    }
    c.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), await d.writeFile(u, JSON.stringify(c, null, 2));
  }
  async function r(l, h, c) {
    let u = await i(l, h);
    u || (u = e(l, h)), u.annotations.push({ ...c, timestamp: (/* @__PURE__ */ new Date()).toISOString() }), await s(l, h, u);
  }
  async function a(l, h, c, u) {
    const f = await i(l, h);
    if (!f) return;
    const m = f.annotations.find((A) => A.id === c);
    m && (m.type = u, await s(l, h, f));
  }
  async function o(l, h, c) {
    const u = await i(l, h);
    u && (u.annotations = u.annotations.filter((f) => f.id !== c), await s(l, h, u));
  }
  return { readFrame: i, addAnnotation: r, updateAnnotationType: a, removeAnnotation: o };
}
const mm = ["comment", "review", "todo", "bug", "question", "instruction"], bm = {
  comment: "bg-text-tertiary/20 text-text-secondary",
  review: "bg-accent/20 text-accent",
  todo: "bg-info/20 text-info",
  bug: "bg-error/20 text-error",
  question: "bg-warning/20 text-warning",
  instruction: "bg-success/20 text-success"
}, Nf = 5, Of = 1056, J1 = 24, Q1 = {
  cMapUrl: `https://unpkg.com/pdfjs-dist@${Kh}/cmaps/`,
  cMapPacked: !0,
  standardFontDataUrl: `https://unpkg.com/pdfjs-dist@${Kh}/standard_fonts/`
}, tw = ({ tab: d, workspacePath: t, fileSystem: e }) => {
  const i = d.path, s = je(() => Z1(e), [e]), [r, a] = Ce(null), [o, l] = Ce(1), [h, c] = Ce(100), [u, f] = Ce(0), [m, A] = Ce("1"), [y, v] = Ce(/* @__PURE__ */ new Set([1])), [w, S] = Ce({}), [E, _] = Ce([]), [x, C] = Ce(!1), [T, L] = Ce(""), [k, D] = Ce(0), [R, N] = Ce(null), [q, B] = Ce("comment"), [Y, O] = Ce(!1), [H, it] = Ce({ top: 0, left: 0 }), [at, Jt] = Ce({}), [Xe, lt] = Ce({}), tt = ss(null), vt = ss({}), se = ss({}), fe = je(() => e.getFileUrl(i), [e, i]);
  bt(() => {
    for (const [P, W] of [
      ["pdf-plugin-annotation-layer", Y1],
      ["pdf-plugin-text-layer", K1]
    ])
      if (!document.getElementById(P)) {
        const U = document.createElement("style");
        U.id = P, U.textContent = W, document.head.appendChild(U);
      }
  }, []), bt(() => {
    const P = tt.current;
    if (!P) return;
    const W = () => f(P.clientWidth);
    W();
    const U = new ResizeObserver(W);
    return U.observe(P), () => U.disconnect();
  }, []);
  const ct = je(() => {
    if (!u) return 612;
    const P = u > 900 ? 340 : 0;
    return Math.max(300, (u - 48 - P) * h / 100);
  }, [u, h]), bi = je(() => {
    const P = /* @__PURE__ */ new Set();
    for (const W of y)
      for (let U = Math.max(1, W - Nf); U <= Math.min(r || 1, W + Nf); U++) P.add(U);
    return P;
  }, [y, r]), Ye = je(() => E.filter((P) => y.has(P.page)), [E, y]), Vi = Se(async () => {
    var P;
    if (!(!t || !i))
      try {
        const W = await s.readFrame(t, i);
        _(((P = W == null ? void 0 : W.annotations) == null ? void 0 : P.filter((U) => U.page != null).map((U) => ({
          id: U.id,
          page: U.page,
          selectedText: U.selectedText,
          topRatio: U.topRatio,
          text: U.text,
          type: U.type || "comment",
          author: U.author,
          timestamp: U.timestamp
        }))) ?? []);
      } catch {
        _([]);
      }
  }, [t, i, s]);
  bt(() => {
    Vi();
  }, [Vi]), bt(() => {
    if (!r || !tt.current) return;
    const P = new IntersectionObserver(
      (W) => v((U) => {
        const ut = new Set(U);
        for (const ft of W) {
          const Qt = parseInt(ft.target.dataset.pageNumber || "0", 10);
          ft.isIntersecting ? ut.add(Qt) : ut.delete(Qt);
        }
        return ut;
      }),
      { root: tt.current, rootMargin: "200px 0px", threshold: 0.01 }
    );
    for (let W = 1; W <= r; W++) {
      const U = vt.current[W];
      U && P.observe(U);
    }
    return () => P.disconnect();
  }, [r]), bt(() => {
    const P = tt.current;
    if (!P || !r) return;
    const W = () => {
      const U = P.getBoundingClientRect().top + P.getBoundingClientRect().height / 2;
      let ut = 1, ft = 1 / 0;
      for (let Qt = 1; Qt <= r; Qt++) {
        const Ke = vt.current[Qt];
        if (!Ke) continue;
        const jt = Ke.getBoundingClientRect(), ge = Math.abs(jt.top + jt.height / 2 - U);
        ge < ft && (ft = ge, ut = Qt);
      }
      l(ut), A(String(ut));
    };
    return P.addEventListener("scroll", W, { passive: !0 }), () => P.removeEventListener("scroll", W);
  }, [r]), bt(() => {
    if (!Ye.length) {
      Jt({}), lt({});
      return;
    }
    const P = setTimeout(() => {
      const W = {}, U = {}, ut = {};
      for (const ft of Ye)
        ut[ft.page] || (ut[ft.page] = []), ut[ft.page].push(ft);
      for (const [ft, Qt] of Object.entries(ut)) {
        const Ke = parseInt(ft, 10), jt = vt.current[Ke];
        if (!jt) continue;
        const ge = jt.querySelector(".react-pdf__Page"), ai = (ge == null ? void 0 : ge.offsetHeight) || Of, zi = jt.getBoundingClientRect();
        let Xn = 0;
        [...Qt].sort((yi, Oe) => (yi.topRatio || 0) - (Oe.topRatio || 0)).forEach((yi) => {
          var Yn;
          let Oe = jt.offsetTop + (yi.topRatio || 0) * ai;
          const xf = ((Yn = se.current[yi.id]) == null ? void 0 : Yn.offsetHeight) || 80;
          Oe < Xn + 12 && (Oe = Xn + 12), W[yi.id] = Oe, Xn = Oe + xf;
        });
        const Yr = ge == null ? void 0 : ge.querySelector(".react-pdf__Page__textContent");
        if (!Yr) continue;
        const J0 = Array.from(Yr.querySelectorAll("span")), _f = [];
        let Kr = "";
        for (const yi of J0) {
          const Oe = yi.textContent || "";
          Oe && (Kr.length > 0 && !Kr.endsWith(" ") && !Oe.startsWith(" ") && (Kr += " "), _f.push({ span: yi, start: Kr.length, end: Kr.length + Oe.length }), Kr += Oe);
        }
        Qt.forEach((yi) => {
          if (!yi.selectedText) return;
          const Oe = yi.selectedText.replace(/\s+/g, " ").trim();
          if (!Oe) return;
          const xf = (yi.topRatio || 0) * ai, Yn = [];
          let Vd = 0;
          for (; (Vd = Kr.indexOf(Oe, Vd)) !== -1; )
            Yn.push(Vd), Vd += Oe.length;
          if (!Yn.length) return;
          let zd = Yn[0];
          if (Yn.length > 1) {
            let tn = 1 / 0;
            for (const en of Yn) {
              const bh = _f.find((Zr) => Zr.start <= en && en < Zr.end);
              if (!bh) continue;
              const Wd = bh.span.getBoundingClientRect().top - zi.top, os = Math.abs(Wd - xf);
              os < tn && (tn = os, zd = en);
            }
          }
          const Mg = zd + Oe.length, Gd = [];
          for (const tn of _f) {
            if (tn.end <= zd || tn.start >= Mg) continue;
            const en = tn.span.firstChild;
            if (!en || en.nodeType !== Node.TEXT_NODE) continue;
            const bh = Math.max(0, zd - tn.start), Wd = Math.min(en.length, Mg - tn.start);
            if (!(bh >= Wd))
              try {
                const os = document.createRange();
                os.setStart(en, bh), os.setEnd(en, Wd);
                for (const Zr of os.getClientRects())
                  Gd.push({ top: Zr.top - zi.top, left: Zr.left - zi.left, width: Zr.width, height: Zr.height });
              } catch {
                const os = tn.span.getBoundingClientRect();
                Gd.push({ top: os.top - zi.top, left: os.left - zi.left, width: os.width, height: os.height });
              }
          }
          Gd.length && (U[yi.id] = { rects: Gd, pageNum: Ke });
        });
      }
      Jt(W), lt(U);
    }, 350);
    return () => clearTimeout(P);
  }, [Ye, ct, y]);
  const xe = Se(({ numPages: P }) => {
    a(P), l(1), A("1");
    const W = /* @__PURE__ */ new Set();
    for (let U = 1; U <= Math.min(P, 1 + Nf); U++) W.add(U);
    v(W);
  }, []), Tt = Se(
    (P) => (W) => S((U) => ({ ...U, [P]: { width: W.width, height: W.height } })),
    []
  ), Pt = Se((P) => {
    var W;
    (W = vt.current[P]) == null || W.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []), Wt = Se(() => {
    const P = parseInt(m, 10);
    P >= 1 && P <= (r || 1) ? Pt(P) : A(String(o));
  }, [m, r, o, Pt]);
  bt(() => {
    const P = tt.current;
    if (!P) return;
    const W = (U) => {
      if (!U.ctrlKey) return;
      U.preventDefault();
      const ut = P.scrollHeight > 0 ? P.scrollTop / P.scrollHeight : 0;
      c((ft) => {
        const Qt = Math.min(300, Math.max(30, ft + (U.deltaY > 0 ? -10 : 10)));
        return requestAnimationFrame(() => {
          P.scrollTop = ut * P.scrollHeight;
        }), Qt;
      });
    };
    return P.addEventListener("wheel", W, { passive: !1 }), () => P.removeEventListener("wheel", W);
  }, []);
  const Nt = Se(() => {
    const P = window.getSelection(), W = P == null ? void 0 : P.toString().replace(/\s+/g, " ").trim();
    if (!W || !tt.current) {
      O(!1);
      return;
    }
    let U = null, ut = null;
    for (let Xn = 1; Xn <= (r || 0); Xn++) {
      const Yr = vt.current[Xn];
      if (Yr != null && Yr.contains(P.anchorNode)) {
        U = Xn, ut = Yr;
        break;
      }
    }
    if (!U || !ut) {
      O(!1);
      return;
    }
    const ft = P.getRangeAt(0), Qt = ft.getBoundingClientRect(), Ke = ut.getBoundingClientRect(), jt = ut.querySelector(".react-pdf__Page"), ge = (jt == null ? void 0 : jt.offsetHeight) || Ke.height || Of, ai = Qt.top - Ke.top, zi = tt.current.getBoundingClientRect();
    it({ top: Qt.top - zi.top + tt.current.scrollTop - 36, left: Qt.left - zi.left + Qt.width / 2 - 16 }), N({ text: W, topRatio: ai / ge, relativeTop: ai, page: U }), O(!0);
  }, [r]), pe = Se(() => {
    if (!R) return;
    const P = vt.current[R.page];
    P && (D(P.offsetTop + R.relativeTop), C(!0), O(!1));
  }, [R]), Ne = Se(async () => {
    var U;
    if (!T.trim() || !R || !t || !i) return;
    const P = crypto.randomUUID(), W = {
      id: P,
      page: R.page,
      selectedText: R.text,
      topRatio: R.topRatio,
      text: T.trim(),
      type: q,
      author: "user",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    _((ut) => [...ut, W]), s.addAnnotation(t, i, {
      id: P,
      page: W.page,
      selectedText: W.selectedText,
      topRatio: W.topRatio,
      text: W.text,
      type: W.type,
      author: "user"
    }).catch((ut) => console.warn("PDF comment sync failed:", ut)), L(""), B("comment"), C(!1), N(null), (U = window.getSelection()) == null || U.removeAllRanges();
  }, [T, q, R, t, i, s]), ri = Se(() => {
    L(""), B("comment"), C(!1), N(null);
  }, []), Ef = Se(async (P, W) => {
    _((U) => U.map((ut) => ut.id === P ? { ...ut, type: W } : ut)), t && i && s.updateAnnotationType(t, i, P, W).catch(console.warn);
  }, [t, i, s]), Sf = Se(async (P) => {
    _((W) => W.filter((U) => U.id !== P)), t && i && s.removeAnnotation(t, i, P).catch(console.warn);
  }, [t, i, s]), mh = Se((P) => {
    const W = w[P];
    return W ? ct * (W.height / W.width) : ct * (11 / 8.5);
  }, [w, ct]);
  return /* @__PURE__ */ le("div", { className: "flex-1 flex flex-col overflow-hidden bg-bg-surface", children: [
    /* @__PURE__ */ le("div", { className: "flex items-center justify-center gap-4 px-4 py-2 bg-bg-elevated border-b border-border", children: [
      /* @__PURE__ */ le("div", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ K(
          "input",
          {
            type: "text",
            value: m,
            onChange: (P) => A(P.target.value),
            onBlur: Wt,
            onKeyDown: (P) => {
              P.key === "Enter" && Wt();
            },
            className: "w-10 text-center text-sm text-text-primary bg-bg-surface border border-border rounded px-1 py-0.5 outline-none focus:border-accent"
          }
        ),
        /* @__PURE__ */ le("span", { className: "text-sm text-text-secondary", children: [
          "/ ",
          r || "..."
        ] })
      ] }),
      /* @__PURE__ */ K("div", { className: "w-px h-4 bg-border" }),
      /* @__PURE__ */ K("button", { onClick: () => c((P) => Math.max(30, P - 10)), className: "p-1 rounded hover:bg-white/[0.06] text-text-secondary", children: /* @__PURE__ */ K(Y0, { size: 18 }) }),
      /* @__PURE__ */ le("span", { className: "text-xs text-text-tertiary w-12 text-center", children: [
        h,
        "%"
      ] }),
      /* @__PURE__ */ K("button", { onClick: () => c((P) => Math.min(300, P + 10)), className: "p-1 rounded hover:bg-white/[0.06] text-text-secondary", children: /* @__PURE__ */ K(K0, { size: 18 }) })
    ] }),
    /* @__PURE__ */ K(
      "div",
      {
        className: "flex-1 overflow-auto py-6 [&::-webkit-scrollbar]:w-2.5 [&::-webkit-scrollbar-thumb]:bg-white/15",
        ref: tt,
        onMouseUp: Nt,
        children: /* @__PURE__ */ le("div", { className: "relative flex flex-col items-center min-w-fit", children: [
          /* @__PURE__ */ K(
            C1,
            {
              file: fe,
              onLoadSuccess: xe,
              options: Q1,
              loading: /* @__PURE__ */ K("div", { className: "text-text-tertiary text-sm p-8", children: "Loading PDF..." }),
              error: /* @__PURE__ */ K("div", { className: "text-error text-sm p-8", children: "Failed to load PDF." }),
              children: r && Array.from({ length: r }, (P, W) => {
                const U = W + 1, ut = bi.has(U);
                return /* @__PURE__ */ le(
                  "div",
                  {
                    ref: (ft) => {
                      vt.current[U] = ft;
                    },
                    "data-page-number": U,
                    className: "relative",
                    style: { marginBottom: J1 },
                    children: [
                      ut ? /* @__PURE__ */ K(
                        z1,
                        {
                          pageNumber: U,
                          width: ct,
                          devicePixelRatio: Math.max(window.devicePixelRatio * 1.5 || 2, 100 / h * (window.devicePixelRatio * 1.5 || 2)),
                          className: "shadow-lg",
                          onLoadSuccess: Tt(U),
                          error: /* @__PURE__ */ le("div", { className: "p-4 text-error text-sm", children: [
                            "Failed to render page ",
                            U
                          ] })
                        }
                      ) : /* @__PURE__ */ le(
                        "div",
                        {
                          className: "bg-bg-elevated shadow-lg flex items-center justify-center text-text-tertiary text-sm",
                          style: { width: ct, height: mh(U) },
                          children: [
                            "Page ",
                            U
                          ]
                        }
                      ),
                      Object.entries(Xe).filter(([, ft]) => ft.pageNum === U).map(([ft, Qt]) => Qt.rects.map((Ke, jt) => /* @__PURE__ */ K(
                        "div",
                        {
                          className: "absolute bg-accent/20 pointer-events-none rounded-sm",
                          style: { top: Ke.top, left: Ke.left, width: Ke.width, height: Ke.height }
                        },
                        `hl-${ft}-${jt}`
                      )))
                    ]
                  },
                  U
                );
              })
            }
          ),
          Y && /* @__PURE__ */ K(
            "button",
            {
              className: "absolute z-50 p-1.5 rounded-lg bg-accent text-white shadow-lg hover:bg-accent-hover transition-colors",
              style: { top: H.top, left: H.left },
              onMouseDown: (P) => P.preventDefault(),
              onClick: pe,
              title: "Add comment",
              children: /* @__PURE__ */ K(X0, { size: 18 })
            }
          ),
          /* @__PURE__ */ le(
            "div",
            {
              className: "absolute top-0 bottom-0 w-[300px] pointer-events-none",
              style: { left: `calc(50% + ${ct / 2}px + 16px)` },
              children: [
                x && /* @__PURE__ */ le(
                  "div",
                  {
                    className: "absolute w-[280px] bg-bg-surface rounded-lg shadow-lg p-3 pointer-events-auto border border-accent z-[100]",
                    style: { top: k },
                    children: [
                      /* @__PURE__ */ K(
                        "textarea",
                        {
                          value: T,
                          onChange: (P) => L(P.target.value),
                          onKeyDown: (P) => {
                            (P.ctrlKey || P.metaKey || P.shiftKey) && P.key === "Enter" && (P.preventDefault(), Ne()), P.key === "Escape" && ri();
                          },
                          placeholder: "Type your comment...",
                          autoFocus: !0,
                          className: "w-full border border-border rounded py-2 px-2 font-[inherit] text-sm resize-y min-h-[60px] outline-none mb-2 text-page-text focus:border-accent"
                        }
                      ),
                      /* @__PURE__ */ le("div", { className: "flex items-center justify-between gap-2", children: [
                        /* @__PURE__ */ K(
                          "select",
                          {
                            value: q,
                            onChange: (P) => B(P.target.value),
                            className: "text-[11px] bg-bg-elevated border border-border rounded px-1.5 py-1 text-text-secondary outline-none cursor-pointer",
                            children: mm.map((P) => /* @__PURE__ */ K("option", { value: P, children: P }, P))
                          }
                        ),
                        /* @__PURE__ */ le("div", { className: "flex gap-2", children: [
                          /* @__PURE__ */ K("button", { onClick: ri, onMouseDown: (P) => P.preventDefault(), className: "py-1.5 px-3 rounded text-[13px] font-medium bg-transparent text-text-tertiary hover:bg-bg-elevated", children: "Cancel" }),
                          /* @__PURE__ */ K("button", { onClick: Ne, onMouseDown: (P) => P.preventDefault(), className: "py-1.5 px-3 rounded text-[13px] font-medium bg-accent text-white hover:bg-accent-hover", children: "Comment" })
                        ] })
                      ] })
                    ]
                  }
                ),
                Ye.map((P) => {
                  var W, U, ut;
                  return /* @__PURE__ */ le(
                    "div",
                    {
                      ref: (ft) => {
                        se.current[P.id] = ft;
                      },
                      className: "absolute w-[280px] bg-bg-surface rounded-lg shadow-md p-3 pointer-events-auto border border-transparent hover:shadow-lg",
                      style: {
                        top: at[P.id] !== void 0 ? at[P.id] : (((W = vt.current[P.page]) == null ? void 0 : W.offsetTop) || 0) + (P.topRatio || 0) * (((ut = (U = vt.current[P.page]) == null ? void 0 : U.querySelector(".react-pdf__Page")) == null ? void 0 : ut.offsetHeight) || Of),
                        transition: "top 0.3s ease-out"
                      },
                      children: [
                        /* @__PURE__ */ le("div", { className: "flex justify-between mb-1 text-xs", children: [
                          /* @__PURE__ */ K(
                            "select",
                            {
                              value: P.type || "comment",
                              onChange: (ft) => Ef(P.id, ft.target.value),
                              className: `px-1 py-0.5 rounded text-[10px] font-medium border-none outline-none cursor-pointer ${bm[P.type] || bm.comment}`,
                              children: mm.map((ft) => /* @__PURE__ */ K("option", { value: ft, children: ft }, ft))
                            }
                          ),
                          /* @__PURE__ */ le("div", { className: "flex gap-2 items-center", children: [
                            /* @__PURE__ */ le("span", { className: "text-text-secondary", children: [
                              "p.",
                              P.page
                            ] }),
                            /* @__PURE__ */ K(
                              "button",
                              {
                                className: "border-none bg-transparent text-text-secondary cursor-pointer py-0.5 px-1.5 rounded hover:bg-bg-elevated hover:text-page-text",
                                onClick: () => Sf(P.id),
                                onMouseDown: (ft) => ft.preventDefault(),
                                title: "Resolve comment",
                                children: /* @__PURE__ */ K(Z0, { size: 14 })
                              }
                            )
                          ] })
                        ] }),
                        /* @__PURE__ */ K("div", { className: "text-sm text-page-text mb-2 whitespace-pre-wrap", children: P.text }),
                        /* @__PURE__ */ le("div", { className: "text-xs text-text-secondary border-l-2 border-warning pl-2 italic whitespace-nowrap overflow-hidden text-ellipsis", children: [
                          '"',
                          P.selectedText,
                          '"'
                        ] })
                      ]
                    },
                    P.id
                  );
                })
              ]
            }
          )
        ] })
      }
    )
  ] });
};
function rw(d) {
  const t = d.services.fileSystem;
  function e(i) {
    return tw({ ...i, fileSystem: t });
  }
  e.displayName = "PdfViewer", d.register({
    id: "pdf-plugin",
    canHandle: (i) => !!i.isPdf || i.name.toLowerCase().endsWith(".pdf"),
    priority: 10,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    component: e
  });
}
export {
  rw as init
};
